﻿# List of the servers SP2 needs to be applied.


Set-Location C:

$server_list = @("CSOVDEVSQL18", "CSOVDEVSQL19")

$script_directory = "\\csodevfile1\DBA\AluthwattaM\Projects\DBA\20160920-SP2installAutomation\"
$psExtractorFileName = "SQL2014SP2_InstallAutomation_params.ps1"

$psExtractorLongName = $script_directory + $psExtractorFileName

foreach ($server_name in $server_list) {
    $ps_job = "job_" + $server_name 
    Write-Output $server_name
    Write-Output $psExtractorLongName
    $job = Start-Job -FilePath $psExtractorLongName -Name $ps_job -ArgumentList $server_name
}
