﻿####################################
#  DBA TEAM
#  23/09/2016
####################################

param
(
    [String] $server_name  
)

$log_file = "\\csodevfile1\DBA\AluthwattaM\Projects\DBA\20160920-SP2installAutomation\LogFile_$server_name.txt"

$sp2_installation_path = '\\csodevfile1\DBA\SQL2014\SQL2014SP2\'    
$sp2_installation_file = 'SQLServer2014SP2-KB3171021-x64-ENU.exe'

$destination_path = "\\$server_name\C$\SQL2014\"
$install_file_local_path = $destination_path + $sp2_installation_file


Write-Output "SP2 upgrade process on $server_name"

Add-Content -Path $log_file "Start Time:  $(Get-Date)" 
Add-Content -Path $log_file "SP2 upgrade process on $server_name"

# if SQL2014 folder does not exist, create it.
If(!(test-path $destination_path))
{
    New-Item -ItemType Directory -Force -Path $destination_path 
    Write-Output "C:\SQL2014 folder created"
    Add-Content -Path $log_file "C:\SQL2014 folder created"
}

# if installation file exists skip copying.
If(!(test-path $install_file_local_path))
{
    Write-Output "Copying $sp2_installation_file to C:\SQL2014"
    Add-Content -Path $log_file "Copying $sp2_installation_file to C:\SQL2014"
    robocopy $sp2_installation_path $destination_path $sp2_installation_file 
    Write-Output "File copying complete"
    Add-Content -Path $log_file "File copying complete"
}
else
{
    Write-Output "Intallation file alrady exists at $destination_path"
    Add-Content -Path $log_file "Intallation file alrady exists at $destination_path"
}

# apply the sp2 pack
Write-Output "SP2 installation in progress.."
Add-Content -Path $log_file "Service pack installation started"

#action=Patch/RemovePatch
Invoke-Command -ComputerName $server_name -ScriptBlock {cmd.exe /c 'C:\SQL2014\SQLServer2014SP2-KB3171021-x64-ENU.exe /q /IAcceptSQLServerLicenseTerms /action=Patch /allinstances'} -ErrorVariable errmsg 2>$null
Add-Content -Path $log_file $errmsg    

# Delete the installation file
Remove-Item $install_file_local_path 
Write-Output "Intallation file deleted"
Add-Content -Path $log_file "Intallation file deleted"

Write-Output "SQL 2014 SP2 upgrade on $server_name successfully completed`n"
Add-Content -Path $log_file "Service pack upgrade on $server_name successfully completed"
Add-Content -Path $log_file "End Time:  $(Get-Date)" 

Add-Content -Path $log_file "Restarting computer.." 
Add-Content -Path $log_file "----------------------" 

Restart-Computer -ComputerName $server_name 





