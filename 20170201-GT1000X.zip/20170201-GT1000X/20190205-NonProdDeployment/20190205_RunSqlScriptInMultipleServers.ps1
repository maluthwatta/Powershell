﻿# --------------------------- #
# Manoj Aluthwatta 26/02/2014 #
#-----------------------------#

#Sever List - \\csodevfile1\DBA\AluthwattaM\PowerShell\DataFiles\Databases.txt

Import-Module \\oceania\cts\DEPTDATA\Development\DatabaseAdmins\Development\AluthwattaM\PowerShell\Common_Scripts\Functions.ps1 -Force


$outputCSVfilePath = "Z:\Projects\DBA\20170201-GT1000X\20190205-NonProdDeployment\Output09.csv"

#$outputCSVfilePath = ""



#Get the status of GT1000 & GT1000X
$SQL = 
"
SELECT @@servername As ServerName, 
(SELECT enabled  
from dbo.sysjobs 
where name = 'DBA.GT1000_1') As GT1000,
(SELECT enabled  
from dbo.sysjobs 
where name = 'DBA.GT1000X_LOAD') As X
"


<#


#Get the paths for xe files
$SQL = 
"
SELECT @@servername As ServerName, 
(
SELECT  SUBSTRING(s.command, (CHARINDEX('@filePath = ', s.command) + Len('@filePath = ') + 2)
, CHARINDEX(', @resetFilePath',s.command) - CHARINDEX('@filePath = ', s.command) + Len('@resetFilePath') - 28) As Xpath
from dbo.sysjobs j inner join dbo.sysjobsteps s 
	on s.job_id = j.job_id		
where j.name = 'DBA.GT1000X_LOAD' and s.step_id = 1
) As Xpath
"
#>


$databaseName = "msdb"


$serverListFile = "Z:\PowerShell\DataFiles\Databases.txt"
$serverList = Get-Content $serverListFile


foreach ($server in $serverList)
{
    Write-Output $server
}

Write-Output ''

$response = Read-Host -Prompt 'Run in all above servers? (Y/N)' 
if (($response -eq 'y') -or ($response -eq 'Y'))
{
    
    $output_array = @()
    
    foreach ($server in $serverList)
    {
        try
        { 
            $results = invoke-sqlcmd -query $sql -serverinstance $server -database $databaseName -Verbose -QueryTimeout 300              
            $output_array +=  $results               
            $results | Format-Table -AutoSize     
        }
        catch
        {
            $errorMessage = $_.Exception.Message
            $failedItem = $_.Exception.ItemName
            Write-Output "Error:" $failedItem
            Write-Output $errorMessage
        }
    }

    $conn.Close();

    Write-host 'Output in a single result set:'
    Write-host '------------------------------'

    $output_array | Format-Table -AutoSize 
    
    if ($outputCSVfilePath -ne "")
    {
        #$output_array | Select-Object -Property ServerName, GT1000, X  | Export-Csv –Path $outputCSVfilePath
        $output_array | Export-Csv –Path $outputCSVfilePath
    }
    
}


