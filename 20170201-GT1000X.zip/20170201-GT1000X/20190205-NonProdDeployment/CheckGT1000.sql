select @@servername As ServerName,  enabled As JobEnabled, *
from msdb.dbo.sysjobs 
where name = 'DBA.GT1000_1';


select ServerName

select @@servername As ServerName,  enabled As JobEnabled, *
from dbo.sysjobs 
where name = 'DBA.GT1000_1';




select @@servername As ServerName,  enabled As JobEnabled, *
from dbo.sysjobs 
where name = 'DBA.GT1000X_LOAD';


SELECT @@servername As ServerName, 
(SELECT enabled  
from dbo.sysjobs 
where name = 'DBA.GT1000_1') As GT1000,
(SELECT enabled  
from dbo.sysjobs 
where name = 'DBA.GT1000X_LOAD') As X