﻿Import-Module \\oceania\cts\DEPTDATA\Development\DatabaseAdmins\Development\AluthwattaM\PowerShell\Common_Scripts\Functions.ps1 -Force
# Now you can call common functions locally

$serverName = "MELDVDEVSQL33"

get-DiskVolumes -ComputerName $serverName -Raw | Where-Object {$_.Label -like "*SYS*"} 
