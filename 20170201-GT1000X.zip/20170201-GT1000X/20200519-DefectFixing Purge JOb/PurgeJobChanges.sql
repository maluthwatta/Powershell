select * from [dbo].[IOFrozenStats]
order by RunTime DESC



Select @@SERVERNAME AS ServerName, count(*) AS CountRows
from aaDBA.perf.gt1000
where Start_time < DATEADD(month, -3, GETDATE())




select * from aaDBA.perf.gt1000

USE aaDBA;

SET NOCOUNT ON; 
DECLARE @RowCount INT; 
SET @RowCount = 1;
 
WHILE @RowCount > 0
BEGIN
  BEGIN TRANSACTION;
 
  DELETE TOP (10000) 
    perf.gt1000
    WHERE Start_time < DATEADD(month, -3, GETDATE());
 
  SET @RowCount = @@ROWCOUNT;
 
  COMMIT TRANSACTION;
END



select MIN(start_time) from perf.gt1000

SELECT DATEDIFF(day, (select MIN(start_time) from perf.gt1000), getdate())


USE aaDBA;

SET NOCOUNT ON; 
DECLARE @RowCount INT; 
SET @RowCount = 1;
 
WHILE @RowCount > 0
BEGIN
  BEGIN TRANSACTION;
 
  DELETE TOP (10000) 
    perf.gt1000
    WHERE Start_time < DATEADD(day, -89, GETDATE());
 
  SET @RowCount = @@ROWCOUNT;
 
  COMMIT TRANSACTION;
END



GO

SELECT MIN(Start_time) FROM perf.gt1000
--2020-02-19 04:45:02.9580000

---------------------------------------------



USE aaDBA;

SET NOCOUNT ON; 
DECLARE @RowCount INT
	, @PurgeDate DATETIME
	, @MaxID INT
	, @StartID INT
	, @EndID INT
	, @BatchSize INT;

SELECT @BatchSize = 10000;

IF OBJECT_ID('tempdb..#PurgeList') IS NOT NULL
    DROP TABLE #PurgeList;

CREATE TABLE #PurgeList(gt_id INT);

SELECT @PurgeDate = DATEADD(month, -3, GETDATE());

INSERT INTO #PurgeList(gt_id)
	SELECT gt_id
	FROM perf.gt1000
	WHERE Start_time < @PurgeDate;

CREATE CLUSTERED INDEX TempUsers_PK ON #PurgeList (gt_id);

SELECT @StartID = MIN(gt_id), @MaxID = MAX(gt_id)
FROM #PurgeList;

SELECT @EndID = @StartID + @BatchSize;

WHILE (@StartID <= @MaxID)
BEGIN
	
	;WITH PurgeList AS (
		SELECT gt_id
		FROM #PurgeList
		WHERE gt_id BETWEEN @StartID AND @EndID
	)
	
	DELETE p
	FROM perf.gt1000 p
		INNER JOIN PurgeList pl
			ON pl.gt_id = p.gt_id;

	SET @StartID = @EndID + 1;
	SET @EndID = @EndID + @BatchSize;

END;

DROP TABLE #PurgeList;

GO
---------------------




USE aaDBA;

SET NOCOUNT ON; 
SET QUOTED_IDENTIFIER ON;
DECLARE @RowCount INT, @PurgeDate DATETIME; 
SET @RowCount = 1;

IF OBJECT_ID('tempdb..#PurgeList') IS NOT NULL
    DROP TABLE #PurgeList;

CREATE TABLE #PurgeList(gt_id INT);

SELECT @PurgeDate = DATEADD(month, -3, GETDATE());

INSERT INTO #PurgeList(gt_id)
       SELECT gt_id
       FROM perf.gt1000
       WHERE Start_time < @PurgeDate; 

CREATE CLUSTERED INDEX TempUsers_PK ON #PurgeList (gt_id);

WHILE @RowCount > 0
BEGIN
       DELETE TOP(10000) p
       FROM perf.gt1000 p
              INNER JOIN #PurgeList t 
                     ON t.gt_id = p.gt_id

       SET @RowCount = @@ROWCOUNT
END;

DROP TABLE #PurgeList;

GO
---------------------


USE aaDBA;

SET NOCOUNT ON; 
SET QUOTED_IDENTIFIER ON;
DECLARE @RowCount INT, @PurgeDate DATETIME; 
SET @RowCount = 1;

IF OBJECT_ID('tempdb..#PurgeList') IS NOT NULL
    DROP TABLE #PurgeList;

CREATE TABLE #PurgeList(gt_id INT);

SELECT @PurgeDate = DATEADD(month, -3, GETDATE());

INSERT INTO #PurgeList(gt_id)
       SELECT gt_id
       FROM perf.gt1000
       WHERE Start_time < @PurgeDate; 

CREATE CLUSTERED INDEX TempUsers_PK ON #PurgeList (gt_id);

WHILE @RowCount > 0
BEGIN
       DELETE TOP(10000) p
       FROM perf.gt1000 p
              INNER JOIN #PurgeList t 
                     ON t.gt_id = p.gt_id

       SET @RowCount = @@ROWCOUNT
	   SELECT CAST(@@ROWCOUNT AS VARCHAR)+' rows deleted'
END;

DROP TABLE #PurgeList;

GO
-------------------------------------------



USE aaDBA;

SET NOCOUNT ON; 
SET QUOTED_IDENTIFIER ON;
DECLARE @RowCount INT, @PurgeDate DATETIME; 
SET @RowCount = 1;

IF OBJECT_ID('tempdb..#PurgeList') IS NOT NULL
    DROP TABLE #PurgeList;

CREATE TABLE #PurgeList(gt_id INT);

SELECT @PurgeDate = DATEADD(month, -3, GETDATE());

INSERT INTO #PurgeList(gt_id)
       SELECT gt_id
       FROM perf.gt1000
       WHERE Start_time < @PurgeDate; 

CREATE CLUSTERED INDEX TempPurgeList_PK ON #PurgeList (gt_id);

WHILE @RowCount > 0
BEGIN
       DELETE TOP(10000) p
       FROM perf.gt1000 p
              INNER JOIN #PurgeList t 
                     ON t.gt_id = p.gt_id

       SET @RowCount = @@ROWCOUNT
	   SELECT CAST(@@ROWCOUNT AS VARCHAR)+' rows deleted'
END;

DROP TABLE #PurgeList;

Go
-----------------------------------------



SET NOCOUNT ON; 
SET QUOTED_IDENTIFIER ON;
DECLARE 
	@RowCount INT
	,@PurgeDate DATETIME
	,@ExpectedNbrRows INT
	,@BatchSize INT = 10000
	,@BatchStart INT = 1
	,@BatchEnd INT = 0
	,@TotalRowCount INT = 0
	,@ActualNbrRows INT = 0; 

SET @RowCount = 1;

IF OBJECT_ID('tempdb..#Candidates') IS NOT NULL
    DROP TABLE #Candidates;

CREATE TABLE #Candidates
(
	GtID INT NOT NULL
	,RowID INT NOT NULL
	,PRIMARY KEY CLUSTERED (RowID ASC)
	,UNIQUE (GtID ASC)
);

SELECT @PurgeDate = DATEADD(month, -3, GETDATE());

INSERT INTO #Candidates
(
	GtID
	,RowID
)
SELECT 
	gt_id as GtID
	,RowID = ROW_NUMBER() OVER ( ORDER BY gt_id ASC )
FROM perf.gt1000
WHERE Start_time < @PurgeDate; 

SET @ExpectedNbrRows = @@ROWCOUNT;

SET @BatchEnd = @BatchStart + @BatchSize - 1;

WHILE @BatchStart <= @ExpectedNbrRows
BEGIN
	WITH Candidates AS
	(
		SELECT TOP ( @BatchSize )
			c.GtID
		FROM #Candidates AS c
		WHERE c.RowID between @BatchStart and @BatchEnd
		ORDER BY c.RowID ASC
	)

	DELETE p
	FROM perf.gt1000 p
		INNER JOIN Candidates c
			ON c.GtID = p.gt_id

	SELECT @ActualNbrRows = @@ROWCOUNT
	SELECT @TotalRowCount = @TotalRowCount + @ActualNbrRows;

	SELECT
		@BatchStart = @BatchStart + @BatchSize
		,@BatchEnd = @BatchEnd + @BatchSize
END;

SELECT CAST(@TotalRowCount AS VARCHAR)+' rows deleted'; 