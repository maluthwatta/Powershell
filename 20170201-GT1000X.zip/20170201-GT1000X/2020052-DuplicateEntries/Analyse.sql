--EXECUTE perf.p_xe_load_gt1000 @filePath = '<<BACKUP_FILE_PATH>>', @resetFilePath = 0


--sp_helptext 'perf.p_xe_load_gt1000'


--select * from perf.gt1000




--CREATE PROCEDURE perf.p_xe_load_gt1000
	DECLARE 

	@filePath NVARCHAR (260) = 'G:\GT1000X\'
	,@resetFilePath bit = 0



DECLARE
	@fileName NVARCHAR(260) = @filePath,
	@source_file_name nvarchar(256),
	@source_file_offset	bigint;

IF RIGHT(@fileName,1) <> '\' SET @fileName += '\';
	SET @fileName = @fileName + 'GT1000*.xel'

--Read all records from all matching files into a Temp table for speed.
IF OBJECT_ID('tempdb..#xEventsTemp') IS NOT NULL  
	DROP TABLE #xEventsTemp;

IF OBJECT_ID('tempdb..#xEventsTempData') IS NOT NULL  
	DROP TABLE #xEventsTempData;


---- If file path is changed then reset the file name & offset. 
--IF @resetFilePath = 1
--BEGIN
--	SET @source_file_name = NULL;
--	SET	@source_file_offset = NULL;
--END
--ELSE
BEGIN
	--Get the last offset value and file name written to perf.GT1000 table
	--SELECT TOP 1 @source_file_name = source_file_name,  @source_file_offset = source_file_offset
	SELECT @source_file_name = 'G:\GT1000X\GT1000_0_132365485007320000.xel',  @source_file_offset = 32718336
	--FROM perf.GT1000
	--ORDER BY gt_id DESC
END


SELECT 
	object_name	
	,CAST(event_data AS XML) AS event_data_XML
	,file_name
	,file_offset
INTO 
	#xEventsTemp 
FROM 
	sys.fn_xe_file_target_read_file(
		@fileName
		,NULL
		,@source_file_name
		,@source_file_offset);

IF @resetFilePath = 1
BEGIN
	/*
	Remove from the Temp table all the ones we have loaded previously.  
	*/
	DELETE xt
	FROM #xEventsTemp AS xt
	INNER JOIN perf.GT1000 AS gt
		ON xt.file_name = gt.Source_File_Name
		AND xt.File_Offset = gt.Source_File_Offset;
END

-- Load data into the temp table
SELECT																								
	COALESCE(event_data_XML.value ('(/event/action[@name=''database_id'']/value)[1]', 'INT'),0) AS database_id
	,COALESCE(DB_NAME(event_data_XML.value ('(/event/action[@name=''database_id'']/value)[1]', 'INT')),'n/a') AS database_name	
	,event_data_XML.value ('(/event/action[@name=''session_id'']/value)[1]', 'INT') AS session_id	
	,event_data_XML.value ('(/event/action[@name=''server_principal_name'']/value)[1]', 'NVARCHAR(128)')						AS server_principal_name
	,COALESCE(event_data_XML.value ('(/event/action[@name=''client_hostname'']/value)[1]', 'NVARCHAR(128)'),'unknown') AS client_hostname
	,COALESCE(event_data_XML.value ('(/event/action[@name=''client_app_name'']/value)[1]', 'NVARCHAR(128)'),'unknown') AS client_app_name	
	,CAST(SWITCHOFFSET(TODATETIMEOFFSET(event_data_XML.value ('(/event/action[@name=''collect_system_time'']/value)[1]', 'DATETIME2'),'+00:00'),DATEPART(tz,SYSDATETIMEOFFSET())) AS DateTime2)	AS end_time  -- Change to local time from UTC																					
								
	,COALESCE((event_data_XML.value ('(/event/data[@name=''duration'']/value)[1]', 'BIGINT')/1000),0) AS duration -- Change to milliseconds	
	,event_data_XML.value ('(/event/data[@name=''logical_reads'']/value)[1]', 'BIGINT') 						AS logical_reads
	,event_data_XML.value ('(/event/data[@name=''physical_reads'']/value)[1]', 'BIGINT') 						AS physical_reads
	,event_data_XML.value ('(/event/data[@name=''writes'']/value)[1]', 'BIGINT') 								AS Writes
	,event_data_XML.value ('(/event/data[@name=''cpu_time'']/value)[1]', 'BIGINT')/1000 						AS cpu_time -- Change to milliseconds on SQL2012
	,COALESCE(CASE WHEN DataLength(event_data_XML.value ('(/event/action[@name=''sql_text'']/value)[1]', 'NVARCHAR(MAX)')) > 8000 THEN 
			CAST('TRUNCATED: ' AS NVARCHAR(MAX)) + SUBSTRING(event_data_XML.value ('(/event/action[@name=''sql_text'']/value)[1]', 'NVARCHAR(MAX)'), 1, 3089)
		ELSE 
			event_data_XML.value ('(/event/action[@name=''sql_text'']/value)[1]', 'NVARCHAR(MAX)')
	 END,'empty') AS sql_text
	,COALESCE(CASE WHEN DataLength(event_data_XML.value ('(/event/data[@name=''statement'']/value)[1]', 'NVARCHAR(MAX)')) > 8000 THEN 
			CAST('TRUNCATED: ' AS NVARCHAR(MAX)) + SUBSTRING(event_data_XML.value ('(/event/data[@name=''statement'']/value)[1]', 'NVARCHAR(MAX)'), 1, 3089)
		ELSE 
			event_data_XML.value ('(/event/data[@name=''statement'']/value)[1]', 'NVARCHAR(MAX)')
	 END,'empty') AS sql_statement
	,n.value ('(@name)[1]', 'VARCHAR(18)') 																		AS event_class
	,File_Name 																									AS Source_File_Name
	,File_Offset 																								AS Source_File_Offset

	,event_data_XML.value ('(/event/action[@name=''offset'']/value)[1]', 'INT')					AS offset
	,event_data_XML.value ('(/event/action[@name=''offset_end'']/value)[1]', 'INT')					AS offset_end

	,event_data_XML.value ('(/event/action[@name=''nt_username'']/value)[1]', 'NVARCHAR(128)')					AS ntusername
	,event_data_XML.value ('(/event/action[@name=''client_pid'']/value)[1]', 'INT')								AS client_pid	
	,event_data_XML.value ('(/event/action[@name=''server_instance_name'']/value)[1]', 'NVARCHAR(128)')			AS server_instance_name
INTO #xEventsTempData
FROM #xEventsTemp AS xE
	CROSS APPLY event_data_XML.nodes('event') AS q(n)
WHERE COALESCE((event_data_XML.value ('(/event/data[@name=''duration'']/value)[1]', 'BIGINT')/1000),0) < 214748364 /* Per change #005 in change log above*/
ORDER BY xE.file_name, xE.file_offset

----Update the GT1000 table
--INSERT perf.GT1000
--(
--    database_id 
--	,database_name	
--	,session_id
--	,server_principal_name�
--	,client_hostname
--	,client_app_name		
--	,end_time
--	,duration
--	,logical_reads
--	,physical_reads 
--	,writes
--	,cpu_time 	
--	,sql_text
--	,event_class
--	,Source_File_Name
--	,Source_File_Offset
--	,nt_username
--	,client_pid
--	,server_instance_name
--)
SELECT
    database_id 
	,[database_name]
	,session_id
	,server_principal_name�
	,client_hostname
	,client_app_name		
	,end_time
	,duration
	,logical_reads
	,physical_reads 
	,writes
	,cpu_time 	
	,(CASE WHEN sql_text = 'empty' THEN sql_statement ELSE sql_text END) AS sql_text
	,event_class
	,Source_File_Name
	,Source_File_Offset
	,offset
	,offset_end
	,ntusername
	,client_pid
	,server_instance_name
FROM #xEventsTempData
	
--DROP TABLE #xEventsTemp;

/*
SELECT * FROM #xEventsTemp 
where file_name = 'G:\GT1000X\GT1000_0_132286885099260000.xel'
order by file_offset

SELECT * FROM #xEventsTempData



*/


SELECT logical_reads, physical_reads, end_time FROM #xEventsTempData
group by logical_reads, physical_reads, end_time
having count(1) > 1
/*
2020-03-14 01:20:03.7230000
2020-03-21 04:50:09.1710000
2020-03-14 00:00:15.1400000
2020-03-21 04:50:13.5490000
2020-03-20 05:00:08.0660000
2020-05-20 04:55:04.7360000
2020-03-20 05:00:06.5510000
2020-03-16 05:00:09.6710000
*/



select * from #xEventsTempData where end_time = '2020-05-20 04:55:04.7360000'

G:\GT1000X\GT1000_0_132341294566310000.xel


SELECT * FROM #xEventsTempData where Source_File_Offset = 3064832

SELECT * FROM #xEventsTemp where File_Offset = 5330944





----------------------
SELECT
 --   database_id 
	--,[database_name]
	--,session_id
	--,server_principal_name�
	--,client_hostname
	--,client_app_name		
	end_time
	,duration
	,logical_reads
	,physical_reads 
	,writes
	,cpu_time 	
	,(CASE WHEN sql_text = 'empty' THEN sql_statement ELSE sql_text END) AS sql_text
	--,event_class
	--,Source_File_Name
	,Source_File_Offset
	--,ntusername
	--,client_pid
	--,server_instance_name
FROM #xEventsTempData
ORDER BY Source_File_Offset, end_time





-----------------------




use aaDBA
go

select database_id, session_id, nt_username, client_hostname, client_app_name, client_pid, server_instance_name, server_principal_name, start_time, end_time, duration, logical_reads, physical_reads, writes, cpu_time, event_class--, sql_text
from perf.gt1000
group by database_id, session_id, nt_username, client_hostname, client_app_name, client_pid, server_instance_name, server_principal_name, start_time, end_time, duration, logical_reads, physical_reads, writes, cpu_time, event_class--, sql_text
having count(1) > 1 and end_time > '2020/06/30 02:50 PM'
order by start_time desc    


use aaDBA;
select server_instance_name As ServerName, count(1) As [Count]
from perf.gt1000
group by database_id, session_id, nt_username, client_hostname, client_app_name, client_pid, server_instance_name, server_principal_name, start_time, end_time, duration, logical_reads, physical_reads, writes, cpu_time, event_class--, sql_text
having count(1) > 1 and end_time > '2020/06/30 02:50 PM'
order by start_time desc    ;
