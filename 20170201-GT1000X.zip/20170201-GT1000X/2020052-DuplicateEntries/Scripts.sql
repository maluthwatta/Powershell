alter table [perf].[gt1000] add date_inserted  datetime not null default getdate();





select * from perf.gt1000
order by start_time desc

select session_id, duration, start_time 
from perf.gt1000
group by session_id, duration, start_time 
having count(1) > 1
order by start_time desc


select * from perf.gt1000 where start_time = '2020-06-22 08:15:03.6580000'


select * from perf.gt1000 where start_time > '2020-06-22 08:10:03.6580000'
order by gt_id
