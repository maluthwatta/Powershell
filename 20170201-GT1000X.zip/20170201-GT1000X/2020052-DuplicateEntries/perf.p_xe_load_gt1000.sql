
DROP PROCEDURE IF EXISTS [perf].[p_xe_load_gt1000]
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [perf].[p_xe_load_gt1000]
	@filePath NVARCHAR (260)
	,@resetFilePath bit = 0
AS

/*

	Name:				perf.p_xe_load_gt1000
	Creation Date:		05/07/2013
 	Written by:			Gordon Downie

 	Purpose:			
 	
 	Loads all outstanding records that the GT1000X session
	has written to file into the GT1000X table.
	
	Loads all the records in all Events files into a table
	and then discards those already loaded.
	
	Functionality to start reading from a certain point in a certain file
	exists in to the load function, but does not work properly. 
	In SQL2008 there is a bug so it does not work with multiple files at all.
	In SQL2012 it throws an error if the file you specify does not exist.
	So for the moment I have skipped it.

	Usage:

		EXECUTE dbo.p_DBA_xEvents_LoadGT1000XToTable	@filePath = 'H:\Backups_01\SQLTrace'

Updates:
Change No.	Date 			Author 			Purpose
001			29/10/2015		Paul Jenkins	Tweaked for SQL2014
002			09/03/2017		Manoj A			Added new fields to support SSAS
003			20/04/2017		Manoj A			Use the offset to get events from the last entry on perf.GT1000
004			24/04/2017		Manoj A			Added @resetFilePath, to facilitate filepath changes
005			20/06/2017		Manoj A			Added the filter to remove duration > 214748364 to fix arithmatic overflaw issue
											This will ignore events running for greater than 214748364ms
006			29/05/2020		Manoj A			Fixed duplicate record issue
*/

SET NOCOUNT ON;

DECLARE
	@fileName NVARCHAR(260) = @filePath,
	@source_file_name nvarchar(256),
	@source_file_offset	bigint,
	@last_entry_end_time datetime;

IF RIGHT(@fileName,1) <> '\' SET @fileName += '\';
	SET @fileName = @fileName + 'GT1000*.xel'

--Read all records from all matching files into a Temp table for speed.
IF OBJECT_ID('tempdb..#xEventsTemp') IS NOT NULL  
	DROP TABLE #xEventsTemp;

IF OBJECT_ID('tempdb..#xEventsTempData') IS NOT NULL  
	DROP TABLE #xEventsTempData;


-- If file path is changed then reset the file name & offset. 
IF @resetFilePath = 1
BEGIN
	SET @source_file_name = NULL;
	SET	@source_file_offset = NULL;
END
ELSE
BEGIN
	--Get the last offset value, file name and last entry time written to perf.GT1000 table
	SELECT TOP 1 @source_file_name = source_file_name
		,@source_file_offset = source_file_offset
		,@last_entry_end_time = end_time 
	FROM perf.GT1000
	ORDER BY gt_id DESC
END


SELECT 
	CAST(event_data AS XML) AS event_data_XML
	,file_name
	,file_offset
INTO 
	#xEventsTemp 
FROM 
	sys.fn_xe_file_target_read_file(
		@fileName
		,NULL
		,@source_file_name
		,@source_file_offset);

IF @resetFilePath = 1
BEGIN
	/*
	Remove from the Temp table all the ones we have loaded previously.  
	*/
	DELETE xt
	FROM #xEventsTemp AS xt
	INNER JOIN perf.GT1000 AS gt
		ON xt.file_name = gt.Source_File_Name
		AND xt.File_Offset = gt.Source_File_Offset;
END

-- Load data into the temp table
SELECT																								
	COALESCE(event_data_XML.value ('(/event/action[@name=''database_id'']/value)[1]', 'INT'),0) AS database_id
	,COALESCE(DB_NAME(event_data_XML.value ('(/event/action[@name=''database_id'']/value)[1]', 'INT')),'n/a') AS database_name	
	,event_data_XML.value ('(/event/action[@name=''session_id'']/value)[1]', 'INT') AS session_id	
	,event_data_XML.value ('(/event/action[@name=''server_principal_name'']/value)[1]', 'NVARCHAR(128)')						AS server_principal_name
	,COALESCE(event_data_XML.value ('(/event/action[@name=''client_hostname'']/value)[1]', 'NVARCHAR(128)'),'unknown') AS client_hostname
	,COALESCE(event_data_XML.value ('(/event/action[@name=''client_app_name'']/value)[1]', 'NVARCHAR(128)'),'unknown') AS client_app_name	
	,CAST(SWITCHOFFSET(TODATETIMEOFFSET(event_data_XML.value ('(/event/action[@name=''collect_system_time'']/value)[1]', 'DATETIME2'),'+00:00'),DATEPART(tz,SYSDATETIMEOFFSET())) AS DateTime2)	AS end_time  -- Change to local time from UTC																													
	,COALESCE((event_data_XML.value ('(/event/data[@name=''duration'']/value)[1]', 'BIGINT')/1000),0) AS duration -- Change to milliseconds	
	,event_data_XML.value ('(/event/data[@name=''logical_reads'']/value)[1]', 'BIGINT') 						AS logical_reads
	,event_data_XML.value ('(/event/data[@name=''physical_reads'']/value)[1]', 'BIGINT') 						AS physical_reads
	,event_data_XML.value ('(/event/data[@name=''writes'']/value)[1]', 'BIGINT') 								AS Writes
	,event_data_XML.value ('(/event/data[@name=''cpu_time'']/value)[1]', 'BIGINT')/1000 						AS cpu_time -- Change to milliseconds on SQL2012
	,COALESCE(CASE WHEN DataLength(event_data_XML.value ('(/event/action[@name=''sql_text'']/value)[1]', 'NVARCHAR(MAX)')) > 8000 THEN 
			CAST('TRUNCATED: ' AS NVARCHAR(MAX)) + SUBSTRING(event_data_XML.value ('(/event/action[@name=''sql_text'']/value)[1]', 'NVARCHAR(MAX)'), 1, 3089)
		ELSE 
			event_data_XML.value ('(/event/action[@name=''sql_text'']/value)[1]', 'NVARCHAR(MAX)')
	 END,'empty') AS sql_text
	,COALESCE(CASE WHEN DataLength(event_data_XML.value ('(/event/data[@name=''statement'']/value)[1]', 'NVARCHAR(MAX)')) > 8000 THEN 
			CAST('TRUNCATED: ' AS NVARCHAR(MAX)) + SUBSTRING(event_data_XML.value ('(/event/data[@name=''statement'']/value)[1]', 'NVARCHAR(MAX)'), 1, 3089)
		ELSE 
			event_data_XML.value ('(/event/data[@name=''statement'']/value)[1]', 'NVARCHAR(MAX)')
	 END,'empty') AS sql_statement
	,n.value ('(@name)[1]', 'VARCHAR(18)') 																		AS event_class
	,File_Name 																									AS Source_File_Name
	,File_Offset 																								AS Source_File_Offset
	,event_data_XML.value ('(/event/action[@name=''nt_username'']/value)[1]', 'NVARCHAR(128)')					AS ntusername
	,event_data_XML.value ('(/event/action[@name=''client_pid'']/value)[1]', 'INT')								AS client_pid	
	,event_data_XML.value ('(/event/action[@name=''server_instance_name'']/value)[1]', 'NVARCHAR(128)')			AS server_instance_name
INTO #xEventsTempData
FROM #xEventsTemp AS xE
	CROSS APPLY event_data_XML.nodes('event') AS q(n)
WHERE COALESCE((event_data_XML.value ('(/event/data[@name=''duration'']/value)[1]', 'BIGINT')/1000),0) < 214748364 /* Per change #005 in change log above*/
ORDER BY xE.file_name, xE.file_offset

--Update the GT1000 table
INSERT perf.GT1000
(
    database_id 
	,database_name	
	,session_id
	,server_principal_name�
	,client_hostname
	,client_app_name		
	,end_time
	,duration
	,logical_reads
	,physical_reads 
	,writes
	,cpu_time 	
	,sql_text
	,event_class
	,Source_File_Name
	,Source_File_Offset
	,nt_username
	,client_pid
	,server_instance_name
)
SELECT
    database_id 
	,[database_name]
	,session_id
	,server_principal_name�
	,client_hostname
	,client_app_name		
	,end_time
	,duration
	,logical_reads
	,physical_reads 
	,writes
	,cpu_time 	
	,(CASE WHEN sql_text = 'empty' THEN sql_statement ELSE sql_text END) AS sql_text
	,event_class
	,Source_File_Name
	,Source_File_Offset
	,ntusername
	,client_pid
	,server_instance_name
FROM #xEventsTempData
WHERE end_time > @last_entry_end_time
ORDER BY Source_File_Offset, end_time
	
DROP TABLE #xEventsTemp;

GO


