﻿# --------------------------- #
# Manoj Aluthwatta 24/03/2017 #
#-----------------------------#


$ServerName = 'CSOVUATSQL15'

$ScriptPath = "\\oceania\CTS\DEPTDATA\Development\DatabaseAdmins\Development\AluthwattaM\Projects\DBA\20170201-GT1000X\TFS_LatestScripts\Scripts"

$SqlScriptFolder = $ScriptPath + "\SQL\"
$AgentJobFolder = $ScriptPath + "\AgentJobs\"


$Server = New-Object ("Microsoft.SqlServer.Management.Smo.Server") $ServerName
$BackupDirectory = $Server.Settings.BackupDirectory

$GT1000Xdir = $BackupDirectory + '\GT1000X'


# Create GT1000X folder if it does not exist
If(!(test-path $GT1000Xdir))
{
    New-Item -ItemType Directory -Force -Path $GT1000Xdir 
    write-host "Folder $GT1000Xdir created"
}

$FileList = Get-ChildItem -Path $SqlScriptFolder –File


foreach ($Sqlfile in $FileList)
{
    $SqlFileName = $SqlScriptFolder + $Sqlfile
    write-host $SqlFileName
    try
    {
        Invoke-Sqlcmd -InputFile $SqlFileName -ServerInstance $ServerName -database "aaDBA" -ErrorAction Stop -Verbose -QueryTimeout 1800 # 30min

    }
    catch
    {
        write-host "Error: $($_.Exception.Message)" -ForegroundColor Red         
    }
}


$AgentJobSqlFileList = Get-ChildItem -Path $AgentJobFolder –File
foreach ($SqlAgentfile in $AgentJobSqlFileList)
{
    $SqlAgentFileName = $AgentJobFolder + $SqlAgentfile
    write-host $SqlAgentFileName
    try
    {        
        $AgentJobSql = Get-Content $SqlAgentFileName
        $AgentJobSql = [string]($AgentJobSql -replace "<<BACKUP_FILE_PATH>>", $BackupDirectory )
        Invoke-Sqlcmd -Query $AgentJobSql -ServerInstance $ServerName -database "msdb" -ErrorAction Stop -Verbose -QueryTimeout 1800

    }
    catch
    {
        write-host "Error: $($_.Exception.Message)" -ForegroundColor Red         
    }
}


#Run the agent job to create the 
Invoke-Sqlcmd -Query "exec sp_start_job 'DBA.GT1000X_CREATE'" -ServerInstance $ServerName -database "msdb" -ErrorAction Stop -Verbose -QueryTimeout 1800
