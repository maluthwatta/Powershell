SELECT gt_id, database_id, database_name, client_hostname, client_app_name, server_principal_name, start_time, duration, logical_reads,	physical_reads,	writes, cpu_time, sql_text
FROM perf.GT1000 
WHERE start_time > DATEADD(WEEK, -1, GETDATE())



SELECT *
FROM perf.GT1000 
WHERE start_time > DATEADD(WEEK, -1, GETDATE())



SELECT *
FROM perf.GT1000 
WHERE start_time > DATEADD(DAY, -7, GETDATE())