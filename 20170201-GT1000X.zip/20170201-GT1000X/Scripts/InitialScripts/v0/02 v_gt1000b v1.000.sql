USE aaDBA;
GO

IF EXISTS (SELECT * FROM sys.views WHERE name = 'v_gt1000b' AND schema_id = SCHEMA_ID('perf'))
	DROP VIEW perf.v_gt1000b;
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE VIEW perf.v_gt1000b
AS

/*
	Name:				perf.v_gt1000b
	Creation Date:		30/10/2015
 	Written by:			Paul Jenkins
									
 	Purpose:			
 	
	Provides a basic view of the GT1000 data.
	 						
	Usage:
	
	SELECT * FROM perf.v_gt1000;
	
Updates:
Change No.	Date 			Author 			Purpose

*/


	SELECT
		database_name
		,username
		,CAST(start_time AS SMALLDATETIME) AS start_time
		,CAST(end_time AS SMALLDATETIME) AS end_time
		,(((Duration/1000) % 86400) / 3600) AS hours
		,(((Duration/1000) % 3600) / 60) AS minutes
		,((Duration/1000) % 60) AS seconds
		,(logical_reads + physical_reads) AS reads
		,writes		
		,cpu_time AS cpu_time_ms
		,sql_text
	FROM perf.gt1000 WITH (NOLOCK);

GO

