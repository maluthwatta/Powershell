USE aaDBA;
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'p_get_pvt_gt1000_month' AND schema_id = SCHEMA_ID('perf'))
	DROP PROCEDURE perf.p_get_pvt_gt1000_month
GO


CREATE PROCEDURE perf.p_get_pvt_gt1000_month	
	@date SMALLDATETIME = NULL
AS

/*

	Name:				perf.p_get_pvt_gt1000_month
	Creation Date:		07/07/2015
 	Written by:			Gordon Downie

 	Purpose:			
 	
	Gets pivoted GT1000 data across the month.

	Usage:

	EXECUTE perf.p_get_pvt_gt1000_month 		

Updates:
Change No.	Date 			Author 			Purpose
001			04/11/2015		Paul Jenkins	Converted to stored procedure
*/

SET NOCOUNT ON;SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
SET NOCOUNT ON;

IF (@date IS NULL)
	SET @date = GETDATE();

	SELECT 
		CAST(DATEADD(WEEK, [Week] - 1,DATEADD(dd, 1 - DATEPART(WEEKDAY, '1/1/' + CONVERT(VARCHAR(4),DATEPART(Year, GETDATE()))), '1/1/' + CONVERT(VARCHAR(4),DATEPART(Year, GETDATE())))) AS DATE) 
			 as WeekCommencing
		,[1] as Sunday
		,[2] as Monday
		,[3] as Tuesday
		,[4] as Wednesday
		,[5] as Thursday
		,[6] as Friday
		,[7] as Saturday
	FROM 
	(
		SELECT 
			start_time
			,DATEPART(WEEKDAY, start_time) AS [Day]
			,DATEPART(WEEK, start_time) AS [Week]
		FROM 
			perf.v_gt1000b WITH (NOLOCK)
		WHERE
			start_time BETWEEN
				DATEADD(MONTH,DATEDIFF(MONTH,0,@date),0) --fist day of month
				AND
				DATEADD(MONTH,DATEDIFF(MONTH,0,@date)+1,0)-1 --last day of month
	) AS SourceTable
	PIVOT 
	(
		COUNT(start_time)
		FOR [Day]
		IN ([1],[2],[3],[4],[5],[6],[7])
	) AS PivotTable
	ORDER BY 
		[Week] DESC;
