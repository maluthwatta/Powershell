USE aaDBA;
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'p_get_pvt_gt1000_hour' AND schema_id = SCHEMA_ID('perf'))
	DROP PROCEDURE perf.p_get_pvt_gt1000_hour
GO


CREATE PROCEDURE perf.p_get_pvt_gt1000_hour	
	@startTime SMALLDATETIME
	,@endTime SMALLDATETIME
	,@databaseName NVARCHAR(128) = NULL
AS

/*

	Name:				perf.p_get_pvt_gt1000_month
	Creation Date:		07/07/2015
 	Written by:			Gordon Downie

 	Purpose:			
 	
	Gets pivoted GT1000 data as hours between two start dates
	~ useful for showing increased/decreased activity

	Usage:

	EXECUTE perf.p_get_pvt_gt1000_hour	
				@startTime = '2015-11-01'
				,@endTime = '2015-11-04'
				,@databaseName = 'aaDBA';

Updates:
Change No.	Date 			Author 			Purpose
001			04/11/2015		Paul Jenkins	Converted to stored procedure
*/

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
SET NOCOUNT ON;

IF (@endTime <= @startTime)
	SET @endTime = DATEADD(HOUR,1,@startTime);

IF (@databaseName IS NULL)
	SET @databaseName = '%'
ELSE
	SET @databaseName = @databaseName + '%';


	SELECT *		
	FROM 
	(
		SELECT 
			start_time
			,[Hour] = DATEPART(HOUR, start_time)
			,[Date] = CONVERT(CHAR(10), start_time, 120)
		FROM perf.v_gt1000b WITH (NOLOCK)
		WHERE
			start_time BETWEEN
				@startTime
				AND
				@endTime
		AND	
			database_name LIKE @databaseName
		
		) AS SourceTable
		PIVOT 
		(
			COUNT(start_time)
			FOR [Hour]
			IN ([0],[1],[2],[3],[4],[5],[6],[7],[8],[9],[10],[11],[12],[13],[14],[15],[16],[17],[18],[19],[20],[21],[22],[23] )
		) 
		AS PivotTable
	ORDER BY 
		[Date] DESC;
