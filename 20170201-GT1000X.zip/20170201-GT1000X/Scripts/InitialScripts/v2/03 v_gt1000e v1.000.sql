USE aaDBA;
GO

IF EXISTS (SELECT * FROM sys.views WHERE name = 'v_gt1000e' AND schema_id = SCHEMA_ID('perf'))
	DROP VIEW perf.v_gt1000e;
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE VIEW perf.v_gt1000e
AS

/*
	Name:				perf.v_gt1000e
	Creation Date:		30/10/2015
 	Written by:			Paul Jenkins
									
 	Purpose:			
 	
	Provides a enhanced view of the GT1000 data.
	 						
	Usage:
	
	SELECT * FROM perf.v_gt1000;
	
Updates:
Change No.	Date 			Author 			Purpose

*/


	SELECT
		gt_id
		,database_name
		,session_id
		,nt_username
		,CAST(start_time AS DATETIME) AS start_time
		,CAST(end_time AS DATETIME) AS end_time
		,duration AS duration_ms
		,(((Duration/1000) % 86400) / 3600) AS hours
		,(((Duration/1000) % 3600) / 60) AS minutes
		,((Duration/1000) % 60) AS seconds
		,logical_reads
		,physical_reads
		,writes
		,cpu_time AS cpu_time_ms
		,sql_text
		,event_class
		,client_hostname
		,client_app_name
	FROM perf.gt1000 WITH (NOLOCK);

GO

