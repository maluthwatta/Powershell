USE aaDBA;
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'p_xe_create_gt1000' AND schema_id = SCHEMA_ID('perf'))
	DROP PROCEDURE perf.p_xe_create_gt1000;
GO


CREATE PROCEDURE perf.p_xe_create_gt1000
	@filePath NVARCHAR (260)
	,@duration INT = 1000000
	,@max_file_size INT = 1024 --MB
	,@max_rollover_files INT = 5
	,@max_memory INT = 4 -- MB
	,@max_dispatch_latency INT = 30 --seconds
	,@max_event_size INT = 0 --MB
AS

/*
	Name:				perf.p_xe_create_gt1000
	Creation Date:		05/07/2013
 	Written by:			Gordon Downie
									
 	Purpose:			
 	
 	Creates a new Extended Events session to capture all queries
	taking longer than 1 second. - GT1000X (even though it is in microseconds
	rather than milliseconds these days).

	Captured data is written to file.

	If the session exists is stops it and deletes it first, so any existing
	capture files are preserved.
	 						
	Usage:
	
		EXECUTE perf.p_xe_create_gt1000 @v_FileName = 'H:\Backups_01\SQLTrace'

	The session will produce files GT1000*.xel with a unique (to the second) 
	time based identifier added to the name e.g.
		GT1000_0_130174933173890000.xel
	
Updates:
Change No.	Date 			Author 			Purpose
001			29/10/2015		Paul Jenkins	Tweaked for SQL2014
*/

SET NOCOUNT ON;


DECLARE
	@v_SQL NVARCHAR(MAX)
	,@v_FileName NVARCHAR(260) = 'GT1000.xel';

IF RIGHT(@filePath,1) <> '\'
	SET @filePath += '\';

SET @v_FileName = @filePath + @v_FileName;

IF EXISTS (SELECT * FROM sys.dm_xe_sessions WHERE name = 'GT1000') 
	ALTER EVENT SESSION [GT1000] ON SERVER STATE = Stop;

IF EXISTS (SELECT * FROM sys.server_event_sessions WHERE name = 'GT1000') 
	DROP EVENT SESSION [GT1000] ON SERVER;

SET @v_SQL = N'
CREATE EVENT SESSION [GT1000] ON SERVER 
ADD EVENT 
	sqlserver.rpc_completed (
		ACTION(
		sqlserver.database_id
		,sqlserver.client_hostname
		,sqlserver.client_app_name		
		,sqlserver.client_pid
		,sqlserver.nt_username
		,sqlserver.server_principal_name
		,sqlserver.server_instance_name
		,sqlserver.session_id
		,sqlserver.sql_text
		,package0.collect_system_time
		)
    WHERE 
		([duration]>=(' + CAST(@duration AS NVARCHAR(12)) + N'))),
ADD EVENT 
	sqlserver.sql_batch_completed (
		ACTION(
		sqlserver.database_id
		,sqlserver.client_app_name
		,sqlserver.client_hostname
		,sqlserver.client_pid
		,sqlserver.nt_username
		,sqlserver.server_principal_name
		,sqlserver.server_instance_name
		,sqlserver.session_id
		,sqlserver.sql_text
		,package0.collect_system_time
		)
    WHERE 
		([duration]>=(' + CAST(@duration AS NVARCHAR(12)) + N'))) 
ADD TARGET 
	package0.event_file (SET filename=' + NCHAR(39) + @v_FileName + NCHAR(39) + ', max_file_size=('+CAST(@max_file_size AS NVARCHAR(12))+'), max_rollover_files=('+CAST(@max_rollover_files AS NVARCHAR(12))+'))
WITH (
		MAX_MEMORY= '+CAST(@max_memory AS NVARCHAR(12))+' MB
		,EVENT_RETENTION_MODE=ALLOW_SINGLE_EVENT_LOSS
		,MAX_DISPATCH_LATENCY= '+CAST(@max_dispatch_latency AS NVARCHAR(12))+' seconds
		,MAX_EVENT_SIZE='+CAST(@max_event_size AS NVARCHAR(12))+' MB
		,MEMORY_PARTITION_MODE=NONE
		,TRACK_CAUSALITY=OFF
		,STARTUP_STATE=ON
		);';

EXECUTE sp_executesql @stmt = @v_SQL;


IF NOT EXISTS (SELECT * FROM sys.dm_xe_sessions WHERE name = 'GT1000') 
	ALTER EVENT SESSION [GT1000] ON SERVER STATE = Start;


GO


