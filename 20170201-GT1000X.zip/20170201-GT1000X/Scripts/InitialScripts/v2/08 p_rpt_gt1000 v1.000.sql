USE aaDBA;
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

IF EXISTS (SELECT * FROM sys.procedures WHERE name = 'p_rpt_gt1000' AND schema_id = SCHEMA_ID('perf'))
	DROP PROCEDURE perf.p_rpt_gt1000
GO


CREATE PROCEDURE perf.p_rpt_gt1000
	@databaseName NVARCHAR(128) = NULL
	,@timeStart SMALLDATETIME
	,@timeEnd SMALLDATETIME
	,@excelFormat BIT = 1	
	,@debug BIT = 0
AS

/*
	Name:				perf.p_rpt_gt1000
	Creation Date:		30/10/2015
 	Written by:			Paul Jenkins
									
 	Purpose:			
 	
	Reports GT1000 data based on critiera when this data is intended or destined
	for clients/customers.

	It provides a consistent format.

	Sometimes when copying dates and text into Excel the formating goes awry

	To combat this the dates be surrounded by # and white space
	characters are stripped from the sql text

	This will mean the dates are copied without issue (although you still
	have to do a find+replace within excel to remove the #).

	
	 						
	Usage:
	

	
Updates:
Change No.	Date 			Author 			Purpose

*/

SET TRANSACTION ISOLATION LEVEL READ UNCOMMITTED;
SET NOCOUNT ON;


DECLARE
	@v_SQLCMD NVARCHAR(MAX);

IF (@databaseName IS NULL)
	SET @databaseName = '%'
ELSE
	SET @databaseName = @databaseName + '%';


SET @v_SQLCMD = N'
DECLARE
	@v_TAB CHAR(1) = CHAR(9)
	,@v_Space CHAR(1) = CHAR(32)
	,@v_NewLineChar1 CHAR(2) = CHAR(13) + CHAR(10)
	,@v_NewLineChar2 CHAR(1) = CHAR(13)
	,@v_NewLineChar3 CHAR(2) = CHAR(10) + CHAR(13)
	,@v_NewLineChar4 CHAR(1)= CHAR(10)
	,@v_Excel BIT = ' + CAST(@excelFormat AS NCHAR(1)) + ';

SELECT
	database_name
	,nt_username
	,CASE @v_Excel
		WHEN 1 THEN ''#'' + CONVERT(CHAR(20),start_time,120) + ''#''
		ELSE CONVERT(NCHAR(20),start_time,120)
		END AS start_time
	,CASE @v_Excel
		WHEN 1 THEN ''#'' + CONVERT(CHAR(20),end_time,120) + ''#''
		ELSE CONVERT(NCHAR(20),end_time,120)
		END	AS end_time
	--,duration_ms
	,hours
	,minutes
	,seconds
	,logical_reads
	,physical_reads
	,writes
	,cpu_time_ms	
	,LTRIM(RTRIM(REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(sql_text,@v_NewLineChar1,@v_Space), @v_NewLineChar2,@v_Space),@v_NewLineChar3,@v_Space),@v_NewLineChar4,@v_Space),@v_TAB,@v_Space)))	
	AS sql_text	
	,event_class
	,client_hostname
	,client_app_name
FROM perf.v_gt1000e WITH (NOLOCK)
WHERE 
	database_name LIKE ' + NCHAR(39) + @databaseName + NCHAR(39) + NCHAR(10) +
' AND 
	start_time BETWEEN ' 
+ NCHAR(39) + CONVERT(NCHAR(19),@timeStart,120) + NCHAR(39) 
+  ' AND ' 
+ NCHAR(39) +  CONVERT(NCHAR(19),@timeEnd,120) + NCHAR(39) + ';';

IF (@debug = 1)
	PRINT @v_SQLCMD;

EXECUTE sp_executesql @stmt = @v_SQLCMD;

