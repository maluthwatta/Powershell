USE aaDBA;
GO

IF EXISTS (SELECT * FROM sys.views WHERE name = 'v_gt1000x' AND schema_id = SCHEMA_ID('perf'))
	DROP VIEW perf.v_gt1000x;
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE VIEW perf.v_gt1000x
AS

/*
	Name:				perf.v_gt1000b
	Creation Date:		07/03/2017
 	Written by:			Manoj Aluthwatta
									
 	Purpose:			
 	
	Provides a compatible view for the SSAS process. The fields here are matching to that of the
	old dbo.GT1000_ALL table
	 						
	Usage:
	
	SELECT * FROM perf.v_gt1000x;
	
Updates:
Change No.	Date 			Author 			Purpose

*/


	SELECT
		gt_id As RowID
		,database_id As DataBaseID
		,[database_name] As DataBaseName
		,cast(session_id As int) As SPID
		,SUBSTRING ( nt_username  ,case when (CHARINDEX ( '\' , nt_username)>0) then (CHARINDEX ( '\' , nt_username) + 1) else 0 end , len(nt_username))  As NTUserName
		,client_hostname As HostName
		,client_app_name As ApplicationName
		,cast(start_time As datetime) As StartTime
		,cast(end_time As datetime) As EndTime
		,duration As Duration
		,logical_reads As Reads
		,writes As Writes
		,cast(cpu_time As int) As CPU
		,event_class As EventClass
		,cast(sql_text As ntext) As TextData
		,SUBSTRING ( nt_username  ,0 , case when (CHARINDEX ( '\' , nt_username)>0) then (CHARINDEX ( '\' , nt_username)) else len(nt_username) end)  As NTDomainName
		,server_principal_name�As LoginName
		,client_pid As ClientProcessID
		,server_instance_name As ServerName
	FROM perf.gt1000 WITH (NOLOCK);

