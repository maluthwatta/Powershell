﻿# --------------------------- #
# Manoj Aluthwatta 26/02/2014 #
#-----------------------------#

#Sever List - \\csodevfile1\DBA\AluthwattaM\PowerShell\DataFiles\Databases.txt


$SQL = 
'
declare @startTime datetime
declare @endTime datetime
select @startTime = ''2017-04-03 00:00:00.000''
select @endTime   = ''2017-04-03 04:00:00.000''

SELECT *
FROM dbo.GT1000_ALL t (nolock)
FULL OUTER JOIN perf.gt1000 x (nolock)
ON x.session_id = t.SPID and x.logical_reads = t.Reads 
	and x.writes = t.Writes and x.cpu_time = t.CPU
	and cast(x.start_time as smalldatetime) = cast(t.StartTime as smalldatetime)
WHERE t.StartTime > @startTime and t.StartTime < @endTime
	and ((t.ApplicationName not like ''%GT1000%'') or (x.client_app_name not like ''%GT1000%''))
	and (t.RowID is null or x.gt_id is null );
'


$SQL2 = 
'
select dropped_event_count, largest_event_dropped_size 
from sys.dm_xe_sessions
where name = ''GT1000''
'

$databaseName = "aaDBA"
$serverListFile = "\\csodevfile1\DBA\AluthwattaM\PowerShell\DataFiles\Databases.txt"
$serverList = Get-Content $serverListFile


foreach ($server in $serverList)
{
    Write-Output $server
}

Write-Output ''

$response = Read-Host -Prompt 'Run in all above servers? (Y/N)' 
if (($response -eq 'y') -or ($response -eq 'Y'))
{
    foreach ($server in $serverList)
    {
        try
        { 
            Write-Output "-------------------------------------"
            Write-Output "Server: $server"
            
            $results = invoke-sqlcmd -query $sql2 -serverinstance $server -database $databaseName -QueryTimeout 3000               
            
            
            write-host "Dropped event count:" $results.dropped_event_count
            write-host "Largest event dropped size:"   $results.largest_event_dropped_size

            invoke-sqlcmd -query $sql -serverinstance $server -database $databaseName -QueryTimeout 3000   
  

            $results2 = invoke-sqlcmd -query $sql -serverinstance $server -database $databaseName -QueryTimeout 300   
            $results2 | Format-Table     

        }
        catch
        {
            $errorMessage = $_.Exception.Message
            $failedItem = $_.Exception.ItemName
            Write-Output "Error:" $failedItem
            Write-Output $errorMessage
        }
    }

    $conn.Close();

}


