USE aaDBA;
GO

alter table perf.GT1000
add nt_username nvarchar(256),
	client_pid int,
	server_instance_name nvarchar(256),
	server_principal_name�nvarchar(256)
Go

drop index perf.GT1000.gt1000__nc2
Go

alter table perf.GT1000
drop column username;
Go

declare @v_SQL NVARCHAR(MAX)

SET @v_SQL = N'
	CREATE NONCLUSTERED INDEX gt1000__nc2 ON perf.gt1000
	(
		database_name ASC
		,start_time ASC
		,gt_id ASC
		,server_principal_name�ASC
		,client_hostname ASC	
	)
	INCLUDE 
	(
		sql_text
		,duration	
		,end_time
		,logical_reads
		,physical_reads
		,writes
		,cpu_time
	)'
	+ CASE WHEN 1 = 1 THEN + N' WITH (DATA_COMPRESSION = PAGE)' ELSE
	'' END + N' ON [DATA];';
	
	EXECUTE sp_executesql @stmt = @v_SQL;
Go	