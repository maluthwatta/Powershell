

select * from sys.dm_xe_sessions
where name = 'GT1000' 

select * from sys.server_event_sessions 
where name = 'GT1000' 


select * from sys.dm_xe_sessions 
where dropped_event_count > 0
and name = 'GT1000' 


