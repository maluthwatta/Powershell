﻿#Add the servers e.g. @("CSOVDEVSQL10", "CSOVDEVSQL11", "CSOVDEVSQL12\INS4")
$ServerList = @("MELYVDEVSQL33\INS1") 
$SqlScriptFolderPath = '\\oceania\CTS\DEPTDATA\Development\DatabaseAdmins\Development\AluthwattaM\Projects\DBA\20170201-GT1000X\TFS_LatestScripts\Scripts\SQL'
$AgentJobFolderPath  = '\\oceania\CTS\DEPTDATA\Development\DatabaseAdmins\Development\AluthwattaM\Projects\DBA\20170201-GT1000X\TFS_LatestScripts\Scripts\AgentJobs'
$GT1000XFiles = "G:\GT1000X" # Leave it blank to get the default backup path e.g. G:\MSSQL13.INS1 Or D:

#Full file path of DeployGT1000X.ps1
$scriptGT1000XAutomation = '\\oceania\CTS\DEPTDATA\Development\DatabaseAdmins\Development\AluthwattaM\Projects\DBA\20170201-GT1000X\TFS_LatestScripts\Automation\DeployGT1000X.ps1'

Foreach ($Server in $ServerList) {
    $argumentListGT1000XAutomation  = $Server, $SqlScriptFolderPath, $AgentJobFolderPath, $GT1000XFiles
    Invoke-Expression "$scriptGT1000XAutomation $argumentListGT1000XAutomation"           
}

