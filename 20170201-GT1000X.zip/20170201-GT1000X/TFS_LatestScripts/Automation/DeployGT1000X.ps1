﻿# --------------------------- #
# Manoj Aluthwatta 24/03/2017 #
#-----------------------------#

param 
( 
    [string]$ServerName, 
    [string]$SqlScriptFolder,
    [string]$AgentJobFolder,
    [string]$GT1000Xdir = ""
)


try
{
    $MachineName = ""
    $InstanceName = ""
    $InstanceIndex = $ServerName.IndexOf("\")

    #if the $ServerName has an instance then add a sub folder to the GT1000x path
    if ($InstanceIndex -gt 0){
        $MachineName = $ServerName.Substring(0, $InstanceIndex)
        $InstanceName =  $ServerName.Substring($InstanceIndex+1)
    }
    else
    {
        $MachineName = $ServerName
    }

    
    # If $GT1000Xdir is not provided, use the BackupDirectory as per the server setting
    if ($GT1000Xdir -eq "")
    {
        $Server = New-Object ("Microsoft.SqlServer.Management.Smo.Server") $ServerName
        $GT1000EventsDir = $Server.Settings.BackupDirectory
        if ($GT1000EventsDir.Substring($GT1000EventsDir.Length-1) -ne '\')
        {
            $GT1000EventsDir = $GT1000EventsDir + '\'
        }

        $GT1000Xdir = $GT1000EventsDir + "GT1000X"
        if ($InstanceName -ne "")
        {
            $GT1000Xdir = $GT1000Xdir + "\" + $InstanceName
        }
    }

    Write-host "Server: $ServerName"
    Write-host "EventsPath: $GT1000Xdir"

    #Setup server sessions
    $remoteSession = New-PSSession -ComputerName $MachineName 

    #Command to create GT1000X folder if it does not exist 
    $command = { 
        If(!(test-path $Using:GT1000Xdir))
        {
            New-Item -Path $Using:GT1000Xdir -ItemType Directory 
            Write-host "Folder $GT1000Xdir created"
        }
        else
        {
            Write-Host "Folder $GT1000Xdir exists"
        }
    }

    Invoke-command -session $remoteSession -ScriptBlock $command

    if ($SqlScriptFolder.Substring($SqlScriptFolder.Length-1) -ne '\')
    {
        $SqlScriptFolder = $SqlScriptFolder + '\'
    }

    #Get the SQL scripts and run all of them on aaDBA
    $FileList = Get-ChildItem -Path $SqlScriptFolder –File

    foreach ($Sqlfile in $FileList)
    {
        $SqlFileName = $SqlScriptFolder + $Sqlfile
        write-host $SqlFileName
        try
        {
            Invoke-Sqlcmd -InputFile $SqlFileName -ServerInstance $ServerName -database "aaDBA" -ErrorAction Stop -Verbose -QueryTimeout 1800 # 30min
        }
        catch
        {
            write-host "Error: $($_.Exception.Message)" -ForegroundColor Red         
        }
    }

    #Get all agent job creation scripts and run them in the server
    if ($AgentJobFolder.Substring($AgentJobFolder.Length-1) -ne '\')
    {
        $AgentJobFolder = $AgentJobFolder + '\'
    }

    $AgentJobSqlFileList = Get-ChildItem -Path $AgentJobFolder –File
    foreach ($SqlAgentfile in $AgentJobSqlFileList)
    {
        $SqlAgentFileName = $AgentJobFolder + $SqlAgentfile
        write-host $SqlAgentFileName
        try
        {        
            $AgentJobSql = Get-Content $SqlAgentFileName
            $AgentJobSql = [string]($AgentJobSql -replace "<<BACKUP_FILE_PATH>>", $GT1000Xdir )
            Invoke-Sqlcmd -Query $AgentJobSql -ServerInstance $ServerName -database "msdb" -ErrorAction Stop -Verbose -QueryTimeout 1800
        }
        catch
        {
            write-host "Error: $($_.Exception.Message)" -ForegroundColor Red         
        }
    }

    #Run the agent job DBA.GT1000X_CREATE to create the event session 
    Invoke-Sqlcmd -Query "exec sp_start_job 'DBA.GT1000X_CREATE'" -ServerInstance $ServerName -database "msdb" -ErrorAction Stop -Verbose -QueryTimeout 1800

    Write-Host "Complete."
}
catch
{
    Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red         
}