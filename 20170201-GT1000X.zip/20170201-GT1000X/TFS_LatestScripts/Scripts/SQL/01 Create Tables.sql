﻿USE aaDBA;
GO

/*	
	Creation Date:		29/10/2015
 	Written by:			Paul Jenkins
 	SQL Version:		SQL 2014

	Purpose:	Create GT1000 tables
	
	Notes:	



Updates:
Change No.	Date 			Author 				Purpose
01          03/09/2017	    Manoj Aluthwatta	Added few more fields required for SSAS process

*/
SET NOCOUNT ON;	

--Get the SQL Edition, we'll use this to determine if indexes can be compressed.
 DECLARE
	@v_Edition NVARCHAR(128) = (SELECT CAST(SERVERPROPERTY('Edition') AS VARCHAR(128)))
	,@v_Compress BIT = 0
	,@v_SQL NVARCHAR(MAX);

IF (@v_Edition LIKE 'Enterprise%' OR @v_Edition LIKE 'Developer%')
	SET @v_Compress = 1;

PRINT 'Schemas';

IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = 'perf')
BEGIN
	BEGIN TRY
		EXECUTE sp_executesql @statement = N'CREATE SCHEMA [perf] AUTHORIZATION [dbo];';
		PRINT CHAR(9) + 'created perf';
	END TRY
	BEGIN CATCH
		PRINT 'failed to create perf';
	END CATCH;
END
ELSE
	PRINT CHAR(9) + 'exists perf';


PRINT 'Tables...';

IF NOT EXISTS (SELECT * FROM sys.tables WHERE name = 'gt1000' AND schema_id = SCHEMA_ID('perf'))
BEGIN

	SET @v_SQL = N'
	CREATE TABLE perf.gt1000
	(
		gt_id INT IDENTITY (1,1) NOT NULL
			CONSTRAINT gt1000__pk PRIMARY KEY CLUSTERED (gt_id ASC)		
		,database_id INT NOT NULL 
		,database_name NVARCHAR(128) NULL
		,session_id BIGINT	
		,nt_username NVARCHAR(128) NULL
		,client_hostname NVARCHAR(128) NOT NULL
		,client_app_name NVARCHAR(128) NOT NULL
		,client_pid int NULL
		,server_instance_name nvarchar(128) NULL
		,server_principal_name nvarchar(128) NULL
		,start_time AS DATEADD(ms, -1 * duration, end_time) PERSISTED
		,end_time DATETIME2
		,duration BIGINT NOT NULL
		,logical_reads BIGINT NOT NULL			
		,physical_reads BIGINT NOT NULL			
		,writes BIGINT			
		,cpu_time BIGINT					
		,event_class VARCHAR(18) NULL
		,sql_text NVARCHAR(4000) NULL
		,source_file_name NVARCHAR(260) NOT NULL
		,source_file_offset BIGINT NOT NULL
	) ON [DATA]' 
	+ CASE WHEN @v_Compress = 1 THEN + N' WITH (DATA_COMPRESSION = PAGE)' ELSE
	'' END + N';';

	EXECUTE sp_executesql @stmt = @v_SQL;	

	PRINT CHAR(9) + 'Created gt1000';

	EXEC sys.sp_addextendedproperty 
			  @name = N'Description', 
			  @value = N'Holds performance data recorded by gt1000 extended events', 
			  @level0type = N'SCHEMA', @level0name = 'perf',
			  @level1type = N'TABLE',  @level1name = 'gt1000';

	--additional indexes
	SET @v_SQL = N'
	CREATE NONCLUSTERED INDEX  gt1000__nc1 ON perf.gt1000
	(
		start_time ASC
	)'
	+ CASE WHEN @v_Compress = 1 THEN + N' WITH (DATA_COMPRESSION = PAGE)' ELSE
	'' END + N' ON [DATA];';
	
	EXECUTE sp_executesql @stmt = @v_SQL;

	SET @v_SQL = N'
	CREATE NONCLUSTERED INDEX gt1000__nc2 ON perf.gt1000
	(
		database_name ASC
		,start_time ASC
		,gt_id ASC
		,server_principal_name ASC
		,client_hostname ASC	
	)
	INCLUDE 
	(
		sql_text
		,duration	
		,end_time
		,logical_reads
		,physical_reads
		,writes
		,cpu_time
	)'
	+ CASE WHEN @v_Compress = 1 THEN + N' WITH (DATA_COMPRESSION = PAGE)' ELSE
	'' END + N' ON [DATA];';
	
	EXECUTE sp_executesql @stmt = @v_SQL;
	
	SET @v_SQL = N'
	CREATE INDEX gt1000__nc3 ON perf.gt1000
	(
		Source_File_Name ASC
		,Source_File_Offset ASC
	)'
	+ CASE WHEN @v_Compress = 1 THEN + N' WITH (DATA_COMPRESSION = PAGE)' ELSE
	'' END + N' ON [DATA];';
	
	EXECUTE sp_executesql @stmt = @v_SQL;

END
ELSE
	PRINT CHAR(9) + 'exists gt1000';

