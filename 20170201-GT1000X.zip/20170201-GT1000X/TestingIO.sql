
EXECUTE perf.p_xe_create_gt1000 
	@filePath = 'D:\GT1000X' 	
	,@duration = 1000000 /*sec*/	
	,@max_file_size = 1024 /*MB*/
	,@max_rollover_files = 100 	
	,@max_memory = 4 /*MB*/
	,@max_dispatch_latency = 30 /*sec*/
	,@max_event_size = 0 /*MB*/


	select * from sys.dm_xe_sessions
	where name = 'GT1000'
	and dropped_event_count > 0

	 select * from sys.server_event_sessions