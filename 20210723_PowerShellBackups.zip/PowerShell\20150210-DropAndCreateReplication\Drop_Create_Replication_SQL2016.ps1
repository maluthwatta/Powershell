# --------------------------- #
# Manoj Aluthwatta 05/12/2014 #
#-----------------------------#

# Add the pssnapin 
<#
if ( (Get-PSSnapin -Name SqlServerCmdletSnapin100 -ErrorAction SilentlyContinue) -eq $null )
{
    Add-PsSnapin SqlServerCmdletSnapin100
}

if ( (Get-PSSnapin -Name SqlServerProviderSnapin100 -ErrorAction SilentlyContinue) -eq $null )
{
    Add-PsSnapin SqlServerProviderSnapin100
}
#>

Set-Location C:

$ENV_OPTIONS = 'SYSTEST' #PRODCOPY, DBATEST, SYSTEST, TRAINING, SIT, UAT, HANDOVER
$DEBUG = 0

$drop_subscribers = 0
$drop_publisher = 0
$create_publisher = 0
$create_subscribers = 0


If($DEBUG -eq 1){write-host "Debug Mode....." -ForegroundColor Yellow}
ELSE{write-host "Active Mode....." -ForegroundColor Yellow} 

write-host "Environment: $ENV_OPTIONS" -ForegroundColor Red


$SNAPSHOT_PATH = ""
$POST_SNAPSHOT_SCRIPT = ""

If ($ENV_OPTIONS -eq "SYSTEST")
{
    $SNAPSHOT_PATH = '\\csovdevsql28\SQLReplData'
    $POST_SNAPSHOT_SCRIPT = '\\csovdevsql28\SQLReplData\CC\Post_snapshot_script.sql'  
}
ELSE
{
    $SNAPSHOT_PATH = '\\CSOVDEVSQL35i1\SQLReplData'
    $POST_SNAPSHOT_SCRIPT = '\\CSOVDEVSQL35i1\SQLReplData\CC\Post_snapshot_script.sql'   
}


$PRODCOPY_PUBLISHER = @{"Environment" = "PRODCOPY"; "Publication_server" = "CSOVDEVSQL35i1\INS1"; "Publication_db" = "CC_AU_PRODCOPY_2008"}
$DBATEST_PUBLISHER = @{"Environment" = "DBATEST"; "Publication_server" = "CSOVDEVSQL28\INS1"; "Publication_db" = "CC_AU_DBATEST"}
$SYSTEST_PUBLISHER = @{"Environment" = "SYSTEST"; "Publication_server" = "CSOVDEVSQL28\INS1"; "Publication_db" = "CC_AU_SYSTEST"}
$TRAINING_PUBLISHER = @{"Environment" = "TRAINING"; "Publication_server" = "CSOVDEVSQL35i1\INS1"; "Publication_db" = "CC_AU_TRAIN"}
$SIT_PUBLISHER = @{"Environment" = "SIT"; "Publication_server" = "CSOVDEVSQL35i1\INS1"; "Publication_db" = "CC_SIT_AU"}
$UAT_PUBLISHER = @{"Environment" = "UAT"; "Publication_server" = "CSOVDEVSQL35i1\INS1"; "Publication_db" = "CC_AU_UAT"}
$HANDOVER_PUBLISHER = @{"Environment" = "HANDOVER"; "Publication_server" = "CSOVDEVSQL35i1\INS1"; "Publication_db" = "CC_HANDOVER_AU"}

##DBATEST SUBSCRIBERS
$DBATEST_SUBSCRIBER_NA =  @{"Environment" = "DBATEST"; "Region" = "NA"; "Subscriber_server" = "CSODEVSQL42INS3\INS3"; "Subscriber_db" = "CC_NA_DBATEST"; "Active" = 1}
$DBATEST_SUBSCRIBER_UK =  @{"Environment" = "DBATEST"; "Region" = "UK"; "Subscriber_server" = "CSODEVSQL42INS3\INS3"; "Subscriber_db" = "CC_UK_DBATEST"; "Active" = 1}
##SYSTEST SUBSCRIBERS
$SYSTEST_SUBSCRIBER_NA =  @{"Environment" = "SYSTEST"; "Region" = "NA"; "Subscriber_server" = "CSOVDEVSQL38\INS1"; "Subscriber_db" = "CC_NA_SYSTEST"; "Active" = 1}
$SYSTEST_SUBSCRIBER_UK =  @{"Environment" = "SYSTEST"; "Region" = "UK"; "Subscriber_server" = "CSOVDEVSQL38\INS1"; "Subscriber_db" = "CC_UK_SYSTEST"; "Active" = 1}
##SIT SUBSCRIBERS
$SIT_SUBSCRIBER_NA =  @{"Environment" = "SIT"; "Region" = "NA"; "Subscriber_server" = "CSACWEBSQLU10C\WEB"; "Subscriber_db" = "CC_SIT_NA"; "Active" = 1}
$SIT_SUBSCRIBER_UK =  @{"Environment" = "SIT"; "Region" = "UK"; "Subscriber_server" = "CSEVUQREPC1INS1\INS1"; "Subscriber_db" = "CC_SIT_UK"; "Active" = 1}
##TRAINING SUBSCRIBERS
$TRAINING_SUBSCRIBER_NA =  @{"Environment" = "TRAINING"; "Region" = "NA"; "Subscriber_server" = "CSACWEBSQLU10C\WEB"; "Subscriber_db" = "CC_NA_TRAIN"; "Active" = 1}
$TRAINING_SUBSCRIBER_UK =  @{"Environment" = "TRAINING"; "Region" = "UK"; "Subscriber_server" = "CSEVUQREPC1INS1\INS1"; "Subscriber_db" = "CC_UK_TRAIN"; "Active" = 1}
#HANDOVER SUBSCRIBERS
$HANDOVER_SUBSCRIBER_NA =  @{"Environment" = "HANDOVER"; "Region" = "NA"; "Subscriber_server" = "CSACWEBSQLU10C\WEB"; "Subscriber_db" = "CC_HANDOVER_NA"; "Active" = 1}
$HANDOVER_SUBSCRIBER_UK =  @{"Environment" = "HANDOVER"; "Region" = "UK"; "Subscriber_server" = "CSEVUQREPC1INS1\INS1"; "Subscriber_db" = "CC_HANDOVER_UK"; "Active" = 1}
#UAT SUBSCRIBERS
$UAT_SUBSCRIBER_NA =  @{"Environment" = "UAT"; "Region" = "NA"; "Subscriber_server" = "CSACWEBSQLU10C\WEB"; "Subscriber_db" = "CC_NA_UAT"; "Active" = 1}
$UAT_SUBSCRIBER_UK =  @{"Environment" = "UAT"; "Region" = "UK"; "Subscriber_server" = "CSEVUQREPC1INS1\INS1"; "Subscriber_db" = "CC_UK_UAT"; "Active" = 1}
#PRODCOPY SUBSCRIBERS
$PRODCOPY_SUBSCRIBER_NA =  @{"Environment" = "PRODCOPY"; "Region" = "NA"; "Subscriber_server" = "CSACWEBSQLU10C\WEB"; "Subscriber_db" = "CC_NA_PRODCOPY_2008"; "Active" = 1}
$PRODCOPY_SUBSCRIBER_UK =  @{"Environment" = "PRODCOPY"; "Region" = "UK"; "Subscriber_server" = "CSEVUQREPC1INS1\INS1"; "Subscriber_db" = "CC_UK_PRODCOPY_2008"; "Active" = 1}

$DBATEST_SUBSCRIBERS = $DBATEST_SUBSCRIBER_NA, $DBATEST_SUBSCRIBER_UK
$SYSTEST_SUBSCRIBERS = $SYSTEST_SUBSCRIBER_NA, $SYSTEST_SUBSCRIBER_UK
$SIT_SUBSCRIBERS = $SIT_SUBSCRIBER_NA, $SIT_SUBSCRIBER_UK
$TRAINING_SUBSCRIBERS = $TRAINING_SUBSCRIBER_NA, $TRAINING_SUBSCRIBER_UK
$HANDOVER_SUBSCRIBERS = $HANDOVER_SUBSCRIBER_NA, $HANDOVER_SUBSCRIBER_UK
$UAT_SUBSCRIBERS = $UAT_SUBSCRIBER_NA, $UAT_SUBSCRIBER_UK
$PRODCOPY_SUBSCRIBERS = $PRODCOPY_SUBSCRIBER_NA, $PRODCOPY_SUBSCRIBER_UK

switch($ENV_OPTIONS)
{
    DBATEST
    {
        $PUBLISHER_SELECTED = $DBATEST_PUBLISHER
        $SUBSCRIBERS_SELECTED = $DBATEST_SUBSCRIBERS
    }
    SYSTEST
    {
        $PUBLISHER_SELECTED = $SYSTEST_PUBLISHER
        $SUBSCRIBERS_SELECTED = $SYSTEST_SUBSCRIBERS
    }
    PRODCOPY
    {
        $PUBLISHER_SELECTED = $PRODCOPY_PUBLISHER
        $SUBSCRIBERS_SELECTED = $PRODCOPY_SUBSCRIBERS
    }
    TRAINING
    {
        $PUBLISHER_SELECTED = $TRAINING_PUBLISHER
        $SUBSCRIBERS_SELECTED = $TRAINING_SUBSCRIBERS
    }
    SIT
    {
        $PUBLISHER_SELECTED = $SIT_PUBLISHER
        $SUBSCRIBERS_SELECTED = $SIT_SUBSCRIBERS
    }
    UAT
    {
        $PUBLISHER_SELECTED = $UAT_PUBLISHER
        $SUBSCRIBERS_SELECTED = $UAT_SUBSCRIBERS
    }
    HANDOVER
    {
        $PUBLISHER_SELECTED = $HANDOVER_PUBLISHER
        $SUBSCRIBERS_SELECTED = $HANDOVER_SUBSCRIBERS
    }
    DEFAULT
    {
        $PUBLISHER_SELECTED = @()
        $SUBSCRIBERS_SELECTED = @()
    }
}

$PUBLICATION_MASTER =  @{"Type" = "MASTER"; "Name" = "CC_MERGE_$($PUBLISHER_SELECTED.Environment)_MASTER"; "Active" = 1}
$PUBLICATION_NONEMASTER =  @{"Type" = "NONEMASTER"; "Name" = "CC_MERGE_$($PUBLISHER_SELECTED.Environment)_NONEMASTER"; "Active" = 1}
$PUBLICATIONS = $PUBLICATION_MASTER, $PUBLICATION_NONEMASTER

function Drop-Subscribers
{     
    #ON SUBSCRIBERS
    foreach($subscriber in $SUBSCRIBERS_SELECTED | Where-Object {$_.Active -eq 1})
    {
        foreach($publication in $PUBLICATIONS | Where-Object {$_.Active -eq 1})
        {   
            $SQL_SUBSCRIBERS = "exec sp_dropmergepullsubscription @publication = '" + $($publication.Name) + "', @publisher = '" +  $PUBLISHER_SELECTED.Publication_server + "', @publisher_db = '" + $PUBLISHER_SELECTED.Publication_db + "'"
            write-host "Dropping subscription $($publication.Name) on $($subscriber.Subscriber_db)"
            If(-Not $DEBUG)
            {
                $result = invoke-sqlcmd -query $SQL_SUBSCRIBERS -serverinstance $subscriber.Subscriber_server -database $subscriber.Subscriber_db -Verbose -QueryTimeout 30000
            }
            write-host "Complete."
            write-host "--------------------------------------------------"


            $SQL_PUBLISHER = "exec sp_dropmergesubscription  @publication = '" + $($publication.Name) + "', @subscriber = '" + $subscriber.Subscriber_server + "',@subscriber_db = '" + $subscriber.Subscriber_db + "',@subscription_type = 'PULL'"
            write-host "Removing subscription $($publication.Name) of $($subscriber.Subscriber_db) at publisher $($PUBLISHER_SELECTED.Publication_db)"
            If(-Not $DEBUG)
            {
                $result = invoke-sqlcmd -query $SQL_PUBLISHER -serverinstance $PUBLISHER_SELECTED.Publication_server -database $PUBLISHER_SELECTED.Publication_db -Verbose -QueryTimeout 30000
            }
            write-host "Complete."
            write-host "--------------------------------------------------"
        }
    }
}


function Drop-Publisher
{
    foreach($publication in $PUBLICATIONS | Where-Object {$_.Active -eq 1})
    {       
        $SQL_DROP_PUBLISHER = "exec p_CC_DropMergeReplication @database_name = '" + $PUBLISHER_SELECTED.Publication_db + "',@publication= '" + $($publication.Name) + "'"      
        write-host "Removing publication $($publication.Name) on $($PUBLISHER_SELECTED.Publication_server).$($PUBLISHER_SELECTED.Publication_db)"

        If(-Not $DEBUG)
        {
            $result = invoke-sqlcmd -query $SQL_DROP_PUBLISHER -serverinstance $PUBLISHER_SELECTED.Publication_server -database $PUBLISHER_SELECTED.Publication_db -Verbose -QueryTimeout 30000
        }
        write-host "Complete."
        write-host "--------------------------------------------------"
    }        
}


function Create-Publisher
{
    foreach($publication in $PUBLICATIONS | Where-Object {$_.Active -eq 1})
    {
        $SQL_CREATE_PUBLICATION = "
            exec P_CC_CreateMergeReplication      
                @database_name = '$($PUBLISHER_SELECTED.Publication_db)'
                ,@publication = '$($publication.Name)'     
                ,@snapshotpath = '$SNAPSHOT_PATH'       
                ,@compresssnapshot='TRUE'       
                ,@replicationType = '$($publication.Type)'      
                ,@post_snapshot_script='$POST_SNAPSHOT_SCRIPT'      
            "    
        write-host "Creating publication $($publication.Name) on $($PUBLISHER_SELECTED.Publication_server).$($PUBLISHER_SELECTED.Publication_db) ...."
        $SQL_CREATE_PUBLICATION
        If(-Not $DEBUG)
        {
            $result_master = invoke-sqlcmd -query $SQL_CREATE_PUBLICATION -serverinstance $PUBLISHER_SELECTED.Publication_server -database $PUBLISHER_SELECTED.Publication_db -Verbose -QueryTimeout 30000
        }        
        write-host "Complete."
        write-host "----------------------------------------------------"
        
    }


    #Grant Publication Access
    foreach ($login in @("EMEA\SQLCUQREPL1A", "AMERICAS\NASVC_WEBSQLU10"))
    {
        $SQL_Add_Login = "
        IF NOT EXISTS (SELECT name FROM sys.server_principals WHERE name = '$login') 
        BEGIN
            CREATE LOGIN [$login] FROM WINDOWS WITH DEFAULT_DATABASE = TEMPDB
        END
        IF NOT EXISTS (SELECT name FROM sys.database_principals WHERE name = '$login') 
        BEGIN
            CREATE USER [$login] FROM LOGIN [$login]
        END
        "
        write-host "Adding login $login"     
        If(-Not $DEBUG)
        {           
            invoke-sqlcmd -query $SQL_Add_Login -serverinstance $PUBLISHER_SELECTED.Publication_server -database $PUBLISHER_SELECTED.Publication_db -Verbose -QueryTimeout 30000 
        }
    }
    
    $pub_access = @("NT AUTHORITY\SYSTEM", "EMEA\SQLCUQREPL1A", "AMERICAS\NASVC_WEBSQLU10", "distributor_admin")
    
    foreach($publication in $PUBLICATIONS | Where-Object {$_.Active -eq 1})
    {
        foreach ($access in $pub_access) 
        {
            $SQL_PUB_ACCESS = "exec sp_grant_publication_access @publication = N'$($publication.Name)', @login = N'$access' "
            write-host "Grant publication access on $($publication.Name) to $access"
            If(-Not $DEBUG)
            {
                invoke-sqlcmd -query $SQL_PUB_ACCESS -serverinstance $PUBLISHER_SELECTED.Publication_server -database $PUBLISHER_SELECTED.Publication_db -Verbose -QueryTimeout 30000     
            }  
        }        
    }

    ## FOR SYSTEST/DBATEST ONLY    
    If(($PUBLISHER_SELECTED.Environment -eq 'SYSTEST') -or ($PUBLISHER_SELECTED.Environment -eq 'DBATEST'))
    {
        $SQL_SYSTEST_Login = "
        IF NOT EXISTS (SELECT name FROM sys.server_principals WHERE name = 'OCEANIA\SQLAGT_CSODEVSQL38I1') 
        BEGIN
            CREATE LOGIN [OCEANIA\SQLAGT_CSODEVSQL38I1] FROM WINDOWS WITH DEFAULT_DATABASE = TEMPDB
        END
        IF NOT EXISTS (SELECT name FROM sys.database_principals WHERE name = 'OCEANIA\SQLAGT_CSODEVSQL38I1') 
        BEGIN
            CREATE USER [OCEANIA\SQLAGT_CSODEVSQL38I1] FROM LOGIN [OCEANIA\SQLAGT_CSODEVSQL38I1]
        END
        "      
        write-host "SYSTEST ONLY - Add logins"
        If(-Not $DEBUG)
        {  
            invoke-sqlcmd -query $SQL_SYSTEST_Login -serverinstance $PUBLISHER_SELECTED.Publication_server -database $PUBLISHER_SELECTED.Publication_db -Verbose -QueryTimeout 30000       
        }

        foreach($publication in $PUBLICATIONS | Where-Object {$_.Active -eq 1})
        {
            $SQL_SYSTEST_ACCESS = "exec sp_grant_publication_access @publication = N'$($publication.Name)', @login = N'OCEANIA\SQLAGT_CSODEVSQL38I1'"
            write-host "SYSTEST ONLY - Grant Publication Access"
            If(-Not $DEBUG)
            {
                invoke-sqlcmd -query $SQL_SYSTEST_ACCESS -serverinstance $PUBLISHER_SELECTED.Publication_server -database $PUBLISHER_SELECTED.Publication_db -Verbose -QueryTimeout 30000 
            }
        }      
     }    
}


function Create-Subscribers
{
    foreach($subscriber in $SUBSCRIBERS_SELECTED | Where-Object {$_.Active -eq 1})
    {
        foreach($publication in $PUBLICATIONS | Where-Object {$_.Active -eq 1})
        {
            $SQL_CREATE_SUBSCRIPTION = "                
                exec p_CC_AddMergesubscriptions      
                    @publication = '$($publication.Name)'     
                    ,@pub_Srv_name = '$($PUBLISHER_SELECTED.Publication_server)'       
                    ,@pub_database_name ='$($PUBLISHER_SELECTED.Publication_db)'       
                    ,@snapshotpath = '$SNAPSHOT_PATH'      
                    ,@distributor='$($PUBLISHER_SELECTED.Publication_server)'      
                " 
            
            write-host "Creating $($publication.Name) on $($subscriber.Subscriber_server).$($subscriber.Subscriber_db)" 
            $SQL_CREATE_SUBSCRIPTION

            If(-Not $DEBUG)
            {
                invoke-sqlcmd -query $SQL_CREATE_SUBSCRIPTION -serverinstance $subscriber.Subscriber_server -database $subscriber.Subscriber_db -Verbose -QueryTimeout 30000 
            }
            write-host "Complete."
            write-host "----------------------------------------------------"

            $SQL_CREATE_SUB_IN_PUB = "
                exec sp_addmergesubscription 
                    @publication = '$($publication.Name)' 
                    ,@subscriber = '$($subscriber.Subscriber_server)'
                    ,@subscriber_db = '$($subscriber.Subscriber_db)'
                    ,@subscription_type = N'pull' 
                    ,@subscriber_type = N'local'
                    ,@subscription_priority = 50
                    ,@sync_type = N'None'
                "

            write-host "Adding $($publication.Name) to $($PUBLISHER_SELECTED.Publication_server).$($PUBLISHER_SELECTED.Publication_db)" 
            $SQL_CREATE_SUB_IN_PUB

            If(-Not $DEBUG)
            {
                invoke-sqlcmd -query $SQL_CREATE_SUB_IN_PUB -serverinstance $PUBLISHER_SELECTED.Publication_server -database $PUBLISHER_SELECTED.Publication_db -Verbose -QueryTimeout 30000 

            }
            write-host "Complete."
            write-host "----------------------------------------------------"

        }
    }    
}


<#

[array]$DropDownEnv = "PRODCOPY", "DBATEST", "SYSTEST", "TRAINING", "SIT", "UAT", "HANDOVER"


[void][System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
[void][System.Reflection.Assembly]::LoadWithPartialName("System.Drawing")

$Form = New-Object System.Windows.Forms.Form

$Form.width = 260
$Form.height = 220
$Form.Text = �Replication Drop Create�
$Form.StartPosition = "CenterScreen"

$DropDownEnv = new-object System.Windows.Forms.ComboBox
$DropDownEnv.Location = new-object System.Drawing.Size(100,10)
$DropDownEnv.Size = new-object System.Drawing.Size(130,30)


ForEach ($Item in $DropDownEnvArray) {
	[void]$DropDownEnv.Items.Add($Item)
}

$Form.Controls.Add($DropDownEnv)

$DropDownLabelEnv = new-object System.Windows.Forms.Label
$DropDownLabelEnv.Location = new-object System.Drawing.Size(10,10) 
$DropDownLabelEnv.size = new-object System.Drawing.Size(100,20) 
$DropDownLabelEnv.Text = "Environment"
$Form.Controls.Add($DropDownLabelEnv)

$Button = new-object System.Windows.Forms.Button
$Button.Location = new-object System.Drawing.Size(130,140)
$Button.Size = new-object System.Drawing.Size(100,20)
$Button.Text = "Execute"
$Button.Add_Click({Click-Execute})
$form.Controls.Add($Button)
$Form.Add_Shown({$Form.Activate()})
$Form.ShowDialog()

#>




Write-Host "Drop All $($PUBLISHER_SELECTED.Environment) Subscribers?" -ForegroundColor Green
$confirmationDropSubscribers = Read-Host "Click 'Y' to continue? "
if ($confirmationDropSubscribers -eq 'y') {
    write-host "##### Dropping subscribers #####"    
    Drop-Subscribers
    write-host "##### Subscribers dropped  #####"
}

Write-Host "Drop $($PUBLISHER_SELECTED.Environment) Publication?" -ForegroundColor Green
$confirmationDropPublishers = Read-Host "Click 'Y' to continue?" 
if ($confirmationDropPublishers -eq 'y') {
    write-host "##### Dropping publisher #####" 
    Drop-Publisher
    write-host "##### Publisher dropped ####"
}

Write-Host "Create CC $($PUBLISHER_SELECTED.Environment) Publication?" -ForegroundColor Green 
$confirmationCreate = Read-Host "Click 'Y' to continue?" 
if ($confirmationCreate -eq 'y') {
    write-host "##### Creating Publication #####"    
    Create-Publisher
    write-host "##### Publication created  #####"
}

Write-Host "Run Publisher Snapshot Agents"  -ForegroundColor Green
$confirmationSnapshot = Read-Host "Press any key to continue" 


Write-Host "Create Subscribers?" -ForegroundColor Green
$confirmationCreateSubs = Read-Host "Create Subscribers (Click 'Y' to continue)?" 
if ($confirmationCreateSubs -eq 'y') 
{
    write-host "##### Creating Subscribers #####"    
    Create-Subscribers
    write-host "##### Subscribers created  #####"
}


