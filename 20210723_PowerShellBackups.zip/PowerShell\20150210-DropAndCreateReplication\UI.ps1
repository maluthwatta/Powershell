﻿[array]$DropDownEnvArray = "PRODCOPY", "DBATEST", "SYSTEST", "TRAINING", "SIT", "UAT"
[array]$DropDownRegionArray = "NA", "UK", "NA + UK"
[array]$DropDownTaskArray = "Drop Subscribers", "Drop Publisher", "Drop Subscribers+Publisher", "Create Publisher", "Create Subscribers"


[System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
[System.Reflection.Assembly]::LoadWithPartialName("System.Drawing")

$Form = New-Object System.Windows.Forms.Form

$Form.width = 260
$Form.height = 220
$Form.Text = ”CC Replication Setup”
$Form.StartPosition = "CenterScreen"

$DropDownEnv = new-object System.Windows.Forms.ComboBox
$DropDownEnv.Location = new-object System.Drawing.Size(100,10)
$DropDownEnv.Size = new-object System.Drawing.Size(130,30)

$DropDownRegion = new-object System.Windows.Forms.ComboBox
$DropDownRegion.Location = new-object System.Drawing.Size(100,50)
$DropDownRegion.Size = new-object System.Drawing.Size(130,30)

$DropDownTask = new-object System.Windows.Forms.ComboBox
$DropDownTask.Location = new-object System.Drawing.Size(60,90)
$DropDownTask.Size = new-object System.Drawing.Size(170,30)

ForEach ($Item in $DropDownEnvArray) {
	$DropDownEnv.Items.Add($Item)
}

ForEach ($Item in $DropDownRegionArray) {
	$DropDownRegion.Items.Add($Item)
}

ForEach ($Item in $DropDownTaskArray) {
	$DropDownTask.Items.Add($Item)
}

$Form.Controls.Add($DropDownEnv)
$Form.Controls.Add($DropDownRegion)
$Form.Controls.Add($DropDownTask)

$DropDownLabelEnv = new-object System.Windows.Forms.Label
$DropDownLabelEnv.Location = new-object System.Drawing.Size(10,10) 
$DropDownLabelEnv.size = new-object System.Drawing.Size(100,20) 
$DropDownLabelEnv.Text = "Environment"
$Form.Controls.Add($DropDownLabelEnv)

$DropDownLabelRegion = new-object System.Windows.Forms.Label
$DropDownLabelRegion.Location = new-object System.Drawing.Size(10,50) 
$DropDownLabelRegion.size = new-object System.Drawing.Size(100,20) 
$DropDownLabelRegion.Text = "Region"
$Form.Controls.Add($DropDownLabelRegion)

$DropDownLabelTask = new-object System.Windows.Forms.Label
$DropDownLabelTask.Location = new-object System.Drawing.Size(10,90) 
$DropDownLabelTask.size = new-object System.Drawing.Size(100,20) 
$DropDownLabelTask.Text = "Task"
$Form.Controls.Add($DropDownLabelTask)

$Button = new-object System.Windows.Forms.Button
$Button.Location = new-object System.Drawing.Size(130,140)
$Button.Size = new-object System.Drawing.Size(100,20)
$Button.Text = "Execute"
$Button.Add_Click({Click-Execute})
$form.Controls.Add($Button)

$Form.Add_Shown({$Form.Activate()})

$Form.ShowDialog()