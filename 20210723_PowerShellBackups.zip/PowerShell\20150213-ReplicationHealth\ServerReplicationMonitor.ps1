﻿##Cross-Server Replication Monitor
## Daniel Grossman, Madeira, Sep. 2012

##If not Loaded, Please Load SQLServer Snapins Into PowerShell By Running The Following Cmdlets:
##[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")
##[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SmoExtended")
##Add-PSSnapin SqlServerCmdletSnapin100
##Add-PSSnapin SqlServerProviderSnapin100

##If Script Execution Is Disabled Please Run The Following cmdlet:
##Set-ExecutionPolicy RemoteSigned

## Beginning of Monitor

## Path To Server ListFile: Edit Path and List Target Servers In File With Line Breaks, For Named Instances Use The Typical "Server\Instance" Convention
 foreach ( $svr in get-content "Z:\PowerShell\20150213-ReplicationHealth\Servers.txt") 
{
##Connection String With Server Variable, Distribution Database name is 'Distribution'
$con = "server= $svr;database=Distribution;Integrated Security=sspi" 

##Begin SQL Query
##Refreshing Replication Monitor Cache
$cmd = "SET NOCOUNT ON; EXEC sp_replmonitorhelppublisher" 
##Getting Info From Replication Sp and Tables, Joining and Selecting 
$cmd = $cmd + " CREATE TABLE #COUNTERS"
$cmd = $cmd + " ("
$cmd = $cmd + " [DATABASE]       SYSNAME,"
$cmd = $cmd + " REPLICATEDTRANS  INT,"
$cmd = $cmd + " REPRATESEC       FLOAT,"
$cmd = $cmd + " REPLATENCY       FLOAT,"
$cmd = $cmd + " LSN1             BINARY(10),"
$cmd = $cmd + " LSN2             BINARY(10)"
$cmd = $cmd + " )"
$cmd = $cmd + " INSERT INTO #COUNTERS"
$cmd = $cmd + " EXEC sp_replcounters"
$cmd = $cmd + " SELECT DISTINCT "
$cmd = $cmd + "        m.Publisher_db,"
$cmd = $cmd + "        m.Publication,"
$cmd = $cmd + "        s.name AS 'Subscriber',"
$cmd = $cmd + "        ma.Subscriber_db,"
$cmd = $cmd + "        CASE [Status]"
$cmd = $cmd + "             WHEN 1 THEN 'Started'"
$cmd = $cmd + "             WHEN 2 THEN 'Succeeded'"
$cmd = $cmd + "             WHEN 3 THEN 'In Progress'"
$cmd = $cmd + "             WHEN 4 THEN 'Idle'"
$cmd = $cmd + "             WHEN 5 THEN 'Retrying'"
$cmd = $cmd + "             WHEN 6 THEN 'Failed'"
$cmd = $cmd + "        END AS [Status],"
$cmd = $cmd + "        CASE warning"
$cmd = $cmd + "             WHEN 0 THEN NULL"
$cmd = $cmd + "             WHEN 1 THEN 'Expiration'"
$cmd = $cmd + "             WHEN 2 THEN 'Latency'"
$cmd = $cmd + "             ELSE 'MergeWarning'"
$cmd = $cmd + "        END AS [Warning],"
$cmd = $cmd + "        C.REPLICATEDTRANS AS 'Awaiting Transactions To Dist',"
$cmd = $cmd + "        CONVERT(INT, c.REPRATESEC) AS 'Avrage Trans/Sec to Dist',"
$cmd = $cmd + "        CONVERT(DECIMAL(10, 2), c.REPLATENCY) AS 'Avg. Latency to Dist/Sec',"
$cmd = $cmd + "        CONVERT(DECIMAL(10, 2), mm.cur_latency) AS 'Avg. Latency to Subscriber'"
$cmd = $cmd + "        INTO #MonitorRepl"
$cmd = $cmd + " FROM   dbo.MSpublications m"
$cmd = $cmd + "        INNER JOIN dbo.MSreplication_monitordata mm"
$cmd = $cmd + "             ON  mm.publisher_db = m.publisher_db"
$cmd = $cmd + "             AND mm.publication_id = m.publication_id"
$cmd = $cmd + "             AND mm.agent_type = 3"
$cmd = $cmd + "        INNER JOIN dbo.MSdistribution_agents ma"
$cmd = $cmd + "             ON  ma.publisher_id = m.publisher_id"
$cmd = $cmd + "             AND ma.publication = mm.publication"
$cmd = $cmd + "             AND ma.job_id = mm.job_id"
$cmd = $cmd + "        INNER JOIN sys.servers s"
$cmd = $cmd + "             ON  ma.subscriber_id = s.server_id"
$cmd = $cmd + "        INNER JOIN #COUNTERS C"
$cmd = $cmd + "             ON  m.publisher_db = C.[DATABASE]"
$cmd = $cmd + " ORDER BY"
$cmd = $cmd + "        m.publisher_db,"
$cmd = $cmd + "        m.publication,"
$cmd = $cmd + "        s.name,"
$cmd = $cmd + "        ma.subscriber_db"
$cmd = $cmd + "        DROP TABLE #COUNTERS"
$cmd = $cmd + " SELECT *"
$cmd = $cmd + " FROM   #MonitorRepl"
$cmd = $cmd + " DROP TABLE #MonitorRepl"
##Creating DataSet Object
$set = new-object system.data.dataset
##Running Query
$da = new-object System.Data.SqlClient.SqlDataAdapter ($cmd, $con)
##Filling DataSet With Results
$da.fill($set) | out-null
##Creating Table Object and Inserting DataSet
$dt = new-object System.Data.DataTable
$dt = $set.Tables[1]
##Displaying Current Server Name
$svr
##Formating DataTable To A Readable List And Presenting
$dt|Format-List
}