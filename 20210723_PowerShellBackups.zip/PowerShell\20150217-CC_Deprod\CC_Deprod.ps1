﻿# --------------------------- #
# Manoj Aluthwatta 17/02/2015 #
#-----------------------------#

# Add the pssnapin 
<#
if ( (Get-PSSnapin -Name SqlServerCmdletSnapin100 -ErrorAction SilentlyContinue) -eq $null )
{
    Add-PsSnapin SqlServerCmdletSnapin100
}

if ( (Get-PSSnapin -Name SqlServerProviderSnapin100 -ErrorAction SilentlyContinue) -eq $null )
{
    Add-PsSnapin SqlServerProviderSnapin100
}
#>

#PROD COPY
$AU_PROD = @{"Environment" = "PRODCOPY"; "Server" = "CSODEVSQL42INS4\INS4"; "Database" = "CC_AU_PRODCOPY_2008"; "Active" = 0 }
$NA_PROD = @{"Environment" = "PRODCOPY"; "Server" = "CSACCOSSQLUAT4C\COS"; "Database" = "CC_NA_PRODCOPY_2008"; "Active" = 1 }
$UK_PROD = @{"Environment" = "PRODCOPY"; "Server" = "CSESQL5CUAT2\UAT2"; "Database" = "CC_UK_PRODCOPY_2008"; "Active" = 0 }

#TRAINING
$AU_TRAIN = @{"Environment" = "TRAINING"; "Server" = "CSODEVSQL42INS4\INS4"; "Database" = "CC_AU_TRAIN"; "Active" = 0 }
$NA_TRAIN = @{"Environment" = "TRAINING"; "Server" = "CSACCOSSQLUAT4C\COS"; "Database" = "CC_NA_TRAIN"; "Active" = 0 }
$UK_TRAIN = @{"Environment" = "TRAINING"; "Server" = "CSESQL5CUAT2\UAT2"; "Database" = "CC_UK_TRAIN"; "Active" = 0 }

#PRODCOPY ON DEV
$AU_PROD_DEV = @{"Environment" = "PRODCOPY_DEV"; "Server" = "CSODEVSQL42INS3\INS3"; "Database" = "CC_DEV_NA_PRODCOPY"; "Active" = 0 }

$ALL_DATABASES = $AU_PROD, $NA_PROD, $UK_PROD, $AU_PROD_DEV, $AU_TRAIN, $NA_TRAIN, $UK_TRAIN


Write-Host "Run de-prod script on following CC databases?" -ForegroundColor Green
foreach($database in $ALL_DATABASES | Where-Object {$_.Active -eq 1})
{
    write-host "$($database.Server).$($database.Database)" -ForegroundColor Yellow
}

$confirmationRun = Read-Host "Click 'y' to continue" 

if ($confirmationRun -eq 'y') {

    foreach($database in $ALL_DATABASES | Where-Object {$_.Active -eq 1})
    {
        #SET RECOVERY SIMPLE
        write-host "Running on $($database.Database)"
        $recovery_sql = "ALTER DATABASE $($database.Database) SET RECOVERY SIMPLE"
        $recovery_sql
        invoke-sqlcmd -query $recovery_sql -serverinstance $database.Server -database $database.Database -QueryTimeout 3000
        write-host "Complete."
        write-host "--------------------------"
    
        #SHRINK LOG FILE
        $shrinklog_sql = "DBCC SHRINKFILE(2)"
        $shrinklog_sql
        invoke-sqlcmd -query $shrinklog_sql -serverinstance $database.Server -database $database.Database -QueryTimeout 3000
        write-host "Complete."
        write-host "--------------------------"
    
        #RUN DEPROD
        $deprod_script = "\\csodevfile1\DBA\AluthwattaM\Scripts\CC\20140605_DeprodScript\CC_De_PROD.sql"  
        write-host "Running de-prod script."
        invoke-sqlcmd -inputfile $deprod_script -serverinstance $database.Server -database $database.Database -QueryTimeout 3000  
        write-host "Complete."
        write-host "--------------------------"  
    }
}
    




            
           