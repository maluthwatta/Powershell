
exec zDBA..p_DBA_RestoreDB @DB_Name = 'CSB_AluthwattaM_AU'
     , @Backup_Path = '\\Csodevfile1\DevDumps\CSB\CSB_2008\Final Master Dumps\CSB_Master_AUDB_V0707000903.cBAK'   
     , @debug_flag = 0
go

exec zDBA..p_DBA_RestoreDB @DB_Name = 'CSB_AluthwattaM_HK'
     , @Backup_Path = '\\Csodevfile1\DevDumps\CSB\CSB_2008\Final Master Dumps\CSB_Master_HKDB_V0707000903.cBAK'   
     , @debug_flag = 0
go

exec zDBA..p_DBA_RestoreDB @DB_Name = 'CSB_AluthwattaM_ZA'
     , @Backup_Path = '\\Csodevfile1\DevDumps\CSB\CSB_2008\Final Master Dumps\CSB_Master_ZADB_V0707000903.cBAK'   
     , @debug_flag = 0 
go

exec zDBA..p_DBA_RestoreDB @DB_Name = 'CSB_AluthwattaM_US'
     , @Backup_Path = '\\Csodevfile1\DevDumps\CSB\CSB_2008\Final Master Dumps\CSB_Master_USDB_V0707000903.cBAK'   
     , @debug_flag = 0 
go

exec zDBA..p_DBA_RestoreDB @DB_Name = 'CSB_AluthwattaM_UK'
     , @Backup_Path = '\\Csodevfile1\DevDumps\CSB\CSB_2008\Final Master Dumps\CSB_Master_UKDB_V0707000903.cBAK'   
     , @debug_flag = 0 
go