﻿# --------------------------- #
# Manoj Aluthwatta 26/05/2015 #
#-----------------------------#

$CSODEVSQL42 = @{"Cluster"="CSODEVSQL42";"Policy"="MELYDEVSQL42"}
$CSODEVSQL42INS2  = @{"Cluster"="CSODEVSQL42INS2\INS2";"Policy"="MELYDEVSQL42"}
$CSODEVSQL42INS3  = @{"Cluster"="CSODEVSQL42INS3\INS3";"Policy"="MELYDEVSQL42"}
$CSODEVSQL42INS4  = @{"Cluster"="CSODEVSQL42INS4\INS4";"Policy"="MELDDEVSQL42"}
$CSODEVSQL42INS6  = @{"Cluster"="CSODEVSQL42INS6\INS6";"Policy"="MELYDEVSQL42"}
$CSODEVSQL42INS7  = @{"Cluster"="CSODEVSQL42INS7\INS7";"Policy"="MELDDEVSQL42"}
$CSODEVSQL42INS8  = @{"Cluster"="CSODEVSQL42INS8\INS8";"Policy"="MELDDEVSQL42"}
$CSODEVSQL42INS9  = @{"Cluster"="CSODEVSQL42INS9\INS9";"Policy"="MELYDEVSQL42"}
$CSODEVSQL42INS10 = @{"Cluster"="CSODEVSQL42I10\INS10";"Policy"="MELDDEVSQL42"}
$CSODEVSQL42INS11 = @{"Cluster"="CSODEVSQL42I11\INS11";"Policy"="MELYDEVSQL42"}
$CSODEVSQL42INS12 = @{"Cluster"="CSODEVSQL42I12\INS12";"Policy"="MELDDEVSQL42"}
$CSODEVSQL42INS13 = @{"Cluster"="CSODEVSQL42I13\INS13";"Policy"="MELDDEVSQL42"}

#$CSODEVSQL45 = @{"Cluster"="CSODEVSQL45";"Policy"="MELYDEVSQL45A"}
#$CSODEVSQL45INS2 = @{"Cluster"="CSODEVSQL45INS2\INS2";"Policy"="MELDDEVSQL45A"}
#$CSODEVSQL45INS5 = @{"Cluster"="CSODEVSQL45INS5\INS5";"Policy"="MELYDEVSQL45A"}
#$CSODEVSQL45INS6 = @{"Cluster"="CSODEVSQL45INS6\INS6";"Policy"="MELDDEVSQL45A"}

#$CSODEVSQL45INS3 = @{"Cluster"="CSODEVSQL45INS3\INS3";"Policy"="MELYDEVSQL45A"}
#$CSODEVSQL45INS4 = @{"Cluster"="CSODEVSQL45INS4\INS4";"Policy"="MELDDEVSQL45A"}
#$CSODEVSQL45INS  1,3,5 - Y / 2,4,6 - D



$ALL = $CSODEVSQL42, $CSODEVSQL42INS2, $CSODEVSQL42INS3, $CSODEVSQL42INS4, $CSODEVSQL42INS6, $CSODEVSQL42INS7, 
    $CSODEVSQL42INS8, $CSODEVSQL42INS9, $CSODEVSQL42INS10, $CSODEVSQL42INS11, $CSODEVSQL42INS12, $CSODEVSQL42INS13


function GetActiveNode
{
    param($cluster_name)

    # Load SMO extension
    [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo") | out-null;
    $srv = New-Object "Microsoft.SqlServer.Management.Smo.Server" $cluster_name;
    # Get server properties
    $properties = $srv.Properties
    $owner_node = $properties.Item("ComputerNamePhysicalNetBIOS").Value;
    return $owner_node       
}

$output_array = @()



#Write-Host "Instance Name" `t "Active Node" `t "Policy Node"
#Write-Host "-------------" `t "-----------" `t "-----------"

foreach ($cluster in $ALL) {
    $cluster_name = $cluster.item("Cluster")
    $active_node = GetActiveNode -cluster_name $cluster_name
    $policy_node = $cluster.item("Policy") 

    if ($active_node -ne $policy_node){
        $policy_violation = "**********"
    }
    else
    {
        $policy_violation = ""
    }

    #Write-Host $cluster_name `t $active_node `t $policy_node -ForegroundColor $color_theme


    $myobj = New-Object -TypeName PSObject
    Add-Member -InputObject $myobj -MemberType 'NoteProperty' -Name 'Clustername' -Value $cluster_name
    Add-Member -InputObject $myobj -MemberType 'NoteProperty' -Name 'PolicyNode' -Value $policy_node
    Add-Member -InputObject $myobj -MemberType 'NoteProperty' -Name 'ActiveNode' -Value $active_node
    Add-Member -InputObject $myobj -MemberType 'NoteProperty' -Name 'PolicyViolation' -Value $policy_violation

    $output_array += $myobj
}


$output_array | ft -AutoSize


Set-Location C: