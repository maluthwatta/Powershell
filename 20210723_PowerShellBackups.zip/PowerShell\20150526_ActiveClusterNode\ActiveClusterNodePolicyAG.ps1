﻿set-location c:

Import-Module -Name SqlServer

$DEVSQLAG31L01  = @{"AGName"="DEVSQLAG31L01";"Policy"="MELYVDEVSQL31"} #SQL 2014
$DEVSQLAG31L02  = @{"AGName"="DEVSQLAG31L02";"Policy"="MELYVDEVSQL31"}
$DEVSQLAG31L03  = @{"AGName"="DEVSQLAG31L03";"Policy"="MELYVDEVSQL31"}
$DEVSQLAG31L04  = @{"AGName"="DEVSQLAG31L04";"Policy"="MELYVDEVSQL31"}

$DEVSQLAG32L01  = @{"AGName"="DEVSQLAG32L01";"Policy"="MELYVDEVSQL32"}
$DEVSQLAG32L02  = @{"AGName"="DEVSQLAG32L02";"Policy"="MELYVDEVSQL32"}
$DEVSQLAG32L03  = @{"AGName"="DEVSQLAG32L03";"Policy"="MELYVDEVSQL32"}
$DEVSQLAG32L04  = @{"AGName"="DEVSQLAG32L04";"Policy"="MELYVDEVSQL32"}
$DEVSQLAG32L05  = @{"AGName"="DEVSQLAG32L05";"Policy"="MELYVDEVSQL32"}

$DEVSQLAG33L01  = @{"AGName"="DEVSQLAG33L01";"Policy"="MELYVDEVSQL33\INS1"}
$DEVSQLAG33L02  = @{"AGName"="DEVSQLAG33L02";"Policy"="MELYVDEVSQL33\INS1"}
$DEVSQLAG33L03  = @{"AGName"="DEVSQLAG33L03";"Policy"="MELYVDEVSQL33\INS1"}

$DEVSQLAG36L01  = @{"AGName"="DEVSQLAG36L01";"Policy"="MELYVDEVSQL36\INS1"} # DBA Test

$DEVSQLAG39L01  = @{"AGName"="DEVSQLAG39L01";"Policy"="MELYVDEVSQL39\INS1"}
$DEVSQLAG39L02  = @{"AGName"="DEVSQLAG39L02";"Policy"="MELYVDEVSQL39\INS1"}
$DEVSQLAG39L03  = @{"AGName"="DEVSQLAG39L03";"Policy"="MELYVDEVSQL39\INS2"}
$DEVSQLAG39L04  = @{"AGName"="DEVSQLAG39L04";"Policy"="MELYVDEVSQL39\INS2"}
$DEVSQLAG39L05  = @{"AGName"="DEVSQLAG39L05";"Policy"="MELYVDEVSQL39\INS3"}

$ALL_AG = $DEVSQLAG31L01, $DEVSQLAG31L02, $DEVSQLAG31L03, $DEVSQLAG31L04, 
    $DEVSQLAG32L01, $DEVSQLAG32L02, $DEVSQLAG32L03, $DEVSQLAG32L04, $DEVSQLAG32L05, 
    $DEVSQLAG33L01, $DEVSQLAG33L02, $DEVSQLAG33L03, 
    $DEVSQLAG36L01, 
    $DEVSQLAG39L01, $DEVSQLAG39L02, $DEVSQLAG39L03, $DEVSQLAG39L04, $DEVSQLAG39L05


$output_array = @()

foreach ($ag in $ALL_AG) {
    $ag_name = $ag.item("AGName")
    $policy_node = $ag.item("Policy") 
    $sql_ag_primary = "SELECT hags.primary_replica As PrimaryReplica, synchronization_health_desc As SynchronizationHealth
    FROM sys.dm_hadr_availability_group_states as hags
	    INNER JOIN sys.availability_groups as ag
		    ON ag.group_id = hags.group_id
    WHERE ag.name = '$ag_name'"

    $primary_replica = invoke-sqlcmd -query $sql_ag_primary -serverinstance $policy_node -database 'aaDBA' -QueryTimeout 3000  

    if ($primary_replica.PrimaryReplica -ne $policy_node){
        $policy_violation = "**********"
    }
    else
    {
        $policy_violation = ""
    }

    
    $myobj = New-Object -TypeName PSObject
    Add-Member -InputObject $myobj -MemberType 'NoteProperty' -Name 'AGName' -Value $ag_name
    Add-Member -InputObject $myobj -MemberType 'NoteProperty' -Name 'PolicyNode' -Value $policy_node
    Add-Member -InputObject $myobj -MemberType 'NoteProperty' -Name 'PrimaryReplica' -Value $primary_replica.PrimaryReplica
    Add-Member -InputObject $myobj -MemberType 'NoteProperty' -Name 'PolicyViolation' -Value $policy_violation
    Add-Member -InputObject $myobj -MemberType 'NoteProperty' -Name 'SynchronizationHealth' -Value $primary_replica.SynchronizationHealth

    $output_array += $myobj
    
    #Write-Host $ag_name `t $primary_replica.PrimaryReplica `t $policy_node -ForegroundColor $color_theme

}

$output_array | ft -AutoSize 