﻿

#$ENV_OPTIONS = 'SYSTEST' #PRODCOPY, DBATEST, SYSTEST, TRAINING, SIT, UAT, HANDOVER
Set-Location C:


##DBATEST SUBSCRIBERS
$DBATEST_SUBSCRIBER_NA =  @{"Environment" = "DBATEST"; "Region" = "NA"; "Publisher_server" = "CSOVDEVSQL28\INS1"; "Publisher_db" = "CC_AU_DBATEST"; "Subscriber_server" = "CSOVDEVSQL38\INS1"; "Subscriber_db" = "CC_NA_DBATEST"; "Active" = 1}
$DBATEST_SUBSCRIBER_UK =  @{"Environment" = "DBATEST"; "Region" = "UK"; "Publisher_server" = "CSOVDEVSQL28\INS1"; "Publisher_db" = "CC_AU_DBATEST"; "Subscriber_server" = "CSOVDEVSQL38\INS1"; "Subscriber_db" = "CC_UK_DBATEST"; "Active" = 1}
##SYSTEST SUBSCRIBERS
$SYSTEST_SUBSCRIBER_NA =  @{"Environment" = "SYSTEST"; "Region" = "NA"; "Publisher_server" = "CSOVDEVSQL28\INS1"; "Publisher_db" = "CC_AU_SYSTEST"; "Subscriber_server" = "CSOVDEVSQL38\INS1"; "Subscriber_db" = "CC_NA_SYSTEST"; "Active" = 1}
$SYSTEST_SUBSCRIBER_UK =  @{"Environment" = "SYSTEST"; "Region" = "UK"; "Publisher_server" = "CSOVDEVSQL28\INS1"; "Publisher_db" = "CC_AU_SYSTEST"; "Subscriber_server" = "CSOVDEVSQL38\INS1"; "Subscriber_db" = "CC_UK_SYSTEST"; "Active" = 1}
##SIT SUBSCRIBERS
$SIT_SUBSCRIBER_NA =  @{"Environment" = "SIT"; "Region" = "NA"; "Publisher_server" = "CSOVDEVSQL35i1\INS1"; "Publisher_db" = "CC_SIT_AU"; "Subscriber_server" = "CSACWEBSQLU10C\WEB"; "Subscriber_db" = "CC_SIT_NA"; "Active" = 1}
$SIT_SUBSCRIBER_UK =  @{"Environment" = "SIT"; "Region" = "UK"; "Publisher_server" = "CSOVDEVSQL35i1\INS1"; "Publisher_db" = "CC_SIT_AU"; "Subscriber_server" = "CSEVUQREPC1INS1\INS1"; "Subscriber_db" = "CC_SIT_UK"; "Active" = 1}
##TRAINING SUBSCRIBERS
$TRAINING_SUBSCRIBER_NA =  @{"Environment" = "TRAINING"; "Region" = "NA"; "Publisher_server" = "CSOVDEVSQL35i1\INS1"; "Publisher_db" = "CC_AU_TRAIN"; "Subscriber_server" = "CSACWEBSQLU10C\WEB"; "Subscriber_db" = "CC_NA_TRAIN"; "Active" = 1}
$TRAINING_SUBSCRIBER_UK =  @{"Environment" = "TRAINING"; "Region" = "UK"; "Publisher_server" = "CSOVDEVSQL35i1\INS1"; "Publisher_db" = "CC_AU_TRAIN"; "Subscriber_server" = "CSEVUQREPC1INS1\INS1"; "Subscriber_db" = "CC_UK_TRAIN"; "Active" = 1}
#HANDOVER SUBSCRIBERS
$HANDOVER_SUBSCRIBER_NA =  @{"Environment" = "HANDOVER"; "Region" = "NA"; "Publisher_server" = "CSOVDEVSQL35i1\INS1"; "Publisher_db" = "CC_HANDOVER_AU"; "Subscriber_server" = "CSACWEBSQLU10C\WEB"; "Subscriber_db" = "CC_HANDOVER_NA"; "Active" = 1}
$HANDOVER_SUBSCRIBER_UK =  @{"Environment" = "HANDOVER"; "Region" = "UK"; "Publisher_server" = "CSOVDEVSQL35i1\INS1"; "Publisher_db" = "CC_HANDOVER_AU"; "Subscriber_server" = "CSEVUQREPC1INS1\INS1"; "Subscriber_db" = "CC_HANDOVER_UK"; "Active" = 1}
#UAT SUBSCRIBERS
$UAT_SUBSCRIBER_NA =  @{"Environment" = "UAT"; "Region" = "NA"; "Publisher_server" = "CSOVDEVSQL35i1\INS1"; "Publisher_db" = "CC_AU_UAT"; "Subscriber_server" = "CSACWEBSQLU10C\WEB"; "Subscriber_db" = "CC_NA_UAT"; "Active" = 1}
$UAT_SUBSCRIBER_UK =  @{"Environment" = "UAT"; "Region" = "UK"; "Publisher_server" = "CSOVDEVSQL35i1\INS1"; "Publisher_db" = "CC_AU_UAT"; "Subscriber_server" = "CSEVUQREPC1INS1\INS1"; "Subscriber_db" = "CC_UK_UAT"; "Active" = 1}
#PRODCOPY SUBSCRIBERS
$PRODCOPY_SUBSCRIBER_NA =  @{"Environment" = "PRODCOPY"; "Region" = "NA"; "Publisher_server" = "CSOVDEVSQL35i1\INS1"; "Publisher_db" = "CC_AU_PRODCOPY_2008"; "Subscriber_server" = "CSACWEBSQLU10C\WEB"; "Subscriber_db" = "CC_NA_PRODCOPY_2008"; "Active" = 1}
$PRODCOPY_SUBSCRIBER_UK =  @{"Environment" = "PRODCOPY"; "Region" = "UK"; "Publisher_server" = "CSOVDEVSQL35i1\INS1"; "Publisher_db" = "CC_AU_PRODCOPY_2008"; "Subscriber_server" = "CSEVUQREPC1INS1\INS1"; "Subscriber_db" = "CC_UK_PRODCOPY_2008"; "Active" = 1}

#Subscriber Types
$SUBSCRIBER_MASTER =  @{"Type" = "MASTER"; "Active" = 1}
$SUBSCRIBER_NONEMASTER =  @{"Type" = "NONEMASTER"; "Active" = 1}
$SUBSCRIBERS = $SUBSCRIBER_MASTER, $SUBSCRIBER_NONEMASTER


$global:SUBSCRIBERS_SELECTED = $null
$global:AgentJobsArray = $null # AgentJobName, Server, Active



#Get the AU time diff with UTC
$AU_UTC_DIFF = invoke-sqlcmd -query "SELECT DATEDIFF (hour, GETUTCDATE(), GETDATE()) as TimeDIFF" -serverinstance "CSOVDEVSQL35i1\INS1" -database "TempDB" -QueryTimeout 300 
[int]$AU_UTC_Time_Diff = $AU_UTC_DIFF[0]


#For agent job status
$SQL_AGENT_STATUS = "
USE msdb 
GO 
SELECT 
   j.[name] AS [JobName], 
   run_status = CASE h.run_status 
   WHEN 0 THEN 'Failed'
   WHEN 1 THEN 'Succeeded'
   WHEN 2 THEN 'Retry'
   WHEN 3 THEN 'Canceled'
   WHEN 4 THEN 'In progress'
   END,
   h.run_date AS LastRunDate,  
   h.run_time AS LastRunTime,
   h.run_duration AS Duration,
   DATEDIFF (hour, GETUTCDATE(), GETDATE()) As TimeDiffHrs
FROM sysjobhistory h 
   INNER JOIN sysjobs j ON h.job_id = j.job_id 
       WHERE j.enabled = 1  
       AND h.instance_id IN 
       (SELECT MAX(h.instance_id) 
           FROM sysjobhistory h GROUP BY (h.job_id))
AND j.[name] = "

#For agent job run
$SQL_AGENT_RUN = "
USE msdb ;
GO

EXEC dbo.sp_start_job N'"



function Set-Environment
{
    param($Environment)

    Write-host "<<"$Environment" >>" -ForegroundColor "Magenta"

    switch($Environment)
    {
        DBATEST {$global:SUBSCRIBERS_SELECTED = $DBATEST_SUBSCRIBER_NA, $DBATEST_SUBSCRIBER_UK}
        SYSTEST {$global:SUBSCRIBERS_SELECTED = $SYSTEST_SUBSCRIBER_NA, $SYSTEST_SUBSCRIBER_UK}
        PRODCOPY{$global:SUBSCRIBERS_SELECTED = $PRODCOPY_SUBSCRIBER_NA, $PRODCOPY_SUBSCRIBER_UK}
        TRAINING{$global:SUBSCRIBERS_SELECTED = $TRAINING_SUBSCRIBER_NA, $TRAINING_SUBSCRIBER_UK}
        SIT {$global:SUBSCRIBERS_SELECTED = $SIT_SUBSCRIBER_NA, $SIT_SUBSCRIBER_UK}
        UAT {$global:SUBSCRIBERS_SELECTED = $UAT_SUBSCRIBER_NA, $UAT_SUBSCRIBER_UK}
        HANDOVER {$global:SUBSCRIBERS_SELECTED = $HANDOVER_SUBSCRIBER_NA, $HANDOVER_SUBSCRIBER_UK}
        DEFAULT {$global:SUBSCRIBERS_SELECTED = @()}
    }    
}


function Get-Aus-Time
{
    param($DateInt, $TimeInt, $TimeDiff2UTC)    
    
    $timeConverted = [datetime]::ParseExact($DateInt,”yyyyMMdd”,$null)
    $timeConverted = $timeConverted.AddHours([Math]::Floor($TimeInt/10000)) 
    $timeConverted = $timeConverted.AddMinutes(([Math]::Floor(($TimeInt%10000)/100))) 
    $timeConverted = $timeConverted.AddSeconds(([Math]::Floor(($TimeInt%10000)%100))) 
    $timeConverted= $timeConverted.AddHours(-$TimeDiff2UTC+$AU_UTC_Time_Diff)
    return $timeConverted
}


function Get-AgentJob-Status
{
    param($AgentJobName, $ServerName)    
            
    $sql_execute = $SQL_AGENT_STATUS + "'" + $AgentJobName + "'"
    $result = invoke-sqlcmd -query $sql_execute -serverinstance $ServerName -database "msdb" -QueryTimeout 3000 
    return $result.run_status
}


function Recurse-agents-till-complete
{
   $currentDate = get-date
   Write-Host "Waiting for agents to complete. starting at $currentDate"
    
   Do
   {
   $endLoop = $true
   Start-Sleep -s 5 #wait for 5 sec

       foreach ( $agentJob in $global:AgentJobsArray | Where-Object {$_ -eq 1}) 
       {
            $endLoop = $false

            #Write-Host $agentJob[2]
            $agent_status = Get-AgentJob-Status -AgentJobName $agentJob[0] -ServerName $agentJob[1]
            if (($agent_status -eq "In progress") -or ($agent_status -eq "Retry"))
            {                 
            }
            else
            {
                Write-Host $agentJob[0] ": " $agent_status
                $agentJob[2] = 0
            }
       }
   }
   while ($endLoop -eq $false)

   Write-Host  ("*" * 35)
      
}


function Wait-Sync
{
    $global:AgentJobsArray = $null

    #ON SUBSCRIBERS
    foreach($subscriber in $global:SUBSCRIBERS_SELECTED | Where-Object {$_.Active -eq 1})
    {
        foreach($subscriber_type in $SUBSCRIBERS | Where-Object {$_.Active -eq 1})
        {  
            $trimSubscriber = "-CC_MERGE_"+$subscriber.Environment+"_"+$subscriber_type.Type
            $trimSubscriber = $trimSubscriber.Substring(0, [System.Math]::Min(24, $trimSubscriber.Length))
            $AgentJobName = $subscriber.Publisher_server+"-"+$subscriber.Publisher_db+$trimSubscriber+"-"+$subscriber.Subscriber_server+"-"+$subscriber.Subscriber_db+"- 0"        
            $global:AgentJobsArray += ,($AgentJobName, $subscriber.Subscriber_server, 1)

        }            
    }

    Recurse-agents-till-complete
}


function Get-Replication_Status
{
    #ON SUBSCRIBERS
    foreach($subscriber in $global:SUBSCRIBERS_SELECTED | Where-Object {$_.Active -eq 1})
    {
        foreach($subscriber_type in $SUBSCRIBERS | Where-Object {$_.Active -eq 1})
        {  
            $trimSubscriber = "-CC_MERGE_"+$subscriber.Environment+"_"+$subscriber_type.Type
            $trimSubscriber = $trimSubscriber.Substring(0, [System.Math]::Min(24, $trimSubscriber.Length))
            $AgentJobName = $subscriber.Publisher_server+"-"+$subscriber.Publisher_db+$trimSubscriber+"-"+$subscriber.Subscriber_server+"-"+$subscriber.Subscriber_db+"- 0"
            #write-host $AgentJobName
            
            #$sql_execute = $SQL_AGENT_STATUS + "'" + $AgentJobName + "'"
            #$results = invoke-sqlcmd -query $sql_execute -serverinstance $subscriber.Subscriber_server -database $subscriber.Subscriber_db -QueryTimeout 3000 
            
            #$agent_job_status = Get-AgentJob-Status -AgentJobName $AgentJobName -ServerName $subscriber.Subscriber_server

            $sql_execute = $SQL_AGENT_STATUS + "'" + $AgentJobName + "'"
            $result = invoke-sqlcmd -query $sql_execute -serverinstance $subscriber.Subscriber_server -database "msdb" -QueryTimeout 3000 
            
            [string]$lastRunTimeConverted2AU = Get-Aus-Time -DateInt $result.LastRunDate -TimeInt $result.LastRunTime -TimeDiff2UTC $result.TimeDiffHrs
            $out_message = $subscriber.Subscriber_server+"."+$subscriber.Subscriber_db+"-"+ ($subscriber_type.Type).PadRight(10, ' ')+ "-"+$result.run_status + "-" + $lastRunTimeConverted2AU + "(" + $result.Duration + "s)"
            switch ($result.run_status){
                "Failed" {$color = "red"}
                "Succeeded" {$color = "green"}
                "Retry" {$color = "yellow"}
                "Canceled" {$color = "red"}                
                "In progress" {$color = "yellow"}
            }
            Write-Host $out_message -ForegroundColor $color


            <#
            foreach($result in $results)
            {
                [string]$lastRunTimeConverted2AU = Get-Aus-Time -DateInt $result.LastRunDate -TimeInt $result.LastRunTime -TimeDiff2UTC $result.TimeDiffHrs
                $out_message = $subscriber.Subscriber_server+"."+$subscriber.Subscriber_db+"-"+ ($subscriber_type.Type).PadRight(10, ' ')+ "-"+$result.run_status + "-" + $lastRunTimeConverted2AU + "(" + $result.Duration + "s)"
                switch ($result.run_status){
                    "Failed" {$color = "red"}
                    "Succeeded" {$color = "green"}
                    "Retry" {$color = "yellow"}
                    "Canceled" {$color = "red"}                
                    "In progress" {$color = "yellow"}
                }
                Write-Host $out_message -ForegroundColor $color
            }#>
        }            
    }
    Write-Host "Complete"
    Write-Host  ("*" * 35)
}



function Run-Agent-Job
{
    $global:AgentJobsArray = $null

    Write-Host "Running agent jobs..."

    #ON SUBSCRIBERS
    foreach($subscriber in $global:SUBSCRIBERS_SELECTED | Where-Object {$_.Active -eq 1})
    {
        foreach($subscriber_type in $SUBSCRIBERS | Where-Object {$_.Active -eq 1})
        {  
            $trimSubscriber = "-CC_MERGE_"+$subscriber.Environment+"_"+$subscriber_type.Type
            $trimSubscriber = $trimSubscriber.Substring(0, [System.Math]::Min(24, $trimSubscriber.Length))
            $AgentJobName = $subscriber.Publisher_server+"-"+$subscriber.Publisher_db+$trimSubscriber+"-"+$subscriber.Subscriber_server+"-"+$subscriber.Subscriber_db+"- 0"

            #write-host $AgentJobName
            $sql_execute = $SQL_AGENT_RUN + $AgentJobName + "'"
            
            
            Write-Host $AgentJobName

            $result = invoke-sqlcmd -query $sql_execute -serverinstance $subscriber.Subscriber_server -database "msdb" -QueryTimeout 3000 
            
            $global:AgentJobsArray += ,($AgentJobName, $subscriber.Subscriber_server, 1)

        }            
    }

    Write-Host  ("*" * 35)


    Recurse-agents-till-complete
    Get-Replication_Status
}



function Click-Execute {    

    Write-Output "inside click"    
    
    $Form.Cursor = 'WaitCursor'    
    
    #Filter Product, Environment       
    ######$ProcessDB =  $AllDB | Where-Object {$_.Product -eq $SelectedProduct -and $_.Environment -eq $SelectedEnvironment}

    

    Set-Environment -Environment $DropDownEnv.SelectedItem
    
        
    #Filter Region 
    <#
    if (($DropDownRegion.SelectedItem -eq $null) -or ($DropDownRegion.SelectedItem -eq "")  -or ($DropDownRegion.SelectedItem -eq "ALL")){
    }
    else {
        $ProcessDB =  $ProcessDB | Where-Object {$_.Region -eq $DropDownRegion.SelectedItem}
    }    
    #>
    
    if ($DropDownTask.SelectedItem -eq 'Sync Status')
    {
        Get-Replication_Status 
    }  
    
    if ($DropDownTask.SelectedItem -eq 'Run Sync')
    {
        Run-Agent-Job   
    } 

    if ($DropDownTask.SelectedItem -eq 'Wait Sync')
    {
        Wait-Sync   
    } 


    $Form.Cursor = 'Default'
}




##################### UI ###########################

[array]$DropDownEnvArray = "SYSTEST", "UAT", "SIT", "HANDOVER", "PRODCOPY", "DBATEST", "TRAINING"
[array]$DropDownRegionArray = "ALL", "AU", "NA", "UK"
[array]$DropDownTaskArray = "Sync Status", "Run Sync", "Wait Sync"


[void][System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
[void][System.Reflection.Assembly]::LoadWithPartialName("System.Drawing")

$Form = New-Object System.Windows.Forms.Form

$Form.width = 260
$Form.height = 220
$Form.Text = ”CC Replication”
$Form.StartPosition = "CenterScreen"

$DropDownEnv = new-object System.Windows.Forms.ComboBox
$DropDownEnv.Location = new-object System.Drawing.Size(100,10)
$DropDownEnv.Size = new-object System.Drawing.Size(130,30)

$DropDownRegion = new-object System.Windows.Forms.ComboBox
$DropDownRegion.Location = new-object System.Drawing.Size(100,50)
$DropDownRegion.Size = new-object System.Drawing.Size(130,30)

$DropDownTask = new-object System.Windows.Forms.ComboBox
$DropDownTask.Location = new-object System.Drawing.Size(100,90)
$DropDownTask.Size = new-object System.Drawing.Size(130,30)

ForEach ($Item in $DropDownEnvArray) {
	[void]$DropDownEnv.Items.Add($Item)
}

ForEach ($Item in $DropDownRegionArray) {
	[void]$DropDownRegion.Items.Add($Item)
}

ForEach ($Item in $DropDownTaskArray) {
	[void]$DropDownTask.Items.Add($Item)
}

$Form.Controls.Add($DropDownEnv)
$Form.Controls.Add($DropDownRegion)
$Form.Controls.Add($DropDownTask)

$DropDownLabelEnv = new-object System.Windows.Forms.Label
$DropDownLabelEnv.Location = new-object System.Drawing.Size(10,10) 
$DropDownLabelEnv.size = new-object System.Drawing.Size(100,20) 
$DropDownLabelEnv.Text = "Environment"
$Form.Controls.Add($DropDownLabelEnv)

$DropDownLabelRegion = new-object System.Windows.Forms.Label
$DropDownLabelRegion.Location = new-object System.Drawing.Size(10,50) 
$DropDownLabelRegion.size = new-object System.Drawing.Size(100,20) 
$DropDownLabelRegion.Text = "Region"
$Form.Controls.Add($DropDownLabelRegion)

$DropDownLabelTask = new-object System.Windows.Forms.Label
$DropDownLabelTask.Location = new-object System.Drawing.Size(10,90) 
$DropDownLabelTask.size = new-object System.Drawing.Size(100,20) 
$DropDownLabelTask.Text = "Task"
$Form.Controls.Add($DropDownLabelTask)

$Button = new-object System.Windows.Forms.Button
$Button.Location = new-object System.Drawing.Size(130,140)
$Button.Size = new-object System.Drawing.Size(100,20)
$Button.Text = "Execute"
$Button.Add_Click({Click-Execute})
$form.Controls.Add($Button)

$Form.Add_Shown({$Form.Activate()})

$Form.ShowDialog()