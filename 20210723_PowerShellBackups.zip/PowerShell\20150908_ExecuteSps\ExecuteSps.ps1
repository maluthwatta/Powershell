﻿# --------------------------- #
# Manoj Aluthwatta 08/09/2015 #
#-----------------------------#



$BASE_ALL = @{"ENV"="CI_BASE_ALL";"PATH"="\\csodevfile1\DevDumps\CosmosInvestor\SQL2008\BASE\";"SERVER" = "CSODEVSQL42INS3\INS3";"DATABASE" = "CI_AluthwattaM_BASE_ALL"; "TESTER" = "00"}
$BASE_AU = @{"ENV"="CI_BASE_AU";"PATH"="\\csodevfile1\DevDumps\CosmosInvestor\SQL2008\BASE\";"SERVER" = "CSODEVSQL42INS3\INS3";"DATABASE" = "CI_AluthwattaM_BASE_AU"; "TESTER" = "00"}
$BASE_NA = @{"ENV"="CI_BASE_NA";"PATH"="\\csodevfile1\DevDumps\CosmosInvestor\SQL2008\BASE\";"SERVER" = "CSODEVSQL42INS3\INS3";"DATABASE" = "CI_AluthwattaM_BASE_NA"; "TESTER" = "00"}
$BASE_UK = @{"ENV"="CI_BASE_UK";"PATH"="\\csodevfile1\DevDumps\CosmosInvestor\SQL2008\BASE\";"SERVER" = "CSODEVSQL42INS3\INS3";"DATABASE" = "CI_AluthwattaM_BASE_UK"; "TESTER" = "00"}
$DEV_ALL = @{"ENV"="CI_DEV_All_Regions";"PATH"="\\csodevfile1\DevDumps\CosmosInvestor\SQL2008\DEV\";"SERVER" = "CSODEVSQL42INS3\INS3";"DATABASE" = "CI_AluthwattaM_DEV"; "TESTER" = "00"}
$ALL_DB = $BASE_ALL,$BASE_AU, $BASE_NA, $BASE_UK, $DEV_ALL

$WORKING_FOLDER = "\\Csodevfile1\Upgrades\DBAUpgrades\TEMP\"

#source
$source = 'C:\Temp\v4.4.0.41.0'

#destination
$destination = $WORKING_FOLDER

#filters to specify compile order
$filter1 = 'v'
$filter2 = 'f'
$filter3 = 't'

#add set options
$sql_set_options = "set quoted_identifier on;
set ansi_nulls on;
"


$destFolder = $destination + "StoredProcTemp"

#write the source location
write-host "Source folder: $source"


#if the destination folder exists delete it
if (Test-Path $destFolder -pathType container)
{
    write-host "Removing folder: $destFolder"
    Remove-Item $destFolder -Force -Recurse    
}

#create the folder
write-host "Creating folder: $destFolder"
New-Item $destFolder -type directory | out-null


#Load scripts to destination
write-host "Copying files to: $destFolder"
Get-ChildItem $source -Recurse | `
    Where-Object { $_.PSIsContainer -eq $False } | `
    ForEach-Object {Copy-Item -Path $_.Fullname -Destination $destFolder -Force} 

#set options
write-host "SET OPTIONS:"
write-host $sql_set_options


#sort the order by applying the filters
$FileList = get-item $destFolder\* | `
    Select-Object Name, @{name="SortOrder";Expression={switch -Wildcard ($_.Name){"$filter1*"{5} "$filter2*"{4} "$filter3*"{3} default{0}}}} | `
    Sort-Object SortOrder -Descending | Select-Object Name

Write-Host  ("-" * 35)


$all_error_count = 0


foreach($database in $ALL_DB)
{
    $success_count = 0
    $error_count = 0

    
    write-host "Executing on $($database.Server).$($database.Database) ..." 
    
    #write-host "$($database.Server).$($database.Database)"


    foreach ($file in $FileList)
    {
        $input_file = $destFolder + "\" + $file.Name
        write-host $file.Name
        try
        {
            $success_count += 1
            Invoke-Sqlcmd -query $sql_set_options -ServerInstance $database.Server -database $database.Database -ErrorAction Stop -Verbose -QueryTimeout 1800 # 30min
            Invoke-Sqlcmd -InputFile $input_file -ServerInstance $database.Server -database $database.Database -ErrorAction Stop -Verbose -QueryTimeout 1800 # 30min
        }
        catch
        {
            write-host "Error: $($_.Exception.Message)" -ForegroundColor Red
            $error_count += 1
            $success_count -= 1
            $all_error_count += 1
        }
    }

    
    Write-Host "$success_count SCRIPT(S) SUCCESSFULLY RUN" -ForegroundColor Green
    If ($error_count -gt 0)
    {
        Write-Host "$error_count SCRIPT(S) FAILED" -ForegroundColor Red   
    }
    Write-Host  ("-" * 35)
}

if ($all_error_count -eq 0)
{
    $color = "Green"
}
else
{
    $color = "Red"
}

Write-Host  ("#" * 35)
write-host "BATCH COMPLETED. ERRORS: $all_error_count" -ForegroundColor $color
Write-Host  ("#" * 35)
 

