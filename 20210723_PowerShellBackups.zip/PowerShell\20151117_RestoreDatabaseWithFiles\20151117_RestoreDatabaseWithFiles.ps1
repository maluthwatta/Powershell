﻿# --------------------------- #
# Manoj Aluthwatta 19/11/2015 #
#-----------------------------#


$server_name   = "CSACCOSSQLUAT4C\COS"
$database_name = "CC_NA_TRAIN"
$debug_mode = $false


$fullBackups = @(
"\\CANRDDBU6.AMERICAS.CSHARE.NET\SQL\CSACCOSSQLUAT4C\CC_NA_TRAIN\CC_NA_TRAIN_201602261948_1.bak",
"\\CANRDDBU6.AMERICAS.CSHARE.NET\SQL\CSACCOSSQLUAT4C\CC_NA_TRAIN\CC_NA_TRAIN_201602261948_2.bak",
"\\CANRDDBU6.AMERICAS.CSHARE.NET\SQL\CSACCOSSQLUAT4C\CC_NA_TRAIN\CC_NA_TRAIN_201602261948_3.bak",
"\\CANRDDBU6.AMERICAS.CSHARE.NET\SQL\CSACCOSSQLUAT4C\CC_NA_TRAIN\CC_NA_TRAIN_201602261948_4.bak",
"\\CANRDDBU6.AMERICAS.CSHARE.NET\SQL\CSACCOSSQLUAT4C\CC_NA_TRAIN\CC_NA_TRAIN_201602261948_5.bak",
"\\CANRDDBU6.AMERICAS.CSHARE.NET\SQL\CSACCOSSQLUAT4C\CC_NA_TRAIN\CC_NA_TRAIN_201602261948_6.bak",
"\\CANRDDBU6.AMERICAS.CSHARE.NET\SQL\CSACCOSSQLUAT4C\CC_NA_TRAIN\CC_NA_TRAIN_201602261948_7.bak",
"\\CANRDDBU6.AMERICAS.CSHARE.NET\SQL\CSACCOSSQLUAT4C\CC_NA_TRAIN\CC_NA_TRAIN_201602261948_8.bak"
)

$diffBackups = @(
"\\CANRDDBU6.AMERICAS.CSHARE.NET\SQL\CSACCOSSQLUAT4C\CC_NA_TRAIN\CC_NA_TRAIN_201603021713.diff"
)

$logBackups = @(

)


<#Format:
"\\CANRDDBU6.AMERICAS.CSHARE.NET\SQL\CSACCOSSQL19C\CI_InvProd\CI_InvProd_201511130205_1.bak",
"\\CANRDDBU6.AMERICAS.CSHARE.NET\SQL\CSACCOSSQL19C\CI_InvProd\CI_InvProd_201511130205_2.bak",
#>


Set-Location C:

$error_found = $false

##### KILL PROCESSES ####################################
$sql_processes= 
"select spid from master..sysprocesses
 where dbid = db_id('$database_name')"

$processes = invoke-sqlcmd -query $sql_processes -serverinstance $server_name -database 'master' -QueryTimeout 10000

foreach($process in $processes)
{
    [string]$spid = $process.spid
    $sql_kill = "KILL $spid"
    if ($debug_mode)
    {
        Write-Host $sql_kill`n 
    }
    else
    {
        Write-Host $sql_kill 
        invoke-sqlcmd -query $sql_kill -serverinstance $server_name -database 'master' -QueryTimeout 10000 
        Write-Host "Complete." -ForegroundColor "Yellow"
    }
}
#########################################################






##### FULL BACKUP ########################################

$fullbackups_available = $false

$disks_fullbackup = ""
$first_run = $true

foreach($fullBackup in $fullBackups)
{
    $fullbackups_available = $true
    if ($first_run) 
    {
        $disks_fullbackup += "FROM DISK = '$fullBackup'`n"   
        $first_run = $false 
    }
    else
    {
        $disks_fullbackup += ",DISK = '$fullBackup'`n"
    }
}

$sql_files =
"SELECT name, physical_name
FROM master.sys.master_files
WHERE database_id = db_id('$database_name')"
#and type_desc = 'ROWS'"

$results = invoke-sqlcmd -query $sql_files -serverinstance $server_name -database 'master' -QueryTimeout 10000 

$move_files = ""

foreach($file_path in $results)
{    
    [System.IO.FileInfo]$file = $file_path.physical_name
    $path = split-path -path $file -parent          
    $logical_name = $($file_path.name)
    $file_extension = $file.Extension
    $path_filename = $path + "\" + $database_name + "_" + $logical_name + "_data" + "$file_extension"     
    $move_files += ",MOVE '$logical_name' to '$path_filename'`n"  
}


#Restore Statement
$sql_restore_full_backup = "RESTORE DATABASE $database_name `n" +
$disks_fullbackup +
"WITH NORECOVERY`n" +
$move_files +
",REPLACE`n" +
",FILE = 1`n" +
",STATS = 10" 

if ($fullbackups_available) 
{
    if ($debug_mode)
    {
        Write-Host $sql_restore_full_backup`n
    }
    else
    {
        Write-Host $sql_restore_full_backup
        try
        {
            invoke-sqlcmd -query $sql_restore_full_backup -serverinstance $server_name -database 'master' -QueryTimeout 10000 -ErrorAction Stop
            Write-Host "Complete.`n" -ForegroundColor "Yellow"
        }
        catch
        {
            Write-Host $_.Exception.Message`n  -ForegroundColor "Red"          
            $error_found = $true
        }
        
    }
}
#########################################################





##### DIFF BACKUP #######################################
$diffbackups_available = $false
$disks_diffbackup = ""
$first_run = $true

foreach($diffBackup in $diffBackups)
{
    $diffbackups_available = $true
    if ($first_run) 
    {
        $disks_diffbackup += "FROM DISK = '$diffBackup'`n"   
        $first_run = $false 
    }
    else
    {
        $disks_diffbackup += ",DISK = '$diffBackup'`n"
    }
}

#Restore Statement
$sql_restore_diff_backup = "RESTORE DATABASE $database_name `n" +
$disks_diffbackup + 
"WITH NORECOVERY"

if ($diffbackups_available) 
{
    if($debug_mode)
    {
        Write-Host $sql_restore_diff_backup`n
    }
    else
    {
        Write-Host $sql_restore_diff_backup
        try
        {
            invoke-sqlcmd -query $sql_restore_diff_backup -serverinstance $server_name -database 'master' -QueryTimeout 10000 -ErrorAction Stop
            Write-Host "Complete.`n" -ForegroundColor "Yellow"
        }
        catch
        {
            Write-Host $_.Exception.Message`n  -ForegroundColor "Red"   
            $error_found = $true
        }
    }
}
#########################################################





##### LOG BACKUPS #######################################
foreach($logBackup in $logBackups)
{
    $sql_disks_logbackup = "RESTORE LOG $database_name `n" +
    "FROM DISK = '$logBackup'`n" + 
    "WITH NORECOVERY" 

    if($debug_mode)
    {
        Write-Host $sql_disks_logbackup`n
    }
    else
    {
        Write-Host $sql_disks_logbackup
        try
        {
            invoke-sqlcmd -query $sql_disks_logbackup -serverinstance $server_name -database 'master' -QueryTimeout 10000 -ErrorAction Stop
            Write-Host "Complete.`n" -ForegroundColor "Yellow"
        }
        Catch
        {
            Write-Host $_.Exception.Message`n -ForegroundColor "Red"    
            $error_found = $true
        }
    }
}
#########################################################





##### WITH RECOVERY #####################################
$sql_with_recovery = "RESTORE DATABASE $database_name WITH RECOVERY"

if($debug_mode)
{
    Write-Host $sql_with_recovery`n
}
else
{
    Write-Host $sql_with_recovery
    if(!$error_found)
    {
        invoke-sqlcmd -query $sql_with_recovery -serverinstance $server_name -database 'master' -QueryTimeout 10000 
        Write-Host "Complete." -ForegroundColor "Yellow"
    }
    else
    {
        Write-Host "Errors found. Database has not been RECOVERED!" -ForegroundColor "Red"
    }
}
#########################################################


if(!$error_found)
{
    Write-Host "Restore complete." -ForegroundColor "Green"
    Write-Host "#################"
}



#########################################################
# SET RECOVERY SIMPLE & SHRINK LOG FILE


if(!$error_found)
{
    $sql_simple_recovery = "ALTER DATABASE $database_name SET RECOVERY SIMPLE"

    invoke-sqlcmd -query $sql_simple_recovery -serverinstance $server_name -database 'master' -QueryTimeout 10000 
    Write-Host "Database recovery changed to SIMPLE." -ForegroundColor "White"

    $sql_shrink_log = "DBCC SHRINKFILE(2)"
    invoke-sqlcmd -query $sql_shrink_log -serverinstance $server_name -database $database_name -QueryTimeout 10000 
    Write-Host "Shrinking log file completed." -ForegroundColor "White"
    Write-Host "#################"
}