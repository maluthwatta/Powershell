﻿$filepath = '\\csodevfile1\DBA\AluthwattaM\PowerShell\20151117_RestoreDatabaseWithFiles\RestoreFileList.txt'


$FullBackupsArray = @()
$DiffBackupsArray = @()
$LogBackupsArray = @()


$content = get-content $filepath
foreach ($line in $content)
{



    switch ($line)
    {
        "<FULLBACKUPS>" 
            {
                continue
            }
        "</FULLBACKUPS>" {}
        "<DIFFBACKUPS>" {}
        "</DIFFBACKUPS>" {}
        "<LOGBACKUPS>" {}
        "</LOGBACKUPS>" {}        
    }

    Write-Host $line
}

<#

$myarray = gc $filepath | 
% { [regex]::matches( $_ , '(?<=<FULLBACKUPS>\s+)(.*?)(?=\s+</FULLBACKUPS>)' ) } | 
select -expa value

#>