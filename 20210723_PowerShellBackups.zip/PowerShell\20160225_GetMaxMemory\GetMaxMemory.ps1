﻿Import-Module \\csodevfile1\DBA\AluthwattaM\PowerShell\20160225_GetMaxMemory\SqlMaxMemory.psm1

Get-SqlMaxMemory -Servers CSODEVSQL45, CSODEVSQL42INS3\INS3

