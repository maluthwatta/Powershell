
# -----------------------------------------------------------------------------
# "Building TeamFoundationServer Projects"
# ToolSet:  VisualStudio.NET2003, VisualStudio.NET2005, VisualStudio.NET2008
#           TeamFoundationServer 1.0
#           WindowsPowerShell 1.0 (for this script)
#
# Author:   Clift Norris, norris@acm.org
#
# Usage:
#    .\BuildMe.ps1 [inputFile] [label]
#  If 'inputFile' is not specified, then a file called BuildMe.xml will be read.
#  The 'inputFile' should contain an XML description of the VS.NET Solution to be built.
#
#  'inputFile' can be either the name of an XML file, or it can be the TeamFoundationServer
#  path to the XML file.  If the TFS path (begins with "$/") is specified, then the
#  file is extracted from TFS and placed in the current dir, then the build is done
#  using the contents of the extracted XML file.
#  [label], if present applies to the TFS 'get' that is done to retrieve the XML file.
#  The [label] is not used if just the name of the XML file (no TFS path) is specified.
#
#  Example:
#    ./BuildMe.ps1  $/DMINABTC0601/DMINABTC0601_sln/BuildMe.xml  v2.3
#    ./BuildMe.ps1  BuildMe.xml
#
#The script does this:
# -If command-line arg is specified as the TFS path for the BuildMe.xml file, the file
#    will be fetched from TFS and placed in the current dir location.  Otherwise (if the
#    command-line arg is just the name of the xml file), the xml file is opened and read.
# -The script takes note of any currently-mapped drive letters,
# -Maps any new required drive(as specified in the XML input file),
# -Creates a temporary workspace in the current folder,
# -'gets' source code (described in BuildMe.xml) from the TFS source repository,
# -Builds the specified solution/configuration, using the version of VS.NET that is specified
#     in the Solution file.  (Supported versions are 2003, 2005, 2008)
# -Deletes the temporary workspace.
# -Restores any drive mapping that was present before the script started.
#
#
#The output from the VS.NET compiler is written to 'BuildMe.xml.SolutionBuild.log',
#  with the name of the actual command-line argument being substituted for 'BuildMe.xml'
#  if a command-line argument was specified.
#
#
# The Build will happen 'relative' to the
#   current dir, using the variables/paths specified below.
# If you have other code (TFS projects) that need extracting from version control,
#   you can specify those projects in the XML input file also.
#   The <TFSprojec> element may be repeated as many times as necessary.
#
# Here is an example XML input file.
#
#<Solution>
#  <!-- For use with BuildMe.ps1  -->
#  <SlnToBuild> .\DMI_BATTLE\DMI_BATTLE_sln\DMI_BATTLE_sln.sln </SlnToBuild>
#  <ConfigToBuild>  Release </ConfigToBuild>
#  <ConfigToBuild>  Debug </ConfigToBuild>
#  <BuildBitsOutputFolder>
#      .\DMI_BATTLE\DMI_BATTLE_sln\projects\DMI_BATTLE_Setup\($ConfigToBuild)
#  </BuildBitsOutputFolder>
#  <MappedDrive>
#    <Drive> M: </Drive>
#    <MapTo> \\utm-Server2\bsdev\SharedLibs </MapTo>
#  </MappedDrive>
#  <TFSproject >
#    <ProjName>      $/DMI_BATTLE  </ProjName>
#    <ProjLocalDir>  .\DMI_BATTLE  </ProjLocalDir>
#    <ProjTreeToGet> $/DMI_BATTLE  </ProjTreeToGet>
#    <Label>         v0.6          </Label>
#  </TFSproject>
#</Solution>






Set-psdebug -strict               # Require variables to be initialized before use.
$ErrorActionPreference = "stop"   # Stop execution as soon as an error is thrown

$g_ScriptName   =  ([System.IO.FileInfo]$MyInvocation.MyCommand.Path).Name
$g_sLogFilename =  $g_ScriptName + ".log"     # Our script output goes to the console and here.
                                              # Note: this must be define BEFORE we can write anything to the logfile.

write-host "`n----> " $g_ScriptName " version 1.8.0, 14Apr2008  <----"
write-host "`nPath:  "  $pwd


$g_sDefaultInputFilename = ".\BuildMe.xml"     # Unless overridden by a command-line arg

# This is the name for a temporary TFS workspace that we'll use just for this Build.
#  We'll create it, use it, then delete it when we're finished.
$g_myWSpace = "TmpWSpace"

$g_myServer = "theTFSserverName"    # Name of your TFS server  (the port, 8080, is hard-coded elsewhere).




# =============================================================================
# =============== Main ==================================================
# Note: execution actually begins at the bottom of this file at 'Start Here'.
function Main( [string[]]$aCmdLine )
{
   write-host $MyInvocation.MyCommand.Name "CmdLine: $aCmdLine"  -foregroundcolor darkblue

   $sXMLBuildFile = $aCmdLine[0];  # Assume it is a BuildMe.xml file

   #Test for something like this:   BuildMe.ps1  $/myTFSProj/folder/filename.txt  v2.0.1
   if( ($aCmdLine.Length -gt 0) -and ($aCmdLine[0].StartsWith("$/")) )
   {
      $sPathPlusFilenameFetched = "";    # Full path for the BuildMe.xml file once we 'get' it here to our local machine.
      [string] $sTFSFilenameToGet = $aCmdLine[0];
      [string] $sLabel = ""              # Label for the Buildme.xml file that we'll first 'get' from TFS
      if( ($aCmdLine.Length) -gt 1 ) {$sLabel = $aCmdLine[1] }

      $sLocalDir = ".\";    # The BuildMe.xml file will be 'put' here (Must be a relative path).
      GetSingleFileFromTFS  ([ref]$sPathPlusFilenameFetched) $sTFSFilenameToGet  $sLabel  $sLocalDir

      write-host "The Filename we fetched is: (" $sPathPlusFilenameFetched ")"
      if($sPathPlusFilenameFetched.Length -lt 1)
      {
         write-host "`nWe failed to 'Get' the XML file from TFS.   Exiting now." -foregroundcolor darkred
         exit 5;
      }  # don't continue with the Build.

      $sXMLBuildFile = $sPathPlusFilenameFetched     # This is used below to actually do the Build.
   }


   #write-host "`nDoing the Build using this input file: (" $sXMLBuildFile ")"   -foregroundcolor darkgreen
   BuildUsingXMLfile   $sXMLBuildFile

}
# -------- End Main -----------------------------------------------------------


# -----------------------------------------------------------------------------
# $sFilename is the name of the XML file containing our input data.
function BuildUsingXMLfile ([string]$sFilename)
{
   $boShouldCreateNewMapping   = $false;
   $boNeedToRestorePrevMapping = $false;

   [xml]$xmldoc = $null;    # For reading our input XML file.

   if(($sFilename -eq $null) -or ($sFilename.length -lt 1))    {  $sFilename = $g_sDefaultInputFilename }

   $sFilename = MakePathAbsolute  $sFilename
   if( [io.file]::Exists($sFilename) )
   {
      write-host "`nInput filename: " $sFilename  -foregroundcolor darkgreen
      ReadInput $sFilename ([ref]$xmldoc)
   }
   else
   {
      write-host "Cannot find file: (" $sFilename ")`nExiting." -foregroundcolor red
      exit
   }

   # This is output from Devenv.exe ONLY (other output goes to console & PSH pipeline)
   $myLogFile  = ($sFilename + ".SolutionBuild.Log")
   #write-host "The VisualStudio output file is" $myLogFile

   $mySlnToBuild            = ($xmldoc.Solution.SlnToBuild).Trim().Trim('"')               # " This comment just 'fixes' the...
   $mySlnToBuild            =  MakePathAbsolute $mySlnToBuild
   $myBuildBitsOutputFolder = ($xmldoc.Solution.BuildBitsOutputFolder).Trim().Trim('"')    # "   confused syntax coloring.
   $myBuildBitsOutputFolder =  MakePathAbsolute $myBuildBitsOutputFolder
   $myConfigsToBuild        = ($xmldoc.Solution.ConfigToBuild)           # " A collection

   $projects = $xmldoc.SelectNodes("descendant::TFSproject")
   write-host "Project count (from input file): " $projects.count



   [string[]]$aPrevMappedDrive = @(""  ,"", "", "");           # DriveLetter, MappedTo, CodeToCreate, CodeToDel
  #[string[]]$aReqdMappedDrive = @("M:", "\\myServer\SharedLibs" );      # This is an array of strings
   [string[]]$aReqdMappedDrive = @(""  , "", "", "");                       # Empty if no mapped drive is required.

   #write-host "Drive:" $xmldoc.Solution.MappedDrive.Drive

   if( ([string]($xmldoc.Solution.MappedDrive.Drive)).Trim().length -gt 0)   # If we found any mapped drives in the XML file...
   {
      $aReqdMappedDrive[0] = ((($xmldoc.Solution.MappedDrive.Drive).Trim()).Trim('"')).ToUpper()   # "    Trim double quotes too.
      #write-host "ReqdMappedDrive[0]:" $aReqdMappedDrive[0]
      if( ! $aReqdMappedDrive[0].EndsWith(":") )
      {  $aReqdMappedDrive[0] += ":"
      }
      $aReqdMappedDrive[1] =  (($xmldoc.Solution.MappedDrive.MapTo).Trim()).Trim('"')              # "
   }

   # At this point, the $aReqdMappedDrive[0] (if not empty) should have a colon terminator, like "M:"

   if($aReqdMappedDrive.length -lt 3) { $aReqdMappedDrive += ("","") }   # Make sure there is space for the CodeToCreate & CodeToDel

   write-host "Required MappedDrive: " $aReqdMappedDrive
   #exit;


   #set-psdebug -trace 0
   SetUpInitialDriveMapping ([ref]$aPrevMappedDrive)          ([ref]$aReqdMappedDrive) `
                            ([ref]$boShouldCreateNewMapping)  ([ref]$boNeedToRestorePrevMapping)
   #set-psdebug -trace 0

   write-host "The SolutionBuild LogFile is: $myLogFile"  `n
   write-host "Getting the source files." "Mapping workspaces/workfolders and extracting files..."


   $workspace = $null;
   CreateTmpWorkspace ([ref]$workspace) ;  # Create a temporary TFS workspace that we'll use JUST for this build operation.


   # Get the code for the individual TFS projects:
   $projects = $xmldoc.SelectNodes("descendant::TFSproject")
   foreach($proj in $projects)
   {
      $sProjName      = ($proj.ProjName.Trim()).Trim('"')          # "  Trim the double-quotes too.
      $sProjLocalDir  = ($proj.ProjLocalDir.Trim()).Trim('"')      # "
      $sProjLocalDir  =  MakePathAbsolute $sProjLocalDir
      $sProjTreeToGet = ($proj.ProjTreeToGet.Trim()).Trim('"')     # "
      $sLabel         = ($proj.Label.Trim()).Trim('"')             # "

      #write-host "`nMapWorkFolderAndGetCode for  Project: " $sProjName "  ProjLocalDir: " $sProjLocalDir   -foregroundcolor darkgreen
      $iRtn2 = -5523;  # nonsense-ical value

      MapWorkFolderAndGetCode  ([ref]$iRtn2)  $workspace  $sProjName  $sProjLocalDir  $sProjTreeToGet  $sLabel
      write-host "Return value from MapWorkFolderAndGetCode: ($iRtn2)"

      if ( $iRtn2 -ne 0 )
      {
         $sMsg = "The MapWorkFolderAndGetCode failed for Project:`n" + " ($sProjName) with ReturnCode: ($iRtn2)"
         HaltScript  $sMsg
      }
      else
      {
         write-host "Got source files for ("  $sProjName  ")" -foregroundcolor darkgreen
      }
   }



   # ----- Build the solution: ----------
   foreach($conf in $myConfigsToBuild)
   {
      [string]$sConfig = $conf;
      $sConfig = $sConfig.Trim();   # Most important !
      #write-host "myConfigsToBuild: " $myConfigsToBuild
      #write-host "config: ($sConfig)"

      # Some banner info
      $sMsg = "Starting Devenv.exe to build " + $mySlnToBuild   + " (config: " + $sConfig + ")`n"

      $sPathErrors = "";
      $sVSPathPlusFileName = "";
      FindVisualStudioExe $mySlnToBuild  ([ref]$sVSPathPlusFileName) ([ref]$sPathErrors)
      if( $sPathErrors.length -gt 1)
      {
        write-host "`nThe path for VS.NET could not be determined. ($sPathErrors)"  -foregroundcolor red
        exit;
      }
      write-host "`nThe path for VS.NET is:`n  "  $sVSPathPlusFileName



      write-progress "Building the Solution..." $sMsg
      write-host     "Building the Solution...`n" $sMsg   -foregroundcolor darkgreen

      # Start Microsoft VisualStudio, build our Solution file:
      # (Pipe to out-null so the script will wait, and capture $LASTEXITCODE)
      #devenv.exe  $mySlnToBuild  /Build  $sConfig  /out $myLogFile   | out-null

      &($sVSPathPlusFileName)   $mySlnToBuild  /Build  $sConfig  /out $myLogFile   | out-null

      $sCommandLine = "/Build  $sConfig  /out $myLogFile "      # Note variable expansion in the string.


      if ($LASTEXITCODE -ne 0)
      {
         write-host "`nThe build using DevEnv.exe returned:" $LASTEXITCODE   -foregroundcolor red
         write-host "`nThis is NOT a success code !!! "                        # But keep processing this script
         write-host "Please inspect the log file: " $myLogFile "`n"            # But keep processing this script
      }
      else
      {
         $outputFolder =  $myBuildBitsOutputFolder -creplace '\$\(ConfigToBuild\)', $sConfig
         "`nThe Build output should now be in:`n  " + $outputFolder | out-string
      }
   }

   # Now clean up (at least in TFS):
   write-host "Deleting the temporary workspace...";
   $workspace.Delete()  | out-null  # Clean up our temp workspace. (delete via workspace OBJECT, not via name)

   write-host "Resetting the drive mappings..."

   if($boShouldCreateNewMapping )     # If we created a new mapping, remove it now that we're finished with it.
   {
      $sExp = $aReqdMappedDrive[3]
      write-host "Removing the temporary mapping we created: (" $sExp ")"
      Invoke-expression  ($sExp)      # Remove the mapping we created just for this Build.
   }
   if($boNeedToRestorePrevMapping )
   {
      $sExp =  $aPrevMappedDrive[2]
      write-host "Restoring the previously-mapped drive: (" $sExp ")"
      Invoke-expression  ($sExp)       # Re-create the previous mapping
   }

   write-host "-------- Finished ------------"  -foregroundcolor darkgreen
   #set-psdebug -trace 0


} # end function BuildUsingXMLfile



# -------------------------------------------------------------------------------------
# Delete the temporary TFS workspace that we used JUST for this build operation.
# Note that we are deleting the workspace using its NAME.
# Uses global object $g_tfs
function DeleteTmpWorkspaceViaName( $sWorkSpaceName )
{
   $oldErrorAction = $ErrorActionPreference;
   $ErrorActionPreference = "silentlycontinue";   # If the workspace doesn't exist, we'll ignore the error.

   $boOK = $g_tfs.vcs.DeleteWorkspace( $sWorkSpaceName, $g_tfs.vcs.AuthenticatedUser);
   write-host "Result of deletion of previously-existing  workspace (" $sWorkSpaceName "):" $boOK

   $ErrorActionPreference = $oldErrorAction;   # Restore the old setting
}


# -------------------------------------------------------------------------------------
# Create a temporary TFS workspace that we'll use JUST for this build operation.
# $workspace is created and returned.
function CreateTmpWorkspace( [ref]$workspace )
{

   $tfs = $g_tfs;   # Use our gloal singleton TFS object
   if (! $tfs )
   {
      HaltScript   "The creation of the new TFS object (" + $g_myServer + ") failed."
   }

   # First remove any existing Workspace having the specified NAME:  (from a previous run. (ignore errors))
   DeleteTmpWorkspaceViaName  $g_myWSpace;



   # Create a new temporary workspace.
   #[Microsoft.TeamFoundation.VersionControl.Client.Workspace]
   $workspace.value = $tfs.vcs.CreateWorkspace($g_myWSpace, $tfs.vcs.AuthenticatedUser);

   if ($workspace.value -eq $null)
   {
      HaltScript  "The creation of the temporary workspace ($g_myWSpace) failed."
   }
   else
   {
      write-host "Creation of the temporary workspace (" $g_myWSpace ") succeeded.";
   }

   #write-host "`nexiting..." ; exit

   # At this point we have a new workspace, with its root ($/) mapped to our current dir location.
   # This command should confirm it:
   #tf.exe workspaces /format:detailed  $g_myWSpace

}



# -------------------------------------------------------------------------------------
# Look in the solution file to determine the version of VisualStudio that
#  the file was generated by.
# Using the version, find the path to DevEnv.exe by examining the appropriate
#  system environment variable.
# The function can detect these VS.NET versions:
#   VisualStudio 2008, v9.0
#   VisualStudio 2005, v8.0
#   VisualStudio 2003, v7.1
#
function FindVisualStudioExe( $sSLNPathPlusFilename,        # Visual Studio solution file that user wants to 'run'
                              [ref] $sVSPathPlusFilename ,  # Path to visual studio: DevEnv.exe. (returned)
                              [ref] $sRtnErrors )           # Returned: empty means no errors encountered.
{
   [string]$sErrors = "";   # local variable

   if( ! ([System.IO.FileInfo]$sSLNPathPlusFilename).Exists )
   {
     $sErrors = "Solution file not found: " + $sSLNPathPlusFilename
   }
   else
   {
      # Read the first few lines of the Solution file into an array.
      $sSLNlines = (get-content $sSLNPathPlusFilename)[0..3]
      [string]$sVerLine = "";
      [string]$sEnvVar = "";

      $sVerLine = $sSLNlines -like  "*Microsoft Visual Studio Solution File, Format Version*"
      if($sVerLine.Length -gt 0)
      {
        if($sVerLine.Contains("10.00"))         # VisualStudio 2008, v9.0
        {  $sEnvVar = "VS90COMNTOOLS"        }
        elseif ( $sVerLine.Contains("9.00"))    # VisualStudio 2005, v8.0
        {  $sEnvVar = "VS80COMNTOOLS"        }
        elseif ( $sVerLine.Contains("8.00"))    # VisualStudio 2003, v7.1
        {  $sEnvVar = "VS71COMNTOOLS"        }
        else
        {
           $sErrors = "Could not locate VisualStudio version number in the Solution file: " +  $sSLNPathPlusFilename
        }
      }
      else
      {  $sErrors = "Could not locate VisualStudio version line in the Solution file: " +  $sSLNPathPlusFilename
      }
   }


   if($sErrors.length -lt 1)
   {
      # Lookup the path to the Tools dir:
      # It should be something such as: "C:\Program Files\Microsoft Visual Studio 9.0\Common7\Tools\"
      [string]$sPath = [Environment]::GetEnvironmentVariable($sEnvVar, "Machine");
      if($sPath.length -lt 1)
      {
        $sErrors = "Could not locate environment variable for VisualStudio environment variable: " +  $sEnvVar
      }
      else
      {
         $sPathPlusFilename = $sPath.Replace("Tools","IDE") + "DevEnv.exe"
         #write-host "`nThe determined path for vs.net is: " $sPathPlusFilename
         $sVSPathPlusFilename.value =  $sPathPlusFilename   # This is returned.
      }
   }
   $sRtnErrors.value = $sErrors;   # return it  (should be empty if no errors were encountered.)
}




# -------------------------------------------------------------------------------------
# From $sFilename, read all the text and return it as XML in $xmldoc
function ReadInput( $sFilename, [ref]$xmldoc )
{
   $xmldoc.value = [xml] [string]::join("`n", (get-content -ReadCount -1 $sFilename))

   if(0)  # diagnostics...
   {
      $nodes = $xmldoc.value.SelectNodes("Solution")
      write-host "Solution node count: " $nodes.count
      #$nodes
      write-host "xmldoc.value.Solution.SlnToBuild       : " $xmldoc.value.Solution.SlnToBuild
      write-host "xmldoc.value.Solution.BuildBitsOutputFolder: " $xmldoc.value.Solution.BuildBitsOutputFolder
      write-host "xmldoc.value.Solution.ConfigToBuild    : " $xmldoc.value.Solution.ConfigToBuild        # Could be a collection
      write-host "xmldoc.value.Solution.MappedDrive.Drive: " $xmldoc.value.Solution.MappedDrive.Drive
      write-host "xmldoc.value.Solution.MappedDrive.MapTo: " $xmldoc.value.Solution.MappedDrive.MapTo
      $nodes = $xmldoc.value.SelectNodes("descendant::TFSproject") #|  fl  ProjName, ProjLocalDir, ProjTreeToGet, ConfigToBuild, Label
      write-host "Project node count: " $nodes.count
      foreach($n in $nodes)
      {
         write-host "ProjName     : " $n.ProjName
         write-host "ProjLocalDir : " $n.ProjLocalDir
         write-host "ProjTreeToGet: " $n.ProjTreeToGet
         write-host "Label        : " $n.Label
      }
   }
}



# -------------------------------------------------------------------------------------
# The only 'inputs' here are:
#   $aReqdMappedDr[0], this is the DriveLetter that the caller wants mapped. Example: "M:"
#   $aReqdMappedDr[1], this is the MappedLocation for the DriveLetter.       Example: "\\utm-bamtfsnt\bsdev".
# If the requested drive is *already* mapped, then the current mapping
#   info is returned in $aPrevMappedDr.
#
function SetUpInitialDriveMapping( [ref]$aPrevMappedDr,
                                   [ref]$aReqdMappedDr,
                                   [ref]$boShouldCreateNewMap,
                                   [ref]$boNeedToRestorePrevMap
                                 )
{
   # Note: this is what the array elements are:
   #[string]$sDriveLetter     = ($aPrevMappedDr.value)[0]
   #[string]$sMappedTo        = ($aPrevMappedDr.value)[1]
   #[string]$sCodeToCreateMap = ($aPrevMappedDr.value)[2]
   #[string]$sCodeToDelMap    = ($aPrevMappedDr.value)[3]

   if(($aReqdMappedDr.value[0]).length -gt 0)          # If he wants us to map a drive...
   {
      $aPrevMappedDr.value[0] = $aReqdMappedDr.value[0]    # This is the Drive letter
      GetDriveMapping  $aPrevMappedDr                      # Check to see if the required drive letter is already mapped.

      if( (($aPrevMappedDr.value[1]).length -gt 0)  )  # If the drive letter was already mapped... ([1] is 'MappedTo')
      {
         $sMsg2 = "Drive (" + $aPrevMappedDr.value[0] +") is previously mapped to: (" + $aPrevMappedDr.value[1] +")"
         write-host $sMsg2
         #$sMsg3 = "Code to create drive map: " + $aPrevMappedDr.value[2] + "`nCode to delete drive map: " + $aPrevMappedDr.value[3]
         #write-host $sMsg3

         if( $aPrevMappedDr.value[1]  -ne  $aReqdMappedDr.value[1]  )   # If it was NOT mapped to our new location..
         {
            # Remove current mapping...
            write-host ("Removing the mapping: (" + $sMsg2 + ")")
            Invoke-expression  ($aPrevMappedDr.value[3]);       # Execute the code block to remove the current mapping.
            #exit;
            $boNeedToRestorePrevMap.value = $true;   # Used later to determine whether we need to restore the mapping.
            $boShouldCreateNewMap.value   = $true;
         }
         #else it is already mapped to where we want it.
      }
      else
      {
         write-host ("The requested drive (" + $aPrevMappedDr.value[0]  + ") was not previously mapped.");
         $boShouldCreateNewMap.value  = $true;
      }

      if($boShouldCreateNewMap.value)
      {
         write-host ("The requested drive (" + $aReqdMappedDr.value[0]  + ") is now being mapped to (" + $aReqdMappedDr.value[1] + ")." )
         MapDrive  $aReqdMappedDr
      }
   }
}



# -------------------------------------------------------------------------------------
# Map the drive letter specified in $aDriveInfo[0] to the location in $aDriveInfo[1]
# $aDriveInfo  must be a 4 element array of string.
#
function MapDrive( [ref]$aDriveInfo  )
{
   if(($aDriveInfo.value).length -lt 4)
   {
     throw "The drive info array MUST contain 4 elements."
   }

   # Local convenience variables:
   [string]$sDriveLetter     = ($aDriveInfo.value)[0]
   [string]$sMappedTo        = ($aDriveInfo.value)[1]
   [string]$sCodeToCreateMap = ($aDriveInfo.value)[2]
   [string]$sCodeToDelMap    = ($aDriveInfo.value)[3]

   if($sMappedTo.StartsWith("\\") )    # If it is a network-mapped...
   {
      # These are returned to the caller:
      if($sCodeToDelMap    -ne $null)  {$sCodeToDelMap     =  "net use /delete " + $sDriveLetter + " /yes"          }  # 'yes' is the answer to the prompt about "Mapped device is currently in use, delete anyway?"
      if($sCodeToCreateMap -ne $null)  {$sCodeToCreateMap  =  "net use         " + $sDriveLetter + " " + $sMappedTo }
   }
   elseif( $sMappedTo -match '^[A-Z]:$' )    # If it is a SUBST'ed drive mapping...
   {
      # These are returned to the caller:
      if($sCodeToDelMap    -ne $null)   {$sCodeToDelMap     = "SUBST /D  " + $sDriveLetter                     }
      if($sCodeToCreateMap -ne $null)   {$sCodeToCreateMap  = "SUBST     " + $sDriveLetter + "  " + $sMappedTo }
   }
   else
   {
      throw("Mapped-to portion of drive info (" + $sMappedTo + ") was not recognized." )
   }

   # Assign the results that we'll pass back to the caller:
   ($aDriveInfo.value)[2]   =   [string]$sCodeToCreateMap
   ($aDriveInfo.value)[3]   =   [string]$sCodeToDelMap

   Invoke-expression  ($sCodeToCreateMap)  ; # Do the creation

}

# -------------------------------------------------------------------------------------
# ($aDriveInfo.value)[0] is the DriveLetter, and is expected to be populated with
#   something such as "M:" upon entry to this function.
# The function populates the rest of the $aDriveInfo array with information
#   about the mapping for DriveLetter.
# If the DriveLetter is NOT already mapped, the array elements are not set.
function GetDriveMapping( [ref]$aDriveInfo )
{
   # Local convenience variables:
   [string]$sDriveLetter     = ($aDriveInfo.value)[0]    #  $sDriveLetter is expected to look like:  "M:"
   [string]$sMappedTo        = ($aDriveInfo.value)[1]
   [string]$sCodeToCreateMap = ($aDriveInfo.value)[2]
   [string]$sCodeToDelMap    = ($aDriveInfo.value)[3]


   $sMappedTo= ""   # Indicates we haven't found a drive having $sDriveLetter, yet.
   $sDriveLetter = ($sDriveLetter.ToUpper()).Trim();

   # Look for Network drive mapping:  ($sDriveLetter should include the trailing colon).
   # EnumNetworkDrives() returns a zero-based array of strings: EVEN indices hold drives, ODD hold mappings.
   # If the drive array element is empty, then it is just a network share and the network path
   #   is in the next array element.
   $aDrives =  @((new-object -com WScript.Network).EnumNetworkDrives() )

   #write-host "Mapped Network Drives: " $aDrives;  # display

   for($i=0; $i -lt ($aDrives.length); ++$i)
   {
      if($aDrives[$i] -ieq $sDriveLetter)       # note: case-insensitive
      {
          $sMappedTo = $aDrives[$i+1];
          break;
      }
   }

   if($sMappedTo -ne "")    # If it was a network-mapped...
   {
      # These are returned to the caller:
      if($sCodeToDelMap    -ne $null)  {$sCodeToDelMap     = " net use /delete " + $sDriveLetter + " /yes"           }   # 'yes' is the answer to the prompt about "Mapped device is currently in use, delete anyway?"
      if($sCodeToCreateMap -ne $null)  {$sCodeToCreateMap  = " net use "         + $sDriveLetter + "  " + $sMappedTo }
   }

   # ------
   if($sMappedTo -eq "")    # If it wasn't network-mapped, check to see if it was created via SUBST
   {
      # Look for a SUBST'ed drive:  ($drs will be $null if no drives are SUBST'ed)
      $drs = SUBST
      #write-host "Subst results: " $drs
      if( ($drs -ne $null) -and ($drs -ne "") )
      {
         $iCount = $drs.count
         foreach($sLine in $drs)    # $sLine should look like: "M:\: => D:\_M_drive"
         {
           if($sLine.StartsWith($sDriveLetter) )
           {
              $sTmpLine = $sLine.Replace($sDriveLetter+"\: => ", "")
              $sMappedTo= $sTmpLine.Trim()  # after we removed the leading "M:\: =>"
              break;
           }
         }
      }

      if($sMappedTo -ne "" )    # If it was a SUBST-mapped drive...
      {
         # These are returned to the caller:
         if($sCodeToDelMap    -ne $null)   {$sCodeToDelMap     = " SUBST /D  " + $sDriveLetter   }
         if($sCodeToCreateMap -ne $null)   {$sCodeToCreateMap  = " SUBST     " + $sDriveLetter + "  " + $sMappedTo }
      }
   }

   ($aDriveInfo.value)[0]   =   [string]$sDriveLetter
   ($aDriveInfo.value)[1]   =   [string]$sMappedTo
   ($aDriveInfo.value)[2]   =   [string]$sCodeToCreateMap
   ($aDriveInfo.value)[3]   =   [string]$sCodeToDelMap

   #Diagnostic code:
   if(0)
   {
      write-host "DriveInfo array: " ($aDriveInfo.value)
      $sMsgOut =  "Drive is mapped to: (" + $sMappedTo.value + ")"
      write-host $sMsgOut
      write-host "Exiting......."; exit;
   }
}



# -------------------------------------------------------------------------------------
# Credit for this code goes to:
#   James Manning (http://blogs.msdn.com/jmanning/archive/2006/09/28/776141.aspx)
function Get-TFS_X ( [string] $serverName = $(throw 'Get-TFS_X: serverName is required') )
{
   begin
   {
       # load the required dll
       [void][System.Reflection.Assembly]::LoadWithPartialName("Microsoft.TeamFoundation.Client")

       $propertiesToAdd =
       (
         ('VCS'  , 'Microsoft.TeamFoundation.VersionControl.Client'  , 'Microsoft.TeamFoundation.VersionControl.Client.VersionControlServer'),
         ('WIT'  , 'Microsoft.TeamFoundation.WorkItemTracking.Client', 'Microsoft.TeamFoundation.WorkItemTracking.Client.WorkItemStore'),
         ('CSS'  , 'Microsoft.TeamFoundation', 'Microsoft.TeamFoundation.Server.ICommonStructureService'),
         ('GSS'  , 'Microsoft.TeamFoundation', 'Microsoft.TeamFoundation.Server.IGroupSecurityService'),
         ('REG'  , 'Microsoft.TeamFoundation', 'Microsoft.TeamFoundation.Server.IRegistration'),
         ('AUTH' , 'Microsoft.TeamFoundation', 'Microsoft.TeamFoundation.Server.IAuthorizationService'),
         ('EVENT', 'Microsoft.TeamFoundation', 'Microsoft.TeamFoundation.Server.IEventService')
       )
   }

   process
   {
       # Fetch the TFS instance, but add some useful properties to make life easier
       # Make sure to "promote" it to a psobject now to make later modification easier
       [psobject] $tfsLocal = [Microsoft.TeamFoundation.Client.TeamFoundationServerFactory]::GetServer($serverName)
       foreach ($entry in $propertiesToAdd)
       {
           #write-debug ("Adding property: " + $entry[0])
           $scriptBlock = '
               [System.Reflection.Assembly]::LoadWithPartialName("{0}") > $null
               $this.GetService([{1}])
           ' -f $entry[1],$entry[2]
           $tfsLocal | add-member scriptproperty $entry[0] $ExecutionContext.InvokeCommand.NewScriptBlock($scriptBlock)
       }
       return $tfsLocal
   }
}


# -----------------------------------------------------------------------------
#  Using an existing TFS workspace, $oWorkspace (created elsewhere),
#    map $sProjName to the workspace in the $sProjLocalDir.
#    Then 'Get' the source code from the project and put it into $sProjLocalDir.
#  Return value: 0 if successful, non-zero otherwise.
#
function MapWorkFolderAndGetCode( [ref]$iRtn, $oWorkspace, [string]$sProjName,      [string]$sProjLocalDir,
                                                           [string]$sProjTreeToGet, [string]$sLabel )
{
   $iRtn.value = -4   # initial condition: failure

   #[Microsoft.TeamFoundation.VersionControl.Client.WorkingFolder]
   $myworkingfolder =
         new-object -typeName "Microsoft.TeamFoundation.VersionControl.Client.WorkingFolder"   -argumentList $sProjName, $sProjLocalDir

   if($myworkingfolder -ne $null)
   {
      # Create a mapping between the workspace and the working folder:
      $oWorkspace.CreateMapping($myworkingfolder);

      if($sLabel -eq "")   # Empty string means 'get latest version'.
      {
         write-host "The Label is empty."
         $verSpec = [Microsoft.TeamFoundation.VersionControl.Client.VersionSpec]::Latest
      }
      else
      {
         write-host "The Label is: " $sLabel
         #[Microsoft.TeamFoundation.VersionControl.Client.LabelVersionSpec]
         $verSpec =  new-object  -typeName "Microsoft.TeamFoundation.VersionControl.Client.LabelVersionSpec"   -argumentList $sLabel
       }
      if($verSpec -ne $null)
      {
         #"verSpec is: " +$verSpec | out-string
         write-host "Getting Project: " $sProjName "  ProjLocalDir: " $sProjLocalDir  "  ProjTreeToGet: " $sProjTreeToGet -foregroundcolor darkgreen
         # Get the files from the repository.
         $items = ($sProjTreeToGet)
         [Microsoft.TeamFoundation.VersionControl.Client.GetStatus]$Status =
         $oWorkspace.Get( $items, $verSpec,
                         [Microsoft.TeamFoundation.VersionControl.Client.RecursionType]::Full,
                         [Microsoft.TeamFoundation.VersionControl.Client.GetOptions]::Overwrite  -bor
                         [Microsoft.TeamFoundation.VersionControl.Client.GetOptions]::GetAll
                       )  ;
         write-host "Results from GET: "
         $Status ;
         $iRtn.value = ($Status.GetFailures()).Length    # This is returned.

         #$oWorkspace.Get(); # This works too, to get the latest version
      }
      else
      {
         write-host "The call to create the verSpec object failed."
         write-host "verSpec is: " $verSpec
      }
   }
   else
   {
      write-host "Failed creating workingfolder for Project: " $sProjName "  ProjLocalDir: " $sProjLocalDir   -foregroundcolor red
   }
}


# -----------------------------------------------------------------------------
#  'Get' a single file from the TeamFoundationServer source control database.
#  $sLocalDir is the *relative* path on our local machine where the file will be deposited.
#    -'Get' the single file and put it into $sLocalDir.
#  If $sTFSlabel is empty, then the 'latest version' is fetched.
#  Return value (in $sPathPlusFilenameFetched): The fetched filename if successful, empty string otherwise.
#
function GetSingleFileFromTFS( [ref]$sPathPlusFilenameFetched,
                               [string] $sTFSpathPlusFilename, [string] $sTFSlabel, [string] $sLocalDir )
{
   begin
   {
      [void][System.Reflection.Assembly]::LoadWithPartialName("Microsoft.TeamFoundation.VersionControl.Common")
      [void][System.Reflection.Assembly]::LoadWithPartialName("Microsoft.TeamFoundation.VersionControl.Client")
   }

   process
   {
      $iRtn = -4;                            # Initial Error value
      $sPathPlusFilenameFetched.value = ""   # initial condition: failure

      $oTFS = $g_tfs
      if (! $oTFS )  {  HaltScript   "The creation of the new TFS object for (" + $g_myServer + ") failed."  }

      $sTFSFolderName =  [Microsoft.TeamFoundation.VersionControl.Common.VersionControlPath]::GetFolderName( $sTFSpathPlusFilename )

      if($sTFSlabel -eq "")   # Empty string means 'get latest version'.
      {
         write-host "The Label is empty."
         $verSpec = [Microsoft.TeamFoundation.VersionControl.Client.VersionSpec]::Latest
      }
      else
      {
         write-host "The Label is: " $sTFSlabel
         #[Microsoft.TeamFoundation.VersionControl.Client.LabelVersionSpec]
         $verSpec =  new-object  -typeName "Microsoft.TeamFoundation.VersionControl.Client.LabelVersionSpec"   -argumentList $sTFSlabel
       }
      if($verSpec -ne $null)
      {
         #"verSpec is: " +$verSpec | out-string
         $sFilename = [Microsoft.TeamFoundation.VersionControl.Common.VersionControlPath]::GetFileName( $sTFSpathPlusFilename )
         $sRelativePathPlusFilename = [System.IO.Path]::Combine($sLocalDir, $sFilename);
         $sAbsolutePathPlusFilename =  MakePathAbsolute  $sRelativePathPlusFilename

         write-host "Getting single file from TFS...`n   TFSfolder    : " $sTFSpathPlusFilename "`n   LocalFilename: " $sAbsolutePathPlusFilename    -foregroundcolor darkgreen

         $oTFS.vcs.DownloadFile( $sTFSpathPlusFilename, 0, $verSpec,  $sAbsolutePathPlusFilename );
         #Note: if the specified workingFolder string is not an existing folder in TFS, the above call will
         #      throw an exception.  We need to handle it and let our callers
         #      know that the call failed.     (Or do a $ErrorActionPreference = "stop")
         $iRtn = 0   # Success indicator
      }
      else
      {
         write-host "The call to create the verSpec object failed."
         write-host "verSpec is: " $verSpec
      }

      if($iRtn -eq 0)  # If everything worked so far, assign the returned filename.
      {
         $sPathPlusFilenameFetched.value = $sAbsolutePathPlusFilename;
         # This is returned.
      }

   } # end process
}


#------------------------------------------------------------------------------
# If $sPath is a relative path, add our current working directory as a
#   prefix to the $sPath.  If $sPath is already a full absolute path,
#   don't add the prefix.
function MakePathAbsolute( [string]$sPath )
{
   #"Initial path: " + $sPath | out-string   # Outputing stuff here will mess up the function return value !!
   $sPath = ($sPath.Trim()).Trim('"')       #  " Trim double-quotes too.
   $sAbsPath = $sPath
   if( ($sAbsPath -match '^[A-Za-z]:') -or ($sAbsPath.StartsWith("\\"))  )   # If it is already an absolute path...
   {     }
   else
   {
      $sAbsPath = [System.IO.Path]::Combine($PWD,$sAbsPath);  # Note: $PWD is the current dir that the caller may have CD'ed to.
   }
   return $sAbsPath
}

# -------------------------------
function Test_MakePathAbsolute()
{
   $sPath = ".\foo"
   write-host "Initial path: " $sPath  "  Absolute path: " (MakePathAbsolute $sPath)
   $sPath = "C:\.\foo"
   write-host "Initial path: " $sPath  "  Absolute path: " (MakePathAbsolute $sPath)
   $sPath = "d:foo"
   write-host "Initial path: " $sPath  "  Absolute path: " (MakePathAbsolute $sPath)
   $sPath = "\\foo\bar\ouch.txt"
   write-host "Initial path: " $sPath  "  Absolute path: " (MakePathAbsolute $sPath)
   $sPath = "foo.txt"
   write-host "Initial path: " $sPath  "  Absolute path: " (MakePathAbsolute $sPath)
}



 #------------------------------------------------------------------------------
 # Note that we are logging to the file called $g_sLogFilename AND to the host screen.
 # If you call this with an arg that is built by concatting strings, then
 #   you should put parens around the strings. Otherwise no parens are necessary.
 #   Examples:
 #     LogMsg ("Hi " + "there " + $name)
 #     LogMsg  $yourMsg
 function LogMsg( [string]$sMsg )
 {
     [datetime]::now.ToString()+ ": " + $sMsg | add-content -Path $g_sLogFilename -encoding ascii -force
     write-host $sMsg
 }


#------------------------------------------------------------------------------
function HaltScript( [string]$sMsg )
{
   "`nSomething FAILED.... please check your Build input values and/or logfile:`n  (" +  $myLogFile + ")." | out-string
   $sMsg | out-string
   "Exiting the script now." | out-string
    exit  100  # failure
}


#--------------------------------------------------------------------------------
#-------------- Start Here ------------------------------------------------------
# This is where execution of our functions actually begins:

$g_tfs = Get-TFS_X  ("http://" + $g_myServer + ":8080")    # I can only call this ONCE. (so I re-use the same object in multiple places)

#write-host "PreMain::CmdLine: $args`n"  -foregroundcolor black
Main $args



