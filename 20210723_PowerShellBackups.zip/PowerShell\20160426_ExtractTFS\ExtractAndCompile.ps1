﻿[void][Reflection.Assembly]::Load(“Microsoft.TeamFoundation.Client, Version=11.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a”);
[void][System.Reflection.Assembly]::LoadWithPartialName("Microsoft.TeamFoundation.Client") 
[void][System.Reflection.Assembly]::LoadWithPartialName("Microsoft.TeamFoundation.VersionControl.Client")  
[void][System.Reflection.Assembly]::LoadWithPartialName("Microsoft.TeamFoundation.VersionControl.Client.VersionSpec")  
Add-PSSnapin Microsoft.TeamFoundation.PowerShell


#Input Data
$productCode = "CI"
$currentVersion = "4.4.0.65.0"
$targetVerion = "4.4.0.67.0"

$deployDirectory = "\\melyw0599\Datashare\TFS"
#filters to specify compile order
$filter1 = 'v'
$filter2 = 'f'
$filter3 = 't'

#Set options 
$SET_OPTIONS = "set quoted_identifier on;
set ansi_nulls on;"

#Globals variables
$tfsUrl = "http://tfsprod.oceania.cshare.net:8080/tfs/CPU"
$versionDatabase = "DBA_ProductVersion_DEV"
$versionServer = "CSODEVSQL42INS3\INS3"

#Get the user credentials
$user = "Oceania\AluthwattaM"
$file = "C:\Manoj\Password.txt"
$credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $user, (Get-Content $file | ConvertTo-SecureString)


#Clear the deploy directory
Remove-Item $deployDirectory\* -recurse

$tfs = new-object Microsoft.TeamFoundation.Client.TfsTeamProjectCollection $tfsUrl, $Credential
$tfsVCS = $tfs.GetService("Microsoft.TeamFoundation.VersionControl.Client.VersionControlServer")


$global:totalFiles = 0

function Extract-Files-From-TFS
{
    param($tfsPath, $copyPath, $tfsLabel)    

    $label = New-Object Microsoft.TeamFoundation.VersionControl.Client.LabelVersionSpec($tfsLabel)
    $items = Get-TfsChildItem $tfsPath -Server $tfs -Recurse 
    
    $filesCopied = 0

    foreach ($item in $items) {
        Write-Host $($item.ServerItem)

        $destinationPath = $item.ServerItem.Replace($tfsPath, $copyPath)
    
        if ($item.ItemType -eq "Folder") {
            New-Item $([IO.Path]::GetFullPath($destinationPath)) -ItemType Directory -Force | Out-Null
        }
        else {
            # Download the file (not folder) to destination directory
            $tfsVCS.DownloadFile($item.ServerItem, $null, $label, $([IO.Path]::GetFullPath($destinationPath)))
            $filesCopied++
            $global:totalFiles++
        }
    }
    Write-Host "Files extracted from TFS: $filesCopied`n"
    
}

function Query-Label
{
    param($tfsPath, $tfsLabel)
    return $tfsVCS.QueryLabels($tfsLabel, $tfsPath, $null, $false)   
}


function Compile-SPs{

    param($server, $database, $file_path) 


    #sort the order by applying the filters
    $FileList = get-childitem $file_path\*  -Recurse | Where-Object { $_.Attributes -ne "Directory"} | `
        Select-Object Name, @{name="SortOrder";Expression={switch -Wildcard ($_.Name){"$filter1*"{5} "$filter2*"{4} "$filter3*"{3} default{0}}}}, FullName | `
        Sort-Object SortOrder -Descending | Select-Object Name, FullName


    Write-Host  ("-" * 20)
    Write-host "Executing on $server`.$database ..." 

    $success_count = 0
    $error_count = 0


    foreach ($file in $FileList)
    {
        $input_file = $file.FullName
        write-host $input_file
        try
        {
            $success_count += 1
            Invoke-Sqlcmd -query $SET_OPTIONS -ServerInstance $server -database $database -ErrorAction Stop -Verbose -QueryTimeout 1800 # 30min
            Invoke-Sqlcmd -InputFile $input_file -ServerInstance $server -database $database -ErrorAction Stop -Verbose -QueryTimeout 1800 # 30min
        }
        catch
        {
            write-host "Error: $($_.Exception.Message)" -ForegroundColor Red
            $error_count += 1
            $success_count -= 1                
        }
    }
    
    Write-Host "Scripts executed: $success_count" -ForegroundColor Green
    If ($error_count -gt 0)
    {
        Write-Host "Scripts failed: $error_count" -ForegroundColor Red   
    }
}




try
{
    #Get all the labels
    $sql_labels = "
    exec dbo.p_get_component_labels
	    @ProductCode = '$productCode'
	    ,@FromVersion = '$currentVersion'
	    ,@ToVersion = '$targetVerion'
    "

    $results = invoke-sqlcmd -query $sql_labels -serverinstance $versionServer -database $versionDatabase -QueryTimeout 3000 

    foreach ($result in $results) {

        $label_exists = Query-Label -tfsPath $result.TFSPath -tfsLabel $result.Label
        if (!$label_exists)
        {
            $errorMsg = "Label not found `nComponent: $($result.ComponentName) `nLabel: $($result.Label)"
            Throw $errorMsg            
        }
        else
        {            
            $component = $($result.ComponentName)
            $copyPath = $deployDirectory + "\"+ $productCode + "\" + "v" + $currentVersion + "-v" + $targetVerion + "\" + $component
            $tfsSQLpath = $($result.TFSPath) + $($result.SQLRelPath)
            $tfsLabel = $($result.Label)
            Write-Host "Component: $component"
            Write-Host "Source: $tfsSQLpath"
            Write-Host "Destination: $copyPath"
            Write-Host "Label: $tfsLabel`n"
            Extract-Files-From-TFS -tfsPath $tfsSQLpath -copyPath $copyPath -tfsLabel $tfsLabel
        }
    }
    Write-Host "Total files extracted: $global:totalFiles`n" -ForegroundColor Green


    Write-Host "Compiling sp's..."
    Compile-SPs -server "CSODEVSQL42INS3\INS3" -database "CI_AluthwattaM_BASE_ALL" -file_path $deployDirectory
    

}
Catch
{
    $ErrorMessage = $_.Exception.Message
    $FailedItem = $_.Exception.ItemName
    Write-Host $ErrorMessage -ForegroundColor Red
    Write-Host $FailedItem -ForegroundColor Red
}
