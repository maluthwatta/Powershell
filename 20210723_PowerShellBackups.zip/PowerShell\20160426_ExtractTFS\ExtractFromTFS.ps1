﻿<#
Manoj Aluthwatta 06/05/2016
Ref: https://nkdagility.com/powershell-tfs-2013-api-1-get-tfscollection-and-tfs-services/
#>


function Get-TfsCollection {
 Param(
       [string] $CollectionUrl,
       [System.Management.Automation.PSCredential] $Credential
       )

    $tfs = new-object Microsoft.TeamFoundation.Client.TfsTeamProjectCollection $CollectionUrl, $Credential

    Return $tfs
}


function Get-TfsVersionControlServer {
    Param(
        [Microsoft.TeamFoundation.Client.TfsTeamProjectCollection] $TfsCollection
        )
    Return $TfsCollection.GetService("Microsoft.TeamFoundation.VersionControl.Client.VersionControlServer")
}



[Reflection.Assembly]::Load(“Microsoft.TeamFoundation.Client, Version=11.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a”);
$tfsUrl = "http://tfs.cshare.net:8080/tfs/global"
$credential = Get-Credential


#$tfsConnection = Get-TfsCollection $tfsUrl, $credential

$tfsConnection = new-object Microsoft.TeamFoundation.Client.TfsTeamProjectCollection $tfsUrl , $credential
$tfsConnection.Authenticate()


$tfs = Get-TfsVersionControlServer $tfsConnection

# Register PowerShell commands
Add-PSSnapin Microsoft.TeamFoundation.PowerShell


$dir = "$/DBA OCEANIA/Development/Applications/TestMA"

# Get all directories and files in the AutoDeploy directory
$items = Get-TfsChildItem $dir -Recurse

$items