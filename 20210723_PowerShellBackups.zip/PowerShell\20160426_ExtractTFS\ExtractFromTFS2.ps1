﻿$picker = New-Object Microsoft.TeamFoundation.Client.TeamProjectPicker([Microsoft.TeamFoundation.Client.TeamProjectPickerMode]::NoProject, $false)
$dialogResult = $picker.ShowDialog()
if ($dialogResult -ne "OK")
{
    #exit
}

$tfs = $picker.SelectedTeamProjectCollection
$tfsVCS = $tfs.GetService("Microsoft.TeamFoundation.VersionControl.Client.VersionControlServer")

#$tfsVCS.TeamProjectCollection
#$files = $tfsVCS.GetItems("$/DBA OCEANIA/Development/Applications/TestMA")
#$tfsVCS | gm

$tfsPath = "$/DBA OCEANIA/Development/Applications/TestMA"     
$deployDirectory = "\\melyw0599\Datashare\TFS"
$label = "Label_MA_20160511_1402"


$label_obj = New-Object Microsoft.TeamFoundation.VersionControl.Client.LabelVersionSpec($label)

#$tfsVCS.GetAllTeamProjects(0)
#$tfsVCS.GetTeamProject("DBA OCEANIA")
#$project = $tfsVCS.GetTeamProject("DBA OCEANIA")
#$project | gm

#Add-PSSnapin Microsoft.TeamFoundation.PowerShell

$items = Get-TfsChildItem $tfsPath -Server $tfs -Recurse 

foreach ($item in $items) {
    Write-Host "TFS item to download:" $($item.ServerItem)

    $destinationPath = $item.ServerItem.Replace($tfsPath, $deployDirectory)

    if ($item.ItemType -eq "Folder") {
        New-Item $([IO.Path]::GetFullPath($destinationPath)) -ItemType Directory -Force
    }
    else {
        # Download the file (not folder) to destination directory
        $tfsVCS.DownloadFile($item.ServerItem, $null, $label_obj, $([IO.Path]::GetFullPath($destinationPath)))
        #$tfsVCS.DownloadFile($item.ServerItem, $([IO.Path]::GetFullPath($destinationPath)))
    }
}


#$history = Get-TfsItemHistory $tfsPath -Server $tfs -Version "Test" -Recurse -IncludeItems 
#Get-TfsItemHistory $tfsPath -Server $tfs -Recurse -IncludeItems 


<#
public VersionControlLabel[] QueryLabels(
	string labelName,
	string labelScope,
	string owner,
	bool includeItems,
	string filterItem,
	VersionSpec versionFilterItem
)
https://msdn.microsoft.com/en-us/library/bb138963(v=vs.120).aspx

Label_MA_20160511

#>

<#
$labels = $tfsVCS.QueryLabels('Label_MA_20160511',$tfsPath,$null,$true)
$lastlabel = $labels | Select-Object -last 1
write-host $lastlabel.Name
write-host $lastlabel.LabelID


$tfsVCS | gm
#>