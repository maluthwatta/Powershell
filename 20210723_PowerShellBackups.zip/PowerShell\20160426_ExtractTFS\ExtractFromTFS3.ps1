﻿[Reflection.Assembly]::Load(“Microsoft.TeamFoundation.Client, Version=11.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a”);

$tfsUrl = "http://tfsprod.oceania.cshare.net:8080/tfs/CPU"
#$tfsUrl = "http://tfs.cshare.net:8080/tfs/global"

$tfsPath = "$/Investor/Development/Cosmos Investor/Trunk/Code/SQL Objects"     
$deployDirectory = "\\melyw0599\Datashare\TFS"
$label = "End of Development - CIM 4.12.0"

#Get the user credentials
$User = "Oceania\AluthwattaM"
$File = "C:\Manoj\Password.txt"
$credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $User, (Get-Content $File | ConvertTo-SecureString)


#Clear the deploy directory
Remove-Item $deployDirectory\* -recurse


$tfs = new-object Microsoft.TeamFoundation.Client.TfsTeamProjectCollection $tfsUrl, $Credential
$tfsVCS = $tfs.GetService("Microsoft.TeamFoundation.VersionControl.Client.VersionControlServer")

$global:totalFiles = 0

function Extract-Files-From-TFS
{
    param($tfs_location, $local_path, $tfs_label)    

    $label_obj = New-Object Microsoft.TeamFoundation.VersionControl.Client.LabelVersionSpec($label)
    $items = Get-TfsChildItem $tfsPath -Server $tfs -Recurse 
    
    
    foreach ($item in $items) {
        Write-Host "TFS item to download:" $($item.ServerItem)

        $destinationPath = $item.ServerItem.Replace($tfsPath, $deployDirectory)
    
        if ($item.ItemType -eq "Folder") {
            New-Item $([IO.Path]::GetFullPath($destinationPath)) -ItemType Directory -Force | Out-Null
        }
        else {
            # Download the file (not folder) to destination directory
            $tfsVCS.DownloadFile($item.ServerItem, $null, $label_obj, $([IO.Path]::GetFullPath($destinationPath)))
            $global:totalFiles++
        }
    }
    
}

function Query-Label
{
    param($tfs_location, $label)

    return $tfsVCS.QueryLabels($label, $tfs_location, $null, $false)

    
}

#########################################################


#Check if the label exists. 

$labels = Query-Label -tfs_location $tfsPath -label $label
if (!$labels)
{
    Write-Host "Label NOT found" -ForegroundColor Red
}
else
{
    Write-Host "Labelfound" -ForegroundColor Green
}


<#

Extract-Files-From-TFS -tfs_location $tfsPath -local_path $deployDirectory -tfs_label $label

Write-Host "Download Location: "$deployDirectory -ForegroundColor Green
Write-Host "Total files downloaded: "$global:totalFiles -ForegroundColor Green
#>