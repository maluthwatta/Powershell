﻿
#Save Password
(Get-Credential).Password | ConvertFrom-SecureString | Out-File "C:\Manoj\Password.txt"


#Retrieve Password
$User = "Oceania\AluthwattaM"
$File = "C:\Manoj\Password.txt"
$MyCredential=New-Object -TypeName System.Management.Automation.PSCredential `
 -ArgumentList $User, (Get-Content $File | ConvertTo-SecureString)

$MyCredential