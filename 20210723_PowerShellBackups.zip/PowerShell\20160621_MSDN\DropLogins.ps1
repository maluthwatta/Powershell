﻿<#
LoginName = "'OCEANIA\#AUCTSQLMonitor'"
LoginName = "NULL"
#>
$LoginName = "NULL"

<#
ServerName = "'CSODEVSQL42INS2\INS2'"
ServerName = "NULL"
#>
$ServerName = "CSODEVSQL42INS4\INS4"


$runQuery = $FALSE ##### BEWARE THIS WILL RUN THE SCRIPT
$generateSQL = $FALSE #### Generate the SQL query to be run

#Snapshot database details
$SnapshotServer = "CSODEVSQL45"
$SnapshotDatabase = "zDBA_MSDN_Access_UnitTest2"


$sqlLogins =   
    "SELECT DISTINCT ServerLoginsMasterID, ServerName, LoginName
    FROM dbo.ServerLoginsMaster
    WHERE LoginName = ISNULL($LoginName, LoginName)
    AND ServerName = ISNULL($ServerName, ServerName)
    AND HasBeenProcessed = 0 
    AND ProcessAutomatically = 1"

$results = invoke-sqlcmd -query $sqlLogins -serverinstance $SnapshotServer -database $SnapshotDatabase -QueryTimeout 3000 

Write-Output "Dropping Logins >>"

foreach ($result in $results)
{
    try
    {        
        $sqlDropLogin = "IF EXISTS 
                        (SELECT name  
                         FROM master.sys.server_principals
                         WHERE name = '$($result.LoginName)')
                         BEGIN
                            DROP LOGIN [$($result.LoginName)];
                         END"
        
        Write-Output "Server: $($result.ServerName) `t Login: $($result.LoginName)"
        
        if ($generateSQL)
        {
            Write-Output $sqlDropLogin`n
        }

        if ($runQuery)
        {            
            invoke-sqlcmd -query $sqlDropLogin -serverinstance $($result.ServerName) -database 'master' -QueryTimeout 3000 
        }          

        $sqlUpdateDrop = "UPDATE dbo.ServerLoginsMaster SET HasBeenProcessed = 1, ProcessedDatetime = Getdate() WHERE ServerLoginsMasterID = $($result.ServerLoginsMasterID);"

        if ($generateSQL)
        {
            Write-Output $sqlUpdateDrop`n
        }

        if ($runQuery)
        {            
            invoke-sqlcmd -query $sqlUpdateDrop -serverinstance $SnapshotServer -database $SnapshotDatabase -QueryTimeout 3000 
            Write-Output "Login $($result.LoginName) dropped"
        }

    }
    catch
    {
        $errorMessage = $_.Exception.Message
        $failedItem = $_.Exception.ItemName
        $processError = ""
        $sqlUpdateDrop = "UPDATE dbo.ServerLoginsMaster SET HasBeenProcessed = 0, ProcessedDatetime = Getdate(), Comments = $failedItem - $errorMessage
        WHERE ServerLoginsMasterID = $($result.ServerLoginsMasterID)"
        Write-Output $sqlUpdateDrop
        if ($runQuery)
        {            
            invoke-sqlcmd -query $sqlUpdateDrop -serverinstance $SnapshotServer -database $SnapshotDatabase -QueryTimeout 3000 
            Write-Output "Login $($result.LoginName) dropped" -ForegroundColor Red
        }
    }                    
} 

Write-Output "< Complete >"
