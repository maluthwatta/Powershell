﻿<#
LoginName = "'oceania\!AU CT COSMOS Investor Dev Admin'"
LoginName = "NULL"
#>
$LoginName = "NULL"

<#
ServerName = "'CSODEVSQL42INS2\INS2'"
ServerName = "NULL"
#>
$ServerName = "NULL"


$runQuery = $FALSE ##### BEWARE THIS WILL RUN THE SCRIPT
$generateSQL = $FALSE #### Generate the SQL query to be run

#Snapshot database details
$SnapShotServer = "CSODEVSQL45"
$SnapShotDatabase = "zDBA_MSDN_Access_UnitTest2"

$sqlFindServers = 
"
SELECT slp.ServerName, slp.LoginName, ISNULL(PermissionType, 'ROLE') As PermissionType, slp.permission_name as PermissionName, slm.ServerLoginsMasterID 
FROM dbo.ServerLevelPermissons slp INNER JOIN 
	dbo.ServerLoginsMaster slm ON slm.ServerName = slp.ServerName
	AND slm.LoginName = slp.LoginName
	AND slm.HasBeenProcessed = 1 
WHERE slp.LoginName = ISNULL($LoginName, slp.LoginName)
AND slp.ServerName = ISNULL($ServerName, slp.ServerName)
ORDER BY slp.ServerName, CASE slp.permission_name 
	WHEN 'CONNECT SQL' Then 1
	Else 2
	END 
"

$results = invoke-sqlcmd -query $sqlFindServers -serverinstance $SnapShotServer -database $SnapShotDatabase -QueryTimeout 3000 
foreach ($result in $results)
{  
    $sqlToRun = ""

    switch ($result.PermissionType)
    {        
        "COSQ" {   #CONNECT SQL     
            $sqlToRun = "
            IF NOT EXISTS 
                (SELECT name  
                    FROM master.sys.server_principals
                    WHERE name = '$($result.LoginName)')
            BEGIN
                CREATE LOGIN [$($result.LoginName)] FROM WINDOWS WITH DEFAULT_DATABASE = TEMPDB 
            END
            "       
        }
                
        "ROLE" { #Add Server Role
            $sqlToRun = "exec sp_addsrvrolemember @loginame= '$($result.LoginName)', @rolename = '$($result.PermissionName)'"
        }

        default { #Add server permission
            $sqlToRun = "GRANT $($result.PermissionName) TO [$($result.LoginName)]"
        }
    }

    Write-Output "Server: $($result.ServerName) `t $($result.LoginName) `t $($result.PermissionType) `t $($result.PermissionName)"


    $sqlUpdateLoginRollBack = "UPDATE dbo.ServerLoginsMaster SET HasBeenProcessed = 0, ProcessedDatetime = Getdate(), Comments = 'Login Rolledback'
        WHERE ServerLoginsMasterID = $($result.ServerLoginsMasterID)"

    if ($generateSQL){
        Write-Output $sqlToRun`n
        Write-Output $sqlUpdateLoginRollBack`n
    }

    if ($runQuery){
        Try{
            invoke-sqlcmd -query $sqlToRun -serverinstance $($result.ServerName) -database 'master' -QueryTimeout 3000 
            invoke-sqlcmd -query $sqlUpdateLoginRollBack -serverinstance $SnapShotServer -database $SnapShotDatabase -QueryTimeout 3000 
        }
        catch
        {
            Write-Output $_.Exception.Message  -ForegroundColor Red
            Write-Output $_.Exception.ItemName  -ForegroundColor Red
        }

    }
}        

