﻿$database = 'CC_MA'
$server = 'CSODEVSQL42INS3\INS3'
$table = 'dbo.CC_IndexStats_AU'

$csv_file = "Z:\PowerShell\20160808_ImportTabDelimitedFile\TabDelimitedFile.csv"


$data = Import-Csv -Delimiter "`t" -Path $csv_file


foreach ($row in $data){
    "INSERT INTO $table VALUES('$($row.ObjectName)', '$($row.IndexName)', $($row.Reads),$($row.Writes)) " 
       
}




<#
Import-CSV $csv_file | ForEach-Object {Invoke-Sqlcmd `
  -Database $database -ServerInstance $server `
  -Query "insert into $table VALUES ('$($_.IndexName)','$_.ObjectName','$_.Reads','$_.Writes')"
  }
#>

<#

$tableName = 'CC_IndexStats_AU'
$data = Import-Csv -Delimiter "`t" -Path Z:\PowerShell\20160808_ImportTabDelimitedFile\TabDelimitedFile.csv

$data | gm

$data | foreach-object {
    write-output "insert into $tablename VALUES ('$_.IndexName','$_.ObjectName')"
}
#>



<#
$data | get-member -type NoteProperty | foreach-object {
  $name=$_.Name ; 
  $value=$data."$($_.Name)"
  write-host "$name = $value"
}
#>

#$sql = "INSERT INTO $tableName"

<#

INSERT INTO MyTable ( Column1, Column2 ) VALUES
( Value1, Value2 ), ( Value1, Value2 )

#>