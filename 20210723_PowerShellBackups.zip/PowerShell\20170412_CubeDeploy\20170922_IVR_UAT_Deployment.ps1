﻿$debug = $false
$cubeScript = “\\oceania\CTS\DEPTDATA\Development\DatabaseAdmins\Development\AluthwattaM\PowerShell\20170412_CubeDeploy\XmlaScriptDeploy.ps1”

#Run the cube creation script
$argumentList1  = '\\Csofile2\ivr\Reporting\SQL2016_ProjectDeploymentFiles\UAT_SSAS\4_Process_Cube_IVRConnection.xmla', 'CSOVUATSQL20'
if ($debug)
{
    $argumentList1
}
else
{
    Invoke-Expression "$cubeScript $argumentList1"
}
