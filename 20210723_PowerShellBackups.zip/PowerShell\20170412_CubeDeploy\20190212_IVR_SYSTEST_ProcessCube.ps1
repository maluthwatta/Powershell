﻿<#
param(
     [string]$CubeXmlaFilePath
    ,[string]$AnalysisServicesServer
)
#>

$debug = $false
$ssas_server = 'CSOVDEVSQL26' 
$cubeScript = “Z:\PowerShell\20170412_CubeDeploy\XmlaScriptDeploy.ps1”

#Loop throught the other scripts and run
$FileSource = '\\Csofile2\ivr\Reporting\2019_GOS_ReleaseProcess\SysTest\2_SSAS_AlterCube\*.xmla'
$ScriptList = Get-ChildItem -Path $FileSource -Exclude '0_Alter_IVRReportingSysTest_Cube_Structure_Updated.xmla' | where { ! $_.PSIsContainer }

foreach ($xmlaScript in $ScriptList) {
    $argumentList  = $xmlaScript.FullName, $ssas_server    
    if ($debug)
    {
        $argumentList
    }
    else
    {
        Invoke-Expression "$cubeScript $argumentList"
    }
}