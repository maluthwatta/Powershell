﻿<#
param(
     [string]$CubeXmlaFilePath
    ,[string]$AnalysisServicesServer
)
#>

$debug = $false
$ssas_server = 'CSOVDEVSQL26' 
$cubeScript = “\\oceania\cts\DEPTDATA\Development\DatabaseAdmins\Development\AluthwattaM\PowerShell\20170412_CubeDeploy\XmlaScriptDeploy.ps1”

#Loop throught the other scripts and run
$FileSource = '\\Csofile2\ivr\Reporting\2019_GOS_ReleaseProcess\DEV\SSAS\*.xmla'
$ScriptList = Get-ChildItem -Path $FileSource -Exclude '00_Alter_IVR ReportingDEV_Cube_Structure.xmla' | where { ! $_.PSIsContainer }

foreach ($xmlaScript in $ScriptList) {
    $argumentList  = $xmlaScript.FullName, $ssas_server    
    if ($debug)
    {
        $argumentList
    }
    else
    {
        Invoke-Expression "$cubeScript $argumentList"
    }
}