﻿<#
param(
     [string]$CubeXmlaFilePath
    ,[string]$AnalysisServicesServer
)
#>

$debug = $false

$cubeScript = “Z:\PowerShell\20170412_CubeDeploy\XmlaScriptDeploy.ps1”

#Loop throught the other scripts and run
$FileSource = '\\Csofile2\ivr\Reporting\SQL2016_ProjectDeploymentFiles\UAT_SSAS\*.xmla'
$ScriptList = Get-ChildItem -Path $FileSource -Exclude '1_IVR_UAT_SQL2016_Create_Cube.xmla' | where { ! $_.PSIsContainer }

foreach ($xmlaScript in $ScriptList) {
    $argumentList  = $xmlaScript.FullName, 'CSOVUATSQL20'    
    if ($debug)
    {
        $argumentList
    }
    else
    {
        Invoke-Expression "$cubeScript $argumentList"
    }
}