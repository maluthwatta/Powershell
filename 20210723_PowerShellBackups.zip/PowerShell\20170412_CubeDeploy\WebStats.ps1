﻿<#
param(
     [string]$CubeXmlaFilePath
    ,[string]$AnalysisServicesServer
)
#>

$debug = $true

$cubeScript = “Z:\PowerShell\20170412_CubeDeploy\XmlaScriptDeploy.ps1”

#Run the cube creation script
$argumentList1  = '\\csofile2\Webstats\UAT\cubeProcess\00_CreateWST_UAT_CubeDB_SQL2008Script.xmla', 'CSOVUATSQL20'
if ($debug)
{
    $argumentList
}
else
{
    Invoke-Expression "$cubeScript $argumentList1"
}


$response = Read-Host -Prompt 'Install the assembly and then press Y to continue' 
if (($response -eq 'y') -or ($response -eq 'Y'))
{
    
}
else
{
    break   
}


#Loop throught the other scripts and run
$FileSource = '\\csofile2\WebStats\UAT\cubeProcess\SQL2016\*.xmla'
$ScriptList = Get-ChildItem -Path $FileSource -Exclude '00_CreateWST_UAT_CubeDB_SQL2008Script.xmla' | where { ! $_.PSIsContainer }

foreach ($xmlaScript in $ScriptList) {
    $argumentList  = $xmlaScript.FullName, 'CSOVUATSQL20'    
    if ($debug)
    {
        $argumentList
    }
    else
    {
        Invoke-Expression "$cubeScript $argumentList"
    }
}