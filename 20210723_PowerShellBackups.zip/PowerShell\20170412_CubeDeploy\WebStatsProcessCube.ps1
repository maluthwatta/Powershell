﻿<#
param(
     [string]$CubeXmlaFilePath
    ,[string]$AnalysisServicesServer
)
#>

$debug = $false

$cubeScript = “\\oceania\cts\DEPTDATA\Development\DatabaseAdmins\Development\AluthwattaM\PowerShell\20170412_CubeDeploy\XmlaScriptDeploy.ps1”

#Loop throught the other scripts and run
$FileSource = '\\Csofile2\ivr\Reporting\201801_IVRSurveyUpgrade\SSAS\Prod_Process_Cube\*.xmla'
$ScriptList = Get-ChildItem -Path $FileSource -Exclude '1_IVR_UAT_SQL2016_Create_Cube.xmla' | where { ! $_.PSIsContainer }

foreach ($xmlaScript in $ScriptList) {
    $argumentList  = $xmlaScript.FullName, 'CSOVUATSQL20'    
    if ($debug)
    {
        $argumentList
    }
    else
    {
        Invoke-Expression "$cubeScript $argumentList"
    }
}