﻿param(
    [string]$CubeXmlaFilePath
    ,[string]$AnalysisServicesServer
)

    Write-host "XmlaFilePath:    $CubeXmlaFilePath"
    Write-host "Analysis Server: $AnalysisServicesServer"

try
{
    $CubeXmlaFilePath = $CubeXmlaFilePath.Replace('"',"")
    $AnalysisServicesServer = $AnalysisServicesServer.Replace('"',"")
    $qry = [string](get-content $CubeXmlaFilePath)
    $amo = "Microsoft.AnalysisServices"
    [System.Reflection.Assembly]::LoadWithPartialName($amo) > $null
    $svr = New-Object Microsoft.AnalysisServices.Server
    $svr.Connect($AnalysisServicesServer) | out-null
    $startTime = Get-Date 
    $svr.Execute($qry) | out-null
    $endTime = Get-Date

    $timeDiff = NEW-TIMESPAN –Start $startTime –End $endTime

    $diffHours = $timeDiff.Hours.ToString()
    $diffMinutes = $timeDiff.Minutes.ToString()
    $diffSeconds = $timeDiff.Seconds.ToString()

    Write-host "Execution Time - Hours: $diffHours, Minutes: $diffMinutes, Seconds: $diffSeconds"
    Write-host "------------------------------------"

}
Catch
{
    Write-Host "Error in script" -ForegroundColor RED 
    Write-Host $_.Exception.Message
    Write-Host $_.Exception.ItemName
    Write-host "------------------------------------"
}    