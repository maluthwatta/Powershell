﻿\\oceania\CTS\DEPTDATA\Development\DatabaseAdmins\Development\AluthwattaM\PowerShell\20170511_AG_Creation\PutDBinDAG_SKIPbackup.ps1 `
    -DBName "GDE_Test_AG" `
    -DAGName "DEVSQLAG33L01" `
    -PrimaryNode "melyvdevsql33\ins1" `
    -ReplicaNode "meldvdevsql33\ins1"  `
    -BackupLocation "\\OCEANIA\SQLNonProdBackups\CSODEVSQLAG33\DEVSQLAG33L01\GDE_Test_AG\"  