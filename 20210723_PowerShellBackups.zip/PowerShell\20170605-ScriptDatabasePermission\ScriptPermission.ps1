﻿param 
( 
    [string]$server, 
    [string]$database
)


# USERS
$sql_users = "SELECT NAME FROM sys.database_principals 
WHERE TYPE_DESC IN ('WINDOWS_GROUP', 'SQL_USER', 'WINDOWS_USER') 
AND [NAME] NOT IN ('dbo', 'guest', 'INFORMATION_SCHEMA', 'sys')
ORDER BY [NAME]"

$users = invoke-sqlcmd -query $sql_users -serverinstance $server -database $database -QueryTimeout 3000 

foreach ($user in $users)
{
Write-Host "IF NOT EXISTS(SELECT 1 FROM sys.database_principals WHERE NAME = '$($user.Name)')
	CREATE USER [$($user.Name)];
Go"
}

# ROLE PERMISSIONS
$sql_role_permission = 
"SELECT DP1.name AS DatabaseRoleName,   
   DP2.name AS DatabaseUserName   
 FROM sys.database_role_members AS DRM  
 RIGHT OUTER JOIN sys.database_principals AS DP1  
   ON DRM.role_principal_id = DP1.principal_id  
 LEFT OUTER JOIN sys.database_principals AS DP2  
   ON DRM.member_principal_id = DP2.principal_id  
WHERE DP1.type = 'R' and (DP2.name is not null) and DP2.name <> 'dbo'
ORDER BY DP1.name;"

$roles = invoke-sqlcmd -query $sql_role_permission -serverinstance $server -database $database -QueryTimeout 3000 

foreach ($role in $roles)
{
    Write-Host "exec sp_addrolemember [$($role.DatabaseRoleName)],[$($role.DatabaseUserName)];"
    Write-Host "Go"
}


