﻿
#[string[]]$Databases = "CI_AU_HO_BSG",	"CI_AU_HO_DEV_WEB",	"CI_AU_HO_ESB_SYSTEST_TSC",	"CI_AU_HO_IVP",	"CI_AU_HO_PRODSUPP",	"CI_AU_HO_REGTECH",	"CI_AU_HO_SYSTEST_INTONLN",	"CI_AU_HO_WEB_HYC",	"CI_AU_SIT_WEB_LNX",	"CI_AU_Training_V4_3",	"CI_AU_UAT_BSG",	"CI_AU_UAT_DATAWH",	"CI_AU_UAT_DEV_WEB",	"CI_AU_UAT_ESB_SYSTEST_TSC",	"CI_AU_UAT_IVP",	"CI_AU_UAT_REGTECH",	"CI_AU_UAT_SYSTEST_INTONLN",	"CI_AU_UAT_WEB_HYC",	"CI_AU_UAT_WEB_LNX",	"CI_INVTEST",	"CI_TEMPDB"


#################################################
# STOP LOG BACKUPS FIRST IF THIS A LARGE DATABASE
#################################################


[string[]]$Databases = "Gds_CC_Handover"



<#
#Create the backup directories
foreach ($database in $Databases) {
    $path = "\\OCEANIA\SQLNonProdBackups\CSODEVSQLAG33\DEVSQLAG33L03\$database\" 
    New-Item $path -type directory
}
#>


#Add to AG
foreach ($database in $Databases) {
    $BackupPath = "\\OCEANIA\SQLNonProdBackups\CSODEVSQLAG33\DEVSQLAG33L02\$database\" 

    \\oceania\CTS\DEPTDATA\Development\DatabaseAdmins\Development\AluthwattaM\PowerShell\20171114-AG_Dan_NEW\PutDBinDAG.ps1 `
    -DBName $database `
    -DAGName "DEVSQLAG33L02" `
    -PrimaryNode "MELYVDEVSQL33\INS1" `
    -ReplicaNode "MELDVDEVSQL33\INS1"  `
    -BackupLocation $BackupPath  
}


