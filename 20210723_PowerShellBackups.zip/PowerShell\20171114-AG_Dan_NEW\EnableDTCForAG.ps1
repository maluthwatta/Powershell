﻿PARAM
(
	[String]$AGListenerConnStr
)


#$AGListenerConnStr = "DEVSQLAG33L03,20000"

$DAGName = $AGListenerConnStr.Split(",")[0]

$AGReplicas = Invoke-SqlCmd `
    -ServerInstance $AGListenerConnStr `
    -Database "master" `
    -Query "select ar.replica_server_name,arstates.role_desc `
            from sys.availability_groups ag `
            inner join sys.availability_replicas ar on ag.group_id = ar.group_id `
            inner join sys.dm_hadr_availability_replica_states arstates ON AR.replica_id = arstates.replica_id  `
            where ag.name =  '$DAGName'"

If ($AGReplicas.ItemArray.Count -lt 1)
{
    Write-Host "`tERROR: We don't seem to be able to find replica servers= on $DAGName." -ForegroundColor Red
    EXIT
}
else
{
    $PrimaryReplica   = $AGReplicas | where {$_.role_desc -eq "PRIMARY"}   | select replica_server_name 
    $PR = $PrimaryReplica[0].replica_server_name
    $SecondaryReplica = $AGReplicas | where {$_.role_desc -eq "SECONDARY"} | select replica_server_name
}


# _________________________________________________________________________________________________
# Run some validations.
# _________________________________________________________________________________________________
Write-Host "Checking to see if the the AG is eligible for turn on DTC ..."

$AGDTCCheck = Invoke-SqlCmd `
    -ServerInstance $PR `
    -Database "master" `
    -Query "select name, dtc_support from sys.availability_groups where name = '$DAGName'"

$DBList = Invoke-SqlCmd `
    -ServerInstance $PR `
    -Database "master" `
    -Query "select distinct db_name(database_id) as name,synchronization_health_desc, s.truncation_lsn from sys.dm_hadr_database_replica_states S  inner join sys.availability_groups G  on s.group_id=g.group_id where g.name = '$DAGName'"

If ($AGDTCCheck.ItemArray.Count -lt 0)
{
    Write-Host "`tAG DTC Configuration checking: Failed" -ForegroundColor Red
    EXIT
}

If ($AGDTCCheck.dtc_support -eq 1)
{
    Write-Host "`tAG DTC Configuration checking: Failed"
    Write-Host "`tERROR: DTC is already supported on $DAGName." -ForegroundColor Red
    EXIT
}
Else
{
    Write-Host "`tDTC Configuration checking: Passed"
}

If ($DBList.ItemArray.Count -lt 0)
{
    Write-Host "`tGenerating DB checking list: Failed" -ForegroundColor Red
    EXIT
}

If ($DBList.synchronization_health_desc -in "PARTIALLY_HEALTHY", "NOT_HEALTHY")
{
    Write-Host "`tDB checking: Failed"
    Write-Host "`tERROR: Some databases in $DAGName are not HEALTHY, Please fix them before running this script." -ForegroundColor Red
    EXIT
}
Else
{
    Write-Host "`tDB checking: Passed"
}


# _________________________________________________________________________________________________
# Gathering existing AG configrations, SMO
# _________________________________________________________________________________________________

# Load SMO
[System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.SMO") | out-null

$SQLObj = New-Object "Microsoft.SqlServer.Management.Smo.Server" $PR
$SQLObj.ConnectionContext.Connect()

foreach ($ag in ($SQLObj.AvailabilityGroups ))
{
    if ($ag.Name -eq $DAGName)
    {
        $AGName = $ag.Name

        $scriptr = new-object ('Microsoft.SqlServer.Management.Smo.Scripter') ($SQLObj)
        $AGCreationScript = $scriptr.Script($ag)
        ## convert stringcollection to string
        $AGCreationScript = $AGCreationScript | out-string
        
        # _________________________________________________________________________________________________
        # Need to search DTC_SUPPORT = NONE, and replace to DTC_SUPPORT = PER_DB,
        # _________________________________________________________________________________________________

		$AGCreationScript = $AGCreationScript -replace "DTC_SUPPORT = NONE,", "DTC_SUPPORT = PER_DB,"

    }
}

# _________________________________________________________________________________________________
# Looping thru each secondary replicas and remove the DBs from the AG
# _________________________________________________________________________________________________
$ErrorCount = 0

foreach ($SecRep in $SecondaryReplica)
{
    $SR = $SecRep.replica_server_name
    
    foreach ($DB in $DBList)
    {
        $DBName = $DB.Name
        Write-Host "Removing $DBName from $SR ..."

        try
        {
            Invoke-Sqlcmd -ServerInstance $SR -Database "master" -Query "ALTER DATABASE $DBName SET HADR OFF;" -ErrorAction Stop -QueryTimeout 0
        }
        catch
        {
            $ErrorCount++
            Write-Host "`tERROR: We are unable to remove $DBName from $SR in this $DAGName ." -ForegroundColor Red
            Write-Host $Error -ForegroundColor Red
            EXIT
        }
    }
}

# _________________________________________________________________________________________________
#  remove the DBs from the AG on Primary Node
# _________________________________________________________________________________________________
if ($ErrorCount -eq 0)
{
    Write-Host "Removing $DBName from $PR ..."

    foreach ($DB in $DBList)
    {
        $DBName = $DB.Name

        try
        {
            Invoke-Sqlcmd -ServerInstance $PR -Database "master" -Query "ALTER AVAILABILITY GROUP $DAGName REMOVE DATABASE $DBName;" -ErrorAction Stop -QueryTimeout 0
        }
        catch
        {
            $ErrorCount++
            Write-Host "`tERROR: We are unable to remove $DBName from $PR in this $DAGName ." -ForegroundColor Red
            Write-Host $Error -ForegroundColor Red
            EXIT
        }
    }

}


# _________________________________________________________________________________________________
#  Drop AG
# _________________________________________________________________________________________________
if ($ErrorCount -eq 0)
{
    Write-Host "Drop $DAGName on $PR ..."
    try
        {
            Invoke-Sqlcmd -ServerInstance $PR -Database "master" -Query "DROP AVAILABILITY GROUP $DAGName ;" -ErrorAction Stop -QueryTimeout 0
        }
        catch
        {
            $ErrorCount++
            Write-Host "`tERROR: We are unable to drop $DAGName on $PR ." -ForegroundColor Red
            Write-Host $Error -ForegroundColor Red
            EXIT
        }
}

# _________________________________________________________________________________________________
#  recreate AG with the script that just scripted out and swapped
# _________________________________________________________________________________________________

if ($ErrorCount -eq 0)
{
    Write-Host "Re-creating $DAGName on $PR ..."
    try
            {
                Invoke-Sqlcmd -ServerInstance $PR -Database "master" -Query $AGCreationScript -ErrorAction Stop -QueryTimeout 0
            }
            catch
            {
                $ErrorCount++
                Write-Host "`tERROR: We are unable to create $DAGName on $PR ." -ForegroundColor Red
                Write-Host $Error -ForegroundColor Red
                EXIT
            }

    foreach ($SecRep in $SecondaryReplica)
    {
        $SR = $SecRep.replica_server_name
        try
            {
                Invoke-Sqlcmd -ServerInstance $SR -Database "master" -Query "ALTER AVAILABILITY GROUP $DAGName JOIN;" -ErrorAction Stop -QueryTimeout 0
            }
            catch
            {
                $ErrorCount++
                Write-Host "`tERROR: We are unable to enable $DAGName on $SR ." -ForegroundColor Red
                Write-Host $Error -ForegroundColor Red
                EXIT
            }
    }
}

# _________________________________________________________________________________________________
#  checking each DBs last LSN on the PR
# _________________________________________________________________________________________________
if ($ErrorCount -eq 0)
{
    foreach ($SecRep in $SecondaryReplica)
    {
        $SR = $SecRep.replica_server_name
   
        foreach ($DB in $DBList)
        {
            $DBName = $DB.Name
            $LSNFrom = $DB.truncation_lsn

            $Query = "SELECT  'restore database '+b.database_name+' from disk= ''' +f.physical_device_name+''' with norecovery' as query_to_execute `
                      FROM MSDB.DBO.BACKUPMEDIAFAMILY F INNER JOIN MSDB.DBO.BACKUPSET B ON (f.media_set_id=b.media_set_id) `
                      WHERE database_name = '$DBName' and first_lsn >= $LSNFrom "
                

            $MissingLSNList = Invoke-Sqlcmd -ServerInstance $PR -Database "master" -Query $Query

            If ($MissingLSNList.ItemArray.Count -ge 1)
            {
                Write-Host "Applying missing LSN to the database $DBName on Secondary Replica $SR ..."
                foreach ($query in $MissingLSNList)
                {
                    $queryApplyLSN = $query.query_to_execute
                     try
                        {
                            Invoke-Sqlcmd -ServerInstance $SR -Database "master" -Query $queryApplyLSN -ErrorAction Stop -QueryTimeout 0
                        }
                        catch
                        {
                            $ErrorCount++
                            Write-Host "`tERROR: We are unable to remove $DBName from $PR in this $DAGName ." -ForegroundColor Red
                            Write-Host $Error -ForegroundColor Red
                            EXIT
                        }
                    
                }
            
            }

            if ($ErrorCount -eq 0)
            {
                Write-Host "Adding the database $DBName into AlwaysOn on Secondary Replica $SR ..."
                try
                    {
                        Invoke-Sqlcmd -ServerInstance $SR -Database "master" -Query "ALTER DATABASE $DBName SET HADR AVAILABILITY GROUP = $DAGName; " -ErrorAction Stop -QueryTimeout 0
                    }
                    catch
                    {
                        $ErrorCount++
                        Write-Host "`tERROR: We are unable to put $DBName into $DAGName in $SR." -ForegroundColor Red
                        Write-Host $Error -ForegroundColor Red
                        EXIT
                    }     
            }

       
        }
   }
}

# _________________________________________________________________________________________________
# Script has been run successfully.
# _________________________________________________________________________________________________
if ($ErrorCount -eq 0)
{
    Write-Host "The script has been completed."
}
