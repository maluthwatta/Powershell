
PARAM
(
	[String]$DBName,
	[String]$DAGName,
	[String]$PrimaryNode,
	[String]$ReplicaNode,
	[String]$BackupLocation
)

Import-Module SqlPs -DisableNameChecking

# _________________________________________________________________________________________________
# Finding out the primary and secondary replica.
# _________________________________________________________________________________________________
Write-Host "Gathering the primary and secondary replica information ..."

$PrimaryReplica = Invoke-SqlCmd `
    -ServerInstance $ReplicaNode `
    -Database "master" `
    -Query "select b.primary_replica from sys.availability_groups a inner join sys.dm_hadr_availability_group_states b on a.group_id = b.group_id where name = '$DAGName'"

If ($PrimaryReplica.ItemArray.Count -lt 1)
{
    Write-Host "`tERROR: We don't seem to be able to find $DAGName group on $ReplicaNode." -ForegroundColor Red
    EXIT
}
$PrimaryReplicaName = $PrimaryReplica[0]

$PR = $PrimaryNode

$SecondaryReplica = Invoke-SqlCmd `
    -ServerInstance $ReplicaNode `
    -Database "master" `
    -Query "select replica_server_name from sys.dm_hadr_availability_replica_cluster_nodes where group_name = '$DAGName' and replica_server_name <> '$PrimaryReplicaName'"

Write-Host "`tHigh Availability Group: $DAGName"
Write-Host "`tPrimary Replica: $PR"

If ($SecondaryReplica.ItemArray.Count -lt 1)
{
    Write-Host "`tSecondary Replica: N/A"
    Write-Host "`tWARNING: We don't seem to be able to find any secondary replica for $DAGName group." -ForegroundColor Yellow
}
else
{
    Write-Host "`tSecondary Replica(s):"
    foreach ($SecRep in $SecondaryReplica)
    {
        Write-Host "`t`t" $SecRep.replica_server_name
    }
}

# _________________________________________________________________________________________________
# Run some validations.
# _________________________________________________________________________________________________
Write-Host "Checking to see if the database is eligible for Always On ..."
$DatabaseCheck = Invoke-SqlCmd `
    -ServerInstance $PR `
    -Database "master" `
    -Query "select name, state, recovery_model, group_database_id from sys.databases where name = '$DBName'"

If ($DatabaseCheck.ItemArray.Count -lt 0)
{
    Write-Host "`tDatabase Exists: Failed"
    Write-Host "`tERROR: Database $DBName does not exist in $PR." -ForegroundColor Red
    EXIT
}
Else
{
    Write-Host "`tDatabase Exists: Passed"
}

If ($DatabaseCheck.name -in "master", "model", "tempdb", "msdb")
{
    Write-Host "`tSystem Database: Failed"
    Write-Host "`tERROR: Database $DBName in $PR is a system database." -ForegroundColor Red
    EXIT
}
Else
{
    Write-Host "`tSystem Database: Passed"
}

If ($DatabaseCheck.state -ne 0)
{
    Write-Host "`tDatabase Online: Failed"
    Write-Host "`tERROR: Database $DBName is not online in $PR." -ForegroundColor Red
    EXIT
}
Else
{
    Write-Host "`tDatabase Online: Passed"
}

If ($DatabaseCheck.recovery_model -ne 1)
{
    Write-Host "`tFull Recovery Mode: Failed"
    Write-Host "`tERROR: Database $DBName is not in full recovery mode in $PR." -ForegroundColor Red
    EXIT
}
Else
{
    Write-Host "`tFull Recovery Mode: Passed"
}

If ($DatabaseCheck.group_database_id -eq $null)
{
    Write-Host "`tDatabase in AlwaysOn: Failed"
    Write-Host "`tERROR: Database $DBName in $PR is already part of Always On." -ForegroundColor Red
    EXIT
}
Else
{
    Write-Host "`tDatabase in AlwaysOn: Passed"
}

# _________________________________________________________________________________________________
# Start adding the database into AlwaysOn availability group.
# _________________________________________________________________________________________________
If ($SecondaryReplica.ItemArray.Count -ge 1)
{
    # Do a full backup of the database in the primary replica
    Write-Host "Do a full backup of $DBName in $PR ..."
    $FullTs = get-date -format yyyyMMddHHmm
    $FullBackup = "{0}{1}{2}{3}{4}" -f $BackupLocation, $DBName, ".Full.", $FullTs, ".bak"

    try
    {
        Backup-SqlDatabase -ServerInstance $PR -Database $DBName -BackupFile $FullBackup -BackupAction Database -CompressionOption On
    }
    catch
    {
        Write-Host "`tERROR: We are having problem backing up $DBName in $PR." -ForegroundColor Red
        Write-Host $Error -ForegroundColor Red
        EXIT
    }

    Write-Host "`tThe full backup of $DBName in $PR has been completed successfully."

    # Do a transaction log backup of the database in the primary replica
    Write-Host "Do a transaction log backup of $DBName in $PR ..."
    $TLogTs = get-date -format yyyyMMddHHmm
    $TLogBackup = "{0}{1}{2}{3}{4}" -f $BackupLocation, $DBName, ".Log.", $TLogTs, ".trn"

    try
    {
        Backup-SqlDatabase -ServerInstance $PR -Database $DBName -BackupFile $TLogBackup -BackupAction Log -CompressionOption On
    }
    catch
    {
        Write-Host "`tERROR: We are having problem backing up $DBName in $PR." -ForegroundColor Red
        Write-Host $Error -ForegroundColor Red
        EXIT
    }

    Write-Host "`tThe transaction log backup of $DBName in $PR has been completed successfully."

    # Restore the database in secondary replica(s)
    $QueryFullBackup = Invoke-SqlCmd `
        -ServerInstance $PR `
        -Database "msdb" `
        -Query "SELECT TOP 1 m.physical_device_name AS BackupPath FROM msdb.dbo.backupset s INNER JOIN msdb.dbo.backupmediafamily m ON s.media_set_id = m.media_set_id WHERE s.database_name = '$DBName' AND s.type = 'D' ORDER BY backup_start_date DESC, backup_finish_date;"

    $FullBackupPath = $QueryFullBackup.BackupPath

    $QueryTLogBackup = Invoke-SqlCmd `
        -ServerInstance $PR `
        -Database "msdb" `
        -Query "SELECT TOP 1 m.physical_device_name AS BackupPath FROM msdb.dbo.backupset s INNER JOIN msdb.dbo.backupmediafamily m ON s.media_set_id = m.media_set_id WHERE s.database_name = '$DBName' AND s.type = 'L' ORDER BY backup_start_date DESC, backup_finish_date;"

    $TLogBackupPath = $QueryTLogBackup.BackupPath
	
	$dbfilelist = Invoke-SqlCmd `
	-ServerInstance $PR `
	-Database "master" `
	-Query "SELECT db.name AS dbname, type_desc AS FileType, mf.name, Physical_Name AS filename FROM sys.master_files mf INNER JOIN  sys.databases db ON db.database_id = mf.database_id WHERE db.name = '$DBName'"


    foreach ($SecRep in $SecondaryReplica)
    {
        $SR = $SecRep.replica_server_name
        
		Write-Host "Checking $DBName File Path on $SR before the restore ..."
		
	   foreach ($file in $dbfilelist)
	   {
		  $filepath = Split-Path -Path $file.filename

		  $filepathexist = Invoke-SqlCmd `
				-ServerInstance $SR `
				-Database "master" `
				-Query "EXEC master.dbo.xp_fileexist '$filepath'"
	  
		if ($filepathexist[0] -eq $true -or $filepathexist[1] -eq $true) {
			 Write-Host "'$filepath' exists on '$SR'"
		}
		else
		{
			 $createfilepath = Invoke-SqlCmd `
				-ServerInstance $SR `
				-Database "master" `
				-Query "EXEC master.dbo.xp_create_subdir '$filepath'"

			Write-Host "'$filepath' has been created on '$SR'"
		}
		
	   }
		
		Write-Host "Restoring the $DBName into $SR from full backup ..."
        try
        {
            Restore-SqlDatabase -ServerInstance $SR -Database $DBName -BackupFile $FullBackupPath -NoRecovery -ReplaceDatabase -ErrorAction Stop
        }
        catch
        {
            Write-Host "`tERROR: We are having problem restoring $DBName onto $SR." -ForegroundColor Red
            Write-Host $Error -ForegroundColor Red
            EXIT
        }

        Write-Host "`tThe database $DBName has been successfully restored in $SR."

        Write-Host "Restoring the $DBName into $SR from tlog backup ..."

        try
        {
            Restore-SqlDatabase -ServerInstance $SR -Database $DBName -BackupFile $TLogBackupPath -NoRecovery -RestoreAction Log -ErrorAction Stop
        }
        catch
        {
            Write-Host "`tERROR: We are having problem restoring $DBName onto $SR." -ForegroundColor Red
            Write-Host $Error -ForegroundColor Red
            EXIT
        }

        Write-Host "`tThe database $DBName has been successfully restored in $SR."
    }

    # We are ready to put the database into Always On
    Write-Host "Adding the database $DBName into AlwaysOn on Primary Replica $PR ..."

    try
    {
        Invoke-Sqlcmd -ServerInstance $PR -Database "master" -Query "ALTER AVAILABILITY GROUP $DAGName ADD DATABASE $DBName;" -ErrorAction Stop -QueryTimeout 0
        #Add-SqlAvailabilityDatabase -Path "SQLSERVER:\SQL\$PR\AvailabilityGroups\$DAGName" -Database $DBName
    }
    catch
    {
        Write-Host "`tERROR: We are unable to put $DBName into $DAGName in $PR." -ForegroundColor Red
        Write-Host $Error -ForegroundColor Red
        EXIT
    }

    Write-Host "`tThe database $DBName is now in $DAGName in $PR."

    foreach ($SecRep in $SecondaryReplica)
    {
        $SR = $SecRep.replica_server_name

        Write-Host "Adding the database $DBName into AlwaysOn on Secondary Replica $SR ..."

        try
        {
            Invoke-Sqlcmd -ServerInstance $SR -Database "master" -Query "ALTER DATABASE $DBName SET HADR AVAILABILITY GROUP = $DAGName;" -ErrorAction Stop -QueryTimeout 0
            #Add-SqlAvailabilityDatabase -Path "SQLSERVER:\SQL\$SR\AvailabilityGroups\$DAGName" -Database $DBName
        }
        catch
        {
            Write-Host "`tERROR: We are unable to put $DBName into $DAGName in $SR." -ForegroundColor Red
            Write-Host $Error -ForegroundColor Red
            EXIT
        }

        Write-Host "`tThe database $DBName is now in $DAGName in $SR."
    }
}
else
{
    # The High Availability Group does not currently have secondary replica. At this point, we will put the database into the group.
    Write-Host "Adding the database $DBName into AlwaysOn on Primary Replica $PR ..."

    try
    {
        Invoke-Sqlcmd -ServerInstance $PR -Database "master" -Query "ALTER AVAILABILITY GROUP $DAGName ADD DATABASE $DBName;" -ErrorAction Stop -QueryTimeout 0
        #Add-SqlAvailabilityDatabase -Path "SQLSERVER:\SQL\$PR\AvailabilityGroups\$DAGName" -Database $DBName
    }
    catch
    {
        Write-Host "`tERROR: We are unable to put $DBName into $DAGName in $PR." -ForegroundColor Red
        Write-Host $Error -ForegroundColor Red
        EXIT
    }

    Write-Host "`tThe database $DBName is now in $DAGName in $PR."
}

# _________________________________________________________________________________________________
# Script has been run successfully.
# _________________________________________________________________________________________________
Write-Host "The script has been completed."