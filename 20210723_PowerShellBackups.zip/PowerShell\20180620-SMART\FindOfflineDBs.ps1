﻿$SMARTServer = "CSOVDEVSQL34\INS1"
$SMARTDB = "SMART_AU_NonProd"


$sql = "select i.ComponentName as 'InstanceName', d.ComponentName as 'DatabaseName', d.StateDesc as 'StateDesc'
from rep.SQLDatabase d
inner join rep.SQLInstance i on i.ComponentID = d.ParentComponentID
where d.StateDesc <> 'ONLINE'
order by i.ComponentTypeName,i.ComponentName, d.ComponentName"


$sqlout = Invoke-Sqlcmd -ServerInstance $SMARTServer -Database $SMARTDB -Query $sql `
		-ErrorVariable sqlerr -ErrorAction 'Stop' -Verbose -OutputSqlErrors 1 -querytimeout ([int]::MaxValue)

$sqlout | Format-Table -GroupBy InstanceName -AutoSize -Property DatabaseName, StateDesc >> "C:\temp\psout.txt"
