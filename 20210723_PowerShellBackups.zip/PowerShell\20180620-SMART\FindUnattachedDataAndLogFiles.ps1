﻿$LogFile = "\\oceania\cts\DEPTDATA\GPandD\DBA\DBA_DeptData\PSScripts\ScriptLogs\FindUnattachedDataAndLogFiles.log"

$server = "csodevsql42ins3\ins3"
$profile = "DBMAIL_CSODEVSQL42INS3"
$recipeintsList = "Manoj.Aluthwatta@computershare.com.au"
$subjectMail = "Unattached Data and Log Files"

$SMART_Report_Path = "\\csofile2\dba_smart\SMART_AU_NonProd\SMART_Reports\"
$Report_Mask = "SMART_DataFiles_AllUnattached_"

$DateTimeReport = get-date -f "yyyyMMdd"
$Report_Search_Mask = $Report_Mask + $DateTimeReport + '*'

try
{
	$LatestReport = Get-Childitem –Path $SMART_Report_Path -Filter $Report_Search_Mask 
	$ReportFullPath = $LatestReport.FullName
	
	$execStr = "exec sp_send_dbmail @profile_name='$profile', @recipients='$recipeintsList', @subject='$subjectMail', @file_attachments='$ReportFullPath';"
	Invoke-Sqlcmd -ServerInstance $server -Database 'msdb' -Query $execStr -ErrorAction Stop -QueryTimeout 65535 -Verbose	
}
catch
{
	$_.Exception.Message  >>  $LogFile;
	$_.Exception.ItemName >>  $LogFile;
}
