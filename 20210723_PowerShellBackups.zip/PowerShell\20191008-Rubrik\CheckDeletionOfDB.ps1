DO{
    $exists = Get-RubrikDatabase  | Where-Object {$_.EffectiveSlaDomainName -eq 'Unprotected' -and  $_.Name -Like 'DBA_MA_DB1'}
    Start-Sleep -s 60
} Until ($null -eq $exists)

Write-Host "Finished" -ForegroundColor Green
