
<#
$credential = Get-Credential
$credential | Export-CliXml -Path 'Y:\PowerShell\20191008-Rubrik\cred.xml'
#>


Import-Module Rubrik 

$Credential = Import-CliXml -Path 'C:\Powershell\cred.xml'
Connect-Rubrik -Server 10.144.240.14 -Credential $Credential

