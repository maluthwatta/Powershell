

# Details about a Rubrik Database 

$all = Get-RubrikDatabase -ID 'MssqlDatabase:::bf149171-efc7-4b87-a631-3d0a0f5f8f77'
$all.psobject.properties |  foreach-object { 
	$name = $_.Name 
	$value = $_.value
	"$name = $value"
}
