Get-Module Rubrik
	Import-Module Rubrik (if above does not return anything)
	Get-Module Rubrik

$Credential = Get-Credential
Connect-Rubrik -Server 10.144.240.14 -Credential $Credential

Get-Help Connect-Rubrik 
Get-Help Connect-Rubrik -Full  (Examples)


Get-RubrikVersion

Get-RubrikSLA
Get-RubrikSLA -SLA 'SLA-CSOVDEVSQL13-Test01-MA'   (Specific SLA)

All commands
https://github.com/rubrikinc/rubrik-sdk-for-powershell/tree/master/Rubrik/Public


##Create a new SLA 
New-RubrikSLA -SLA 'SLA-CSOVDEVSQL13-Test01-MA-PS' -HourlyFrequency 4 -HourlyRetention 7 -DailyFrequency 1 -DailyRetention 30 -BackupStartHour 22
    -BackupStartMinute 00 -BackupWindowDuration 8


##Create a snapshot
Get-RubrikDatabase 'DBA_MA_TEST2' | New-RubrikSnapshot -ForceFull -SLA 'SLA-CSOVDEVSQL13-Test01-MA'

#Get all the snapshots 
Get-RubrikDatabase -Name 'DBA_MA_TEST2' | Get-RubrikSnapshot 
Get-RubrikDatabase -Name 'DBA_MA_TEST2' | Get-RubrikSnapshot -OnDemandSnapshot

#List protected count
Get-RubrikDatabase  | Where-Object {$_.EffectiveSlaDomainName -ne 'Unprotected'} | Group-Object -Property EffectiveSlaDomainName | Sort-Object -Property Count -Descending

#List all unprotected
Get-RubrikDatabase  | Where-Object {$_.EffectiveSlaDomainName -eq 'Unprotected'} 

#Unprotect a database
Get-RubrikDatabase -Name "DBA_MA_DB1" | Protect-RubrikDatabase -DoNotProtect

#Details about a database 
$all = Get-RubrikDatabase -ID 'MssqlDatabase:::02eedf3f-6787-4ab3-ba56-a2c73e032f61'
$all.psobject.properties |  foreach-object { 
	$name = $_.Name 
	$value = $_.value
	"$name = $value"
}
