﻿$domain = "oceania.cshare.net" # oceania, emea, americas #
$group = "AU CTS SEC SQL DBA CSOVDEVSQLAG33 INS1 SVC"
#$group = "!AU CT ALL SQL Dev Admins"

#get-adgroupmember -Server $domain -Identity $group #| Select-Object SamAccountName where distinguishedName 


#Get the emails of the users in a group


Get-ADGroupMember -Identity $group -Recursive | 
Get-ADUser -Properties Mail | 
Select-Object Name #,Mail #| 
#Export-CSV -Path C:\file.csv -NoTypeInformation



#Get-ADGroupMember -Identity $group -Recursive | 
#Get-ADUser -Filter * -SearchBase "DC=oceania,DC=cshare,DC=net"


#Get-ADGroupMember -Identity $group -Recursive | 
#Get-ADUser -identity SamAccountName

#-Filter * -SearchBase "DC=oceania,DC=cshare,DC=net"


#-Properties Mail |
#Select-Object Name,Mail 