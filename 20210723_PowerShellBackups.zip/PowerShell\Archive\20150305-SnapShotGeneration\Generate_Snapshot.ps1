﻿# --------------------------- #
# Manoj Aluthwatta 05/03/2015 #
#-----------------------------#

####################################

$server = "CSODEVSQL42INS3\INS3"
$database = "CI_AluthwattaM_BASE_ALL"

#######################################


# Add the pssnapin 
<#
if ( (Get-PSSnapin -Name SqlServerCmdletSnapin100 -ErrorAction SilentlyContinue) -eq $null )
{
    Add-PsSnapin SqlServerCmdletSnapin100
}

if ( (Get-PSSnapin -Name SqlServerProviderSnapin100 -ErrorAction SilentlyContinue) -eq $null )
{
    Add-PsSnapin SqlServerProviderSnapin100
}
#>


$sql_dbinfo = "
select name, physical_name 
from master.sys.master_files
WHERE database_id = db_id('$database')
and type_desc = 'ROWS'
"

$dateStr = Get-Date -format "yyyyMMddhhmmss"
$snapshot = "$($database)_$($dateStr)_SS"

$sql_db_create = "CREATE DATABASE $snapshot ON"
$sql_snapshot = "AS SNAPSHOT OF $database"
write-host $sql_db_create

$results = invoke-sqlcmd -query $sql_dbinfo -serverinstance $server -database $database -QueryTimeout 3000

$firstPass = $true
$sql_all_files = ""

foreach($result in $results)
{
    $filename = "$(split-path -parent $result.physical_name)\$($database)_$($result.name)_$dateStr.SS"
    if ($firstPass)
    {
        $sql_create = "(NAME = $($result.name), FILENAME = '$filename')" 
    }
    else
    {
        $sql_create = ",(NAME = $($result.name), FILENAME = '$filename')" 
    }
    $firstPass = $false
    $sql_all_files += $sql_create
    write-host $sql_create
}

write-host $sql_snapshot
$sql_full = $sql_db_create + $sql_all_files + $sql_snapshot
invoke-sqlcmd -query $sql_full -serverinstance $server -database $database -QueryTimeout 3000
write-host "Snapshot $snapshot created...." -ForegroundColor Red

