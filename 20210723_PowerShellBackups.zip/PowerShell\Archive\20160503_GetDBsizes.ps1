﻿# --------------------------- #
# Manoj Aluthwatta 03/05/2016 #
#-----------------------------#

$Server=”CSODEVSQL42INS3\INS3”      
$db_mask = "GDE[_]%"

$sql_db = "
SELECT NAME FROM SYS.DATABASES 
WHERE NAME NOT IN ('master', 'model', 'msdb', 'aaDBA', 'zDBA')
AND NAME LIKE '$db_mask'
ORDER BY NAME
"

$dbs = invoke-sqlcmd -query $sql_db  -serverinstance $Server -database "master" -QueryTimeout 3000 

$sql_db_file_details = "
select
	NAME
	,FILENAME 
	,(size*8/1024.0) as _FileSize_MB_
	,((size*8/1024.0))-(fileproperty(name,'SpaceUsed')*8/1024.0) as _FreeSpace_MB_
	,fileproperty(name,'SpaceUsed')*8/1024.0 as _SpaceUsed_MB_
	,FILEGROUP_Name (groupid) as FileGroup
	,case
		when fileproperty(name, 'IsLogFile') = 1 then 'Log'
		else 'Data'
	end as _FG_Usage_
	,case 
		when FILEGROUPPROPERTY ( FILEGROUP_Name (groupid) , 'IsDefault') = 1 then 'DEFAULT' 
		else '''' 
	end as _Default_FG_ 
	,case 
		when status&0x100000 = 0 then 1024*8 
		else 1 
	end as growthfactor --pages or percent
	,growth
	,maxsize
from dbo.sysfiles
"

ForEach ($db in $dbs)
{
    $db_details = invoke-sqlcmd -query $sql_db_file_details -serverinstance $Server -database $db.NAME -QueryTimeout 3000 

    Write-Host $db.name
    $underline = "-"*($db.name).Length

    Write-Host $underline

    
    
    Write-Host "NAME" `t "File Size(MB)" `t "Free Space(MB)" `t "Space Used(MB)"

    ForEach ($db_detail in $db_details | Sort-Object -Property _FG_Usage_, NAME) 
    {
        $fileSize = [math]::Round($db_detail._FileSize_MB_)
        $freeSpace = [math]::Round($db_detail._FreeSpace_MB_)
        $SpaceUsed = [math]::Round($db_detail._SpaceUsed_MB_)
        Write-Host $db_detail.NAME, $fileSize , $freeSpace, $SpaceUsed
    }

    Write-Host
   
     
}

<#     

[System.Reflection.Assembly]::LoadWithPartialName(“Microsoft.SqlServer.SMO”) | out-null
$SMOserver = New-Object (‘Microsoft.SqlServer.Management.Smo.Server’) -argumentlist $Server

$dbs = $SMOserver.Databases

$dbs | select Name, Size, DataSpaceUsage, IndexSpaceUsage, SpaceAvailable 

ForEach ($db in $dbs)
{
    $dbSize = $db.Size
    $dbDataSpaceUsage = $db.DataSpaceUsage/1KB
    $dbSpaceAvailable = $db.SpaceAvailable/1KB 
    Write-Host $db.name, $dbSize, $dbDataSpaceUsage, $dbSpaceAvailable
}
#>