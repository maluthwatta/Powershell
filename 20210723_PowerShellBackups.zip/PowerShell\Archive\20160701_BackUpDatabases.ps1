﻿# --------------------------- #
# Manoj Aluthwatta 01/07/2016 #
#-----------------------------#

$server = 'CSODEVSQL42INS9\INS9'
$zDBA = 'zDBA'

$db_array = @(
"CDS_AppAdmin_3_5"
,"CDS_AppLog_3_5"
,"CDS_JobAutomation_3_5"
,"CDS_JobControl_3_5"
,"CDS_JobControl_3_5_A"
,"CDS_National_3_5"
)


$backup_path = "\\csodevfile1\DBABackups_NoTape\CDS\"

$dateStr = Get-Date -format "yyyyMMdd"

foreach ($database in $db_array)
{
    Write-Host "Backup $database >>"

    $sql_backup = "
    exec p_DBA_BackupDB @DB_Name = '$database'
	, @Backup_Path = '$backup_path$database`_backup_$dateStr.cBAK'  
    "
    invoke-sqlcmd -query $sql_backup -serverinstance $server -database $zDBA -QueryTimeout 3000    
}

Write-Host "Complete>>"