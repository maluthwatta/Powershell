﻿$server_name = "CSODEVSQL30INS2\INS2"


[Reflection.Assembly]::LoadWithPartialName("Microsoft.SqlServer.Smo")  | Out-Null;
 $srv = new-object Microsoft.SqlServer.Management.Smo.Server($server_name)
 if ($srv.Configuration.XPCmdShellEnabled -eq $TRUE)
 {
 Write-Host "xp_cmdshell is enabled in instance" $srv.Name
 }
 else
 {
 Write-Host "xp_cmdshell is Disabled in instance" $srv.Name
 }