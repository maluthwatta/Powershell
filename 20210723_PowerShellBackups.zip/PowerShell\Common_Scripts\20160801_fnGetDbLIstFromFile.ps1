﻿# --------------------------- #
# Manoj Aluthwatta 26/02/2014 #
#-----------------------------#


Function confirmDBs()
{
    $dbListFile = "\\csodevfile1\DBA\AluthwattaM\PowerShell\DataFiles\Databases.txt"

    $databaseList = Get-Content $dbListFile


    foreach ($database in $databaseList)
    {
        Write-Output $database
    }

    Write-Output ''
    $response = Read-Host -Prompt 'Run in all above databases? (Y/N)' 
    if (($response -eq 'y') -or ($response -eq 'Y'))
    {
        return $true, $databaseList 
    }
    else
    {
        return $false, $databaseList 
    }    

}