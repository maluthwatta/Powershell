﻿param 
( 
    [string]$SourceServer, 
    [string]$SourceDatabase,
    [string]$DestinationServer,
    [string]$DestinationDatabase,
    [string]$BackupPathTemp = "",
    [string]$LogPath = ""
)

$StartTime = Get-Date
$StartTimeToPrint = $StartTime.ToString() 


if ($BackupPathTemp -eq ""){
    $BackupPathTemp = "\\oceania\CTS\SQLNonProdBackups\NoTape\DBABackups\MA"
}

if ($BackupPathTemp.Substring($BackupPathTemp.Length-1) -ne '\')
{
    $BackupPathTemp = $BackupPathTemp + '\'
}

if ($LogPath -eq ""){
    $LogPath = $BackupPathTemp + $SourceServer.Replace("\","") + "." + $SourceDatabase + "-" + $DestinationServer.Replace("\","") + "." + $DestinationDatabase + "_Log.txt"
}

$scriptPathBackup = “\\oceania\CTS\DEPTDATA\Development\DatabaseAdmins\Development\AluthwattaM\PowerShell\Common_Scripts\BackupDatabase.ps1”
$scriptPathRestore = “\\oceania\CTS\DEPTDATA\Development\DatabaseAdmins\Development\AluthwattaM\PowerShell\Common_Scripts\RestoreDatabase.ps1”


$Date = Get-Date
$DateStr = $Date.ToString("yyyyMMddHHmm")

$backupFileName = $SourceDatabase + '_' + $DateStr + '.cBAK'
$backupFileWithPath = $BackupPathTemp + $backupFileName

$argumentListBackupDB  = $SourceServer, $SourceDatabase , $backupFileWithPath, $LogPath
$argumentListRestoreDB  = $DestinationServer, $DestinationDatabase , $backupFileWithPath, $LogPath


try
{
    Invoke-Expression "$scriptPathBackup $argumentListBackupDB" 
    Start-Sleep -s 30 	
    Invoke-Expression "$scriptPathRestore $argumentListRestoreDB" 
}
Catch
{    
    Add-Content $LogPath $_.Exception.Message
    Add-Content $LogPath $_.Exception.ItemName
    Break
}



Add-Content $LogPath "##### START:  $StartTimeToPrint #####"


$EndTime = Get-Date
$EndTimeToPrint = $EndTime.ToString() 
Add-Content $LogPath "##### END  :  $EndTimeToPrint #####"