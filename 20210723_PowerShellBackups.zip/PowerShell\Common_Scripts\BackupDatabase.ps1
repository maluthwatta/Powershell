﻿param 
( 
    [string]$Server, 
    [string]$Database,
    [string]$BackupFile,
    [string]$LogPath = "",
    [boolean]$ForceBackup = $false
)


Write-host "Server: $Server"
Write-host "database: $Database"
Write-host "BackupFile: $BackupFile"

    
if (((Test-Path $BackupFile) -eq $true) -and !($ForceBackup))
{
    write-host "Backup file exists - $BackupFile" -ForegroundColor Red
    if ($LogPath -ne "")
    {
        Add-Content $LogPath "Backup file exists - $BackupFile"
    }    
}
else
{
    try
    {
        $backup_script = Backup-SqlDatabase -ServerInstance $Server -Database $Database -BackupFile $BackupFile -CompressionOption On -CopyOnly -Script

        $startTime = Get-Date
        if ($LogPath -ne "")
        {
            Add-Content $LogPath $backup_script
            Add-Content $LogPath "Backup started : $startTime"
			Write-host "Backup started : $startTime"
        }
        else
        {
            Write-host $backup_script 
            Write-host "Backup started : $startTime"
        }

        Backup-SqlDatabase -ServerInstance $Server -Database $Database -BackupFile $BackupFile -CompressionOption On -CopyOnly  

        $endTime = Get-Date
        if ($LogPath -ne "")
        {
            Add-Content $LogPath "Backup complete: $endTime"
			write-host "Backup complete: $endTime" 
        }
        else
        {
            write-host "Backup complete: $endTime" 
        }  

    }

    catch
    {
        if ($LogPath -ne "")
        {
            Add-Content $LogPath $_.Exception.Message
            Add-Content $LogPath $_.Exception.ItemName
        } 

        write-host "Error: $($_.Exception.Message)" -ForegroundColor Red
        Break
    }
     
}