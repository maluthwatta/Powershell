param 
( 
    [string]$Server, 
    [string]$Database,
    [string]$BackupDirectory,
    [string]$LogPath = "",
    [boolean]$ForceBackup = $false
)


if ($BackupDirectory -eq ""){
    $BackupDirectory = "\\OCEANIA\CTS\SQLNonProdBackups\NoTape\DBABackups\MA\"
}

if ($BackupDirectory.Substring($BackupDirectory.Length-1) -ne '\')
{
    $BackupDirectory = $BackupDirectory + '\'
}


$Date = Get-Date
$DateStr = $Date.ToString("yyyyMMddHHmm")

$backupFileName = $Database + '_' + $DateStr + '.cBAK'
$backupFileWithPath = $BackupDirectory + $backupFileName

\\oceania\CTS\DEPTDATA\Development\DatabaseAdmins\Development\AluthwattaM\PowerShell\Common_Scripts\BackupDatabase.ps1 `
    -Server $Server `
    -Database $Database `
    -backup $backupFileWithPath `
    -LogPath $LogPath `
    -ForceBackup $ForceBackup