﻿param
(
    $source
    ,$destination
) 

$destFolder = $destination 

Write-Host  ("-" * 35)
write-host "Copying files.."

#write the source location
write-host "Source folder: $source"

#test the existence of the source
if (-not (Test-Path $source -pathType container))
{
    throw [System.IO.FileNotFoundException] "$source not found."
}

try
{

    #if the destination folder exists delete it
    if (Test-Path $destFolder -pathType container)
    {
        write-host "Removing folder: $destFolder"
        Remove-Item $destFolder -Force -Recurse    
    }
    
    #create the folder
    write-host "Creating folder: $destFolder"
    New-Item $destFolder -type directory | out-null

    $fileCount = 0
    #Load scripts to destination
    write-host "Copying files to: $destFolder"
    Get-ChildItem $source -Recurse | `
        Where-Object { $_.PSIsContainer -eq $False } | `
        ForEach-Object {Copy-Item -Path $_.Fullname -Destination $destFolder -Force;$fileCount++ } 
    
    write-host "# Files Copied: $fileCount" -ForegroundColor Green;
}
Catch
{
    write-host "Error: $($_.Exception.Message)" -ForegroundColor Red
}