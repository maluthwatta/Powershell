﻿param
(
    [string]$server
    ,[string]$database
    ,[string]$filePath
    ,[string]$setOptions
    ,[string]$FirstPrefix='v' 
    ,[string]$SecondPrefix='f' 
    ,[string]$ThirdPrefix='t'
) 


#sort the order by applying the filters
$FileList = Get-ChildItem -Path $filePath -Recurse | Where-Object { $_.PSIsContainer -eq $False } |`
         Select-Object Name, FullName, @{name="SortOrder";Expression={switch -Wildcard ($_.Name){"$FirstPrefix*"{5} "$SecondPrefix*"{4} "$ThirdPrefix*"{3} default{0}}}} | `
            Sort-Object SortOrder -Descending | Select-Object FullName

Write-Host  ("-" * 35)
Write-host "Database   : $server`.$database" 
Write-host "Path       : $filePath" 


$file_count = Get-ChildItem $filePath -Recurse -File | Measure-Object | %{$_.Count}

if ($file_count -eq 0)
{
    write-host "No files to compile." -ForegroundColor Red
    Break;
}



$success_count = 0

try
{
    #Change set options
    Invoke-Sqlcmd -query $setOptions -ServerInstance $server -database $database -ErrorAction Stop -Verbose -QueryTimeout 1800

    foreach ($file in $FileList)
    {
        write-host $file.FullName     
        Invoke-Sqlcmd -InputFile $file.FullName -ServerInstance $server -database $database -ErrorAction Stop -Verbose -QueryTimeout 1800 # 30min
        $success_count += 1
    }
    Write-Host "$success_count SCRIPT(S) SUCCESSFULLY RUN" -ForegroundColor Green

}
catch
{
    Write-Host "Error: $($_.Exception.Message)" -ForegroundColor Red
    throw $_.Exception.Message
}
    
