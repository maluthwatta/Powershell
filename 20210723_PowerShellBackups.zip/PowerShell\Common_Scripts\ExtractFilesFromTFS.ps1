﻿param($tfsPath, $copyPath, $tfsLabel)  


[void][Reflection.Assembly]::Load(“Microsoft.TeamFoundation.Client, Version=11.0.0.0, Culture=neutral, PublicKeyToken=b03f5f7f11d50a3a”);
[void][System.Reflection.Assembly]::LoadWithPartialName("Microsoft.TeamFoundation.Client") 
[void][System.Reflection.Assembly]::LoadWithPartialName("Microsoft.TeamFoundation.VersionControl.Client")  
[void][System.Reflection.Assembly]::LoadWithPartialName("Microsoft.TeamFoundation.VersionControl.Client.VersionSpec")  
Add-PSSnapin Microsoft.TeamFoundation.PowerShell


$tfsUrl = "http://tfsprod.oceania.cshare.net:8080/tfs/CPU"

#Get the user credentials
$user = "Oceania\AluthwattaM"
$file = "C:\Manoj\Password.txt"

$deployDirectory = "\\melyw0599\Datashare\TFS"


$credential = New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList $user, (Get-Content $file | ConvertTo-SecureString)



#Clear the deploy directory
Remove-Item $deployDirectory\* -recurse

$tfs = new-object Microsoft.TeamFoundation.Client.TfsTeamProjectCollection $tfsUrl, $Credential
$tfsVCS = $tfs.GetService("Microsoft.TeamFoundation.VersionControl.Client.VersionControlServer")



$global:totalFiles = 0



$label = New-Object Microsoft.TeamFoundation.VersionControl.Client.LabelVersionSpec($tfsLabel)
$items = Get-TfsChildItem $tfsPath -Server $tfs -Recurse 
    
$filesCopied = 0

foreach ($item in $items) {
    Write-Host "TFS item to download:" $($item.ServerItem)

    $destinationPath = $item.ServerItem.Replace($tfsPath, $copyPath)
    
    if ($item.ItemType -eq "Folder") {
        New-Item $([IO.Path]::GetFullPath($destinationPath)) -ItemType Directory -Force | Out-Null
    }
    else {
        # Download the file (not folder) to destination directory
        $tfsVCS.DownloadFile($item.ServerItem, $null, $label, $([IO.Path]::GetFullPath($destinationPath)))
        $filesCopied++
        $global:totalFiles++
    }
}
Write-Host "Files: $filesCopied"
    
