﻿function ConfirmAll
{
    $itemListFile = "\\oceania\CTS\DEPTDATA\Development\DatabaseAdmins\Development\AluthwattaM\PowerShell\DataFiles\List.txt"
    $itemList = Get-Content $itemListFile

    foreach ($item in $itemList)
    {
        Write-host $item
    }

    Write-Host "DB List File: $itemListFile"
     
    Write-Host "Run in all above? (Y/N):" -ForegroundColor Yellow -NoNewline
    $response = Read-Host 
    
    if (($response -eq 'y') -or ($response -eq 'Y'))
    {
        return $itemList
    }
    else
    {
        return $null
    }
}



function ConfirmAllServerInstances
{
    $itemListFile = "\\oceania\CTS\DEPTDATA\Development\DatabaseAdmins\Development\AluthwattaM\PowerShell\DataFiles\ServerInstances.txt"
    $itemList = Get-Content $itemListFile

    foreach ($item in $itemList)
    {
        Write-host $item
    }

    Write-Host "Server Instance List File: $itemListFile"
     
    Write-Host "Run in all above? (Y/N):" -ForegroundColor Yellow -NoNewline
    $response = Read-Host 
    
    if (($response -eq 'y') -or ($response -eq 'Y'))
    {
        return $itemList
    }
    else
    {
        return $null
    }
}


function get-DiskVolumes
{
    param(
        [string]$ComputerName=$env:COMPUTERNAME,
        [switch]$Raw
    )

    Write-Host "Server: $ComputerName"

    $Filter = @{Expression={$_.Name};Label="DiskName"}, `
              @{Expression={$_.Label};Label="Label"}, `
              #@{Expression={$_.FileSystem};Label="FileSystem"}, `
              #@{Expression={[int]$($_.BlockSize/1KB)};Label="BlockSizeKB"}, `
              @{Expression={[int]$($_.Capacity/1GB)};Label="CapacityGB"}, `
              @{Expression={[int]$($_.Freespace/1GB)};Label="FreeSpaceGB"},
              @{Expression={[int][math]::Round(([int]$($_.Freespace/1GB)/[int]$($_.Capacity/1GB))*100)};Label="FreeSpace%"}
    if($Raw){Get-WmiObject Win32_Volume -ComputerName $ComputerName | Sort-Object Name | Select-Object $Filter}
    else{Get-WmiObject Win32_Volume -ComputerName $ComputerName |Sort-Object Name | Format-Table $Filter -AutoSize}
}


function get-allServerNames
{
    param(
        [bool]$SQL2000instances = $false,
        [bool]$SQL2005instances = $false,
        [bool]$SQL2008instances = $false,
        [bool]$SQL2012instances = $true,
        [bool]$SQL2014instances = $true,
        [bool]$SQL2016instances = $true        
    )
    
    $sql_all_servers = "SELECT NULL As ServerName"


    if ($SQL2000instances -eq 1)
    {
         $sql_all_servers += " UNION ALL SELECT ComponentName FROM [rep].[SQLInstance2000]"
    }

    if ($SQL2005instances -eq 1)
    {
         $sql_all_servers += " UNION ALL SELECT ComponentName FROM [rep].[SQLInstance2005]"
    }

    if ($SQL2008instances -eq 1)
    {
         $sql_all_servers += " UNION ALL SELECT ComponentName FROM [rep].[SQLInstance2008]"
    }

    if ($SQL2012instances -eq 1)
    {
         $sql_all_servers += " UNION ALL SELECT ComponentName FROM [rep].[SQLInstance2012]"
    }

    if ($SQL2014instances -eq 1)
    {
         $sql_all_servers += " UNION ALL SELECT ComponentName FROM [rep].[SQLInstance2014]"
    }

    if ($SQL2016instances -eq 1)
    {
         $sql_all_servers += " UNION ALL SELECT ComponentName FROM [rep].[SQLInstance2016]"
    }


    $sql_to_run = "
    SELECT ServerName
    FROM
    (
    $sql_all_servers
    )t
    WHERE ServerName IS NOT NULL"

    $server_list = invoke-sqlcmd -query $sql_to_run -serverinstance "CSOVDEVSQL34\INS1" -database 'SMART_AU_NonProd' -QueryTimeout 3000 
             
    foreach ($server_name in $server_list)
    {
        Write-host $server_name.ServerName
    }
 
    Write-Host "Run in all above? (Y/N):" -ForegroundColor Yellow -NoNewline
    $response = Read-Host 
    
    if (($response -eq 'y') -or ($response -eq 'Y'))
    {
        return $server_list
    }
    else
    {
        return $null
    }

}