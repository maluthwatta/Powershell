﻿<#
$argumentList = 
    'SOURCE_SERVER',
    'SOURCE_DB',
    'DESTINATION_SERVER',
    'DESTINATION_SERVER',
    'BACKUP_PATH' [Optional - Default is \\csodevfile1\DBABackups_NoTape\MA]
    'LOG_PATH'    [Optional - Default is \\csodevfile1\DBABackups_NoTape\MA]
#>

<#
Parallel Run
$scriptPathBackupRestore = “Z:\PowerShell\Common_Scripts\BackupAndRestoreDatabase.ps1”
$argumentList1  = 'CSOVTSTSQL2', 'BICR_UK_SysTest_Staging',     'CSOVTSTSQL2', 'BICR_UK_SysTest_Staging_LingC'

$job1 = Start-Job -FilePath $scriptPathBackupRestore -Name "Job1" -ArgumentList $argumentList1
#>


\\oceania\CTS\DEPTDATA\Development\DatabaseAdmins\Development\AluthwattaM\PowerShell\Common_Scripts\BackupAndRestoreDatabase.ps1 `
    -SourceServer 'MELYDEVAPP751' `
    -SourceDatabase 'WinWeb_TeamCity_Dev_1' `
    -DestinationServer 'MELYDEVAPP741' `
    -DestinationDatabase 'WinWeb_TeamCity_Dev_1'