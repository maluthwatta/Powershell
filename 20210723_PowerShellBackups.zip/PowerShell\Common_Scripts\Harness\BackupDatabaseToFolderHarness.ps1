<#
param 
( 
    [string]$Server, 
    [string]$Database,
    [string]$BackupDirectory = "\\csodevfile1\DBABackups_NoTape\MA\",
    [string]$LogPath = "",
    [boolean]$ForceBackup = $false
)
#>


$ServerName = "CSOVDEVSQLNICE1"
$DatabaseList = @("nice_admin","nice_audit","nice_ca","nice_crypto","nice_cti_analysis","nice_customers","nice_dw","nice_ib","nice_interactions","nice_pbs_data","nice_qa","nice_reporter","nice_rule","nice_screen_sense","nice_storage_center")
$BackupDirectory = ""


foreach ($database in $DatabaseList)
{
    \\oceania\CTS\DEPTDATA\Development\DatabaseAdmins\Development\AluthwattaM\PowerShell\Common_Scripts\BackupDatabaseToFolder.ps1 `
        -Server $ServerName `
        -Database $database `
        -BackupDirectory $BackupDirectory
}


