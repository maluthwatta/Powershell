﻿<#
param 
( 
    [string]$Server, 
    [string]$Database,
    [string]$backup,
    [string]$LogPath = "",
    [boolean]$ForceBackup = $false
)
#>

\\oceania\CTS\DEPTDATA\Development\DatabaseAdmins\Development\AluthwattaM\PowerShell\Common_Scripts\BackupDatabase.ps1 `
    -Server "csovdevsql25\ins1" `
    -Database "WST_DEV" `
    -backup "\\OCEANIA\CTS\SQLNonProdBackups\DevDumps\WST\SQL2016\WST_DEV_20170830_BeforeUAT.cBAK" `
    -ForceBackup $FALSE


