﻿$sourceFolder = "\\csofile2\DBAApps\Upgrades\DBAUpgrades\CI\StoredProcs\v4.5\v4.5.0.11.0"
$destinationFolder = "\\csodevfile1\DBA\AluthwattaM\Temp\SPTemp" 



#Copy files from $sourceFolder to $destinationFolder
\\csodevfile1\dba\AluthwattaM\PowerShell\Common_Scripts\CopyAllFilesRecursivelyToAfolder.ps1 `
    -source $sourceFolder `
    -destination $destinationFolder