﻿
$rootFolder = '\\csofile2\DBAApps\Upgrades\DBAUpgrades\CI\StoredProcs\v4.5'
$server = "CSODEVSQL42INS3\INS3"
$database = "CI_AluthwattaM_TESTER_1"

$debug = $true

$SubFolders = Get-ChildItem -Path $rootFolder -Exclude '*v4.5.0.0*' | ?{ $_.PSIsContainer } 

foreach ($SubFolder in $SubFolders)
{
    if ($debug)
    {
        $SubFolders
    }
    else
    {
        \\oceania\CTS\DEPTDATA\Development\DatabaseAdmins\Development\AluthwattaM\PowerShell\Common_Scripts\ExecuteStoredProcs.ps1 `
        -server $server `
        -database $database `
        -filePath $SubFolder.FullName `
        -setOptions "SET QUOTED_IDENTIFIER ON; SET ANSI_NULLS ON"
    }
}

