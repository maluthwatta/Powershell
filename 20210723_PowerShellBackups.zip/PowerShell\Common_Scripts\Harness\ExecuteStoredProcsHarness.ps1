﻿
<#
param
(
    [string]$server
    ,[string]$database
    ,[string]$filePath
    ,[string]$setOptions = "SET QUOTED_IDENTIFIER ON; SET ANSI_NULLS ON" 
    ,[string]$1stPrefix = "v"
    ,[string]$2ndPrefix = "f"
    ,[string]$3rdPrefix = "t"
) 
#>

$server = 'CSODEVSQL42INS3\INS3'
$database = 'CI_AluthwattaM_BASE_AU'
$file_path = '\\csofile2\DBAApps\Upgrades\DBAUpgrades\CI\StoredProcs\v4.5\v4.5.0.14.0'

#Set options 
$set_options = 'set quoted_identifier on; set ansi_nulls on;'


\\oceania\CTS\DEPTDATA\Development\DatabaseAdmins\Development\AluthwattaM\PowerShell\Common_Scripts\ExecuteStoredProcs.ps1 
    -server $server `
    -database $database `
    -filePath $file_path `
    -setOptions $set_options `




