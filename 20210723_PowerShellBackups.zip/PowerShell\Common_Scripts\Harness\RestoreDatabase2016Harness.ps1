﻿<#
param
(
    [string]$server
    ,[string]$database
    ,[string]$backupFile
    ,[string]$runQuery (Y or N)
)
#>

$server = "CSACWEBSQLU10C\WEB"
$database = "CC_HANDOVER_NA"
$backupFile = '\\172.21.232.4\SQLBackupsUAT\CSACCOSSQLUAT4C$COS\CC_HANDOVER_NA\FULL\CC_HANDOVER_NA_backup_20180503_Migration_COPYONLY.cBAK'
$runQuery = "Y"


\\oceania\CTS\DEPTDATA\Development\DatabaseAdmins\Development\AluthwattaM\PowerShell\Common_Scripts\RestoreDatabase2016.ps1 `
    -server $server `
    -database $database `
    -backupFileName $backupFile `
    -runQuery $runQuery 


    