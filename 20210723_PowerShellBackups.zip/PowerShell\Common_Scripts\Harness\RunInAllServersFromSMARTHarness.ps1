﻿Import-Module \\oceania\cts\DEPTDATA\Development\DatabaseAdmins\Development\AluthwattaM\PowerShell\Common_Scripts\Functions.ps1 -Force

$server_list = get-allServerNames -SQL2000instances $false -SQL2005instances $false -SQL2008instances $true -SQL2012instances $true -SQL2014instances $true -SQL2016instances $true

$sql_to_run = "
SELECT Count(1) As RecordCount
FROM perf.gt1000
WHERE Start_time < DATEADD(month, -3, GETDATE());
"

$output_array = @()
             
foreach ($server_name in $server_list)
{    
    try{
        $results = invoke-sqlcmd -query $sql_to_run -serverinstance $server_name.ServerName -database 'aaDBA' -QueryTimeout 3000 
        $results | Add-Member -NotePropertyName InstanceName -NotePropertyValue $server_name.ServerName
        $output_array +=  $results   
    }
    catch{
        Write-Host $_
    }

}

$output_array | ft -AutoSize