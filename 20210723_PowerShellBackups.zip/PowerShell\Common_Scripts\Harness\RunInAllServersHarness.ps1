﻿#Server List = '\\oceania\CTS\DEPTDATA\Development\DatabaseAdmins\Development\AluthwattaM\PowerShell\DataFiles\ServerInstances.txt'

$Database = 'msdb'
$SqlQuery = "exec sp_help_jobstep  @job_name = 'DBA.GT1000X_PURGE';"

\\oceania\CTS\DEPTDATA\Development\DatabaseAdmins\Development\AluthwattaM\PowerShell\Common_Scripts\RunInAllServerInstances.ps1 `
    -Database $Database -SqlQuery $SqlQuery 

