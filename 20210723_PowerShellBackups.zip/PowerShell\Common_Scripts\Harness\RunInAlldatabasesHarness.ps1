﻿
$SqlServer = 'DEVSQLAG33L02,20000'
$ExecuteQuery = "exec sp_helptext 'CISTAStage.p_PR_SCRIPAU_FilterOutAccountWithNoName';
exec sp_helptext 'CISTAStage.p_PR_SCRIPNA_FilterOutAccountWithNoName';
exec sp_helptext 'CISTAStage.p_PR_SCRIPUK_FilterOutAccountWithNoName';
exec sp_helptext 'CISTAStage.p_PR_RMLNZ_FilterOutAccountWithNoName';
exec sp_helptext 'CISTAStage.p_PR_EOSNA_FilterOutAccountWithNoName';"

$DbList = '\\oceania\CTS\DEPTDATA\Development\DatabaseAdmins\Development\AluthwattaM\PowerShell\DataFiles\List.txt'


\\oceania\CTS\DEPTDATA\Development\DatabaseAdmins\Development\AluthwattaM\PowerShell\Common_Scripts\RunInAllDatabases.ps1 `
    -Server $SqlServer -DatabaseList $DbList -SqlQuery $ExecuteQuery 

