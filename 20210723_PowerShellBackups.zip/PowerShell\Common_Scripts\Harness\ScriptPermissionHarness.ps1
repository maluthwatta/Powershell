﻿
$ServerName = "CSOVDEVSQL10"
$DatabaseList = @("IVR_Control2_Stuart")


foreach ($database in $DatabaseList)
{
    #Write-Host "Use $database"
    #Write-Host "Go"
    \\oceania\CTS\DEPTDATA\Development\DatabaseAdmins\Development\AluthwattaM\PowerShell\20170605-ScriptDatabasePermission\ScriptPermission.ps1 `
        -server $ServerName `
        -database $database
}






