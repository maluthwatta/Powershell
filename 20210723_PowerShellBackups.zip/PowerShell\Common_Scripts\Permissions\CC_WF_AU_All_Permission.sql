declare @username table (LoginName nvarchar(500))
declare @SQLcmd nvarchar(1000)
declare @LoginName nvarchar(500) 
 
insert into @username (LoginName) 
select name from sys.database_principals where is_fixed_role=0 and type in ('U','G') 

while exists (select 1 from @username) 
begin
      select top 1 @LoginName=LoginName from @username
      exec sp_revokedbaccess @LoginName
      delete from @username where LoginName=@LoginName
end

if not exists (select name from sys.server_principals where name = 'oceania\UATAdminMTS')
	create login [oceania\UATAdminMTS] from windows with default_database = tempdb

if not exists (select name from sys.database_principals where name = 'oceania\UATAdminMTS')
	create user [oceania\UATAdminMTS] from login [oceania\UATAdminMTS]

if not exists (select name from sys.server_principals where name = 'OCEANIA\!AU CT COSMOS Company Admins')
	create login [OCEANIA\!AU CT COSMOS Company Admins] from windows with default_database = tempdb
	
if not exists (select name from sys.database_principals where name = 'OCEANIA\!AU CT COSMOS Company Admins')
	create user [OCEANIA\!AU CT COSMOS Company Admins]

exec sp_addrolemember 'WFUsers','oceania\UATAdminMTS' 
exec sp_addrolemember 'WFUsers','OCEANIA\!AU CT COSMOS Company Admins' 
