/*
Set up AU UAT WF security permissons, when DEV WF backup is restored on UAT instance.


use CSB_WF_UAT_AU;
go
*/
---------------------------------------------------------------------------------------------------------------------------
set nocount on;

--drop dev security permissions
--drop schemas
if exists (select 1 from sys.schemas as s inner join sys.database_principals as dp	on dp.principal_id = s.principal_id where s.name = N'OCEANIA\!All Cosmos Billing Team')
	drop schema [OCEANIA\!All Cosmos Billing Team];
if exists (select 1 from sys.schemas as s inner join sys.database_principals as dp	on dp.principal_id = s.principal_id where s.name = N'OCEANIA\!AU CT MEL WF2k')
	drop schema [OCEANIA\!AU CT MEL WF2k];
if exists (select 1 from sys.schemas as s inner join sys.database_principals as dp	on dp.principal_id = s.principal_id where s.name = N'OCEANIA\!AU CS Dev Cosmos Billing System')
	drop schema [OCEANIA\!AU CS Dev Cosmos Billing System];
--drop users	
if exists (select 1 from sys.database_principals where name = N'OCEANIA\!All Cosmos Billing Team' and type = N'G')
	drop user [OCEANIA\!All Cosmos Billing Team];
if exists (select 1 from sys.database_principals where name = N'OCEANIA\!AU CT MEL WF2k' and type = N'G')
	drop user [Oceania\!AU CT MEL WF2k];
if exists (select 1 from sys.database_principals where name = N'OCEANIA\!AU CS Dev Cosmos Billing System' and type = N'G')
	drop user [OCEANIA\!AU CS Dev Cosmos Billing System];	
---------------------------------------------------------------------------------------------------------------------------	
--create UAT AU security permissions	
--create user
if not exists (select 1 from sys.database_principals where name = N'OCEANIA\AU CS UAT Cosmos Billing System' and type = N'G')
begin	
	create user [OCEANIA\AU CS UAT Cosmos Billing System] from login [OCEANIA\AU CS UAT Cosmos Billing System];
end;
--add role member
if exists (select 1 from sys.database_principals where name = N'OCEANIA\AU CS UAT Cosmos Billing System' and type = N'G')
begin
	exec sp_addrolemember N'SQLUsers', N'OCEANIA\AU CS UAT Cosmos Billing System';
end;
---------------------------------------------------------------------------------------------------------------------------
--exec CSB_WF_UAT_AU..sp_helpuser;
---------------------------------------------------------------------------------------------------------------------------