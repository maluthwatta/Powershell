/*
Set up UK UAT WF security permissons, when DEV WF backup is restored on UAT instance.
UK & ZA use same WF database.


use CSB_WF_UAT;
go
*/
---------------------------------------------------------------------------------------------------------------------------
set nocount on;

--drop dev security permissions
--drop schemas
if exists (select 1 from sys.schemas as s inner join sys.database_principals as dp	on dp.principal_id = s.principal_id where s.name = N'OCEANIA\!All Cosmos Billing Team')
	drop schema [OCEANIA\!All Cosmos Billing Team];
if exists (select 1 from sys.schemas as s inner join sys.database_principals as dp	on dp.principal_id = s.principal_id where s.name = N'OCEANIA\!AU CT MEL WF2k')
	drop schema [OCEANIA\!AU CT MEL WF2k];
if exists (select 1 from sys.schemas as s inner join sys.database_principals as dp	on dp.principal_id = s.principal_id where s.name = N'OCEANIA\!AU CS Dev Cosmos Billing System')
	drop schema [OCEANIA\!AU CS Dev Cosmos Billing System];
--drop users			
if exists (select 1 from sys.database_principals where name = N'OCEANIA\!All Cosmos Billing Team' and type = N'G')
	drop user [OCEANIA\!All Cosmos Billing Team];
if exists (select 1 from sys.database_principals where name = N'OCEANIA\!AU CT MEL WF2k' and type = N'G')
	drop user [Oceania\!AU CT MEL WF2k];
if exists (select 1 from sys.database_principals where name = N'OCEANIA\!AU CS Dev Cosmos Billing System' and type = N'G')
	drop user [OCEANIA\!AU CS Dev Cosmos Billing System];
---------------------------------------------------------------------------------------------------------------------------
--create UAT UK security permissions	
--create users
if not exists (select 1 from sys.database_principals where name = N'EMEA\UK All Cosmos Billing Users (Domain Local)' and type = N'G')
begin
	create user [EMEA\UK All Cosmos Billing Users (Domain Local)] from login [EMEA\UK All Cosmos Billing Users (Domain Local)];	
end;
if not exists (select 1 from sys.database_principals where name = N'EMEA\UK ALL UAT Cosmos Billing System' and type = N'G')
begin
	create user [EMEA\UK ALL UAT Cosmos Billing System] from login [EMEA\UK ALL UAT Cosmos Billing System];	
end;
if not exists (select 1 from sys.database_principals where name = N'EMEA\ZA All Cosmos Billing Users (Domain Local)' and type = N'G')
begin
	create user [EMEA\ZA All Cosmos Billing Users (Domain Local)] from login [EMEA\ZA All Cosmos Billing Users (Domain Local)];	
end;

--add role members
if exists (select 1 from sys.database_principals where name = N'EMEA\UK All Cosmos Billing Users (Domain Local)' and type = N'G')
begin	
	exec sp_addrolemember N'SQLUsers', N'EMEA\UK All Cosmos Billing Users (Domain Local)';
end;
if exists (select 1 from sys.database_principals where name = N'EMEA\UK ALL UAT Cosmos Billing System' and type = N'G')
begin	
	exec sp_addrolemember N'SQLUsers', N'EMEA\UK ALL UAT Cosmos Billing System';
end;
if exists (select 1 from sys.database_principals where name = N'EMEA\ZA All Cosmos Billing Users (Domain Local)' and type = N'G')
begin	
	exec sp_addrolemember N'SQLUsers', N'EMEA\ZA All Cosmos Billing Users (Domain Local)';
end;
---------------------------------------------------------------------------------------------------------------------------
--exec CSB_WF_UAT..sp_helpuser;
---------------------------------------------------------------------------------------------------------------------------


