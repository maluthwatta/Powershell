﻿param 
( 
    [string]$Server, 
    [string]$Database,
    [string]$Backup,
    [string]$LogPath = ""
)
   
$sql_version_check = "SELECT serverproperty('ProductVersion') AS version"
$sql_version = invoke-sqlcmd -query $sql_version_check -serverinstance $server -database 'tempDB' -QueryTimeout 60000
$version = [version]$($sql_version.version)
if ($version.Major -ge 12 )
{
    $dba_db = "aaDBA"
}
else
{
    $dba_db = "zDBA"
}
         

$killSql = 
"ALTER DATABASE $Database
SET SINGLE_USER
WITH ROLLBACK IMMEDIATE;
ALTER DATABASE $Database
SET MULTI_USER;
" 
    
if ((Test-Path $backup) -eq $true)
{
    $sql = "exec p_DBA_RestoreDB @DB_Name = '$database'
                , @Backup_Path = '$backup'   
                , @debug_flag = 0;
            "
            write-host "Database: $database"
            write-host "Backup: $Backup"
            write-host "Restore SQL:"
            write-host $sql

            try
            {
                invoke-sqlcmd -query $killSql -serverinstance $server -database "tempdb" -Verbose -QueryTimeout 60000                  
       
                if ($LogPath -ne "")
                {
                    Add-Content $LogPath $sql
                    invoke-sqlcmd -query $sql -serverinstance $server -database $dba_db -Verbose 4>> $LogPath -QueryTimeout 60000 
                }
                else
                {
                    invoke-sqlcmd -query $sql -serverinstance $server -database $dba_db -Verbose -QueryTimeout 60000
                }
                write-host "Restore database complete."
                write-host " "

            }
            Catch
            {
                Add-Content $LogPath $_.Exception.Message
                Add-Content $LogPath $_.Exception.ItemName
                Break
            }    
}
else
{
    write-host "File not found - $baseCurrentFile"  -ForegroundColor Red
    if ($LogPath -ne "")
    {
        Add-Content $LogPath "File not found - $baseCurrentFile"
    }   
}