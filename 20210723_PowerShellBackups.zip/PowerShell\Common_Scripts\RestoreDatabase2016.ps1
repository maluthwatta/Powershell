﻿param
(
    [string]$server
    ,[string]$database
    ,[string]$backupFileName
    ,[string]$runQuery # Y or N
)

$sqlBackupFileList = "RESTORE FILELISTONLY FROM DISK='$backupFileName';"
$sqlDatabaseFileList = "SELECT name, physical_name, type_desc  FROM sys.master_files WHERE database_id = db_id('$database')"

$backUpFileList = Invoke-Sqlcmd -query $sqlBackupFileList -ServerInstance $server -database "master" -ErrorAction Stop -Verbose -QueryTimeout 1800 | Select LogicalName, PhysicalName, Type, FileGroupName

$databaseFileList = Invoke-Sqlcmd -query $sqlDatabaseFileList -ServerInstance $server -database "master" -ErrorAction Stop -Verbose -QueryTimeout 1800

$databaseDataPath = $databaseFileList | where {$_.type_desc -eq "ROWS"} | select-object -First 1 
$databaseLogPath  = $databaseFileList | where {$_.type_desc -eq "LOG"} | select-object -First 1 

$dataPath = Split-Path -Path $databaseDataPath.physical_name
$logPath = Split-Path -Path $databaseLogPath.physical_name



$restoredatabaseSQL = "RESTORE DATABASE $database `n" 
$restoredatabaseSQL += "FROM DISK = '$backupFileName' `n"
$restoredatabaseSQL += "WITH RECOVERY, REPLACE, `n"

$relocateFiles = @()


foreach ($backupFile in $backUpFileList)
{        
    $NewPath = ""
    $NewFileName = ""

    foreach ($dbFile in $databaseFileList)
    {
        if ($dbFile.name -eq $backupFile.LogicalName)
        {
            $NewPath = Split-Path -Path $dbFile.physical_name
        }
    }

    if ($NewPath -eq "")
    {  
        Switch ($backupFile.Type)
        {
            "D"{ 
                $NewPath = $dataPath
             }
            "L"{ 
                $NewPath = $logPath
             }            
        }
    }    
        
    #Add the file extension
    Switch ($backupFile.Type)
        {
            "D"{ 
                
               if ($backupFile.FileGroupName -eq 'PRIMARY')
               {
                    $NewFileName = $NewPath + "\"+ $database  + "_" + $backupFile.LogicalName + ".MDF"
               }
               else
               {
                    $NewFileName = $NewPath + "\"+ $database + "_" + $backupFile.LogicalName + ".NDF"
               }                

             }
            "L"{ 
                $NewFileName = $NewPath + "\"+ $database + "_" + $backupFile.LogicalName + ".LDF"
             }            
        }
  
    $relocateFiles += New-Object Microsoft.SqlServer.Management.Smo.RelocateFile($backupFile.LogicalName, $NewFileName)
    $restoredatabaseSQL += "MOVE '$($backupFile.LogicalName)' TO '$NewFileName', `n"
    
}
$restoredatabaseSQL += "STATS = 10;"
write-host $restoredatabaseSQL

$changeDbOwner = "ALTER AUTHORIZATION ON DATABASE::[$database] TO [CTS_DBA];"
write-host $changeDbOwner


$sqlKillConn = "ALTER DATABASE $database SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
ALTER DATABASE $database SET MULTI_USER;"


if ($runQuery -eq "Y")
{
    Invoke-Sqlcmd -query $sqlKillConn -ServerInstance $server -database "tempdb" -ErrorAction Stop -Verbose -QueryTimeout 1800
    Restore-SqlDatabase -ServerInstance $server -Database $database -BackupFile $backupFileName -RelocateFile $relocateFiles -ReplaceDatabase
    #Change owner to CTS_DBA
    Invoke-Sqlcmd -query $changeDbOwner -ServerInstance $server -database "tempdb" -ErrorAction Stop -Verbose -QueryTimeout 1800
}

write-host "Complete."