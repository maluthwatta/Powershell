﻿#Set Variables
$NewDataPath = 'G:\INS1_DATA_01\SQLDATA\IVR'
$NewLogPath = 'G:\INS1_LOG_01\SQLLOG\IVR'
$ServerName = 'CSOVDEVSQL25\INS1'
$dbname = 'IVR_Reporting_DEV'
$BackupFile = '\\Csodevfile1\CSODEVSQL45\IVR\IVR_Reporting_DEV\IVR_Reporting_DEV_backup_201702212330.cBAK'
$relocate = @()

#$OutputFile = "\\csodevfile1\DBABackups_NoTape\MA\$dbname`_restore.sql"


#Get a list of database files in the backup
$dbfiles = Invoke-Sqlcmd -ServerInstance $ServerName -Database tempdb -Query "RESTORE FILELISTONLY FROM DISK='$BackupFile';"


#Loop through filelist files, replace old paths with new paths
foreach($dbfile in $dbfiles){
  $DbFileName = $dbfile.PhysicalName | Split-Path -Leaf
  if($dbfile.Type -eq 'L'){
    $newfile = [io.path]::combine($NewLogPath, $DbFileName)   #Join-Path -Path $NewLogPath -ChildPath $DbFileName
  } else {
    $newfile = [io.path]::combine($NewDataPath, $DbFileName) #Join-Path -Path $NewDataPath -ChildPath $DbFileName
  }
  $relocate += New-Object Microsoft.SqlServer.Management.Smo.RelocateFile ($dbfile.LogicalName,$newfile)
}

#Create Restore script
Restore-SqlDatabase -ServerInstance $ServerName `
    -Database $dbname `
    -RelocateFile $relocate `
    -BackupFile $BackupFile `
    -RestoreAction Database `
    -ReplaceDatabase `
    #-Script | Out-File $OutputFile

