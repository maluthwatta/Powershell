﻿
######################
# Execute stored procs
######################

function Execute-SPs{
    param(
    $server
    , $database
    , $file_path
    , $set_options = 'set quoted_identifier on;set ansi_nulls on;'
    , $FirstPrefix = 'v'
    , $SecondPrefix = 'f'
    , $ThirdPrefix = 't'
    ) 

    \\oceania\cts\DEPTDATA\Development\DatabaseAdmins\Development\AluthwattaM\PowerShell\Common_Scripts\ExecuteStoredProcs.ps1 `
        -server $server `
        -database $database `
        -filePath $file_path `
        -setOptions $set_options `
        -FirstPrefix $FirstPrefix `
        -SecondPrefix $SecondPrefix `
        -ThirdPrefix $ThirdPrefix
}


######################
# Index Rebuild
######################

function IndexRebuild
{
    param($server, $database)   

     \\oceania\cts\DEPTDATA\Development\DatabaseAdmins\Development\AluthwattaM\PowerShell\Common_Scripts\UpdateStatsShrinkIdxRebuild.ps1 `
           -server $server `
           -database $database

}



######################
# Restore database
######################

function RestoreDB
{
    param($server, $database, $backup)    
    
    try
    {    
        if ((Test-Path $backup) -eq $true)
        {

            \\oceania\cts\DEPTDATA\Development\DatabaseAdmins\Development\AluthwattaM\PowerShell\Common_Scripts\RestoreDatabase2016.ps1 -server $server -database $database -backupFileName $backup -runQuery 'Y'
    
        }
        else
        {
            write-host "File not found - $baseCurrentFile"  -ForegroundColor Red
        }
    }
    catch
    {
        write-host "Error: $($_.Exception.Message)" -ForegroundColor Red
    }
}

######################
# Backup database
######################

function BackupDB
{
    param($server, $database, $backup, $forcebackup, $setReadOnly)        
    
    if (((Test-Path $backup) -eq $true) -and (!($force_backup)))
    {
        write-host "Backup file exists - $baseCurrentFile" -ForegroundColor Red
    }
    else
    {
        $sql_shrink_log = "dbcc shrinkfile(2)"
        write-host "shrink log file"
        invoke-sqlcmd -query $sql_shrink_log -serverinstance $server -database $database -QueryTimeout 3000 

        write-host $backup

        \\oceania\CTS\DEPTDATA\Development\DatabaseAdmins\Development\AluthwattaM\PowerShell\Common_Scripts\BackupDatabase.ps1 -Server $server -Database $database -BackupFile $backup -LogPath "" -ForceBackup $force_backup

        #invoke-sqlcmd -query $sql -serverinstance $server -database 'aaDBA' -QueryTimeout 3000 
        write-host "Backingup database $database complete."
        write-host "--------------------------------------"            


        #Make the backup file READ_ONLY
        if($setReadOnly)
        {
            Set-ItemProperty -Path $backup -Name IsReadOnly -Value $true
            write-host "Backup made read only" 
        }

    }
}

######################
# Restore WF database
######################

function RestoreWinFormsDB
{    
    param($server, $database, $backupPath, $setDBReadOnly)    

    #$Backup_Path = "\\OCEANIA\SQLNonProdBackups\DevDumps\CosmosInvestor\SQL2016\WINFORMS\CI_Winforms_Release_V$($majorVersion)_$($minorVersion)_$($buildVersion)_0.cBAK"
	write-host	$backupPath
    RestoreDB -server $server -database $database -backup $backupPath

    #Make WF database READ ONLY
    if ($setDBReadOnly){
        $sql_readonly = "ALTER DATABASE $database SET READ_ONLY"
        invoke-sqlcmd -query $sql_readonly -serverinstance $server -database 'master' -QueryTimeout 3000  
    }
}


