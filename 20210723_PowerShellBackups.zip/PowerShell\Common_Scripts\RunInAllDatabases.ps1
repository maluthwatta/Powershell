﻿param 
( 
    [string]$Server, 
    [string]$DatabaseList = "\\oceania\CTS\DEPTDATA\Development\DatabaseAdmins\Development\AluthwattaM\PowerShell\DataFiles\List.txt",
    [string]$SqlQuery
)

. \\oceania\CTS\DEPTDATA\Development\DatabaseAdmins\Development\AluthwattaM\PowerShell\Common_Scripts\Functions.ps1

$dbList = ConfirmAll

foreach ($database in $dbList)
{
    try
    { 
        Write-Host "Database Name: $database" 
        invoke-sqlcmd -ServerInstance $SqlServer -query $ExecuteQuery -Database $database | ft -AutoSize
    }
    catch
    {
        $errorMessage = $_.Exception.Message
        $failedItem = $_.Exception.ItemName
        Write-Output "Error:" $failedItem
        Write-Output $errorMessage
    }
}

Write-Host "Complete"