﻿param 
( 
    [string]$Database = "tempdb",
    [string]$SqlQuery
)

. \\oceania\CTS\DEPTDATA\Development\DatabaseAdmins\Development\AluthwattaM\PowerShell\Common_Scripts\Functions.ps1

$InstanceList = ConfirmAllServerInstances

foreach ($ServerInstance in $InstanceList)
{
    try
    { 
        Write-Host "Server Name: $ServerInstance" 
        invoke-sqlcmd -ServerInstance $ServerInstance -query $SqlQuery -Database $Database | ft -AutoSize
    }
    catch
    {
        $errorMessage = $_.Exception.Message
        $failedItem = $_.Exception.ItemName
        Write-Output "Error:" $failedItem
        Write-Output $errorMessage
    }
}

Write-Host "Complete"