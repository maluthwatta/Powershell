﻿Import-Module \\oceania\cts\DEPTDATA\Development\DatabaseAdmins\Development\AluthwattaM\PowerShell\Common_Scripts\Functions.ps1 -Force

$server_list = ConfirmAllServerInstances

$database_to_run = "msdb"

$sql_to_run = "
exec sp_help_jobstep  @job_name = 'DBA.GT1000X_PURGE';
"

$output_array = @()
             
foreach ($server_name in $server_list)
{
    try{
        $results = invoke-sqlcmd -query $sql_to_run -serverinstance $server_name -database $database_to_run -QueryTimeout 3000 
        $results | Add-Member -NotePropertyName InstanceName -NotePropertyValue $server_name
        $output_array +=  $results   
    }
    catch{
        Write-Host $_
    }
}

$output_array | ft -AutoSize