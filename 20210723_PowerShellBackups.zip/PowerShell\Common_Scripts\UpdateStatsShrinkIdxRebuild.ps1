﻿param
(
    $server
    ,$database
)  

#update statistics
$sql_update_stats = "exec sp_updatestats;"

#shrink database
$sql_shrink_db = "dbcc shrinkdatabase('$database');"


#rebuil inefficient indexes
$sql_rebuild_index = "
    exec aadba.dbo.p_DBX_RebuildInefficientIndexes
	@DBName	= '$database'
	,@ScanDensity = 75
	,@NbrPages = 100
	,@RebuildIndex = 1
	,@RecordHistory = 1
	,@FillFactorPercent = 90	
	,@SortInTempDB = 1			--for 2005
	,@MaxDop = 4				--for 2005  -- changed to 1 instead of 2
	,@Online = 0				--for 2005
	,@IgnoreIndexNbrPages = 8	--for 2005
	,@DebugFlag	= 1;
"

$all_sql = $sql_update_stats + $sql_shrink_db + $sql_rebuild_index
write-host $all_sql
$startTime = Get-Date
write-host "Start: " $startTime
invoke-sqlcmd -query $all_sql -serverinstance $server -database $database -QueryTimeout 30000 
$endTime = Get-Date
write-host "End: " $endTime
    
