﻿$PRODCOPY_AU = @{"Environment" = "PRODCOPY"; "Region" = "AU"; "server" = "CSODEVSQL42INS4\INS4"; "database" = "CC_AU_PRODCOPY_2008"; "Active" = 1}
$PRODCOPY_NA = @{"Environment" = "PRODCOPY"; "Region" = "NA"; "server" = "CSACCOSSQLUAT4C\COS"; "database" = "CC_NA_PRODCOPY_2008"; "Active" = 1}
$PRODCOPY_UK = @{"Environment" = "PRODCOPY"; "Region" = "UK"; "server" = "CSESQL5CUAT2\UAT2"; "database" = "CC_UK_PRODCOPY_2008"; "Active" = 1}
$PRODCOPY = $PRODCOPY_AU, $PRODCOPY_NA, $PRODCOPY_UK

$DBATEST_AU = @{"Environment" = "DBATEST"; "Region" = "AU"; "server" = "CSODEVSQL42INS4\INS4"; "database" = "CC_AU_DBATEST"; "Active" = 1}
$DBATEST_NA = @{"Environment" = "DBATEST"; "Region" = "NA"; "server" = "CSODEVSQL42INS3\INS3"; "database" = "CC_NA_DBATEST"; "Active" = 1}
$DBATEST_UK = @{"Environment" = "DBATEST"; "Region" = "UK"; "server" = "CSODEVSQL42INS3\INS3"; "database" = "CC_UK_DBATEST"; "Active" = 1}
$DBATEST = $DBATEST_AU, $DBATEST_NA, $DBATEST_UK

$SYSTEST_AU = @{"Environment" = "SYSTEST"; "Region" = "AU"; "server" = "CSODEVSQL42INS4\INS4"; "database" = "CC_AU_SYSTEST"; "Active" = 1}
$SYSTEST_NA = @{"Environment" = "SYSTEST"; "Region" = "NA"; "server" = "CSODEVSQL42INS3\INS3"; "database" = "CC_NA_SYSTEST"; "Active" = 1}
$SYSTEST_UK = @{"Environment" = "SYSTEST"; "Region" = "UK"; "server" = "CSODEVSQL42INS3\INS3"; "database" = "CC_UK_SYSTEST"; "Active" = 1}
$SYSTEST = $SYSTEST_AU, $SYSTEST_NA, $SYSTEST_UK

$TRAINING_AU = @{"Environment" = "TRAINING"; "Region" = "AU"; "server" = "CSODEVSQL42INS4\INS4"; "database" = "CC_AU_TRAIN"; "Active" = 1}
$TRAINING_NA = @{"Environment" = "TRAINING"; "Region" = "NA"; "server" = "CSACCOSSQLUAT4C\COS"; "database" = "CC_NA_TRAIN"; "Active" = 1}
$TRAINING_UK = @{"Environment" = "TRAINING"; "Region" = "UK"; "server" = "CSESQL5CUAT2\UAT2"; "database" = "CC_UK_TRAIN"; "Active" = 1}
$TRAINING = $TRAINING_AU, $TRAINING_NA, $TRAINING_UK

$SIT_AU = @{"Environment" = "SIT"; "Region" = "AU"; "server" = "CSODEVSQL42INS4\INS4"; "database" = "CC_SIT_AU"; "Active" = 1}
$SIT_NA = @{"Environment" = "SIT"; "Region" = "NA"; "server" = "CSACCOSSQLUAT4C\COS"; "database" = "CC_SIT_NA"; "Active" = 1}
$SIT_UK = @{"Environment" = "SIT"; "Region" = "UK"; "server" = "CSESQL5CUAT2\UAT2"; "database" = "CC_SIT_UK"; "Active" = 1}
$SIT = $SIT_AU, $SIT_NA, $SIT_UK

$UAT_AU = @{"Environment" = "UAT"; "Region" = "AU"; "server" = "CSODEVSQL42INS4\INS4"; "database" = "CC_AU_UAT"; "Active" = 1}
$UAT_NA = @{"Environment" = "UAT"; "Region" = "NA"; "server" = "CSACCOSSQLUAT4C\COS"; "database" = "CC_NA_UAT"; "Active" = 1}
$UAT_UK = @{"Environment" = "UAT"; "Region" = "UK"; "server" = "CSESQL5CUAT2\UAT2"; "database" = "CC_UK_UAT"; "Active" = 1}
$UAT = $UAT_AU, $UAT_NA, $UAT_UK

$HANDOVER_AU = @{"Environment" = "HANDOVER"; "Region" = "AU"; "server" = "CSODEVSQL42INS4\INS4"; "database" = "CC_HANDOVER_AU"; "Active" = 1}
$HANDOVER_NA = @{"Environment" = "HANDOVER"; "Region" = "NA"; "server" = "CSACCOSSQLUAT4C\COS"; "database" = "CC_HANDOVER_NA"; "Active" = 1}
$HANDOVER_UK = @{"Environment" = "HANDOVER"; "Region" = "UK"; "server" = "CSESQL5CUAT2\UAT2"; "database" = "CC_HANDOVER_UK"; "Active" = 1}
$HANDOVER = $HANDOVER_AU, $HANDOVER_NA, $HANDOVER_UK
