﻿$SQL_TO_RUN = 
"ALTER DATABASE <<DB_NAME>> 
SET RECOVERY SIMPLE
GO

ALTER DATABASE <<DB_NAME>> 
SET COMPATIBILITY_LEVEL = 100 
GO

USE <<DB_NAME>>
GO

-- This database was not set as CHECKSUM
if ((select page_verify_option from sys.databases where name = '<<DB_NAME>>') <> 2 )
begin
  ALTER DATABASE <<DB_NAME>> SET PAGE_VERIFY CHECKSUM WITH NO_WAIT;
  exec sp_msforeachtable 'alter index all on ? rebuild with (sort_in_tempdb = on, maxdop=2)';
end

DBCC UPDATEUSAGE (<<DB_NAME>>) WITH COUNT_ROWS; 

DBCC CHECKDB (<<DB_NAME>>) WITH DATA_PURITY;

-- Update statistics
exec('use <<DB_NAME>>; EXEC sp_updatestats;')
"