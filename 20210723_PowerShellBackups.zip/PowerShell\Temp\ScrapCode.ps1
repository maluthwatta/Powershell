
$ServerInstanceName = "MELYVDEVSQL39\INS1"

$ServerName = ""
$InstanceName = ""

#if the $ServerInstanceName has an instance then add a sub folder to the GT1000x path
$InstanceIndex = $ServerInstanceName.IndexOf("\")    
if ($InstanceIndex -gt 0){
    $ServerName = $ServerInstanceName.Substring(0, $InstanceIndex)
    $InstanceName =  $ServerInstanceName.Substring($InstanceIndex+1)
}
else
{
    $ServerName = $ServerInstanceName
}


$ServerName
$InstanceName