﻿
$FileServerName = "CSOVDEVFILE1"

<#
$FsrmQuotas = Invoke-Command -ComputerName $FileServerName -ScriptBlock {Get-FsrmQuota} | Group-Object -Property {($_.Path).Substring(0,3)} | `
        Select-Object -Property name, @{ Name = 'QuotaAllocated'; Expression = { ($_.Group | Measure-Object -Property size -Sum).Sum } }, `
        @{ Name = 'Usage'; Expression = { ($_.Group | Measure-Object -Property Usage -Sum).Sum } } 
#>


$FsrmQuotas = Invoke-Command -ComputerName "CSOVDEVFILE1" -ScriptBlock {Get-FsrmQuota}
$FsrmQuotaDetails = $FsrmQuotas | select Path, size, Usage
$childPaths = @()

foreach($quotaParent in $FsrmQuotaDetails)
{
    
    foreach($quotaChild in $FsrmQuotaDetails)
    {
        #write-host $quotaDetail1.Path $quotaDetail2.Path

        #write-host "$($quotaParent.Path): $($quotaChild.Path):" (($quotaChild.Path).Contains($quotaParent.Path) -AND (-NOT ($quotaChild.Path).Equals($quotaParent.Path)))

        
        $quotaPath = $quotaChild.Path
        $parentPath = $quotaPath 
        $rootPath = Split-Path -Path $quotaPath -Qualifier 
        $rootPath = $rootPath + "\"

        Do
        {    
            $parentPath = Split-Path -Path $parentPath -Parent 
            #Write-Host "$($quotaParent.Path) $($quotaChild.Path): $parentPath" ($quotaParent.Path).Equals($parentPath)
            if (($quotaParent.Path).Equals($parentPath))
            {
                #Write-Host $($quotaChild.Path)        
                $childPaths += $quotaChild.Path
            }
        }
        while ($parentPath -ne $rootPath)
        
    }
}

$FsrmNoDuplicates = $FsrmQuotaDetails | Where-Object {$childPaths -notcontains $_.Path} 


$FsrmNoDuplicates

#$FsrmQuotaDetails | Where-Object {$childPaths -contains $_.Path} 

#$FsrmQuotaDetails 

#$FsrmQuotaDetails.Rows | ft -AutoSize