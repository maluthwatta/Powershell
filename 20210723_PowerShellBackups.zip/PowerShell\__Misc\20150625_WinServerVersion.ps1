﻿
$server_array = 
"CSACSQLDEV3C",
"CSESQL5CDEV2\DEV2",
"CSODEVSQL42I10\INS10",
"CSODEVSQL42I11\INS11",
"CSODEVSQL42I12\INS12",
"CSODEVSQL42I13\INS13",
"CSODEVSQL42INS2\INS2",
"CSODEVSQL42INS3\INS3",
"CSODEVSQL42INS4\INS4",
"CSODEVSQL42INS6\INS6",
"CSODEVSQL42INS7\INS7",
"CSODEVSQL42INS8\INS8",
"CSODEVSQL42INS9\INS9",
"CSODEVSQL45",
"CSODEVSQL45INS2\INS2",
"CSODEVSQL45INS5\INS5",
"CSODEVSQL45INS6\INS6",
"CSOVDEVSQL1",
"CSOVDEVSQL2",
"CSOVUATSQL01",
"MELSVDEVSQL1",
"MELYDEVAPP246",
"MELYDEVAPP448\BOE140",
"MELYDEVAPP549",
"MELYDEVAPP582",
"MELYDEVSQL6",
"SYDCDEVSQL10",
"SYDCDEVSQL3",
"SYDCDEVSQL7",
"SYDCDEVSQL9",
"SYDCVCONF1"

foreach($server in $server_array)
{
    # Get Operating System Info
    $sServer = $server
    $sOS =Get-WmiObject -class Win32_OperatingSystem -computername $sServer

    foreach($sProperty in $sOS)
    {
       write-host $server `t $sProperty.Description `t $sProperty.Caption
       # write-host $sProperty.Caption
       # write-host $sProperty.OSArchitecture
       # write-host $sProperty.ServicePackMajorVersion
    }
}