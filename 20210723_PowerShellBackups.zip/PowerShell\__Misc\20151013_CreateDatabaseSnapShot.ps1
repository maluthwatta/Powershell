﻿<#
Author: Manoj Aluthwatta
Date: 13/10/2015
#>


[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Windows.Forms")
[void] [System.Reflection.Assembly]::LoadWithPartialName("System.Drawing") 

Set-Location C:

$debug = $true

function create-SnapShot
{
    param($environment)

    switch ($environment)
    {
        "CI-AU-ProdCopy"{$selected = @{"Region" = "AU"; "server_name" = "CSODEVSQL42INS4\INS4"; "database" = "CI_INVTEST"}}
        "CI-NA-ProdCopy"{$selected = @{"Region" = "NA"; "server_name" = "CSACCOSSQLUAT4C\COS"; "database" = "CI_INVTEST"}}
        "CI-UK-ProdCopy"{$selected = @{"Region" = "UK"; "server_name" = "CSESQL5CUAT2\UAT2"; "database" = "CI_INVTEST"}}
        "CC-NA-ProdCopy"{$selected = @{"Region" = "NA"; "server_name" = "CSACCOSSQLUAT4C\COS"; "database" = "CC_NA_PRODCOPY_2008"}}
        "CI_AluthwattaM_DEV"{$selected = @{"Region" = "AU"; "server_name" = "CSODEVSQL42INS3\INS3"; "database" = "CI_AluthwattaM_DEV"}}
    }

    $SQL_Files =
    "SELECT name, physical_name
    FROM master.sys.master_files
    WHERE database_id = db_id('$($selected.database)')
    and type_desc = 'ROWS'"

    if ($debug) 
    {
        write-host "Debug mode...." -ForegroundColor Yellow
        write-host $SQL_Files`n
    }

    $today = Get-Date
    $date = $today.ToString("yyyyMMdd")

    $server_selected = $($selected.server_name)
    $database_selected = $($selected.database)

    $results = invoke-sqlcmd -query $SQL_Files -serverinstance $server_selected -database $database_selected -QueryTimeout 300 
    
    $snapshot_sql = "CREATE DATABASE $database_selected`_$date`_SS ON`n"
    $first_run = $true

    foreach($file_path in $results)
    {
         $path = split-path -path $($file_path.physical_name) -parent          
         $path_name = $($file_path.name)
         $path_filename = $path + "\" + $path_name + "_data_" + $date + ".SS"
         if (!$first_run) 
         {
            $snapshot_sql += ",(NAME =  $path_name, FILENAME = '$path_filename')`n"
         }
         else
         {
            $snapshot_sql += "(NAME =  $path_name, FILENAME = '$path_filename')`n"
         }
         $first_run = $false
    }

    $snapshot_sql += "AS SNAPSHOT OF $database_selected"
    
    if ($debug) 
    {
        write-host $snapshot_sql
    }    
    else
    {
        invoke-sqlcmd -query $snapshot_sql -serverinstance $server_selected -database $database_selected -QueryTimeout 300 
        write-host "Snapshot $database_selected`_$date`_SS created" -ForegroundColor Green
    }

}

$objForm = New-Object System.Windows.Forms.Form 
$objForm.Text = "Create Database Snapshot"
$objForm.Size = New-Object System.Drawing.Size(300,200) 
$objForm.StartPosition = "CenterScreen"

# Got rid of the block of code related to KeyPreview and KeyDown events.
$OKButton = New-Object System.Windows.Forms.Button
$OKButton.Location = New-Object System.Drawing.Size(75,120)
$OKButton.Size = New-Object System.Drawing.Size(75,23)
$OKButton.Text = "OK"

# Got rid of the Click event for the OK button, and instead just assigned its DialogResult property to OK.
$OKButton.DialogResult = [System.Windows.Forms.DialogResult]::OK

$objForm.Controls.Add($OKButton)

# Setting the form's AcceptButton property causes it to automatically intercept the Enter keystroke and
# treat it as clicking the OK button (without having to write your own KeyDown events).
$objForm.AcceptButton = $OKButton

$CancelButton = New-Object System.Windows.Forms.Button
$CancelButton.Location = New-Object System.Drawing.Size(150,120)
$CancelButton.Size = New-Object System.Drawing.Size(75,23)
$CancelButton.Text = "Cancel"

# Got rid of the Click event for the Cancel button, and instead just assigned its DialogResult property to Cancel.
$CancelButton.DialogResult = [System.Windows.Forms.DialogResult]::Cancel

$objForm.Controls.Add($CancelButton)

# Setting the form's CancelButton property causes it to automatically intercept the Escape keystroke and
# treat it as clicking the OK button (without having to write your own KeyDown events).
$objForm.CancelButton = $CancelButton

$objLabel = New-Object System.Windows.Forms.Label
$objLabel.Location = New-Object System.Drawing.Size(10,20) 
$objLabel.Size = New-Object System.Drawing.Size(280,20) 
$objLabel.Text = "Please select a server:"
$objForm.Controls.Add($objLabel) 

$objListBox = New-Object System.Windows.Forms.ListBox 
$objListBox.Location = New-Object System.Drawing.Size(10,40) 
$objListBox.Size = New-Object System.Drawing.Size(260,20) 
$objListBox.Height = 80

[void] $objListBox.Items.Add("CI-NA-ProdCopy")
[void] $objListBox.Items.Add("CI-AU-ProdCopy")
[void] $objListBox.Items.Add("CI-UK-ProdCopy")
[void] $objListBox.Items.Add("CC-NA-ProdCopy")
[void] $objListBox.Items.Add("CI_AluthwattaM_DEV")


$objForm.Controls.Add($objListBox) 

$objForm.Topmost = $True

# Now, instead of having events in the form assign a value to a variable outside of their scope, the code that calls the dialog
# instead checks to see if the user pressed OK and selected something from the box, then grabs that value.

$result = $objForm.ShowDialog()
if ($result -eq [System.Windows.Forms.DialogResult]::OK -and $objListBox.SelectedIndex -ge 0)
{
    $selection = $objListBox.SelectedItem
    #Clear-Host

    # Do something with $selection    
    create-SnapShot -environment $selection
}