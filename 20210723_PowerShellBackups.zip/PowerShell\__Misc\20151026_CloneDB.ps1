<#Author: Manoj Aluthwatta#>
# Clone a SQL Server Database
######################################

$new_database = "Dialogue_Test_Brisbane"

$clone_server   = "CSODEVSQL42INS3\INS3"
$clone_database = "Dialogue_CaltexAU_DBCS"

$generate_script_only = $true
$delete_backup_after_restore = $true

$backup_path = "\\Csodevfile1\DBABackups_NoTape\MA\"

######################################

$sql_clone = 
"
select file_id, physical_name, SERVERPROPERTY('productversion') as sql_version 
from sys.master_files
where database_id = db_id('$clone_database')
and file_id in (1,2)
order by file_id asc
"

$results = invoke-sqlcmd -query $sql_clone -serverinstance $clone_server -database "master" -QueryTimeout 300 

$data_file = $null
$log_file = $null


foreach($result in $results)
{    
    switch ($result.file_id) 
    { 
        1 {$data_file = $result.physical_name } 
        2 {$log_file =  $result.physical_name }
    }
}

$data_file_path = split-path $data_file -Parent 
$log_file_path = split-path $log_file -Parent 

$sql_version = [version]$($results[0].sql_version)
if ($sql_version.Major -ge 12 )
{
    $dba_db = "aaDBA"
}
else
{
    $dba_db = "zDBA"
}


$new_data_file = $data_file_path + "\" + $new_database + "_Data.MDF"
$new_log_file = $log_file_path + "\" + $new_database + "_Log.LDF"

$newDBSQL = 
"
CREATE DATABASE $new_database 
ON 
( 
  NAME = $new_database`_Data
  ,FILENAME = '$new_data_file'
  ,SIZE = 2MB
  ,MAXSIZE = unlimited
  ,FILEGROWTH = 10MB

)
LOG ON 
( 
  NAME = $new_database`_Log 
  ,FILENAME = '$new_log_file'
  ,SIZE = 10MB
  ,MAXSIZE = unlimited
  ,FILEGROWTH = 10MB
); 
"     
    
$backupFileFormat = (get-date -f yyyy-MM-dd_HH_mm_ss)
$backupFileName = $backup_path + $clone_database + '_' + $backupFileFormat + '.cBAK'



<# Backup the database to the file share #>
$sql_backUp = "exec $dba_db..p_DBA_BackupDB @DB_Name = '$clone_database'
	           , @Backup_Path = '$backupFileName';"


<# Restore the database from the backup #>
$sql_restore = "exec $dba_db..p_DBA_RestoreDB @DB_Name = '$new_database'
     , @Backup_Path = '$backupFileName'   
     , @debug_flag = 0;" 


<# Create the shell database #>
if ($generate_script_only)
{
    Write-Host $newDBSQL
    Write-Host $sql_backUp
    Write-Host $sql_restore
}
else
{
    <# Execute the SQL commands#>

   try
   {
        Write-Host "Creating the backup: $backupFileName"
        invoke-sqlcmd -query $sql_backUp -serverinstance $clone_server -database "master" -QueryTimeout 3000 
        Write-Host "Complete."
        Write-Host "Creating the shell database: $new_database"
        invoke-sqlcmd -query $newDBSQL -serverinstance $clone_server -database "master" -QueryTimeout 3000 
        Write-Host "Complete."
        Write-Host "Restoring the backup"
        invoke-sqlcmd -query $sql_restore -serverinstance $clone_server -database "master" -QueryTimeout 3000 
        Write-Host "Cloning complete."

        if ($delete_backup_after_restore)
        {
            Write-Host "Deleting backup: $backupFileName"
            Remove-Item $backupFileName
            Write-Host "Backup deleted"
        }
    }
    catch
    {
            $errorMessage = $_.Exception.Message
            $failedItem = $_.Exception.ItemName
            Write-Output "Error:" $failedItem
            Write-Output $errorMessage
    }
}