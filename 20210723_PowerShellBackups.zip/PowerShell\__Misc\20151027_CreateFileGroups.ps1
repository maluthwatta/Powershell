﻿<#
CMSSession2016
IVRACDActivity2016
IVRACDSession2016
IVRCallerDialogs2016
IVRConnections2016
IVRDialogPrompt2016
IVRDialogStep2016
IVRFailedLogin2016
IVRFunctions2016
IVRFunctionState2016
IVRFunctionStatePath2016
IVRHangupCalls2016
IVRMessages2016
IVRMethods2016
IVRSessions2016
IVRSurvey2016
IVRTransactions2016
IVRTransferCalls2016
IVRUtterance2016
#>




$file_group_array = 
'CMSSession2017
IVRACDActivity2017
IVRACDSession2017
IVRCallerDialogs2017
IVRConnections2017
IVRDialogPrompt2017
IVRDialogStep2017
IVRFailedLogin2017
IVRFunctions2017
IVRFunctionState2017
IVRFunctionStatePath2017
IVRHangupCalls2017
IVRMessages2017
IVRMethods2017
IVRSessions2017
IVRSurvey2017
IVRTransactions2017
IVRTransferCalls2017
IVRUtterance2017
'.split("`n")

$database_name = "IVR_Reporting_TEST"
$file_path = "F:\CLA__DEVSQL45____DAT03_0270_mF\SQLData\IVR\"


foreach ($file_group in $file_group_array | Where-Object {$_ -ne ""}) 
{ 
    $file_group  = $file_group.Trim()
    $physical_filename = $file_path+$database_name+"_"+$file_group+".NDF"

    $SQL_FG = 
    "
    ALTER DATABASE $database_name
    ADD FILEGROUP $file_group;
    GO
    ALTER DATABASE $database_name 
    ADD FILE 
    (
        NAME = $file_group,
        FILENAME = '$physical_filename',
        SIZE = 1MB,
        MAXSIZE = Unlimited,
        FILEGROWTH = 10MB
    )
    TO FILEGROUP $file_group;
    GO"

    Write-Host $SQL_FG
}

