﻿
$source_file = 'CI_INVTEST-201711141627-0.bak'
$source_folder = '\\OCEANIA\SQLNonProdBackups\SQLMigration\CI-201711141627'
$destination_folder = "\\csovdevsql28\g$\INS1_Data_01"


robocopy $source_folder $destination_folder $source_file
