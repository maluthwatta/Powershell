﻿$server_name = "CSOVDEVSQL13"
$database_name = "ACU_DEV_AU"
$compression_type = "Page"

$SQL_TABLES = 
"
select top 10 s.name as [schema_name], t.name as [table_name] from sys.tables t
inner join sys.schemas s on s.schema_id = t.schema_id
where type = 'U'
"


$results = invoke-sqlcmd -query $SQL_TABLES -serverinstance $server_name -database $database_name -QueryTimeout 300 

$results_arr = $null

foreach ($result in $results)
{          
    
    $SQL_Compression = "EXEC sp_estimate_data_compression_savings '$($result.schema_name)', '$($result.table_name)', NULL, NULL, '$compression_type' ;"
    $results = invoke-sqlcmd -query $SQL_Compression -serverinstance $server_name -database $database_name -QueryTimeout 300 
    $results_arr += $results
}


$results_arr | select schema_name, object_name #, index_id, [size_with_current_compression_setting(KB)]