﻿# --------------------------- #
# Manoj Aluthwatta 25/11/2015 #
#-----------------------------#


$name_like = "Daniel Zhang"
$show_groups = $false
#########################

$name_like = "$name_like*"
$users = Get-ADUser -Filter {Name -like $name_like} 


foreach ($user in $users)
{
   Write-Host "************************************"
   Write-Host $user.Name
   Write-Host $user.UserPrincipalName
   
   if ($show_groups)
   {   
       Write-Host "************************************"
       $adgroups = get-ADPrincipalGroupMembership -identity $user.SamAccountName | Where-Object {$_.GroupCategory -eq "Security"} | Sort-Object $_.name #| Select name
       foreach($adgroup in $adgroups)
       { 
            $domain = $adgroup.distinguishedName
            $pos = $domain.IndexOf(",DC=")
            $domain = $domain.Substring($pos+1+3)
            $pos = $domain.IndexOf(",")
            $domain = $domain.Substring(0, $pos) 
       
            $group_name = $domain + "\" + $adgroup.name             
            
            Write-Host $group_name  
       }
       
   }
}

Write-Host "######## END ########"