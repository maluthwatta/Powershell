﻿<###################################################################  
   
Script Name: RandomCode.ps1  
   
Author: G.A.F.F Jakobs   
  
Description: A simple random code generator       
  
####################################################################>  
 
$password = ([char[]](Get-Random -Input $(48..57 + 65..90 + 97..122) -Count 12)) -join "" 
 
Write-Host -foregroundcolor white -backgroundcolor blue $password