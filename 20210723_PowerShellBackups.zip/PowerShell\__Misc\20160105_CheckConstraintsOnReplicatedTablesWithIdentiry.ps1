﻿# --------------------------- #
# Manoj Aluthwatta 05/01/2016 #
#-----------------------------#


$threshold = 70 #percent

#PRODUCT - CC, ENVIRONMENTS EXCLUDED - TRAINING, CLIENT(non-replicated)
[array]$AllDB = Import-Csv -Path \\csodevfile1\DBA\AluthwattaM\PowerShell\Common_Scripts\DB_Environments.csv | Where-Object {$_.Product -eq "CC" -and $_.Environment -ne "TRAINING" -and $_.Environment -ne "CLIENT"}


$sql_tables = 
"
SELECT 
    TableName = t.Name,
    ColumnName = c.Name,
    dc.Name,
    dc.definition,
	@@SERVERNAME as ServerName,
	db_name() as DatabaseName
FROM sys.tables t
INNER JOIN sys.check_constraints dc ON t.object_id = dc.parent_object_id
INNER JOIN sys.columns c ON dc.parent_object_id = c.object_id AND c.column_id = dc.parent_column_id
INNER JOIN dbo.m_mergearticles ma ON ma.Table_name = OBJECT_NAME (t.object_id) and
	ma.table_schema = SCHEMA_NAME (t.schema_id)
WHERE	
	c.is_identity = 1
ORDER BY t.Name
"


write-host "Environment" `t "Server" `t "Database" `t "Table Name" `t "Column" `t "Range Start" `t "Range End" `t "Current Value" `t "% Filled" `t "Danger Zone?"


foreach($db in $AllDB)
{    
    $server = $db.Server
    $database = $db.Database
    $environment = $db.Environment

    $results = invoke-sqlcmd -query $sql_tables -serverinstance $server -database $database -QueryTimeout 3000 

    foreach($table in $results)
    {

        $table_name = $table.TableName
        $sql_ident = "SELECT IDENT_CURRENT('$table_name') as CurrentValue"

        $range = ([regex]"\d+").matches($table.definition)
        $range_from = $range[0].Value
        $range_to = $range[1].Value
    
        $cur_ident = invoke-sqlcmd -query $sql_ident -serverinstance $server -database $database -QueryTimeout 3000 
        $cur_ident_value = $cur_ident.CurrentValue

        [int]$percentFilled = ($cur_ident_value - $range_from)*100/($range_to - $range_from)

        $foreground = "white"
        $danger_zone = ""

        if ($percentFilled -ge $threshold )
        {
            $foreground = "Red" 
            $danger_zone = "Y"
        }
    
        write-host $environment `t $server.PadRight(20, ' ') `t $database.PadRight(20, ' ') `t $table.TableName.PadRight(35, ' ') `t $table.ColumnName.PadRight(35, ' ') `t $range_from.PadRight(15, ' ') `t $range_to.PadRight(15, ' ') `t $cur_ident_value.ToString().PadRight(15, ' ') `t $percentFilled `t $danger_zone -ForegroundColor $foreground
    
    }
}

