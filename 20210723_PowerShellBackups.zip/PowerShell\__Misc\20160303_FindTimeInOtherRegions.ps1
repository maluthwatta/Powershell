﻿# --------------------------- #
# Manoj Aluthwatta 03/03/2016 #
#-----------------------------#

#Format: yyyyMMddHHmm

$AU_TIME = "" 
$UK_TIME = ""
$NA_TIME = "201602242206"


#Get the AU time diff with UTC
$AU_UTC_DIFF = invoke-sqlcmd -query "SELECT DATEDIFF (hour, GETUTCDATE(), GETDATE()) as TimeDIFF" -serverinstance "CSODEVSQL42INS3\INS3" -database "TempDB" -QueryTimeout 300 
[int]$AU_Time_Diff = $AU_UTC_DIFF[0]

#Get the NA time diff with UTC
$NA_UTC_DIFF = invoke-sqlcmd -query "SELECT DATEDIFF (hour, GETUTCDATE(), GETDATE()) as TimeDIFF" -serverinstance "CSACCOSSQLUAT4C\COS" -database "TempDB" -QueryTimeout 300 
[int]$NA_Time_Diff = $NA_UTC_DIFF[0]

#Get the UK time diff with UTC
$UK_UTC_DIFF = invoke-sqlcmd -query "SELECT DATEDIFF (hour, GETUTCDATE(), GETDATE()) as TimeDIFF" -serverinstance "CSESQL5CUAT2\UAT2" -database "TempDB" -QueryTimeout 300 
[int]$UK_Time_Diff = $UK_UTC_DIFF[0]


if ($AU_TIME -ne "")
{
    $timeToConvertAU = [datetime]::ParseExact($AU_TIME,”yyyyMMddHHmm”,[System.Globalization.CultureInfo]::InvariantCulture)
    $AU_Time = $timeToConvertAU


    $NA_hour_diff = $NA_Time_Diff-$AU_Time_Diff
    $NA_Time = $timeToConvertAU.AddHours($NA_hour_diff)
    
    $UK_hour_diff = $UK_Time_Diff-$AU_Time_Diff
    $UK_Time = $timeToConvertAU.AddHours($UK_hour_diff)
    
    Write-Host "AU Time: " $AU_Time.ToString('yyyy-MM-dd HH:mm')
    Write-Host "UK Time: " $UK_Time.ToString('yyyy-MM-dd HH:mm')
    Write-Host "NA Time: " $NA_Time.ToString('yyyy-MM-dd HH:mm')
}
