﻿$source_server = "MELYDEVAPP741"
$destination_server = "CSOVDEVSQL10"
$backup = $true
$restore = $true
$backup_path = "\\Csodevfile1\DBABackups_NoTape\MA\"


#DB List - \\csodevfile1\DBA\AluthwattaM\PowerShell\DataFiles\Databases.txt
$dbListFile = "\\csodevfile1\DBA\AluthwattaM\PowerShell\DataFiles\Databases.txt"
$databaseList = Get-Content $dbListFile


######################
# Backup database
######################

function BackupDB
{
    param($server, $database, $backup) 

    $sql_version_check = "SELECT serverproperty('ProductVersion') AS version"
    $sql_version = invoke-sqlcmd -query $sql_version_check -serverinstance $server -database 'tempDB' -QueryTimeout 60000
    $version = [version]$($sql_version.version)
    if ($version.Major -ge 12 )
    {
        $dba_db = "aaDBA"
    }
    else
    {
        $dba_db = "zDBA"
    }
    
    $sql_version = invoke-sqlcmd -query $sql_version_check -serverinstance $server -database 'tempDB' -QueryTimeout 60000 
    
    if (((Test-Path $backup) -eq $true) -and (!($force_backup)))
    {
        write-host "Backup file exists - $baseCurrentFile" -ForegroundColor Red
    }
    else
    {

        write-host $backup
        $sql = "
            exec p_DBA_BackupDB @DB_Name = '$database'
             , @Backup_Path = '$backup'   
            "
        write-host "Backingup database $database..."
        invoke-sqlcmd -query $sql -serverinstance $server -database $dba_db -QueryTimeout 60000 
        write-host "Backing up database $database complete."
        write-host "--------------------------------------"            
    }
}


######################
# Restore database
######################

function RestoreDB
{
    param($server, $database, $backup)       
    
    $sql_version_check = "SELECT serverproperty('ProductVersion') AS version"
    $sql_version = invoke-sqlcmd -query $sql_version_check -serverinstance $server -database 'tempDB' -QueryTimeout 60000
    $version = [version]$($sql_version.version)
    if ($version.Major -ge 12 )
    {
        $dba_db = "aaDBA"
    }
    else
    {
        $dba_db = "zDBA"
    }
         
    
    if ((Test-Path $backup) -eq $true)
    {
        write-host $backup
        $sql = "
                exec p_DBA_RestoreDB @DB_Name = '$database'
                 , @Backup_Path = '$backup'   
                 , @debug_flag = 0;
                "
                write-host "Restoring database $database..."
                invoke-sqlcmd -query $sql -serverinstance $server -database $dba_db -QueryTimeout 60000 
                write-host "Restoring database $database complete."
                write-host "--------------------------------------"       
    }
    else
    {
        write-host "File not found - $baseCurrentFile"  -ForegroundColor Red
    }
}


# List the database list and get the confirmation
foreach ($database in $databaseList)
{
    Write-Output $database
}

Write-Output ''

$response = Read-Host -Prompt 'Run in all above databases? (Y/N)' 
if (($response -eq 'y') -or ($response -eq 'Y'))
{
    foreach ($database in $databaseList) { 
    
        $today = Get-Date
        $date = $today.ToString("yyyyMMdd")
        $backup = $backup_path + $database + "_" + $date + ".cBAK"    

        BackupDB -server $source_server -database $database -backup $backup

        if ($restore)
        {
            RestoreDB -server $destination_server -database $database -backup $backup          
        }
    
    }

}