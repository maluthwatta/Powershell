﻿#$sql_2014_vms = "CSOVDEVSQL10", "CSOVDEVSQL11", "CSOVDEVSQL12", "CSOVDEVSQL13", "CSOVDEVSQL14", "CSOVDEVSQL15", "CSOVDEVSQL16", "CSOVDEVSQL17", "CSOVDEVSQL21", "CSOVUATSQL13", "CSOVTSTSQL2"

$sql_2014_vms = "CSOVDEVSQL17" ,"CSOVTSTSQL2"


Foreach ($sql_2014_vm in $sql_2014_vms){

    Get-WmiObject –class Win32_processor –computername $sql_2014_vm | ft systemname,Name,DeviceID,NumberOfCores,NumberOfLogicalProcessors, Addresswidth
    Get-WMIObject -class win32_physicalmemory -computer $sql_2014_vm | Format-Table devicelocator, capacity -a
    
}


