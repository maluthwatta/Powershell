﻿<# 
Manoj Aluthwatta
26/05/2016
#>

$server = "CSODEVSQL42INS3\INS3"
$filter = "GDE"


$s = New-Object (‘Microsoft.SqlServer.Management.Smo.Server’) $server

$databases = $s.databases | where {$_.Name -like "$filter*"}


#$databases | get-member | where {$_.membertype -eq “Property”}
foreach($database in $databases) 
{
    $dbsize = $database.size #in MB
    $name = $database.name
    ## Check the log File
    $logfiles = $database.logfiles
        foreach($logfile in $logfiles)
        {
            $filename = $logfile.filename
            $growth = $logfile.growth
            $growthtype = $logfile.growthtype #“Percent” 
            $size = $logfile.size
                    if(($name -ne “Master”) -and ($name -ne “Model”) -and ($name -ne “tempdb”) -and ($name -ne “msdb”))
                    {
                        $logfile.growth = 51200
                        $logfile.growthtype = “KB”
                        $logfile.alter()
                    }
        }
    ## Datafiles
    $filegroups = $database.filegroups
        foreach($group in $filegroups)
        {
            $files = $group.files
            foreach($file in $files)
                {
                $filename = $file.filename
                $type = $file.growthtype
                $growth = $file.growth
                $size = $file.size
                        if(($name -ne “Master”) -and ($name -ne “Model”) -and ($name -ne “tempdb”) -and ($name -ne “msdb”))
                        {
                                if($size -lt 102400)
                                {
                                $file.growth = 10240
                                $file.growthtype = “KB”
                                $file.alter()
                                }

                                if($size -gt 102400)
                                {
                                $file.growth = 102400
                                $file.growthtype = “KB”
                                $file.alter()
                                }

                        }
                }
        }

        Write-Output "File growth settings changed on database $database"
}

