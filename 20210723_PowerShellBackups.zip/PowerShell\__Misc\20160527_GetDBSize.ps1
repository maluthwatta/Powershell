﻿<# 
Manoj Aluthwatta
26/05/2016
#>

$server = "CSOVDEVSQL12"
$filter = "CCS_IX"


$exludeFileName = $true


$s = New-Object (‘Microsoft.SqlServer.Management.Smo.Server’) $server

$databases = $s.databases | where {$_.Name -like "$filter*"}

#$databases | get-member | where {$_.membertype -eq “Property”}

Write-Output "##########Sizes in MB#########"

foreach($database in $databases) 
{
    $dbsize = [math]::Round(($database.size),0)
    $name = $database.name

    Write-Output "Database: $name `t $dbsize"

    ## Check the log File
    $logfiles = $database.logfiles
    foreach($logfile in $logfiles)
    {
        $filename = $logfile.filename
        $name = $logfile.Name
        $size = [math]::Round((($logfile.size)/1024),0)
        if ($exludeFileName) {$filename = ""} 
          
        Write-Output "$name `t $filename `t $size" 
    }
    
    ## Datafiles
    $filegroups = $database.filegroups
    foreach($group in $filegroups)
    {
        $files = $group.files
        foreach($file in $files)
            {
                $filename = $file.filename
                $name = $file.Name
                $size = [math]::Round((($file.size)/1024),0)
                if ($exludeFileName) {$filename = ""} 
                 
                Write-Output "$name `t $filename `t $size" 
            }
    }
    Write-Output ""

}

