﻿<# 
Manoj Aluthwatta
27/05/2016
#>


$server = "CSODEVSQL42INS3\INS3"
$filter = "GDE"


$s = New-Object (‘Microsoft.SqlServer.Management.Smo.Server’) $server
$databases = $s.databases | where {$_.Name -like "$filter*"}

function CleanDB
{
    param($server, $database)  

    #re indexe all
    <#
    $sql_re_index_all = "
    exec sp_msforeachtable 'print ''Begin reindex for ?''
    alter index all on ? rebuild with (sort_in_tempdb = on, maxdop = 1)
    print ''End reindex for ?
 
    ''';
    "
    #>

    #update statistics
    $sql_update_stats = "exec sp_updatestats;"

    #shrink database
    $sql_shrink_db = "dbcc shrinkdatabase('$database');"

    #rebuil inefficient indexes
    $sql_rebuild_index = "
        exec zdba.dbo.p_DBX_RebuildInefficientIndexes
	    @DBName	= '$database'
	    ,@ScanDensity = 75
	    ,@NbrPages = 100
	    ,@RebuildIndex = 1
	    ,@RecordHistory = 1
	    ,@FillFactorPercent = 90	
	    ,@SortInTempDB = 1			--for 2005
	    ,@MaxDop = 1				--for 2005  -- changed to 1 instead of 2
	    ,@Online = 0				--for 2005
	    ,@IgnoreIndexNbrPages = 8	--for 2005
	    ,@DebugFlag	= 1;
    "

    $all_sql = $sql_update_stats + $sql_shrink_db + $sql_rebuild_index
    write-host $all_sql
    invoke-sqlcmd -query $all_sql -serverinstance $server -database $database -QueryTimeout 30000     
}


foreach ($database in $databases)
{    
    cleandb -server $server_name  -database $database.Name
}
