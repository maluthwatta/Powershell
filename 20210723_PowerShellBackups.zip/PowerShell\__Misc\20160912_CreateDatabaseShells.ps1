﻿$server = "CSODEVSQL42INS3\INS3"
$data_file_path = "G:\R5T2_DEVSQL41IN3_DAT04___0129_mG\SQLData\CI"
$log_file_path = "G:\R5T2_DEVSQL41IN3_LOG01_0F81_mG\SQLLog\CI"


$databases = @(
"CI_Dev_v45"
,"CI_Test_v45_ALL"
,"CI_Test_v45_AU"
,"CI_Test_v45_NA"
,"CI_Test_v45_UK"
)


foreach ($database in $databases) { 

    $SQL = 
    "CREATE DATABASE $database
    ON  (NAME = $database`_Data , FILENAME = '$data_file_path\$database`_Data.MDF')
    LOG ON (NAME = $database`_Log, FILENAME = '$log_file_path\$database`_Log.LDF')"

    Write-Host $SQL
    Write-Host 'GO'
    Write-Host ''

    #invoke-sqlcmd -query $SQL -serverinstance $server -database "master" -QueryTimeout 3000  
    
}

