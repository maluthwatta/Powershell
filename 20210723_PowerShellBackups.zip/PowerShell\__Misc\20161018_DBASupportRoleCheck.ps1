﻿
Write-Output "##################################"
Get-Date

#Check the AG's if they are on right node
Write-Output "Checking the AG's whether they are on right node...."
Invoke-Expression \\oceania\cts\DEPTDATA\Development\DatabaseAdmins\Development\AluthwattaM\PowerShell\20150526_ActiveClusterNode\ActiveClusterNodePolicyAG.ps1



#Check the clusters if they are on right node
#Write-Output "Checking the clusters whether they are on right node...."
#Invoke-Expression \\oceania\cts\DEPTDATA\Development\DatabaseAdmins\Development\AluthwattaM\PowerShell\20150526_ActiveClusterNode\ActiveClusterNodePolicy.ps1

#Check if the file server is on the right node
#Write-Output "Checking if the file server is on the right node...."
#Invoke-Expression \\oceania\cts\DEPTDATA\Development\DatabaseAdmins\Development\AluthwattaM\PowerShell\__Misc\20161018_MELYDEVFILE1_Drives.ps1


#Check file server Quotas
#Write-Output "FSRM Quota Report"
#Write-Output "#################"
#Invoke-Expression \\oceania\cts\DEPTDATA\Development\DatabaseAdmins\Development\AluthwattaM\PowerShell\__Misc\20180910_GetFileServerQuotaFSRM.ps1



