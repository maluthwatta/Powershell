﻿# --------------------------- #
# Manoj Aluthwatta 13/01/2017 #
#-----------------------------#

$server=”CSODEVSQL42INS4\INS4” # CSODEVSQL42INS4\INS4, CSESQL5CUAT2\UAT2, CSACCOSSQLUAT4C\COS     
$db_mask = "CI[_]AU[_]UAT"
$db_mask2 = "CI[_]AU[_]HO"


$heaps = "
SELECT SCH.name + '.' + TBL.name AS TableName 
FROM sys.tables AS TBL 
     INNER JOIN sys.schemas AS SCH 
         ON TBL.schema_id = SCH.schema_id 
     INNER JOIN sys.indexes AS IDX 
         ON TBL.object_id = IDX.object_id 
            AND IDX.type = 0 -- = Heap 
ORDER BY TableName
"


$sql_db = "
SELECT NAME FROM SYS.DATABASES 
WHERE NAME NOT IN ('master', 'model', 'msdb', 'aaDBA', 'zDBA')
AND NAME LIKE '$db_mask%' OR NAME LIKE '$db_mask2%'
ORDER BY NAME
"

$dbs = invoke-sqlcmd -query $sql_db  -serverinstance $server -database "master" -QueryTimeout 3000 


$heap_table1 = invoke-sqlcmd -query $heaps -serverinstance $server -database $dbs[0].NAME -QueryTimeout 3000  
#$heap_table1


ForEach ($db in $dbs)
{
    $heap_table2 = invoke-sqlcmd -query $heaps -serverinstance $server -database $db.NAME -QueryTimeout 3000     
    #$heap_table2
    $heap_tablesInt =  Compare-Object $heap_table1 $heap_table2 -includeEqual -excludeDifferent | ForEach-Object { $_.InputObject }
    $heap_table1 =  $heap_tablesInt
}


Write-Host "Common Tables"
Write-Host "-------------"

$heap_table1


#List the other tables different to common tables
Write-Host "Additional tables"
Write-Host "-------------"

ForEach ($db in $dbs)
{
    Write-Host $db.NAME ":"
    $heap_table2 = invoke-sqlcmd -query $heaps -serverinstance $server -database $db.NAME -QueryTimeout 3000     
    Compare-Object $heap_table1 $heap_table2 | ForEach-Object { $_.InputObject }    
    Write-Host "-------------"
}