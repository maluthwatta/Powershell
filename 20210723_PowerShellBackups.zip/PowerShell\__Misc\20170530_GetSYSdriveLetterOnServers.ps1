﻿#Include the functions script
. Z:\PowerShell\Common_Scripts\Functions.ps1

$ServerList = RunInAllDBs

if ($ServerList -ne $null)
{
    foreach ($Server in $ServerList)
    {
        $pos = $Server.IndexOf("\")
        if ($pos -eq -1 )
        {
            $pos = $Server.Length
        }

        $Server = $Server.Substring(0, $pos)

        Try
        {
            Get-WmiObject Win32_Volume -ComputerName $Server -ErrorAction Continue | Where-Object {$_.Label -eq "SYS"} | Select SystemName, DriveLetter, Label 
        }
        Catch
        {
            $Server 
        }
    }
}
else
{
    Write-host "Terminated"
}




