﻿$date = Get-Date
$nextWK = $date.AddDays(7).ToString('MM/dd/yyyy') + " 6:00PM"
$olAppointmentItem = 1 
$o = new-object -comobject outlook.application


$a = $o.CreateItem($olAppointmentItem)
$a.MeetingStatus = 1
$a.Start = [datetime]$nextWK
$a.Duration = 30
$a.Subject = "TT"
$a.Body = "TT"
$a.Location = "#AU MELY Room Table Tennis"
$a.ReminderMinutesBeforeStart = 15
$a.ReminderSet = $True
$a.ForceUpdateToAllAttendees =$True
$a.recipients.add("AUMELYRoomTableTennis@computershare.com.au")
#$a.recipients.add("Daniel.Zhang@computershare.com.au")
$a.send()
$result = $a.Save()


