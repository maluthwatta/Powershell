﻿# --------------------------- #
# Manoj Aluthwatta 13/06/2017 #
#-----------------------------#


$LinkedServerName = "DB-Aardvark-HO-Melbourne.oceania.cshare.net,9105"
$ServerName = "CSOVDEVSQLC30i1\ins1"
$debug = $false


$sqlCreate = 
"exec master.dbo.sp_addlinkedserver
   @server = N'$LinkedServerName'
   ,@srvproduct = N''
   ,@provider = N'SQLNCLI'
   ,@datasrc = N'$ServerName';"

Write-host $sqlCreate
Write-Host "GO"

if (!$debug)
{
    invoke-sqlcmd -query $sqlCreate -serverinstance $ServerName -database "master" -Verbose -QueryTimeout 3000 
}

$sqlLoginSecurity = 
"exec master.dbo.sp_addlinkedsrvlogin
	@rmtsrvname = N'$LinkedServerName'
	,@useself = N'True'
	,@locallogin = NULL;"

Write-host $sqlLoginSecurity
Write-Host "GO"


if (!$debug)
{
    invoke-sqlcmd -query $sqlLoginSecurity -serverinstance $ServerName -database "master" -Verbose -QueryTimeout 3000 
}


$ServerOption= @{}
$ServerOption.Add("collation compatible", "true")
$ServerOption.Add("data access", "true")
$ServerOption.Add("dist", "false")
$ServerOption.Add("pub", "false")
$ServerOption.Add("rpc", "false")
$ServerOption.Add("rpc out", "false")
$ServerOption.Add("sub", "false")
$ServerOption.Add("connect timeout", "0")
$ServerOption.Add("collation name", "null")
$ServerOption.Add("lazy schema validation", "true")
$ServerOption.Add("query timeout", "0")
$ServerOption.Add("use remote collation", "true")
$ServerOption.Add("remote proc transaction promotion", "false")

foreach ($option in $ServerOption.GetEnumerator()) {
    $sqlOption = "exec master.dbo.sp_serveroption
	@server=N'$LinkedServerName'
	,@optname=N'$($option.Name)'
	,@optvalue=N'$($option.Value)'"
    
    Write-host $sqlOption
    Write-Host "GO"

    if (!$debug)
    {
        invoke-sqlcmd -query $sqlOption -serverinstance $ServerName -database "master" -Verbose -QueryTimeout 3000 
    }
}

$sqlValidation = "exec sp_helpserver @server= N'$LinkedServerName'"
invoke-sqlcmd -query $sqlValidation -serverinstance $ServerName -database "master" -Verbose -QueryTimeout 3000 