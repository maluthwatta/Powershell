﻿$domain = "oceania.cshare.net" # oceania, emea, americas #
$group = "!All Web Statistics Users"

#get-adgroupmember -Server $domain -Identity $group -Recursive | Select-Object SamAccountName

get-adgroupmember -Server $domain -Identity $group | Select-Object SamAccountName