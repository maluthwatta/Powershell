﻿# Add the AMO namespace
$loadInfo = [Reflection.Assembly]::LoadWithPartialName(“Microsoft.AnalysisServices”)

## Connect and get the edition of the local server
$connection = “csodevsql45ins4”
$server = New-Object Microsoft.AnalysisServices.Server
$server.connect($connection)


$server.ServerProperties | ft -AutoSize > c:\temp\csodevsql45ins4.txt

<#
foreach ($d in $server.Databases )
{
    Write-Output ( “`nDatabase: {0} Size: {1}`n” -f $d.Name, $d.EstimatedSize )

    foreach ($cube in $d.Cubes) {
        Write-Output ( “Cube: {0}” -f $Cube.Name )
        foreach ($mg in $cube.MeasureGroups) {
            Write-Output ( ” Measure Group: {0} Size: {1}” -f $mg.Name, $mg.EstimatedSize )
            foreach ($part in $mg.Partitions) {
                Write-Output ( “ Partition: {0} Size: {1}” -f $part.Name, $part.EstimatedSize )
            } # Partition
        } # Measure group

        foreach ($dim in $d.Dimensions) {
            Write-Output ( “Dimension: {0}” -f $dim.Name)
        } # Dimensions

    } # Cube

} # Databases
#>