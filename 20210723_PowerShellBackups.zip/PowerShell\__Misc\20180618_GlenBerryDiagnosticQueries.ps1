﻿<# 
To istall dbatools use the below query.

    Invoke-Expression (Invoke-WebRequest -UseBasicParsing https://dbatools.io/in)

#>




Get-Help Invoke-DbaDiagnosticQuery -Detailed


<# To select and run Glenberry queries on a selected instance #>

Invoke-DbaDiagnosticQuery -SqlInstance CSOVDEVSQL29\INS1 -UseSelectionHelper | Select Result

Invoke-DbaDiagnosticQuery -SqlInstance "DEVSQLAG33L02,20000" -UseSelectionHelper | Export-DbaDiagnosticQuery -Path C:\temp\gboutput