﻿$FileServerName = "CSOVDEVFILE1"

Write-Host "FSRM Quota from" $FileServerName

try
{
    Invoke-Command -ComputerName $FileServerName -ScriptBlock {Get-FsrmQuota} | `
    Select Path, @{Name="AllocatedMB"; Expression={[math]::truncate($_.size/1MB)}}, `
    @{Name="UsageMB"; Expression={[math]::truncate($_.Usage/1MB)}},`
    @{Name="FreeMB"; Expression={[math]::truncate(($_.size-$_.Usage)/1MB)}},`
    @{Name="Free%"; Expression={[math]::round((($_.size-$_.Usage)*100/$_.size), 0)}} | Sort-Object -Property Free% | ft  -AutoSize 
}
Catch
{
    write-host "Error: $($_.Exception.Message)" -ForegroundColor Red
}



