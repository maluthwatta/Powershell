﻿$FileServerName = "CSOVDEVFILE1"
$PathName = "E:\DFSRoots\SQLNonProdBackups\CSOVDEVSQL27INS1"
$SetSizeTo = 50GB

# SYNTAX
#Set-FsrmQuota -Path "C:\Shares" -Description "limit usage to 1.5 GB" -Size 1.5GB

Write-Host "Set FSRM Quota of $PathName to $SetSizeTo"

$confirmation = Read-Host "Are you Sure You Want To Proceed:"
if ($confirmation -eq 'y' -or $confirmation -eq 'Y') {
    try
    {
        Invoke-Command -ComputerName $FileServerName -ScriptBlock {Set-FsrmQuota -Path $Using:PathName -Size $Using:SetSizeTo} 
        Write-Host "Complete.."
    }
    catch
    {
        write-host "Error: $($_.Exception.Message)" -ForegroundColor Red
    }

}


