﻿                        
$FileServerName = "CSOVDEVFILE1"
$logfile = '\\OCEANIA\CTS\DEPTDATA\GPandD\DBA\DBA_DEPTDATA\PSScripts\ScriptLogs\FSRM_Report.log'

$diskArray =  @()

Try
{
    [string]$starttime = Get-Date -Format "dd-MMM-yyyy @ hh:mm:ss tt"
    $startString = "The job started $starttime "
    Write-Output $startString > $logfile
    Write-Output "" >>  $logfile
    Write-Output "File Server Name: $FileServerName"  >>  $logfile

    $Disks = Get-WmiObject Win32_Volume -ComputerName $FileServerName | where {($_.DriveLetter -eq "E:" -or $_.DriveLetter -eq "F:")} | select Name, Capacity, Freespace 
    $FsrmQuotaDetails = Invoke-Command -ComputerName "CSOVDEVFILE1" -ScriptBlock {Get-FsrmQuota} | select Path, size, Usage

    #########################################
    # Remove the duplicate quota paths
    # e.g. F:\Data\DevDumps\OpsTech will be removed and F:\Data\DevDumps will be retained 
    #
 
    $childPaths = @()

    foreach($quotaParent in $FsrmQuotaDetails)
    {    
        foreach($quotaChild in $FsrmQuotaDetails)
        {        
            $quotaPath = $quotaChild.Path
            $parentPath = $quotaPath 
            $rootPath = Split-Path -Path $quotaPath -Qualifier 
            $rootPath = $rootPath + "\"

            Do
            {    
                $parentPath = Split-Path -Path $parentPath -Parent 
                if (($quotaParent.Path).Equals($parentPath))
                {  
                    $childPaths += $quotaChild.Path
                }
            }
            while ($parentPath -ne $rootPath)
        
        }
    }

    $FsrmNoDuplicates = $FsrmQuotaDetails | Where-Object {$childPaths -notcontains $_.Path} 
    #
    #########################################

    <#
    $FsrmQuotas = Invoke-Command -ComputerName $FileServerName -ScriptBlock {Get-FsrmQuota} | Group-Object -Property {($_.Path).Substring(0,3)} | `
        Select-Object -Property name, @{ Name = 'QuotaAllocated'; Expression = { ($_.Group | Measure-Object -Property size -Sum).Sum } }, `
        @{ Name = 'Usage'; Expression = { ($_.Group | Measure-Object -Property Usage -Sum).Sum } } 
    #>

    $FsrmQuotas = $FsrmNoDuplicates | Group-Object -Property {($_.Path).Substring(0,3)} | `
        Select-Object -Property name, @{ Name = 'QuotaAllocated'; Expression = { ($_.Group | Measure-Object -Property size -Sum).Sum } }, `
        @{ Name = 'Usage'; Expression = { ($_.Group | Measure-Object -Property Usage -Sum).Sum } } 

    
    $sumCapacityGB = 0
    $sumCapacityFreeGB = 0
    $sumQuotaAllocatedGB = 0
    $sumQuotaFreeGB = 0
    $sumCapacityQuotaDiffGB = 0

    foreach($disk in $Disks)
    {    
        foreach($quota in $FsrmQuotas | where {$_.Name -eq $disk.Name})
        {
            $hItemDetails = [PSCustomObject]@{    
                Drive = $disk.Name
                CapacityGB = [math]::round(($disk.Capacity)/1GB,0)
                CapacityFreeGB = [math]::round(($disk.Freespace)/1GB,0)   
                QuotaAllocatedGB = [math]::round(($quota.QuotaAllocated)/1GB,0)
                QuotaFreeGB = [math]::round(($quota.QuotaAllocated-$quota.Usage)/1GB,0)
                CapacityQuotaDiffGB = [math]::round((($disk.Capacity - $quota.QuotaAllocated)/1GB)) 
            }  
            $diskArray += $hItemDetails    
            $sumCapacityGB += [math]::round(($disk.Capacity)/1GB,0)
            $sumCapacityFreeGB += [math]::round(($disk.Freespace)/1GB,0) 
            $sumQuotaAllocatedGB += [math]::round(($quota.QuotaAllocated)/1GB,0)
            $sumQuotaFreeGB += [math]::round(($quota.QuotaAllocated-$quota.Usage)/1GB,0)
            $sumCapacityQuotaDiffGB += [math]::round((($disk.Capacity - $quota.QuotaAllocated)/1GB)) 

        }           
    }

    $diskArray += [PSCustomObject]@{    
                Drive = ""
                CapacityGB = ""
                CapacityFreeGB = ""  
                QuotaAllocatedGB = ""
                QuotaFreeGB = ""
                CapacityQuotaDiffGB = ""}

    $diskArray += [PSCustomObject]@{    
                Drive = "SUM"
                CapacityGB = $sumCapacityGB
                CapacityFreeGB = $sumCapacityFreeGB 
                QuotaAllocatedGB = $sumQuotaAllocatedGB
                QuotaFreeGB = $sumQuotaFreeGB
                CapacityQuotaDiffGB = $sumCapacityQuotaDiffGB}

    
    #$diskArray | ft -AutoSize >>  $logfile
    $diskArray | ft -AutoSize | Out-File -width 256 -filePath $logfile -Append 

    Write-Output "" >>  $logfile
    Write-Output "FSRM Quota Report (Order by Free% Desc)" >> $logfile
    Write-Output "---------------------------------------" >> $logfile
    
    $FsrmQuotaDetails  | Select Path, @{Name="AllocatedMB"; Expression={[math]::truncate($_.size/1MB)}}, `
    @{Name="UsageMB"; Expression={[math]::truncate($_.Usage/1MB)}},`
    @{Name="FreeMB"; Expression={[math]::truncate(($_.size-$_.Usage)/1MB)}},`  
    @{Name="Free%"; Expression={[math]::round((($_.size-$_.Usage)*100/$_.size), 0)}} | Sort-Object -Property Free% | ft  -AutoSize | Out-File -width 256 -filePath $logfile -Append     

    #Send the Email 
    $profileName= 'DBMAIL_CSODEVSQL42INS3'
    $server= 'CSODEVSQL42INS3\INS3'
    $recipients = 'Manoj.Aluthwatta@computershare.com.au'
    #$recipients = '#AUCTALLDBADevelopment@computershare.com.au'
    $bodyText = 'Run via scheduled job on MELYDEVTSE389'
    $emailSubject = 'FSRM Quota Report'
    $emailSQL = "sp_send_dbmail @profile_name='$profileName', @recipients='$recipients', @subject='$emailSubject', @file_attachments='$logFile', @body='$bodyText'"
    Invoke-Sqlcmd -ServerInstance $server -Database 'msdb' -Query $emailSQL -ErrorAction Stop -QueryTimeout 65535 -Verbose	
}
Catch
{
    Write-Output "Error: $($_.Exception.Message)" >> $logfile
}

