﻿# Drop and recreate tester databases"

$server_name = 'CSOVDEVSQL28\INS1'

#$product_name = 'GDE'

##################################
# To Change

$db_name = 'CI_BarryN'

##################################

$dbo_members = ''
$product_code, $database_name = $db_name.Split("_", 2)

# CI Permission
if ($product_code -eq 'CI'){
    $dbo_members = 'EMEA\!Global CTS EDI COSMOS Investor Developers', 'EMEA\!Global CTS EDI COSMOS Investor Testers', 'Oceania\!AU CT MEL Cosmos Investor Test Team';   
}

# CI Permission
if ($product_code -eq 'GDE'){
    $dbo_members = 'EMEA\!Global CTS EDI GDE Developers', 'EMEA\!Global CTS EDI GDE Testers', 'Oceania\!AU CT MEL Cosmos Investor Test Team';
}

# CI_automationTest
if ($db_name -eq 'CI_automationTest'){
    $dbo_members += 'OCEANIA\JenkinsAgent', 'OCEANIA\AUCTInvLauncherST'
} 



$kill_sessions = "ALTER DATABASE $db_name
SET SINGLE_USER
WITH ROLLBACK IMMEDIATE;
ALTER DATABASE $db_name
SET MULTI_USER;
"

$drop_db_sql = "DROP DATABASE IF EXISTS $db_name;"

$create_db_sql = "CREATE DATABASE $db_name
ON (NAME = $product_name`_Data, FileName = 'G:\INS1_DATA_01\SQLDATA\$product_name\$db_name`_Data.MDF')
LOG ON (NAME = $product_name`_Log, FileName = 'G:\INS1_LOG_01\SQLLOG\$product_name\$db_name`Log.LDF');"

$change_db_owner_sql = "EXEC sp_changedbowner 'cts_dba';"  


$drop_db_sql
$create_db_sql
#$permission_db_sql
# $permission_db_sql2
$change_db_owner_sql

#invoke-sqlcmd -query $kill_sessions -serverinstance $server_name -database 'master' -QueryTimeout 3000  
invoke-sqlcmd -query $drop_db_sql -serverinstance $server_name -database 'master' -QueryTimeout 3000  
invoke-sqlcmd -query $create_db_sql -serverinstance $server_name -database 'master' -QueryTimeout 3000  
invoke-sqlcmd -query $change_db_owner_sql -serverinstance $server_name -database $db_name -QueryTimeout 3000  


# Add permission
foreach ($dbo_member in $dbo_members){
    $permission_db_sql = "USE $db_name;
    if not exists(select * from sys.database_principals where name = '$dbo_member')
        CREATE USER [$dbo_member];
    ALTER ROLE db_owner ADD MEMBER [$dbo_member];"
    $permission_db_sql
    invoke-sqlcmd -query $permission_db_sql -serverinstance $server_name -database 'tempdb' -QueryTimeout 3000  
}
