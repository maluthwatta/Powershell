﻿# Change 1,2 & 3 
set-location C:


$run_query = $false

#1. The script to run: change to MANUAL or AUTOMATIC
$fail_over_mode = "AUTOMATIC" 

[array]$AllAG = Import-Csv -Path \\oceania\cts\DEPTDATA\Development\DatabaseAdmins\Development\AluthwattaM\PowerShell\DataFiles\AGList.csv


$sql_ag_fo_mode = "ALTER AVAILABILITY GROUP <<AG_NAME>> MODIFY REPLICA ON '<<REPLICA_NAME>>' WITH (FAILOVER_MODE = $fail_over_mode);"


foreach ($ag in $AllAG )
{
    #2. What's the current Primary - ReplicaY or ReplicaD 
    $primary_replica = $ag.ReplicaY    
    #3. Which replica should the mode be applied - ReplicaY or ReplicaD
    $replica_to_be_applied = $ag.ReplicaD
    
    $sql_to_run = $sql_ag_fo_mode.Replace("<<AG_NAME>>", $ag.AG)
    $sql_to_run = $sql_to_run.Replace("<<REPLICA_NAME>>", $replica_to_be_applied)

    if ($run_query)
    {
        $sql_to_run
        invoke-sqlcmd -query $sql_to_run -serverinstance $primary_replica -database 'master' -QueryTimeout 3000 
        Write-host "Applied to $primary_replica"
    }
    else
    {
         Write-host $sql_to_run
    }    
}

$all_servers =  $AllAG  | Select-Object ReplicaY -Unique
$sql_fo_mode = "select g.name As AGname, r.replica_server_name As ReplicaName, r.failover_mode_desc as FailoverMode 
from sys.availability_groups g 
	inner join sys.availability_replicas r on r.group_id = g.group_id
"

$output_array = @()

foreach ($AGserver in $all_servers )
{
    $results = invoke-sqlcmd -query $sql_fo_mode -serverinstance $AGserver.ReplicaY -database 'master' -QueryTimeout 3000 
    $output_array +=  $results    
}

$output_array | ft -AutoSize

