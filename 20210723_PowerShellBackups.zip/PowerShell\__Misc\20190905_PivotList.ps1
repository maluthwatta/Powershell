
$listFile = "\\oceania\cts\DEPTDATA\Development\DatabaseAdmins\Development\AluthwattaM\PowerShell\DataFiles\PivotList.txt"
$list = Get-Content $listFile

$enclosedCharacter = "`""
$output = ""
$first = $true

foreach ($item in $list)
{
    if ($first){
        $output += $enclosedCharacter + $item + $enclosedCharacter
        $first = $false
    }
    else {
        $output += ',' + $enclosedCharacter + $item + $enclosedCharacter
    }    
}

$output = '(' + $output + ')'

Write-Host $output