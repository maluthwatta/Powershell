﻿$date = Get-Date
$DateStr = $Date.ToString("yyyyMMdd")
$fileName = "C:\Backups\" + $DateStr + "_PowerShellBackups.zip"
Compress-Archive -Path \\Oceania\CTS\DEPTDATA\Development\DatabaseAdmins\Development\AluthwattaM\PowerShell -DestinationPath $fileName
