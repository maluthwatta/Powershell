$Acl = Get-Acl "\\melywp0273\DataShare"

$Ar = New-Object System.Security.AccessControl.FileSystemAccessRule("OCEANIA\SQLSRV_CSODEVSQL28I1", "FullControl", "ContainerInherit,ObjectInherit", "None", "Allow")

$Acl.SetAccessRule($Ar)
Set-Acl "\\melywp0273\DataShare" $Acl