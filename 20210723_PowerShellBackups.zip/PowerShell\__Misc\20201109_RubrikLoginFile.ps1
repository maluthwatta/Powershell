
$Credential = Import-CliXml -Path 'C:\PowerShell\cred.xml'
$SQLRubrikConnection = Connect-Rubrik -Server rubrik.oceania.cshare.net -Credential $Credential

$SQLRubrikConnection 

