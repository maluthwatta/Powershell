﻿# --------------------------- #
# Manoj Aluthwatta 26/02/2014 #
#-----------------------------#

#DBlist: \\oceania\CTS\DEPTDATA\Development\DatabaseAdmins\Development\AluthwattaM\PowerShell\DataFiles\List.txt


$SQL_SERVER = "CSODEVSQL42INS3\INS3"
$SQL = "CREATE USER [Oceania\AU ALL Citrix Dialogue Users];
exec sp_addrolemember 'db_datareader', [Oceania\AU ALL Citrix Dialogue Users];
exec sp_addrolemember 'db_datawriter', [Oceania\AU ALL Citrix Dialogue Users];"


. Z:\PowerShell\Common_Scripts\Functions.ps1

$dbList = ConfirmAll


foreach ($database in $dbList)
{
    try
    {   
        Write-Output "-------------------------------------"
        Write-Host "Database: $database"      
        invoke-sqlcmd -ServerInstance $SQL_SERVER -query $SQL -Database $database -Verbose -QueryTimeout 1800 | ft -AutoSize
      
    }
    catch
    {
        $errorMessage = $_.Exception.Message
        $failedItem = $_.Exception.ItemName
        Write-Output "Error:" $failedItem
        Write-Output $errorMessage
    }
}

$conn.Close();