﻿# --------------------------- #
# Manoj Aluthwatta 26/02/2014 #
#-----------------------------#


$SERVER_LIST =
"CSODEVSQL42I10\INS10",
"CSODEVSQL42I13\INS13",
"CSODEVSQL42INS2\INS2"

$SQL = 'select @@version as Out'


foreach ($server in $SERVER_LIST)
{
    $results = invoke-sqlcmd -query $SQL -serverinstance $server -database "master" -QueryTimeout 3000  -ErrorAction SilentlyContinue 
    Write-Host $server "-" $($results.Out)

}
