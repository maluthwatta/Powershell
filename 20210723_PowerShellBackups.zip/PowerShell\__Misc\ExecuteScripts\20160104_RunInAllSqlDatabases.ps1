﻿# --------------------------- #
# Manoj Aluthwatta 04/01/2016 #
#-----------------------------#

$ProductCode = "CC"
$sql = 
"
SELECT   TABLE_NAME, 
         COLUMN_NAME, 
         CHECK_CLAUSE, 
		 IDENT_CURRENT( 'Systemtransactions' ) as CurrentValue, 
		 @@SERVERNAME as ServerName,
		 db_name() as DatabaseName
FROM     INFORMATION_SCHEMA.CHECK_CONSTRAINTS cc 
         INNER JOIN INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE c 
           ON cc.CONSTRAINT_NAME = c.CONSTRAINT_NAME 
WHERE TABLE_NAME = 'Systemtransactions'
ORDER BY TABLE_NAME, 
         COLUMN_NAME 
"

[array]$AllDB = Import-Csv -Path \\csodevfile1\DBA\AluthwattaM\PowerShell\Common_Scripts\DB_Environments.csv | Where-Object {$_.Product -eq $ProductCode}


foreach($database in $AllDB)
{
    $results = invoke-sqlcmd -query $sql -serverinstance $database.Server -database $database.Database -QueryTimeout 3000 
    $results
    #write-host "$($results.TABLE_NAME) $($results.CHECK_CLAUSE) $($results.CurrentValue) $($database.Server) $($database.Database)"
}    
write-host "--------------------------------------------------------"  