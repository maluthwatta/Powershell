﻿# --------------------------- #
# Manoj Aluthwatta 03/06/2016 #
#-----------------------------#

$server=”CSODEVSQL42INS4\INS4”      
$db_mask = "CI[_]"



$sql_to_run = "
if exists (select 1 from sys.schemas where name = 'OCEANIA\!AU ALL NSDSQL Users')
begin
	drop schema [OCEANIA\!AU ALL NSDSQL Users]
	print 'Deleted schema from ' + db_name()
end

go

if exists (select 1 from sys.database_principals where name = 'OCEANIA\!AU ALL NSDSQL Users')
begin
	drop user [OCEANIA\!AU ALL NSDSQL Users]
	print 'Deleted user from ' + db_name()
end
"


$sql_db = "
SELECT NAME FROM SYS.DATABASES 
WHERE NAME NOT IN ('master', 'model', 'msdb', 'aaDBA', 'zDBA')
AND NAME LIKE '$db_mask%'
ORDER BY NAME
"

$dbs = invoke-sqlcmd -query $sql_db  -serverinstance $server -database "master" -QueryTimeout 3000 


ForEach ($db in $dbs)
{
    invoke-sqlcmd -query $sql_to_run -serverinstance $server -database $db.NAME -QueryTimeout 3000  
     
}
