﻿# --------------------------- #
# Manoj Aluthwatta 26/02/2014 #
#-----------------------------#

#DB List - \\csodevfile1\DBA\AluthwattaM\PowerShell\DataFiles\Databases.txt

$SQL_SERVER = "DEVSQLAG33L02,20000"

$SQL = "exec sp_helptext N'CISTAStage.p_PR_SCRIPAU_FilterOutAccountWithNoName'"


$dbListFile = "\\oceania\CTS\DEPTDATA\Development\DatabaseAdmins\Development\AluthwattaM\PowerShell\DataFiles\Databases.txt"
$databaseList = Get-Content $dbListFile

$conn = New-Object System.Data.SqlClient.SqlConnection "Server=$SQL_SERVER;Database=tempdb;Integrated Security=SSPI;"; 


foreach ($database in $databaseList)
{
    Write-Output $database
}

Write-Output ''

$response = Read-Host -Prompt 'Run in all above databases? (Y/N)' 
if (($response -eq 'y') -or ($response -eq 'Y'))
{

    ## Attach the InfoMessage Event Handler to the connection to write out the messages 
    $handler = [System.Data.SqlClient.SqlInfoMessageEventHandler] {param($sender, $event) Write-Host $event.Message }; 
    $conn.add_InfoMessage($handler); 
    $conn.FireInfoMessageEventOnUserErrors = $true;

    $conn.Open();

    $cmd = $conn.CreateCommand(); 
    $cmd.CommandText = $SQL; 
    $cmd.CommandTimeout = 3000

    foreach ($database in $databaseList)
    {
        try
        { 
            $conn.ChangeDatabase($database)
            $cmd.ExecuteNonQuery(); 
            Write-Output "-------------------------------------"
        }
        catch
        {
            $errorMessage = $_.Exception.Message
            $failedItem = $_.Exception.ItemName
            Write-Output "Error:" $failedItem
            Write-Output $errorMessage
        }
    }

    $conn.Close();

}



<#

$dbListFile = "\\csodevfile1\DBA\AluthwattaM\PowerShell\DataFiles\Databases.txt"

#>


<#

$databaseList = Get-Content $dbListFile
$conn = New-Object System.Data.SqlClient.SqlConnection "Server=$SQL_SERVER;Database=tempdb;Integrated Security=SSPI;"; 


## Attach the InfoMessage Event Handler to the connection to write out the messages 
$handler = [System.Data.SqlClient.SqlInfoMessageEventHandler] {param($sender, $event) Write-Host $event.Message }; 
$conn.add_InfoMessage($handler); 
$conn.FireInfoMessageEventOnUserErrors = $true;

$conn.Open();

$cmd = $conn.CreateCommand(); 
$cmd.CommandText = $SQL; 
$cmd.CommandTimeout = 3000


foreach ($database in $databaseList)
{
    try
    { 
        $conn.ChangeDatabase($database)
        $res = $cmd.ExecuteNonQuery(); 
        Write-Output "-------------------------------------"
    }
    catch
    {
        $errorMessage = $_.Exception.Message
        $failedItem = $_.Exception.ItemName
        Write-Output "Error:" $failedItem
        Write-Output $errorMessage
    }
}

$conn.Close();


#>