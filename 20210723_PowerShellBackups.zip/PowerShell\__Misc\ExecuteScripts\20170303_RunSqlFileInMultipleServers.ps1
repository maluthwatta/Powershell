﻿# --------------------------- #
# Manoj Aluthwatta 26/02/2014 #
#-----------------------------#

#Sever List - \\csodevfile1\DBA\AluthwattaM\PowerShell\DataFiles\Databases.txt


$sql_file = 'C:\MY_TFS\DBA OCEANIA\Release\Scripts\GT1000X\Scripts\SQL\05 p_xe_load_gt1000.sql'

$databaseName = "aaDBA"


$serverListFile = "\\csodevfile1\DBA\AluthwattaM\PowerShell\DataFiles\Databases.txt"
$serverList = Get-Content $serverListFile


foreach ($server in $serverList)
{
    Write-Output $server
}

Write-Output ''

$response = Read-Host -Prompt 'Run in all above servers? (Y/N)' 
if (($response -eq 'y') -or ($response -eq 'Y'))
{
    foreach ($server in $serverList) 
    {     
        try
        {             
            Write-Output "Server: $server"
            $results = Invoke-Sqlcmd -InputFile $sql_file -ServerInstance $server -database $databaseName -ErrorAction Stop -Verbose -QueryTimeout 1800 # 30min
            $results | Format-Table 
            Write-Output "-------------------------------------"    
        }
        catch
        {
            $errorMessage = $_.Exception.Message
            $failedItem = $_.Exception.ItemName
            Write-Output "Error:" $failedItem
            Write-Output $errorMessage
        }        
    }
}


