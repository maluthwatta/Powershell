﻿# --------------------------- #
# Manoj Aluthwatta 26/02/2014 #
#-----------------------------#

#Sever List - \\csodevfile1\DBA\AluthwattaM\PowerShell\DataFiles\Databases.txt


#$outputCSVfilePath = "Z:\Projects\DBA\20170201-GT1000X\20190205-NonProdDeployment\Output01.csv"

$outputCSVfilePath = ""


$SQL = 
"
select * from perf.gt1000
where sql_text like '%exec sp_executesql%'
"

$databaseName = "aaDBA"


$serverListFile = "Y:\PowerShell\DataFiles\Servers.txt"
$serverList = Get-Content $serverListFile


foreach ($server in $serverList)
{
    Write-Output $server
}

Write-Output ''

$response = Read-Host -Prompt 'Run in all above servers? (Y/N)' 
if (($response -eq 'y') -or ($response -eq 'Y'))
{
    
    $output_array = @()
    
    foreach ($server in $serverList)
    {
        try
        { 
            $results = invoke-sqlcmd -query $sql -serverinstance $server -database $databaseName -Verbose -QueryTimeout 300              
            $output_array +=  $results               
            $results | Format-Table -AutoSize     
        }
        catch
        {
            $errorMessage = $_.Exception.Message
            $failedItem = $_.Exception.ItemName
            Write-Output "Error:" $failedItem
            Write-Output $errorMessage
        }
    }

    $conn.Close();

    Write-host 'Output in a single result set:'
    Write-host '------------------------------'

    $output_array | Format-Table -AutoSize 
    
    if ($outputCSVfilePath -ne "")
    {
        $output_array | Select-Object -Property ServerName, GT1000, X  | Export-Csv –Path $outputCSVfilePath
    }
    
}


