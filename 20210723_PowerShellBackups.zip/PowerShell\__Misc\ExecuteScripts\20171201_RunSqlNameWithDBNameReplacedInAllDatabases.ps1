﻿<#

PS script will replace <<DB_NAME>> with the appropriate actual database name.
e.g. 
$SQL_TO_RUN = "ALTER DATABASE <<DB_NAME>> SET QUERY_STORE = ON;"

DBlist: \\oceania\CTS\DEPTDATA\Development\DatabaseAdmins\Development\AluthwattaM\PowerShell\DataFiles\List.txt

#>

$SERVER = "CSODEVSQL42INS3\INS3"
$run_query = $true

$SQL_TO_RUN = 
"ALTER DATABASE <<DB_NAME>> 
SET RECOVERY SIMPLE
GO

ALTER DATABASE <<DB_NAME>> 
SET COMPATIBILITY_LEVEL = 100 
GO

USE <<DB_NAME>>
GO

-- This database was not set as CHECKSUM
if ((select page_verify_option from sys.databases where name = '<<DB_NAME>>') <> 2 )
begin
  ALTER DATABASE <<DB_NAME>> SET PAGE_VERIFY CHECKSUM WITH NO_WAIT;
  exec sp_msforeachtable 'alter index all on ? rebuild with (sort_in_tempdb = on, maxdop=2)';
end

DBCC UPDATEUSAGE (<<DB_NAME>>) WITH COUNT_ROWS; 

DBCC CHECKDB (<<DB_NAME>>) WITH DATA_PURITY;

-- Update statistics
exec('use <<DB_NAME>>; EXEC sp_updatestats;')
"

. Z:\PowerShell\Common_Scripts\Functions.ps1

$dbList = ConfirmAll

foreach ($database in $dbList)
{
    try
    { 
        $SQL_DB = $SQL_TO_RUN -replace "<<DB_NAME>>", $database

        Write-Host "Database Name: $database" 
        Write-Host $SQL_DB
        if ($run_query){
            invoke-sqlcmd -ServerInstance $SERVER -query $SQL_DB -Database "master" -Verbose -QueryTimeout 1800 | ft 
        }

    }
    catch
    {
        $errorMessage = $_.Exception.Message
        $failedItem = $_.Exception.ItemName
        Write-Output "Error:" $failedItem
        Write-Output $errorMessage
    }
}

Write-Host "Complete"

