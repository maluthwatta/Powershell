﻿$serverName = "CSOVDEVSQL29\INS1"
 
$databases = invoke-sqlcmd -ServerInstance $serverName -Database tempDB `
-Query "SELECT name FROM sys.databases"


foreach ($database in $databases) 
{
    invoke-sqlcmd -ServerInstance $serverName -Database $database.name `
    -Query "SELECT 	db_name() as DatabaseName"
}