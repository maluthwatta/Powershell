﻿# Get all the server names
$SMARTServer = "CSOVDEVSQL34\INS1"
$SMARTDB = "SMART_AU_NonProd"


	
$sql_server_names = "select ComponentName as ServerName from [rep].[SQLInstance2012]
        union
        select ComponentName as ServerName from [rep].[SQLInstance2014]
        union 
        select ComponentName as ServerName from [rep].[SQLInstance2016]"
	
    
#$sql_server_names = "select ComponentName as ServerName from [rep].[SQLInstance2014]"

$server_names = Invoke-Sqlcmd -ServerInstance $SMARTServer -Database $SMARTDB -Query $sql_server_names -QueryTimeout 3000 

#SQL FILE
#$sql_file = "Z:\Projects\DBA\20181009-RAPfindings\Check_data_purity_checks_performed.sql"
    
#SQL COMMAND
$sql_command = "SELECT @@SERVERNAME As ServerName , sqlserver_start_time FROM sys.dm_os_sys_info;"

$output_array = @()

write-host "Running....."  

foreach ($server_name in $server_names) 
{   
    try
    {        
        write-host "Server Name:" $server_name.ServerName     
        
        #SQL FILE
        #$db_result = invoke-sqlcmd -inputfile $sql_file -serverinstance $server_name.ServerName -database "tempdb" -QueryTimeout 3000 
        
        #SQL COMMAND
        $db_result = invoke-Sqlcmd -Query $sql_command -serverInstance $server_name.ServerName -Database "tempdb"  -QueryTimeout 3000 

        $output_array +=  $db_result    
    }
    catch
    {
        write-host "Error: $($_.Exception.Message)" -ForegroundColor Red
    }
}	
write-host "Complete."  
$output_array | Format-Table -AutoSize		


