﻿# --------------------------- #
# Manoj Aluthwatta 			  #
#-----------------------------#

$server = ”CSOVDEVSQL24\INS1”      
$db_mask = "AUUAT"


$sql_file = 'Y:\Work\GEMS\20200113\Case119005_TurnOn_ExecutiveView.sql'


$sql_db = "
SELECT NAME FROM SYS.DATABASES 
WHERE NAME LIKE '$db_mask%'
ORDER BY NAME
"

$dbs = invoke-sqlcmd -query $sql_db  -serverinstance $server -database "master" -QueryTimeout 3000 

ForEach ($db in $dbs)
{
    try{
        #Write-Output $db.NAME
        invoke-sqlcmd -InputFile $sql_file -serverinstance $server -database $db.NAME -Verbose -QueryTimeout 3000  
    }
    catch{
        $_.Exception.Message
        $_.Exception.ItemName
    }
     
}
