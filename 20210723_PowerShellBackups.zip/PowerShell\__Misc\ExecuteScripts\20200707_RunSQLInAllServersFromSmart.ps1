﻿

$Command_Type = "COMMAND" #FILE, COMMAND


#SQL FILE
#$sql_file = "C:\TFS\Global\DBA OCEANIA\Release\Scripts\GT1000X\Scripts\SQL\05 p_xe_load_gt1000.sql"
    
#SQL COMMAND
#$sql_command = "USE aaDBA; select @@SERVERNAME as ServerName, min(start_time) as MinDate from [perf].[gt1000];"

$sql_command = "
use aaDBA;
select server_instance_name As ServerName, count(1) As [Count]
from perf.gt1000
group by database_id, session_id, nt_username, client_hostname, client_app_name, client_pid, server_instance_name, server_principal_name, start_time, end_time, duration, logical_reads, physical_reads, writes, cpu_time, event_class--, sql_text
having count(1) > 1 and end_time > '2020-07-07 11:23:15.770'
order by start_time desc    ;
"


# Get all the server names
$SMARTServer = "CSOVDEVSQL34\INS1"
$SMARTDB = "SMART_AU_NonProd"

	
$sql_server_names = "select ComponentName as ServerName from [rep].[SQLInstance2012]
        union
        select ComponentName as ServerName from [rep].[SQLInstance2014]
        union 
        select ComponentName as ServerName from [rep].[SQLInstance2016]"
	
$server_names = Invoke-Sqlcmd -ServerInstance $SMARTServer -Database $SMARTDB -Query $sql_server_names -QueryTimeout 3000 

$output_array = @()

foreach ($server_name in $server_names) 
{   
    try
    {        
         
        #SQL FILE
        if ($Command_Type -eq "FILE") {
            write-host "Running SQL file on Server Name:" $server_name.ServerName   
            $db_result = invoke-sqlcmd -inputfile $sql_file -serverinstance $server_name.ServerName -database "tempdb" -QueryTimeout 3000 
        }  
        
        #SQL COMMAND
        if ($Command_Type -eq "COMMAND"){
            write-host "Running SQL command on Server Name:" $server_name.ServerName  
            $db_result = invoke-Sqlcmd -Query $sql_command -serverInstance $server_name.ServerName -Database "tempdb"  -QueryTimeout 3000 
        }        

        $output_array +=  $db_result    
    }
    catch
    {
        write-host "Error: $($_.Exception.Message)" -ForegroundColor Red
    }
}	
write-host "Complete."  
$output_array | Format-Table -AutoSize		


