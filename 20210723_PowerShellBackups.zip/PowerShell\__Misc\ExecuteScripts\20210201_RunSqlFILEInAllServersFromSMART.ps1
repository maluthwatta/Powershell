﻿
$Command_Type = "FILE" #FILE, COMMAND

#SQL FILE
$sql_file = "Y:\Projects\DBA\20210201-DevDumpsRelocation\UpdateSQLAgentJobStepsWithNewFileServerLocation-Report.sql"
   

# Get all the server names
$SMARTServer = "CSOVDEVSQL34\INS1"
$SMARTDB = "SMART_AU_NonProd"

	
$sql_server_names = "select ComponentName as ServerName from [rep].[SQLInstance2012]
        union
        select ComponentName as ServerName from [rep].[SQLInstance2014]
        union 
        select ComponentName as ServerName from [rep].[SQLInstance2016]"
	
$server_names = Invoke-Sqlcmd -ServerInstance $SMARTServer -Database $SMARTDB -Query $sql_server_names -QueryTimeout 3000 

$output_array = @()

foreach ($server_name in $server_names) 
{   
    try
    {        
         
        #SQL FILE
        if ($Command_Type -eq "FILE") {
            write-host "Running SQL file on Server Name:" $server_name.ServerName   
            $db_result = invoke-sqlcmd -inputfile $sql_file -serverinstance $server_name.ServerName -database "tempdb" -QueryTimeout 3000 -Verbose
            $db_result
        }  
        
        #SQL COMMAND
        if ($Command_Type -eq "COMMAND"){
            write-host "Running SQL command on Server Name:" $server_name.ServerName  
            $db_result = invoke-Sqlcmd -Query $sql_command -serverInstance $server_name.ServerName -Database "tempdb"  -QueryTimeout 3000  -Verbose
            $db_result
        }        

        $output_array +=  $db_result    
        
    }
    catch
    {
        write-host "Error: $($_.Exception.Message)" -ForegroundColor Red
    }
}	
write-host "Complete."  
$output_array | Format-Table -AutoSize		


