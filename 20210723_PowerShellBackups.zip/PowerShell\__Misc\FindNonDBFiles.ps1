﻿

$SMARTServer = "CSOVDEVSQL34\INS1"
$SMARTDB = "SMART_AU_NonProd"

$LogFile = "\\OCEANIA\CTS\DEPTDATA\GPandD\DBA\DBA_DEPTDATA\PSScripts\ScriptLogs\FindOrphanDBUsers\AllOrphanUsers.txt"
[string]$starttime = Get-Date -Format "dd-MMM-yyyy @ hh:mm:ss tt"
$startString = "The job started $starttime "
Write-Output $startString > $LogFile
Write-Output "" >>  $LogFile


$sql = "SELECT ComponentName, ComponentTypeName
		FROM rep.SQLInstance
        WHERE ComponentName NOT IN ('CSODEVSQL1', 'MELYDEVSCCMSQL1', 'MELYDEVAPP946', 'CSOVDEVSQL29\INS1', 'CSOVDEVSQL21') 
		ORDER BY ComponentTypeName, ComponentName"

$sqlWorkDB = ""
	
$ServerArray = Invoke-Sqlcmd -ServerInstance $SMARTServer -Database $SMARTDB -Query $sql `
	-ErrorVariable sqlerr -ErrorAction 'Stop' -Verbose -OutputSqlErrors 1 -querytimeout ([int]::MaxValue)

foreach ($sqlInstance in $ServerArray)
{	

    $ExecSPStr = "exec dbo.p_MSDN_FindOrphanedDomainUsersinDatabase"
        
    try
    {
        $sqlout = Invoke-Sqlcmd -ServerInstance $sqlInstance.ComponentName -Database $sqlWorkDB -Verbose -Query $ExecSPStr -querytimeout 3600 

        foreach($row in $sqlout)
        {
            $row.Item("Column1") >> $LogFile
        }

        Write-Output "------------------------------------" >>  $LogFile
        Write-Output "" >>  $LogFile
    }
    catch
    {
        $_.Exception.Message  >>  $LogFile 
        $_.Exception.ItemName >>  $LogFile
    } 
}