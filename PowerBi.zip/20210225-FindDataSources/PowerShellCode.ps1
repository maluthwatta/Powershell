﻿#Install-Module -Name ReportingServicesTools


#Get-Module -ListAvailable -Name ReportingServicesTools


#Get-Help Get-RsDataSource

#http://csovdqssrs01/PBIReports

#$rsProxy = New-RsWebServiceProxy -ReportServerUri 'https://csovdqssrs01/PBIReports'

#Get-RsDataSource -Proxy $rsProxy -Path '/path/to/my/datasource'





Get-RsFolderContent -ReportServerUri http://csovdqssrs01/reports -Path /DBA/SMART 


Get-RsItemDataSource -ReportServerUri 'http://csovdqssrs01/reports' -RsItem '/DBA/SMART/Database Application Contact'


Get-RsDataSource -ReportServerUri 'http://csovdqssrs01/reports' -Path '/DBA/SMART/Database Application Contact' 


Get-RsItemReference -ReportServerUri 'http://csovdqssrs01/reports' -Path '/DBA/SMART/Database Application Contact' 



$rsProxy = New-RsWebServiceProxy -ReportServerUri 'http://csovdqssrs01/reports'
Get-RsDataSource -Proxy $rsProxy -Path '/DBA/SMART/Database Application Contact/Data Source 1'



$folderContent = Get-RsFolderContent -ReportServerUri 'http://csovdqssrs01/reports' -Path '/DBA/SMART'


Get-RsItemDataSource -ReportServerUri 'http://csovdqssrs01/reports' -RsItem '/DBA/SMART/Database Application Contact'
