
--AU NONPROD

;with cte_sql_version as
(
SELECT 
		ComponentId,
		FileVersionCharVal 
FROM [rep].[SQLInstance2000]
UNION ALL
SELECT 
		ComponentId,
		FileVersionCharVal 
FROM [rep].[SQLInstance2005]
UNION ALL
SELECT 
		ComponentId,
		FileVersionCharVal 
FROM [rep].[SQLInstance2008]
UNION ALL
SELECT 
		ComponentId,
		FileVersionCharVal 
FROM [rep].[SQLInstance2012]
UNION ALL
SELECT 
		ComponentId,
		FileVersionCharVal 
FROM [rep].[SQLInstance2014]
UNION ALL
SELECT 
	ComponentId,
	FileVersionCharVal 
FROM [rep].[SQLInstance2016]
)
,cte as
(
SELECT 
	  ap.ApplicationID,
      rsdb.ComponentName	AS SQLDatabaseName,
      rsi.ComponentName		AS SQLInstanceName,
	  rsi.ComponentTypeNAme	AS SQLServerVersionShort,
	  csv.FileVersionCharVal as SQLServerVersionFull, 
	  ap.ApplicationName	As [SMART Application],
	  ap.PrimaryContact		As [SMART Primary Contact],
	  ap.Lob				As [SMART Line of Business],
	  ap.Region				As [SMART Region],
	  re.ComponentName		As [Environment]

FROM rep.SQLInstance AS rsi
left JOIN rep.SQLDatabase AS rsdb
    ON  rsdb.ParentComponentID = rsi.ComponentID
left join rep.Environment as re
      on re.ComponentID = rsi.ParentComponentID
LEFT OUTER JOIN dbo.DatabaseApplication As dbap
    ON  dbap.ComponentID = rsdb.ComponentID   
LEFT OUTER JOIN dbo.Application AS ap
    ON  ap.ApplicationID = dbap.ApplicationID 
LEFT OUTER JOIN cte_sql_version as csv
	ON  csv.ComponentID = rsi.ComponentID
WHERE
		rsdb.ComponentName NOT IN ('master','model','msdb','tempdb','zDBA','aadba','distribution')
		AND (isnull(ap.ApplicationName,'') NOT IN ('SMART','System DB','SQL Server')
			 and isnull(ap.ApplicationName,'') NOT LIKE 'DBA%' )
		AND rsdb.DBSizeMB IS NOT NULL
)
select	[ID],
		Title,
		[Line of Business Owner],
		[Manager],
		[Dev Team],
		[Product Owner],
		cte.[SMART Application],
		cte.[SMART Primary Contact],
		cte.[SMART Line of Business],
		cte.[SMART Region],
		cte.SQLInstanceName,
		cte.SQLDatabaseName,
		cte.SQLServerVersionShort,
		cte.SQLServerVersionFull,
		Case 
			when isnull(title,'') = '' then 'In SMART'
			when isnull(title,'') <> '' and isnull(cte.[SMART Application],'') <> '' then 'In Both'
			when isnull(title,'') <> '' and isnull(cte.[SMART Application],'') = '' then 'In Application Catalogue'
		end as [Status],
		[Environment],
		'OCEANIA' As ApplicationRegion,
		'Non-Prod' As ApplicationEnvironment	

from	dbo.ApplicationPortfolioCatalogue As apc
full outer join cte
		on apc.title = cte.[SMART Application]
order by Title, [SMART Application],[SMART Primary Contact],SQLInstanceName,SQLDatabaseName




--AU PROD

;with cte_sql_version as
(
SELECT 
		ComponentId,
		FileVersionCharVal 
FROM [rep].[SQLInstance2000]
UNION ALL
SELECT 
		ComponentId,
		FileVersionCharVal 
FROM [rep].[SQLInstance2005]
UNION ALL
SELECT 
		ComponentId,
		FileVersionCharVal 
FROM [rep].[SQLInstance2008]
UNION ALL
SELECT 
		ComponentId,
		FileVersionCharVal 
FROM [rep].[SQLInstance2012]
UNION ALL
SELECT 
		ComponentId,
		FileVersionCharVal 
FROM [rep].[SQLInstance2014]
UNION ALL
SELECT 
	ComponentId,
	FileVersionCharVal 
FROM [rep].[SQLInstance2016]
)
,cte as
(
SELECT 
	  ap.ApplicationID,
      rsdb.ComponentName	AS SQLDatabaseName,
      rsi.ComponentName		AS SQLInstanceName,
	  rsi.ComponentTypeNAme	AS SQLServerVersionShort,
	  csv.FileVersionCharVal as SQLServerVersionFull, 
	  ap.ApplicationName	As [SMART Application],
	  ap.PrimaryContact		As [SMART Primary Contact],
	  ap.Lob				As [SMART Line of Business],
	  ap.Region				As [SMART Region],
	  re.ComponentName		As [Environment]

FROM rep.SQLInstance AS rsi
left JOIN rep.SQLDatabase AS rsdb
    ON  rsdb.ParentComponentID = rsi.ComponentID
left join rep.Environment as re
      on re.ComponentID = rsi.ParentComponentID
LEFT OUTER JOIN dbo.DatabaseApplication As dbap
    ON  dbap.ComponentID = rsdb.ComponentID   
LEFT OUTER JOIN dbo.Application AS ap
    ON  ap.ApplicationID = dbap.ApplicationID 
LEFT OUTER JOIN cte_sql_version as csv
	ON  csv.ComponentID = rsi.ComponentID
WHERE
		rsdb.ComponentName NOT IN ('master','model','msdb','tempdb','zDBA','aadba','distribution')
		AND (isnull(ap.ApplicationName,'') NOT IN ('SMART','System DB','SQL Server')
			 and isnull(ap.ApplicationName,'') NOT LIKE 'DBA%' )
		AND rsdb.DBSizeMB IS NOT NULL
)
select	[ID],
		Title,
		[Line of Business Owner],
		[Manager],
		[Dev Team],
		[Product Owner],
		cte.[SMART Application],
		cte.[SMART Primary Contact],
		cte.[SMART Line of Business],
		cte.[SMART Region],
		cte.SQLInstanceName,
		cte.SQLDatabaseName,
		cte.SQLServerVersionShort,
		cte.SQLServerVersionFull,
		Case 
			when isnull(title,'') = '' then 'In SMART'
			when isnull(title,'') <> '' and isnull(cte.[SMART Application],'') <> '' then 'In Both'
			when isnull(title,'') <> '' and isnull(cte.[SMART Application],'') = '' then 'In Application Catalogue'
		end as [Status],
		[Environment],
		'OCEANIA' As ApplicationRegion,
		'Prod' As ApplicationEnvironment	

from	dbo.ApplicationPortfolioCatalogue As apc
full outer join cte
		on apc.title = cte.[SMART Application]
order by Title, [SMART Application],[SMART Primary Contact],SQLInstanceName,SQLDatabaseName



--AMERICAS

;with cte_sql_version as
(
SELECT 
		ComponentId,
		FileVersionCharVal 
FROM [rep].[SQLInstance2000]
UNION ALL
SELECT 
		ComponentId,
		FileVersionCharVal 
FROM [rep].[SQLInstance2005]
UNION ALL
SELECT 
		ComponentId,
		FileVersionCharVal 
FROM [rep].[SQLInstance2008]
UNION ALL
SELECT 
		ComponentId,
		FileVersionCharVal 
FROM [rep].[SQLInstance2012]
UNION ALL
SELECT 
		ComponentId,
		FileVersionCharVal 
FROM [rep].[SQLInstance2014]
UNION ALL
SELECT 
	ComponentId,
	FileVersionCharVal 
FROM [rep].[SQLInstance2016]
)
,cte as
(
SELECT 
	  ap.ApplicationID,
      rsdb.ComponentName	AS SQLDatabaseName,
      rsi.ComponentName		AS SQLInstanceName,
	  rsi.ComponentTypeNAme	AS SQLServerVersionShort,
	  csv.FileVersionCharVal as SQLServerVersionFull, 
	  ap.ApplicationName	As [SMART Application],
	  ap.PrimaryContact		As [SMART Primary Contact],
	  ap.Lob				As [SMART Line of Business],
	  ap.Region				As [SMART Region],
	  re.ComponentName		As [Environment]

FROM rep.SQLInstance AS rsi
left JOIN rep.SQLDatabase AS rsdb
    ON  rsdb.ParentComponentID = rsi.ComponentID
left join rep.Environment as re
      on re.ComponentID = rsi.ParentComponentID
LEFT OUTER JOIN dbo.DatabaseApplication As dbap
    ON  dbap.ComponentID = rsdb.ComponentID   
LEFT OUTER JOIN dbo.Application AS ap
    ON  ap.ApplicationID = dbap.ApplicationID 
LEFT OUTER JOIN cte_sql_version as csv
	ON  csv.ComponentID = rsi.ComponentID
WHERE
		rsdb.ComponentName NOT IN ('master','model','msdb','tempdb','zDBA','aadba','distribution')
		AND (isnull(ap.ApplicationName,'') NOT IN ('SMART','System DB','SQL Server')
			 and isnull(ap.ApplicationName,'') NOT LIKE 'DBA%' )
		AND rsdb.DBSizeMB IS NOT NULL
)
select	[ID],
		Title,
		[Line of Business Owner],
		[Manager],
		[Dev Team],
		[Product Owner],
		cte.[SMART Application],
		cte.[SMART Primary Contact],
		cte.[SMART Line of Business],
		cte.[SMART Region],
		cte.SQLInstanceName,
		cte.SQLDatabaseName,
		cte.SQLServerVersionShort,
		cte.SQLServerVersionFull,
		Case 
			when isnull(title,'') = '' then 'In SMART'
			when isnull(title,'') <> '' and isnull(cte.[SMART Application],'') <> '' then 'In Both'
			when isnull(title,'') <> '' and isnull(cte.[SMART Application],'') = '' then 'In Application Catalogue'
		end as [Status],
		[Environment],
		'AMERICAS' As ApplicationRegion,
		CASE 
			WHEN Environment in ('AmericasDEV','AmericasUAT') then 'Non-Prod'
			WHEN Environment = 'Americas' then 'Prod'
		END As ApplicationEnvironment

from	dbo.ApplicationPortfolioCatalogue As apc
full outer join cte
		on apc.title = cte.[SMART Application]
order by Title, [SMART Application],[SMART Primary Contact],SQLInstanceName,SQLDatabaseName



--EMEA

;with cte_sql_version as
(
SELECT 
		ComponentId,
		FileVersionCharVal 
FROM [rep].[SQLInstance2000]
UNION ALL
SELECT 
		ComponentId,
		FileVersionCharVal 
FROM [rep].[SQLInstance2005]
UNION ALL
SELECT 
		ComponentId,
		FileVersionCharVal 
FROM [rep].[SQLInstance2008]
UNION ALL
SELECT 
		ComponentId,
		FileVersionCharVal 
FROM [rep].[SQLInstance2012]
UNION ALL
SELECT 
		ComponentId,
		FileVersionCharVal 
FROM [rep].[SQLInstance2014]
UNION ALL
SELECT 
	ComponentId,
	FileVersionCharVal 
FROM [rep].[SQLInstance2016]
)
,cte as
(
SELECT 
	  ap.ApplicationID,
      rsdb.ComponentName	AS SQLDatabaseName,
      rsi.ComponentName		AS SQLInstanceName,
	  rsi.ComponentTypeNAme	AS SQLServerVersionShort,
	  csv.FileVersionCharVal as SQLServerVersionFull, 
	  ap.ApplicationName	As [SMART Application],
	  ap.PrimaryContact		As [SMART Primary Contact],
	  ap.Lob				As [SMART Line of Business],
	  ap.Region				As [SMART Region],
	  re.ComponentName		As [Environment]

FROM rep.SQLInstance AS rsi
left JOIN rep.SQLDatabase AS rsdb
    ON  rsdb.ParentComponentID = rsi.ComponentID
left join rep.Environment as re
      on re.ComponentID = rsi.ParentComponentID
LEFT OUTER JOIN dbo.DatabaseApplication As dbap
    ON  dbap.ComponentID = rsdb.ComponentID   
LEFT OUTER JOIN dbo.Application AS ap
    ON  ap.ApplicationID = dbap.ApplicationID 
LEFT OUTER JOIN cte_sql_version as csv
	ON  csv.ComponentID = rsi.ComponentID
WHERE
		rsdb.ComponentName NOT IN ('master','model','msdb','tempdb','zDBA','aadba','distribution')
		AND (isnull(ap.ApplicationName,'') NOT IN ('SMART','System DB','SQL Server')
			 and isnull(ap.ApplicationName,'') NOT LIKE 'DBA%' )
		AND rsdb.DBSizeMB IS NOT NULL
)
select	[ID],
		Title,
		[Line of Business Owner],
		[Manager],
		[Dev Team],
		[Product Owner],
		cte.[SMART Application],
		cte.[SMART Primary Contact],
		cte.[SMART Line of Business],
		cte.[SMART Region],
		cte.SQLInstanceName,
		cte.SQLDatabaseName,
		cte.SQLServerVersionShort,
		cte.SQLServerVersionFull,
		Case 
			when isnull(title,'') = '' then 'In SMART'
			when isnull(title,'') <> '' and isnull(cte.[SMART Application],'') <> '' then 'In Both'
			when isnull(title,'') <> '' and isnull(cte.[SMART Application],'') = '' then 'In Application Catalogue'
		end as [Status],
		[Environment],
		'EMEA' As ApplicationRegion,
		CASE 
			WHEN Environment in ('EMEA','CAMSLAN') then  'Prod'
			WHEN Environment = 'EMEA NON-PRODUCTION' then 'Non-Prod'
		END As ApplicationEnvironment

from	dbo.ApplicationPortfolioCatalogue As apc
full outer join cte
		on apc.title = cte.[SMART Application]
order by Title, [SMART Application],[SMART Primary Contact],SQLInstanceName,SQLDatabaseName