
--use SMART_AU_PROD    --AU --CSOVSQL75\INS1
--use SMART_AU_NonProd --AU --CSOVDEVSQL34\INS1

--use SMART_NA_PROD --NA --QASPVPQDBA20\DBA

--use smart_prd		--UK --CSEVPQINFC2INS1\INS1, 65090

--Query 1 - Application Mapping
;with cte_Applications_with_db as
(
SELECT distinct
	  ap.ApplicationName

FROM dbo.Application AS ap
INNER JOIN dbo.DatabaseApplication As dbap
    ON  ap.ApplicationID = dbap.ApplicationID
INNER JOIN rep.SQLDatabase AS rsdb
    ON  dbap.ComponentID = rsdb.ComponentID	
WHERE
		rsdb.ComponentName NOT IN ('master','model','msdb','tempdb','zDBA','aadba','distribution')
		AND (isnull(ap.ApplicationName,'') NOT IN ('SMART','System DB','SQL Server')
			 and isnull(ap.ApplicationName,'') NOT LIKE 'DBA%' )
)
SELECT	[ID],
		Title,
		[Line of Business Owner],
		[Manager],
		[Dev Team],
		[Product Owner],
		App.ApplicationName as [SMART Application],
		App.PrimaryContact as [SMART Primary Contact],
		App.Lob as [SMART Line of Business],
		App.Region as [SMART Region],
		CASE 
			WHEN isnull(title,'') = '' THEN 'In SMART'
			WHEN isnull(title,'') <> '' and isnull(App.ApplicationName,'') <> '' THEN 'In Both'
			WHEN isnull(title,'') <> '' and isnull(App.ApplicationName,'') = '' THEN 'In Application Catalogue'
		END AS [Status]
FROM	dbo.ApplicationPortfolioCatalogue As apc
FULL OUTER JOIN dbo.Application As app
		on apc.title = app.ApplicationName
where exists(select ApplicationName from cte_Applications_with_db as cte where cte.ApplicationName = app.ApplicationName )
order by Title, [SMART Application];


--Query 2 - Database Mapping
;with cte_sql_version as
(
SELECT 
		ComponentId,
		FileVersionCharVal 
FROM [rep].[SQLInstance2000]
UNION ALL
SELECT 
		ComponentId,
		FileVersionCharVal 
FROM [rep].[SQLInstance2005]
UNION ALL
SELECT 
		ComponentId,
		FileVersionCharVal 
FROM [rep].[SQLInstance2008]
UNION ALL
SELECT 
		ComponentId,
		FileVersionCharVal 
FROM [rep].[SQLInstance2012]
UNION ALL
SELECT 
		ComponentId,
		FileVersionCharVal 
FROM [rep].[SQLInstance2014]
UNION ALL
SELECT 
	ComponentId,
	FileVersionCharVal 
FROM [rep].[SQLInstance2016]
)
,cte as
(
SELECT 
	  ap.ApplicationID,
      rsdb.ComponentName	AS SQLDatabaseName,
      rsi.ComponentName		AS SQLInstanceName,
	  rsi.ComponentTypeNAme	AS SQLServerVersionShort,
	  csv.FileVersionCharVal as SQLServerVersionFull, 
	  ap.ApplicationName	As [SMART Application],
	  ap.PrimaryContact		As [SMART Primary Contact],
	  ap.Lob				As [SMART Line of Business],
	  ap.Region				As [SMART Region],
	  re.ComponentName		As [Environment]

FROM rep.SQLInstance AS rsi
left JOIN rep.SQLDatabase AS rsdb
    ON  rsdb.ParentComponentID = rsi.ComponentID
left join rep.Environment as re
      on re.ComponentID = rsi.ParentComponentID
LEFT OUTER JOIN dbo.DatabaseApplication As dbap
    ON  dbap.ComponentID = rsdb.ComponentID   
LEFT OUTER JOIN dbo.Application AS ap
    ON  ap.ApplicationID = dbap.ApplicationID 
LEFT OUTER JOIN cte_sql_version as csv
	ON  csv.ComponentID = rsi.ComponentID
WHERE
		rsdb.ComponentName NOT IN ('master','model','msdb','tempdb','zDBA','aadba','distribution')
		AND (isnull(ap.ApplicationName,'') NOT IN ('SMART','System DB','SQL Server')
			 and isnull(ap.ApplicationName,'') NOT LIKE 'DBA%' )
		AND rsdb.DBSizeMB IS NOT NULL
)
select	[ID],
		Title,
		[Line of Business Owner],
		[Manager],
		[Dev Team],
		[Product Owner],
		cte.[SMART Application],
		cte.[SMART Primary Contact],
		cte.[SMART Line of Business],
		cte.[SMART Region],
		cte.SQLInstanceName,
		cte.SQLDatabaseName,
		cte.SQLServerVersionShort,
		cte.SQLServerVersionFull,
		Case 
			when isnull(title,'') = '' then 'In SMART'
			when isnull(title,'') <> '' and isnull(cte.[SMART Application],'') <> '' then 'In Both'
			when isnull(title,'') <> '' and isnull(cte.[SMART Application],'') = '' then 'In Application Catalogue'
		end as [Status],
		Case 
			when @@SERVERNAME = 'CSOVSQL75\INS1' then 'Prod'	
			when @@SERVERNAME = 'CSOVDEVSQL34\INS1' then 'Non-Prod'
			when @@SERVERNAME = 'QASPVPQDBA20\DBA' and Environment = 'Americas' then 'Prod'
			when @@SERVERNAME = 'QASPVPQDBA20\DBA' and Environment in ('AmericasDEV','AmericasUAT') then 'Non-Prod'
			when @@SERVERNAME = 'CSEVPQINFC2INS1\INS1' and Environment in ('EMEA','CAMSLAN') then  'Prod'
			when @@SERVERNAME = 'CSEVPQINFC2INS1\INS1' and Environment = 'EMEA NON-PRODUCTION' then 'Non-Prod'
		end as [Source]
from	dbo.ApplicationPortfolioCatalogue As apc
full outer join cte
		on apc.title = cte.[SMART Application]
--where Title is null
order by Title, [SMART Application],[SMART Primary Contact],SQLInstanceName,SQLDatabaseName

