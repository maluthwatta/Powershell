--use  CSODEVSQL42INS3\INS3
SELECT sAMAccountName,'oceania' as domain 
FROM  Openquery( CAFADSI, '<GC://dc=oceania,dc=cshare,dc=net>;(&(objectCategory=Person)(objectClass=User)(!(userAccountControl:1.2.840.113556.1.4.803:=2)));sAMAccountName')

