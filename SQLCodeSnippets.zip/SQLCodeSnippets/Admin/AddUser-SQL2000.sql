--Creates a new Microsoft� SQL Server� login
sp_addlogin 'aluthwattam'

--Allows a Microsoft� Windows NT� user or group account to connect to Microsoft SQL Server� using Windows Authentication.
sp_grantlogin 'oceania\aluthwattam'

--Removes a security account/user from the current database.
sp_revokedbaccess 'IVR_SYS'

--Adds a security account/user in the current database
sp_grantdbaccess 'IVR_SYS'

--Changes the default database name
sp_defaultdb 'IVR_SYS', 'IVR_ProdCopy'

--Adds a role member
sp_droprolemember N'db_owner', N'IVR_SYS'

--Drops a role member
sp_addrolemember N'db_owner', N'IVR_SYS'

--GRANT/REVOKE/DENY statements
GRANT CREATE DATABASE, CREATE TABLE
TO Mary, John, [Corporate\BobJ]

--Returns information about the roles in the current database.
sp_helprole

--Returns information about members of a role in the current database
sp_helprolemember

--Returns a list of the Microsoft� SQL Server� fixed server roles.
sp_helpsrvrole

--Returns information about the members of a Microsoft� SQL Server� fixed server role.
sp_helpsrvrolemember

--Returns a report with information about user permissions for an object, 
--or statement permissions, in the current database.
sp_helprotect


