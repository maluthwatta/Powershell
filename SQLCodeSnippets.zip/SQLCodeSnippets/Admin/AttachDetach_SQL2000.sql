dbcc shrinkfile (2)

use master
   go
   sp_detach_db 'LogParser'
   go

use master
  go
  sp_attach_db 'LogParser','I:\SQLData\LogParser_Data.MDF','H:\SQLLog\LogParser_Log.ldf'
  go
 
use LogParser
   go
   sp_helpfile
   go
 



 

 

 

 

 

 
