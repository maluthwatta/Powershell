/*Basic sql queries used for admin purposes*/

/* To display a list of valid login names */
select * from sys.server_principals 

/* To display a list of the user names that can be removed from the current database */
exec sp_helpuser

/* Creates a new SQL Server login. */
CREATE LOGIN login_name { WITH <option_list1> | FROM <sources> }

<sources> ::=
    WINDOWS [ WITH <windows_options> [ ,... ] ]
    | CERTIFICATE certificateName
    | ASYMMETRIC KEY asym_key_name

<option_list1> ::= 
    PASSWORD = { 'password' | hashed_password HASHED } [ MUST_CHANGE ]
    [ , <option_list2> [ ,... ] ]

<option_list2> ::=  
    SID = sid
    | DEFAULT_DATABASE = database    
    | DEFAULT_LANGUAGE = language
    | CHECK_EXPIRATION = { ON | OFF}
    | CHECK_POLICY = { ON | OFF}
    | CREDENTIAL = credential_name 

<windows_options> ::=      
    DEFAULT_DATABASE = database
    | DEFAULT_LANGUAGE = language

-->>example
CREATE LOGIN Manoj WITH PASSWORD = 'ManojSql987',
	DEFAULT_DATABASE = Manoj_test1;
GO

/* Adds a user to the current database.*/
CREATE USER user_name 
    [ { { FOR | FROM }
      { 
        LOGIN login_name 
        | CERTIFICATE cert_name 
        | ASYMMETRIC KEY asym_key_name
      } 
      | WITHOUT LOGIN
    ] 
    [ WITH DEFAULT_SCHEMA = schema_name ]

-->>example
USE Manoj_test1;
CREATE USER ManojTest FOR LOGIN Manoj;
GO 


/*Renames a database user or changes its default schema. */
ALTER USER user_name  
     WITH <set_item> [ ,...n ]
<set_item> ::= 
     NAME = new_user_name 
     | DEFAULT_SCHEMA = schema_name
     | LOGIN = login_name

-->>example
ALTER USER ManojTest
	WITH NAME = ManojTestUser;
GO

/* Removes a user from the current database. */
DROP USER user_name;
GO


/* Grants permissions on a database. */
GRANT <permission> [ ,...n ]  
    TO <database_principal> [ ,...n ] [ WITH GRANT OPTION ]
    [ AS <database_principal> ]

<permission>::=  
permission | ALL [ PRIVILEGES ]

<database_principal> ::= 
        Database_user 
    | Database_role 
    | Application_role 
    | Database_user_mapped_to_Windows_User 
    | Database_user_mapped_to_Windows_Group 
    | Database_user_mapped_to_certificate 
    | Database_user_mapped_to_asymmetric_key 
    | Database_user_with_no_login  

-->>example
USE Manoj_test1
GRANT CREATE VIEW TO ManojTestUser WITH GRANT OPTION;
GO

/*
Grants permissions on a table, view, table-valued function, stored procedure, 
extended stored procedure, scalar function, aggregate function, service queue, or synonym. */
GRANT <permission> [ ,...n ] ON 
    [ OBJECT :: ][ schema_name ]. object_name [ ( column [ ,...n ] ) ]
    TO <database_principal> [ ,...n ] 
    [ WITH GRANT OPTION ]
    [ AS <database_principal> ]

<permission> ::=
    ALL [ PRIVILEGES ] | permission [ ( column [ ,...n ] ) ]

<database_principal> ::= 
        Database_user 
    | Database_role 
    | Application_role 
    | Database_user_mapped_to_Windows_User 
    | Database_user_mapped_to_Windows_Group 
    | Database_user_mapped_to_certificate 
    | Database_user_mapped_to_asymmetric_key 
    | Database_user_with_no_login

-->>example
GRANT SELECT ON OBJECT::Person.Address TO RosaQdM;
GO

GRANT EXECUTE ON OBJECT::HumanResources.uspUpdateEmployeeHireInfo
    TO Recruiting11;
GO 


/*
Removes a previously granted or denied permission. */
REVOKE [ GRANT OPTION FOR ] <permission> [ ,...n ]  
    { TO | FROM } <database_principal> [ ,...n ] 
        [ CASCADE ]
    [ AS <database_principal> ]

<permission> ::=  
permission | ALL [ PRIVILEGES ]

<database_principal> ::= 
        Database_user 
    | Database_role 
    | Application_role 
    | Database_user_mapped_to_Windows_User 
    | Database_user_mapped_to_Windows_Group 
    | Database_user_mapped_to_certificate 
    | Database_user_mapped_to_asymmetric_key 
    | Database_user_with_no_login  

-->>example
REVOKE CREATE VIEW FROM MelanieK;
GO

/*
Revokes permissions on a table, view, table-valued function, stored procedure, 
extended stored procedure, scalar function, aggregate function, service queue, or synonym */
REVOKE [ GRANT OPTION FOR ] <permission> [ ,...n ] ON 
    [ OBJECT :: ][ schema_name ]. object_name [ ( column [ ,...n ] ) ]
        { FROM | TO } <database_principal> [ ,...n ] 
    [ CASCADE ]
    [ AS <database_principal> ]

<permission> ::=
    ALL [ PRIVILEGES ] | permission [ ( column [ ,...n ] ) ]

<database_principal> ::= 
        Database_user 
    | Database_role 
    | Application_role 
    | Database_user_mapped_to_Windows_User 
    | Database_user_mapped_to_Windows_Group 
    | Database_user_mapped_to_certificate 
    | Database_user_mapped_to_asymmetric_key 
    | Database_user_with_no_login    

-->>example
USE AdventureWorks;
REVOKE SELECT ON OBJECT::Person.Address FROM RosaQdM;
GO

REVOKE EXECUTE ON OBJECT::HumanResources.uspUpdateEmployeeHireInfo
    FROM Recruiting11;
GO

/* Denies permissions on a database. */

DENY <permission> [ ,...n ]  
    TO <database_principal> [ ,...n ] [ CASCADE ]
        [ AS <database_principal> ]

<permission> ::=  
permission | ALL [ PRIVILEGES ]

<database_principal> ::= 
        Database_user 
    | Database_role 
    | Application_role 
    | Database_user_mapped_to_Windows_User 
    | Database_user_mapped_to_Windows_Group 
    | Database_user_mapped_to_certificate 
    | Database_user_mapped_to_asymmetric_key 
    | Database_user_with_no_login  

-->>example
USE AdventureWorks;
DENY CREATE CERTIFICATE TO MelanieK;
GO

DENY REFERENCES TO AuditMonitor;
GO


/* Denies permissions on a member of the OBJECT class of securables. These are the members 
of the OBJECT class: tables, views, table-valued functions, stored procedures, 
extended stored procedures, scalar functions, aggregate functions, service queues, and synonyms. */

DENY <permission> [ ,...n ] ON 
    [ OBJECT :: ][ schema_name ]. object_name [ ( column [ ,...n ] ) ]
        TO <database_principal> [ ,...n ] 
    [ CASCADE ]
        [ AS <database_principal> ]

<permission> ::=
    ALL [ PRIVILEGES ] | permission [ ( column [ ,...n ] ) ]

<database_principal> ::= 
        Database_user 
    | Database_role 
    | Application_role 
    | Database_user_mapped_to_Windows_User 
    | Database_user_mapped_to_Windows_Group 
    | Database_user_mapped_to_certificate 
    | Database_user_mapped_to_asymmetric_key 
    | Database_user_with_no_login

-->>example
USE AdventureWorks;
DENY SELECT ON OBJECT::Person.Address TO RosaQdM;

DENY EXECUTE ON OBJECT::HumanResources.uspUpdateEmployeeHireInfo
    TO Recruiting11;
GO


/*
>> sp_helpuser
Reports information about users and database roles in the current database. */
sp_helpuser [[@name_in_db =] 'security_account']
exec sp_helpuser 'dbo'
exec sp_helpuser 'ManojTest'

/*
>> sp_helpsrvrolemember 
Returns information about the members of a fixed server role. */
sp_helpsrvrolemember [[@srvrolename =] 'role']
exec sp_helpsrvrolemember 'sysadmin'

/*
>> sp_helprolemember
Returns information about the members of a role in the current database. */
sp_helprolemember [[@rolename =] 'role']
exec sp_helprolemember 'db_owner'

/*
>> sp_helprole
Returns information about the roles in the current database. */
sp_helprole [[@rolename =] 'role']
exec sp_helprole 'db_owner'

/*
>> sp_helprotect
Returns a report that has information about user permissions for an object, 
or statement permissions, in the current database. */
sp_helprotect [ [ @name = ] 'object_statement' ] 
     [ , [ @username = ] 'security_account' ] 
     [ , [ @grantorname = ] 'grantor' ] 
     [ , [ @permissionarea = ] 'type' ]
exec sp_helprotect 'AA_StoreParameters'


EXEC dbo.sp_grantdbaccess @loginame = N'Oceania\!AU CT MEL InvestorPhone Developers', @name_in_db = N'Oceania\!AU CT MEL InvestorPhone Developers'

sp_helpdb 'BB_Content'

--Create the directory
exec master..xp_cmdshell 'dir O:\SQLData2\BB'

use BB_Content

--Create a server login
create login [oceania\!AU CT ALL Bamboo Team] from windows

--Create a db login
create user [!AU CT ALL Bamboo Team] from Login [oceania\!AU CT ALL Bamboo Team]

sp_helpuser

sp_addrolemember 'db_owner', '!AU CT ALL Bamboo Team'

xp_logininfo 'oceania\horsingtong'


select * from sys.server_principals 
order by name

select * from sys.database_principals 
order by name



