exec sp_helpdb ci_invtest

select db_name(dbid) as [Database Name], sum((size*8)/1024.0) as [Total Size(MB)],
sum((size*8)/(1024.0*1024.0)) as [Total Size in GB] 
from master..sysaltfiles
where db_name(dbid) like 'CI%'
group by db_name(dbid)
order by db_name(dbid)


select sum((size*8)/1024.0) as [Total Size],
sum((size*8)/(1024.0*1024.0)) as [Total Size in GB] 
from master..sysaltfiles
where db_name(dbid) like 'CI%'





--and right(rtrim(filename),3) <> 'ldf'

--and FILEPROPERTY( name, 'IsLogFile') = 1

select * from sysaltfiles
where db_name(dbid) like 'CI_NA_TRAINING_HOC_INV_V2_2'

select name from master..sysdatabases where name like 'CI%'