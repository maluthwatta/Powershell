
--Create the database

CREATE DATABASE BB_Content
ON 
( NAME = BB_Content_dat,
    FILENAME = 'O:\SQLData2\BB\BB_Contentdat.mdf',
    SIZE = 50MB
)
LOG ON
(
	NAME = BB_Content_log,
    FILENAME = 'P:\SQLLog2\BB_Content.ldf',
    SIZE = 10MB
 )

GO


sp_helpdb 'BB_Content'

--Create the directory
exec master..xp_cmdshell 'dir O:\SQLData2\BB'

use BB_Content

--Create a server login
create login [oceania\!AU CT ALL Bamboo Team] from windows

--Create a db login
create user [!AU CT ALL Bamboo Team] from Login [oceania\!AU CT ALL Bamboo Team]

sp_helpuser

sp_addrolemember 'db_owner', '!AU CT ALL Bamboo Team'

sp_addgroup '!AU CT ALL Bamboo Team'

EXEC dbo.sp_grantdbaccess @loginame = N'Oceania\!AU CT MEL InvestorPhone Developers', @name_in_db = N'Oceania\!AU CT MEL InvestorPhone Developers'



