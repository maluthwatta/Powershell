use CI_TEMPDB

SET NOCOUNT ON
-- (MELADEVSQLC1) zBackup all company databases
print '--ZBACKUP ALL COMPANY DATABASES'
select 'EXEC master.dbo.sp_zbackup_db @database=''' + Name + ''', @filename1=''\\melysqlbkup1\DevDumps\CosmosInvestor\SQL2008_Migration\' + name + '.zbak'', @stats=10
'
+ 'GO'
from master..sysdatabases
where name in (select dbname from __DatabaseList)
order by name

-- (CSODEVSQL1) create empty shells for new databases
print '--CREATE EMPTY SHELLS FOR NEW DATABASES'
print 'ON CSODEVSQL1'
select 'create database ' + name + '
on primary ( name = N'''+ name + '_data'', filename= N''G:\R5T2_DEVSQL41IN3_DAT01_0F78_mG\SQLData\CI\' + name + '.mdf'') ' + '
log on ( name = N'''+ name + '_log'', filename= N''G:\R5T2_DEVSQL41IN3_LOG01_0F81_mG\SQLLog\CI\' + name + '.ldf'') '
+ '
GO'
from master..sysdatabases
where name in (select dbname from __DatabaseList)
order by name


-- (CSODEVSQL1) restore backups
print '--RESTORE BACKUPS'
select 'exec master.dbo.sp_zRestoreExisting_db @database=''' + Name + ''', @filename1=''\\melysqlbkup1\DevDumps\CosmosInvestor\SQL2008_Migration\' + name + '.zbak''
'
+ 'GO'
from master..sysdatabases
--where (name like '%CC_%') or (name like 'WFCompany%') or (name in ('WF_Holden', 'WF_Lieu', 'wf_you') )
where name in (select dbname from __DatabaseList)
order by name


-- (CSODEVSQL1) drop existing users 
print '--DROP EXISTING USERS'
select 'use ' + Name + '
go' + '
print ''use '' + db_name()
print ''go''
select ''sp_revokedbaccess ['' + name + '']
go'' from sysusers c where c.uid between 3 and 16000 and c.hasdbaccess = 1'
from master..sysdatabases
--where (name like '%CC_%') or (name like 'WFCompany%') or (name in ('WF_Holden', 'WF_Lieu', 'wf_you') )
where name in (select dbname from __DatabaseList)
order by name

-- (CSODEVSQL1) Add users to roles
print '--ADD USERS TO ROLES'
select 'use ' + Name + '
go' + '
print ''use '' + db_name()
print ''go''

select ''exec sp_grantlogin2 '' + QUOTENAME( d.name) 
+ ''; '' + ''exec sp_grantdbaccess '' 
+ QUOTENAME( d.name) 
+ ''; '' + ''exec sp_addrolemember '' 
+ QUOTENAME(b.name) + '', '' + QUOTENAME( d.name)
from sysmembers a inner join sysusers b
	on a.groupuid = b.uid
inner join sysusers c
	on a.memberuid = c.uid
left join master..syslogins d
	on c.sid = d.sid
where c.uid between 3 and 16000 and c.hasdbaccess = 1
print ''go''
'
from master..sysdatabases
--where (name like '%CC_%') or (name like 'WFCompany%') or (name in ('WF_Holden', 'WF_Lieu', 'wf_you') )
where name in (select dbname from __DatabaseList)
order by name

-- (CSODEVSQL1) Changing the compatibility mode
print '--CHANGE COMPATIBILITY LEVEL'
select 'exec sp_dbcmptlevel ' + QUOTENAME(Name) + ',100' +'
go'
from master..sysdatabases
--where (name like '%CC_%') or (name like 'WFCompany%') or (name in ('WF_Holden', 'WF_Lieu', 'wf_you') )
where name in (select dbname from __DatabaseList)
order by name


-- (CSODEVSQL1) Add All Investors to the db_owner role
print '--GRANT SECURITY'
select 'use ' + Name + '
go' + '
exec sp_grantdbaccess [OCEANIA\AU CT ALL COSMOS Investor Team];exec sp_addrolemember db_owner, [OCEANIA\AU CT ALL COSMOS Investor Team]
go'
from master..sysdatabases
--where (name like '%CC_%') or (name like 'WFCompany%') or (name in ('WF_Holden', 'WF_Lieu', 'wf_you') )
where name in (select dbname from __DatabaseList)
order by name

-- (CSODEVSQL1) Add All Investors to the db_owner role
print '--REBUILD INDEXES'
select 'use ' + Name + '
go' + '
EXEC sp_MSforeachtable @command1="print ''?'' DBCC DBREINDEX (''?'', '' '', 90)"
go'
from master..sysdatabases
--where (name like '%CC_%') or (name like 'WFCompany%') or (name in ('WF_Holden', 'WF_Lieu', 'wf_you') )
where name in (select dbname from __DatabaseList)
order by name
