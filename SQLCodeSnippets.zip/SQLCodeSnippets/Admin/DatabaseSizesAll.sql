    set nocount on
    declare @name sysname
    declare @SQL  nvarchar(600)

    /* Use temporary table to sum up database size w/o using group by */
    create table #databases (
                  DATABASE_ID int NOT NULL,
                  size int NOT NULL)

    declare c1 cursor for 
        select name from master.dbo.sysdatabases
            where has_dbaccess(name) = 1 and name like 'IVP%'-- Only look at databases to which we have access

    open c1
    fetch c1 into @name

    while @@fetch_status >= 0
    begin
        select @SQL = 'insert into #databases
                select '+ convert(sysname, db_id(@name)) + ', sum(size) from '
                + QuoteName(@name) + '.dbo.sysfiles'
        /* Insert row for each database */
        execute (@SQL)
        fetch c1 into @name
    end
    deallocate c1

    select  
        DATABASE_NAME = db_name(DATABASE_ID),
        DATABASE_SIZE = size*8/1024.0 /* Convert from 8192 byte pages to K */
    from #databases
    order by (size*8/1024.0) DESC

    select  sum(size*8/1024.0) as TOT_Size
    from #databases

	drop table #databases

