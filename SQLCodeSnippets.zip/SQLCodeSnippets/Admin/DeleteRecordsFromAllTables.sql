



-- disable triggers
EXEC sp_msforeachtable 'ALTER TABLE ? DISABLE TRIGGER all';
GO 

-- disable referential integrity
EXEC sp_MSForEachTable 'ALTER TABLE ? NOCHECK CONSTRAINT ALL' 
GO 

--
/*
EXEC sp_MSForEachTable 'SET QUOTED_IDENTIFIER ON; DELETE FROM ?' 
GO
*/

--Delete all records except for AA_ApplicationAttributes & AA_ApplicationSignature
EXEC sp_MSforeachtable 'IF OBJECT_ID(''?'') NOT IN (
                                                    ISNULL(OBJECT_ID(''[dbo].[AA_ApplicationAttributes]''),0),
                                                    ISNULL(OBJECT_ID(''[dbo].[AA_ApplicationSignature]''),0)
                                                   )
SET QUOTED_IDENTIFIER ON; DELETE FROM ?' 										 

-- enable referential integrity again 
EXEC sp_MSForEachTable 'ALTER TABLE ? WITH CHECK CHECK CONSTRAINT ALL' 
GO

-- enable triggers
EXEC sp_msforeachtable 'ALTER TABLE ? ENABLE TRIGGER all'
GO

