select 'alter database ' + name + ' set online; drop database '+ name+';' from sys.databases where state = 6 and name like 'GDE%'
order by name 