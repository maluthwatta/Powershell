DECLARE @command varchar(1000) 
SELECT @command = 'USE ? SELECT db_name() FROM sys.tables t INNER JOIN sys.schemas s on s.schema_id = t.schema_id
WHERE t.type = ''U'' AND s.name = ''dbo'' AND t.name = ''Staging_HLDPII'''
EXEC sp_MSforeachdb @command