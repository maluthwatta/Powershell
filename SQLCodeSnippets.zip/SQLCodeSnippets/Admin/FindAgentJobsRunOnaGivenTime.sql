set transaction isolation level read uncommitted
declare @starttime as datetime, @endtime as datetime
set @starttime = Getdate()-2
set @endtime = Getdate()-2 + 10.0/24

--############## or use this to check the history ############## 
--exec msdb..sp_help_jobhistory @step_id=0, @minimum_run_duration = 544, @start_run_date = 20090901
--,@start_run_time=80000
--############################ 


select distinct name, Start_Time, Finish_Time, datediff(mi,Start_Time, Finish_Time) as Duration
into #temp
from (

	select name, job_id, step_name
	,Duration
	,Run_time
	,run_date
	,DATEADD(
		SS
		, (convert(int,left(Run_time,2)))*3600 + (convert(int,substring(Run_time,3,2)) )*60 + (convert(int,right(Run_time,2)) )
		, run_date
		) as Start_Time
	,DATEADD(
		SS
		, (convert(int,left(Run_time,2)) + convert(int,left(Duration,2)))*3600 + (convert(int,substring(Run_time,3,2)) + convert(int,substring(Duration,3,2)))*60 + (convert(int,right(Run_time,2)) + convert(int,right(Duration,2)))
		, run_date
		) as Finish_Time
	from (
		SELECT  sj.name, jh.job_id, jh.step_name
		,replicate('0',6-len(jh.run_duration)) + convert(varchar,jh.run_duration) as Duration
		,replicate('0',6-len(jh.run_time)) + convert(varchar,jh.run_time) as Run_time
		,convert(datetime,convert(varchar,jh.run_date),112) as run_date
		,jh.instance_id
		FROM msdb.dbo.sysjobhistory jh inner join msdb..sysjobs sj
			on jh.job_id = sj.job_id
	) x

)y
where (@Starttime <= Start_Time or @Starttime <= Finish_Time) and (@Endtime >= Start_Time or @Endtime >= Finish_Time)
order by Start_Time


select name, min(Start_Time) as Start_Time, max(Finish_Time) as Finish_Time, Max(Duration) as Duration
from #temp
group by name
order by 2

drop table #temp
