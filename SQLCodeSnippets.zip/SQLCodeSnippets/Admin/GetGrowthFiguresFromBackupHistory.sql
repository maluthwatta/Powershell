/***********************************************************Check growth of .LDF and .MDF from backuphistory.
Lines returned depends on the frequency of full backups
Parameters: database name
            fromdate  (date from which info is requiered in 
                       smalldatetime)
Results best viewed in grid
***********************************************************/
--- Change these vars for your database
declare @dbname varchar(128)
declare @fromdate smalldatetime
select @dbname = 'IVP_Control_Prod%'
--select @dbname = 'co_prod_cmp_bhpb'
select @fromdate = getdate()-365   ---filegrowth last 30 days

create table #sizeinfo
(
filedate datetime null,
--dbname nvarchar(128) null,
Dsize numeric (20,0) null,
Lsize numeric (20,0) null,
backup_set_id int null,
backup_size numeric (20,0) null
)

--- tmp pivot table to get mdf en ldf info in one line
insert #sizeinfo
select 
filedate=bs.backup_finish_date,
--dbname=bs.database_name, 
SUM(CASE file_type WHEN 'D' THEN file_size ELSE 0 END) as Dsize,
SUM(CASE file_type WHEN 'L' THEN file_size ELSE 0 END) as Lsize,
bs.backup_set_id,
bs.backup_size
from msdb..backupset bs, msdb..backupfile bf
where bf.backup_set_id = bs.backup_set_id
--and rtrim(bs.database_name) = rtrim(@dbname)
and rtrim(bs.database_name) like @dbname
and bs.type = 'D'
and bs.backup_finish_date >= @fromdate
group by bs.backup_finish_date, bs.backup_set_id, bs.backup_size--, bs.database_name
order by bs.backup_finish_date, bs.backup_set_id, bs.backup_size--, bs.database_name

select 
Date=filedate, 
--Dbname=dbname, 
MDFSizeInMB=(Dsize/1024)/1024, 
LDFSizeInMB=(Lsize/1024)/1024, 
TotalFIleSizeInGB=((Dsize+Lsize)/1024)/1024/1024,
BackupSizeInGB=(backup_size/1024)/1024/1024
from #sizeinfo
order by filedate

drop table #sizeinfo


select db_name(dbid), sum((size*8)/1024.0)
from master..sysaltfiles
where db_name(dbid) like 'IVP_Control_Prod%'
group by db_name(dbid)
order by db_name(dbid)
