sp_helplogins 'NorthDomain\Mike'
  
sp_addlogin - SQL login
sp_grantlogin 'NorthDomain\Mary' - Windows login
sp_defaultdb 'NorthDomain\Mary', 'master'
