
declare @dbname sysname

create table #database_list(dbname sysname)
create table #db_login (NTlogin sysname)

insert into #database_list(dbname)
select name from sys.databases
where name like 'CI%'

declare dblist_cursor cursor for
	select dbname from #database_list
	
open dblist_cursor
fetch next from dblist_cursor into @dbname
while @@FETCH_STATUS = 0
begin
	insert into #db_login(NTlogin)
	exec ('select name from ' + @dbname + '.sys.database_principals where type_desc in (''WINDOWS_USER'', ''WINDOWS_GROUP'')')
	fetch next from dblist_cursor into @dbname
end

close dblist_cursor
deallocate dblist_cursor

select distinct NTlogin 
from #db_login
where NTlogin not in (select name from sys.server_principals where type_desc in ('WINDOWS_LOGIN', 'WINDOWS_GROUP'))
order by NTlogin

drop table #database_list
drop table #db_login

