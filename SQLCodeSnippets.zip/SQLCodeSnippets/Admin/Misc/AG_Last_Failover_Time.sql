DECLARE @FileName NVARCHAR(200)

SELECT @FileName = target_data.value('(EventFileTarget/File/@name)[1]','nvarchar(4000)')
FROM (
	SELECT
	CAST(target_data AS XML) target_data
	FROM sys.dm_xe_sessions s
	JOIN sys.dm_xe_session_targets t
	ON s.address = t.event_session_address
	WHERE s.name = N'AlwaysOn_health'
) ft


;WITH AG_Data AS (
SELECT 
	XEData.value('(event/@timestamp)[1]','datetime2(3)') AS event_timestamp,
	XEData.value('(event/data[@name="previous_state"]/text)[1]', 'varchar(255)') AS previous_state,
	XEData.value('(event/data[@name="current_state"]/text)[1]', 'varchar(255)') AS current_state,
	XEData.value('(event/data[@name="availability_replica_name"]/value)[1]', 'varchar(255)') AS availability_replica_name,
	XEData.value('(event/data[@name="availability_group_name"]/value)[1]', 'varchar(255)') AS availability_group_name
FROM (
SELECT CAST(event_data AS XML) XEData, *
FROM sys.fn_xe_file_target_read_file(@FileName, NULL, NULL, NULL)
WHERE object_name = 'availability_replica_state_change'
) event_data
WHERE XEData.value('(event/data[@name="current_state"]/text)[1]', 'varchar(255)') = 'PRIMARY_NORMAL'
)


SELECT * FROM AG_Data
ORDER BY event_timestamp DESC;