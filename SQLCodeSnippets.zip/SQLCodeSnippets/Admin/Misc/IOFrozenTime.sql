
declare @LogFile int
declare @logStartDate datetime
declare @logEndDate datetime

--Value of error log file you want to read: 0 = current, 1 = Archive #1, 2 = Archive #2, etc...
select @LogFile = 0

select @logStartDate = '2020-05-07 18:00:00',
		 @logEndDate = '2020-05-07 23:59:59'


if OBJECT_ID('tempdb..#ErrorLogsIOFrozen') IS NOT NULL DROP TABLE tempdb.#ErrorLogsIOFrozen;
if OBJECT_ID('tempdb..#ErrorLogsIOResume') IS NOT NULL DROP TABLE tempdb.#ErrorLogsIOResume;


create table #ErrorLogsIOFrozen
(
    LogDate  DATETIME,
	ProcessInfo VARCHAR(20),
	LogText NVARCHAR(500),
);

create table #ErrorLogsIOResume
(
    LogDate  DATETIME,
	ProcessInfo VARCHAR(20),
	LogText NVARCHAR(500),
);

insert into #ErrorLogsIOFrozen
exec sp_readerrorlog @LogFile, 1, 'I/O is frozen'; 

insert into #ErrorLogsIOResume
EXEC sp_readerrorlog @LogFile, 1, 'I/O was resumed';


/*
SELECT * FROM #ErrorLogsIOFrozen ORDER BY LogDate
SELECT * FROM #ErrorLogsIOResume ORDER BY LogDate
*/

;WITH IOFrozen AS(
	SELECT *, DatabaseName = SUBSTRING(LogText, 27, CHARINDEX('. ', LogText, 27 )-27 )
	FROM #ErrorLogsIOFrozen
	WHERE LogDate > @logStartDate AND LogDate < @logEndDate
)

,IOResume AS(
	SELECT *, DatabaseName = SUBSTRING(LogText, 29, CHARINDEX('. ', LogText, 29 )-29 )
	FROM #ErrorLogsIOResume
	WHERE LogDate > @logStartDate AND LogDate < @logEndDate
)


SELECT f.DatabaseName, f.LogDate AS IOFrozenTime, r.LogDate AS IOReleaseTime, IOFrozenDurationSec = DATEDIFF(s, f.LogDate, r.LogDate)
FROM IOFrozen f 
	INNER JOIN IOResume r ON
		r.ProcessInfo = f.ProcessInfo
		AND r.DatabaseName = f.DatabaseName
ORDER BY f.LogDate



