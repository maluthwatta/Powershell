
DECLARE @logStartDate DATETIME
	,@logEndDate DATETIME
	,@MaxLog INT
	,@RunTime DATETIME


--SELECT @logStartDate = '2020-05-01 09:00:00',
--		 @logEndDate = '2020-05-12 23:59:59'

SELECT @logStartDate = '',
		 @logEndDate = ''

SELECT @RunTime = GETDATE();

--If @logStartDate & @logEndDate is not provided then run for yesterday
IF ISNULL(@logStartDate, '') = '' AND ISNULL(@logEndDate, '') = '' 
BEGIN
	SELECT @logStartDate = CONVERT(VARCHAR, DATEADD(day, -1, @RunTime), 23) + ' 00:00:00'
	SELECT @logEndDate = CONVERT(VARCHAR, DATEADD(day, -1, @RunTime), 23) + ' 23:59:59'
END

IF OBJECT_ID('tempdb..#ErrorLogsIOFrozen') IS NOT NULL 
	DROP TABLE tempdb.#ErrorLogsIOFrozen;
IF OBJECT_ID('tempdb..#ErrorLogsIOResume') IS NOT NULL 
	DROP TABLE tempdb.#ErrorLogsIOResume;
IF OBJECT_ID('tempdb..#ErrorLogsIOFrozen') IS NOT NULL 
	DROP TABLE tempdb.#ErrorLogsIOFrozen;
IF OBJECT_ID('tempdb..#ErrorLogs') IS NOT NULL 
	DROP TABLE tempdb.#ErrorLogs;

CREATE TABLE #ErrorLogsIOFrozen
(
    LogDate  DATETIME,
	ProcessInfo VARCHAR(20),
	LogText NVARCHAR(500),
);

CREATE TABLE #ErrorLogsIOResume
(
    LogDate  DATETIME,
	ProcessInfo VARCHAR(20),
	LogText NVARCHAR(500),
);

CREATE TABLE #ErrorLogs
(
    LogID    INT,
    LogDate  DATETIME,
    LogSize  BIGINT
);

INSERT INTO #ErrorLogs
EXEC sys.sp_enumerrorlogs;

SELECT
	TOP 1
	@MaxLog = LogID
FROM #ErrorLogs
WHERE LogDate <= @logStartDate
ORDER BY LogDate DESC;


WHILE @MaxLog >= 0
BEGIN

	INSERT INTO #ErrorLogsIOFrozen
	EXEC sp_readerrorlog @MaxLog, 1, 'I/O is frozen'; 

	INSERT INTO #ErrorLogsIOResume
	EXEC sp_readerrorlog @MaxLog, 1, 'I/O was resumed';

	SET @MaxLog = @MaxLog - 1;

END


;WITH IOFrozen AS(
	SELECT *, DatabaseName = SUBSTRING(LogText, 27, CHARINDEX('. ', LogText, 27 )-27 )
	FROM #ErrorLogsIOFrozen
	WHERE LogDate > @logStartDate AND LogDate < @logEndDate
)

,IOResume AS(
	SELECT *, DatabaseName = SUBSTRING(LogText, 29, CHARINDEX('. ', LogText, 29 )-29 )
	FROM #ErrorLogsIOResume
	WHERE LogDate > @logStartDate AND LogDate < @logEndDate
)


SELECT @@SERVERNAME AS ServerName, f.DatabaseName, f.LogDate AS IOFrozenTime, r.LogDate AS IOReleaseTime, IOFrozenDurationSec = DATEDIFF(s, f.LogDate, r.LogDate), @RunTime AS RunTime
FROM IOFrozen f 
	INNER JOIN IOResume r ON
		r.ProcessInfo = f.ProcessInfo
		AND r.DatabaseName = f.DatabaseName
		AND CONVERT(DATE, r.LogDate) =  CONVERT(DATE,f.LogDate)
WHERE 1=2
ORDER BY f.LogDate, f.DatabaseName


