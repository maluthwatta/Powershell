select date_id, date_sale from dbo.Dates

-- Setup a clean system
drop partition scheme YearPS
drop partition function YearPF

-- Create a partitioning function.
-- Here we're creating two partitions based on date values: all values from and after 2003-07-01 
-- will go in the second partition and al the values before goes in the first one.
create partition function YearPF(datetime)
as range right for values ('20030701');

sp_helpdb IVP_Control_MA

-- Now we need to add filegroups that will contains partitioned values
alter database IVP_Control_MA add filegroup YearFG1;
alter database IVP_Control_MA add filegroup YearFG2;

-- Now we need to add file to filegroups
alter database IVP_Control_MA add file 
(name = 'YearF1', filename = 'S:\mpS_CSODEVSQL4_SQLDATA\IVP_Control_MA_F1.ndf') 
to filegroup YearFG1;

alter database IVP_Control_MA add file 
(name = 'YearF2', filename = 'S:\mpS_CSODEVSQL4_SQLDATA\IVP_Control_MA_F2.ndf') 
to filegroup YearFG2;

-- Here we associate the partition function to 
-- the created filegroup via a Partitioning Scheme
create partition scheme YearPS
as partition YearPF to (YearFG1, YearFG2)

-- Now just create a table that uses the particion scheme
create table PartitionedOrders
(
Id int not null identity(1,1),
DueDate DateTime not null,
) on YearPS(DueDate)

-- And now we just have to use the table!
insert into PartitionedOrders values('2003-07-01')
insert into PartitionedOrders values('2003-06-13')
insert into PartitionedOrders values('2003-09-01')
insert into PartitionedOrders values('2004-07-01')
insert into PartitionedOrders values('2001-07-01')

-- Now we want to see where our values has falled
select *, $partition.YearPF(DueDate) as [PartitionID] from PartitionedOrders
order by id

-- You can also view how many partitions we did
select * from sys.partitions where object_id = object_id('PartitionedOrders')

-----------------------------------------------------------------------------
insert into PartitionedOrders(DueDate)
select date_sale from dbo.Dates

select *, $partition.YearPF(DueDate) as [PartitionID] from PartitionedOrders
order by id
-----------------------------------------------------------------------------------------------

truncate table PartitionedOrders
drop table PartitionedOrders


-- Setup a clean system
drop partition scheme YearPS
drop partition function YearPF

-- Create a partitioning function.
-- Here we're creating two partitions based on date values: all values from and after 2003-07-01 
-- will go in the second partition and al the values before goes in the first one.
create partition function YearPF(datetime)
as range right for values ('20010801', '20020801', '20030801');

sp_helpdb IVP_Control_MA

-- Now we need to add filegroups that will contains partitioned values
alter database IVP_Control_MA add filegroup YearFG1;
alter database IVP_Control_MA add filegroup YearFG2;
alter database IVP_Control_MA add filegroup YearFG3;
alter database IVP_Control_MA add filegroup YearFG4;

-- Now we need to add file to filegroups
alter database IVP_Control_MA add file 
(name = 'YearF1', filename = 'S:\mpS_CSODEVSQL4_SQLDATA\IVP_Control_MA_F1.ndf') 
to filegroup YearFG1;

alter database IVP_Control_MA add file 
(name = 'YearF2', filename = 'S:\mpS_CSODEVSQL4_SQLDATA\IVP_Control_MA_F2.ndf') 
to filegroup YearFG2;

alter database IVP_Control_MA add file 
(name = 'YearF3', filename = 'S:\mpS_CSODEVSQL4_SQLDATA\IVP_Control_MA_F3.ndf') 
to filegroup YearFG3;

alter database IVP_Control_MA add file 
(name = 'YearF4', filename = 'S:\mpS_CSODEVSQL4_SQLDATA\IVP_Control_MA_F4.ndf') 
to filegroup YearFG4;


-- Here we associate the partition function to 
-- the created filegroup via a Partitioning Scheme
create partition scheme YearPS
as partition YearPF to (YearFG1, YearFG2, YearFG3, YearFG4)

-- Now just create a table that uses the particion scheme
create table PartitionedOrders
(
Id int not null identity(1,1),
DueDate DateTime not null,
) on YearPS(DueDate)

-- And now we just have to use the table!
insert into PartitionedOrders(DueDate)
select date_sale from dbo.Dates

-- Now we want to see where our values has falled
select *, $partition.YearPF(DueDate) as [PartitionID] from PartitionedOrders
order by id

-- You can also view how many partitions we did
select * from sys.partitions where object_id = object_id('PartitionedOrders')


select * from sys.partitions where object_id = object_id('Source.SCRIPWebImportQ01')

k