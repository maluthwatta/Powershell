--to get partition boundaries
select pf.name, * from sys.partition_range_values prv inner join sys.partition_functions pf
	on pf.function_id = prv.function_id
	
--to get the partition to which the data gets inserted
SELECT $PARTITION.pf_ETL_BalanceActivity(20110422) [PARTITION NUMBER]	

-- to find out what pf is being used by a ps
select ps.name as 'partition_schema', pf.name as 'partition_function', * 
from sys.partition_schemes ps 
inner join sys.partition_functions pf on pf.function_id = ps.function_id

-- to find out what file group is being used
select ds.name , dds.destination_id as 'pf boundary id' , ds2.name as 'FG' ,* 
from sys.destination_data_spaces dds
inner join sys.data_spaces ds on ds.data_space_id = dds.partition_scheme_id
inner join sys.data_spaces ds2 on ds2.data_space_id = dds.data_space_id

-- to find out the data type of the partition key
select pf.name, t.name, *
from sys.partition_functions pf 
	inner join sys.partition_parameters pp on pp.function_id = pf.function_id
	inner join sys.types t on t.system_type_id = pp.system_type_id
