select fg.Name, so.name , si.Name
from sys.objects so
inner join sys.indexes si
    on so.object_ID = si.object_ID
inner join sys.data_spaces ds
    on si.data_space_id = ds.data_space_id
inner join sys.filegroups fg
    on ds.data_space_id = fg.data_space_id
where fg.name in ('FG_ConnAnalysis')
and si.Name is not null
and object_name(si.object_id) = 'Connection_TransferSession'
order by fg.Name, so.name , si.Name