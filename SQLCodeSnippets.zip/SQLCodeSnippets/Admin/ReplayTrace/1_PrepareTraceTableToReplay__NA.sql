p_dba_helpdb zDBA
sp_helpdb
use zDBA
--1) CREATE TRACE REPLAY TABLE
--drop table [CI_REPLAY_TEST]
CREATE TABLE [dbo].[CI_REPLAY_TEST](
	[RowNumber] [int] IDENTITY(1,1) NOT NULL,
	[EventClass] [int] NULL,
	[EventSubClass] [int] NULL,
	[TextData] [ntext] NULL,
	[ApplicationName] [nvarchar](128) NULL,
	[LoginName] [nvarchar](128) NULL,
	[DatabaseID] [int] NULL,
	[ClientProcessID] [int] NULL,
	[HostName] [nvarchar](128) NULL,
	[ServerName] [nvarchar](128) NULL,
	[BinaryData] [image] NULL,
	[SPID] [int] NULL,
	[StartTime] [datetime] NULL,
    Reads int,
    Writes int,
    Duration int,
    CPU int,
PRIMARY KEY CLUSTERED 
(
	[RowNumber] ASC
)
)
--2) POPULATE TRACE REPLAY TABLE
INSERT INTO [dbo].[CI_REPLAY_TEST]
           ([EventClass]
           ,[EventSubClass]
           ,[TextData]
           ,[ApplicationName]
           ,[LoginName]
           ,[DatabaseID]
           ,[ClientProcessID]
           ,[HostName]
           ,[ServerName]
           ,[BinaryData]
           ,[SPID]
           ,[StartTime]
           ,Reads
           ,Writes
           ,Duration
           ,CPU)

select top 100
    EventClass
    ,null as [EventSubClass]
	,TextData
    ,'App Name' as [ApplicationName]
    ,[LoginName]
    ,[DataBaseID]
    ,[ClientProcessID]
    ,'HOSTNAME' as [HostName]
    ,'CSOSQL3' as [ServerName]
    , null as [BinaryData]
    ,[SPID]
    ,[StartTime]
    ,Reads
    ,Writes
    ,Duration
    ,CPU
FROM ::fn_trace_gettable('R:\SQLTrace\CI\CI_InvProd_Before_V30.trc',default)

--i:\SQLTrace\CI\CI_InvProd_16_7_2007_C.trc
master..xp_cmdshell 'dir G:\SQLTrace\'
select count(*) FROM ::fn_trace_gettable('i:\SQLTrace\CI\CI_InvProd_16_7_2007_C.trc',default)

SELECT top 100
       10 as [EventClass]
      ,null as [EventSubClass]
      ,[TextData]
      ,[ApplicationName]
      ,[LoginName]
      ,46 as [DataBaseID]
      ,[ClientProcessID]
      ,[HostName]
      ,[ServerName]
      , null as [BinaryData]
      ,[SPID]
      ,[StartTime]
  FROM [zDBA].[dbo].[CSOSQL3_GT1000_ALL] (nolock)
where DataBaseID = db_id('CI_invProd')
and StartTime between 'Jul 09 2007 8:00 AM' and 'Jul 09 2007 6:00 PM'

CI_InvTest on CSODEVSQL1 = DBID --> 222
CI_InvTest on CSODEVSQL4\DEV1 = DBID --> 46
CI_InvTest on CSOSQL9 = DBID --> 5
CI_InvTest on CSESQL4C\COS1 = DBID --> 8
use zdba
select top 10 * from [CI_REPLAY_TEST]
--3) SET THE TARGET DB ID
update [CI_REPLAY_TEST]
set [DatabaseID] = 18

update [CI_REPLAY_TEST]
set [DatabaseID] = 20

--4) SET THE SP ID
--begin tran
--update [CI_REPLAY_TEST]
--set [TextData] = 'print ' + convert(varchar,Rownumber) + ';' + convert(varchar(2000),TextData)
--where [TextData] like '%exec%'

update [CI_REPLAY_TEST]
set [TextData] = 'print ' + replicate('0',8-len(convert(varchar,Rownumber)))+ convert(varchar,Rownumber) + ';' + convert(varchar(2000),TextData)
where [TextData] like '%exec%'

declare @rowcount int
declare @Start int, @End int
set @Start = 0
set @End = @Start + 50000

while (1=1)
begin
    update [CI_REPLAY_TEST]
    set [TextData] = 'print ' + replicate('0',8-len(convert(varchar,Rownumber)))+ convert(varchar,Rownumber) + ';' + convert(varchar(2000),TextData)
    where Rownumber between @Start and @End
    select @rowcount = @@rowcount

    if @rowcount = 0 break;

    set @Start = @End+ 1
    set @End = @Start + 10000
end
--Took 3 minutes for 1091411 rows

select top 10 *from [CI_REPLAY_TEST]

--select top 10 'print ' + replicate('0',8-len(convert(varchar,Rownumber)))+ convert(varchar,Rownumber) + ';' + convert(varchar(2000),TextData)
--from [CI_REPLAY_TEST]

select top 10 *
from [CI_REPLAY_TEST]
sp_spaceused [CI_REPLAY_TEST]



--rollback


SELECT 
TextData, Reads,Duration, StartTime,  DATENAME(weekday, StartTime) as [weekday], NTUserName
--RowID, TextData, DataBaseName, NTUserName, NTDomainName, HostName, ClientProcessID, ApplicationName, LoginName, SPID, Duration, StartTime, EndTime, Reads, Writes, CPU, ServerName, EventClass, DataBaseID 
FROM zDBA.dbo.CSACCOSSQL3C_GT1000_ALL(nolock)
where DataBaseID = db_id('CI_invProd') 
--and StartTime between 'Apr 1 2006 00:00' and 'Apr 1 2006 23:59'
and StartTime between '11/19/2006 4:43:34' and '11/19/2006 6:22:04'
and TextData Like '%exec %'
and NTUserName = 'InvestorMTS'
--and TextData Like '%p_CI_SearchICAccountByNameAddressPaged%'
--and TextData Like '%p_CI_GetInvestorTaxTransAccountsByDesignationTaxRegimePaged%'
order by Reads desc
use zDBA
select top 100 * from [CI_REPLAY_TEST]
where writes >10

print db_id('CI_Invprod')


select count(*) from [CI_REPLAY_TEST]
where textdata like '%p_CI_SearchICAccountByNameAddressPaged%'

update [CI_REPLAY_TEST]
set textdata =  '--' + convert(varchar(2000),textdata)
where textdata like '%p_CI_SearchICAccountByNameAddressPaged%'

select * 
into [CI_REPLAY_TEST___TEMP]
from [CI_REPLAY_TEST]
where textdata like '%p_CI_SearchICAccountByNameAddressPaged%'






SELECT * FROM :: fn_trace_getinfo(default)

exec sp_trace_setstatus @TraceID, Status

Status Description 
0 Stops the specified trace. 
1 Starts the specified trace. 
2 Closes the specified trace and deletes its definition from the server 

SELECT count(*) FROM ::fn_trace_gettable('R:\SQLTrace\CI\CI_InvProd_20_7_2007_A.trc',default)

use zDBA

select name from sysobjects where xtype = 'U'



ALTER TABLE CI_REPLAY_TEST ADD SP_Name nvarchar(200) null

declare @rowcount int
declare @Start int, @End int
set @Start = 0
set @End = @Start + 50000

while (1=1)
begin
    update CI_REPLAY_TEST
    set SP_Name = dbo.fn_extractspname_ex(TextData)
    where Rownumber between @Start and @End
    select @rowcount = @@rowcount

    waitfor delay '00:00:01'

    if @rowcount = 0 break;
    
    set @Start = @End+ 1
    set @End = @Start + 50000
    select @Start, @End
end


create index ix_bimal on CI_REPLAY_TEST (SP_Name)


-- DELETE DML SPs
select top 1000 SP_Name from [CI_REPLAY_TEST]
delete from [CI_REPLAY_TEST]
where (SP_Name like 'p_CI_Create%'
or SP_Name like 'p_CI_Update%'
or SP_Name like 'p_CI_Delete%'
or SP_Name like 'p_CI_Insert%'
)

-- DELETE BM and Hybrid load SPs
select top 1000 SP_Name from [CI_REPLAY_TEST]
delete 
select SP_Name from [CI_REPLAY_TEST]
where (SP_Name like 'p_CI_BM%'
or SP_Name like 'p_CI_8%'
)

--DELETE dynamic SQL, Non SPs
select top 1000 SP_Name from [CI_REPLAY_TEST]
delete 
select top 10 TextData, SP_Name delete from [CI_REPLAY_TEST]
where (SP_Name like 't%')

p_CI_BM400_StoreMatchingData

select top 1000 SP_Name from [CI_REPLAY_TEST]
where writes >10


p_CI_CreateInvestorAddress
p_CI_UpdateIAccounts