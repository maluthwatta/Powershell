sp_help CI_REPLAY_V3_0_TRACE_ON_3_0_DB_Run_without_heavyCalls
sp_help CI_REPLAY_V3_0_TRACE_ON_3_0_DB_Run_without_heavyCalls


SELECT top 10
[RowNumber]
      ,[EventClass]
      ,[EventSubClass]
      ,[TextData]
      ,[ApplicationName]
      ,[LoginName]
      ,[DatabaseID]
      ,[ClientProcessID]
      ,[HostName]
      ,[ServerName]
      ,[BinaryData]
      ,[SPID]
      ,[StartTime]
      ,[Reads]
      ,[Writes]
      ,[Duration]
      ,[CPU]
FROM [CI_Profile_AU].[dbo].CI_REPLAY_V3_0_TRACE_ON_2_4_DB_Run_without_heavyCalls

SELECT top 10
[RowNumber]
      ,[EventClass]
      ,[TextData]
      ,[CPU]
      ,[Reads]
      ,[Writes]
      ,[Duration]
      ,[SPID]
      ,[StartTime]
      ,[DatabaseID]
      ,[BinaryData]
  FROM [dbo].[CI_REPLAY_V3_0_TRACE_ON_3_0_DB_Run_without_heavyCalls]

select top 50
convert(int,replace(left(convert(varchar(2000),[TextData]),14),'print ',''))
FROM [CI_Profile_AU].[dbo].[CI_REPLAY_V3_0_TRACE_ON_3_0_DB_Run_without_heavyCalls]


print 00000001;exec dbo.p_CR_SearchOperators @UserName = N'PapilloJ', @OperatorName = N'%', @DomainName = N'OCEANIA', @BranchCode = N'%', @DebugMode = 0

select top 10 a.[TextData], a.Duration, b.Duration, a.Reads, b.Reads, a.CPU, b.CPU
from [CI_REPLAY_V2_3_TRACE_DATA] as A inner join [CI_CSOSQL9_REPLAY_RESULTS_Round1] B
    on a.[RowNumber] = b.[SP_Number]

ALTER TABLE CI_REPLAY_V3_0_TRACE_ON_3_0_DB_Run_without_heavyCalls ADD SP_Number int null

declare @rowcount int
declare @Start int, @End int
set @Start = 0
set @End = @Start + 100000

while (1=1)
begin
    update CI_REPLAY_V3_0_TRACE_ON_3_0_DB_Run_without_heavyCalls
    set SP_Number = convert(int,replace(left(convert(varchar(2000),[TextData]),14),'print ',''))
    where Rownumber between @Start and @End
    select @rowcount = @@rowcount

    waitfor delay '00:00:02'

    if @rowcount = 0 break;
    
    set @Start = @End+ 1
    set @End = @Start + 100000
    select @Start, @End
end

  select top 10 *FROM [CI_Profile_AU].[dbo].[CI_REPLAY_V3_0_TRACE_ON_3_0_DB_Run_without_heavyCalls]

CI_REPLAY_V3_0_TRACE_ON_2_4_DB_Run_without_heavyCalls
CI_REPLAY_V3_0_TRACE_ON_3_0_DB_Run_without_heavyCalls

create unique index CI_REPLAY_V3_0_TRACE_ON_2_4_DB_Run_without_heavyCalls__AK1 on CI_REPLAY_V3_0_TRACE_ON_2_4_DB_Run_without_heavyCalls(SP_Number, Reads, Writes, Duration, CPU)
create unique index CI_REPLAY_V3_0_TRACE_ON_3_0_DB_Run_without_heavyCalls_AK1 on CI_REPLAY_V3_0_TRACE_ON_3_0_DB_Run_without_heavyCalls(SP_Number, Reads, Writes, Duration, CPU)

drop index CI_REPLAY_V3_0_TRACE_ON_3_0_DB_Run_without_heavyCalls.CI_REPLAY_V3_0_TRACE_ON_3_0_DB_Run_without_heavyCalls_AK1
create unique index CI_REPLAY_V3_0_TRACE_ON_3_0_DB_Run_without_heavyCalls_AK1 on CI_REPLAY_V3_0_TRACE_ON_3_0_DB_Run_without_heavyCalls(SP_Number, Reads, Writes, Duration, CPU,SP_name)

select top 1000 a.[TextData], a.Duration, b.Duration/1000 as Duration, a.Reads, b.Reads, a.CPU, b.CPU
from CI_REPLAY_V3_0_TRACE_ON_2_4_DB_Run_without_heavyCalls as A inner join CI_REPLAY_V3_0_TRACE_ON_3_0_DB_Run_without_heavyCalls B
    on a.[RowNumber] = b.[SP_Number]


select count(*)
from CI_REPLAY_V3_0_TRACE_ON_2_4_DB_Run_without_heavyCalls as A inner join CI_REPLAY_V3_0_TRACE_ON_3_0_DB_Run_without_heavyCalls B
    on a.[RowNumber] = b.[SP_Number]
where (a.CPU < b.CPU or a.Reads < b.reads) and a.Duration > b.Duration/1000

select sum(a.Reads) as V2_4_Reads, sum(b.Reads) as V3_0_Reads, sum(a.Reads) - sum(b.Reads) as Reads_Diff
from CI_REPLAY_V3_0_TRACE_ON_2_4_DB_Run_without_heavyCalls as A inner join CI_REPLAY_V3_0_TRACE_ON_3_0_DB_Run_without_heavyCalls B
    on a.[SP_Number] = b.[SP_Number]

select a.TextData, a.Reads as 24_reads, b.Reads as 30_Reads, a.Reads-b.Reads
from CI_REPLAY_V3_0_TRACE_ON_2_4_DB_Run_without_heavyCalls as A inner join CI_REPLAY_V3_0_TRACE_ON_3_0_DB_Run_without_heavyCalls B
    on a.[SP_Number] = b.[SP_Number]

--where a.Duration < b.Duration/1000
#Performing slower than Original = 416555

--where a.Duration >= b.Duration/1000
#Performing faster than or equal to Original = 674850

--where a.Reads < b.Reads
#Performing more reads than Original = 898380

--where a.Reads >= b.Reads
#Performing less reads than Original = 193025


--where a.CPU < b.CPU
#Performing more CPU than Original = 264571

--where a.CPU >= b.CPU
#Performing less CPU than Original = 826834

---SUMMARY---
select count(*)
from CI_REPLAY_V3_0_TRACE_ON_2_4_DB_Run_without_heavyCalls as A inner join CI_REPLAY_V3_0_TRACE_ON_3_0_DB_Run_without_heavyCalls B
    on a.[SP_Number] = b.[SP_Number]


select sum(a.Reads) as V2_4_Reads, sum(b.Reads) as V3_0_Reads, sum(a.Reads) - sum(b.Reads) as Reads_Diff
from CI_REPLAY_V3_0_TRACE_ON_2_4_DB_Run_without_heavyCalls as A inner join CI_REPLAY_V3_0_TRACE_ON_3_0_DB_Run_without_heavyCalls B
    on a.[SP_Number] = b.[SP_Number]

V2_4_Reads	V3_0_Reads	Reads_Diff
938803696	637793672	301010024

This means 32% less Reads are done in SQL 2005

select sum(a.CPU) as V2_4_CPU, sum(b.CPU) as V3_0_CPU, sum(a.CPU) - sum(b.CPU) as CPU_Diff
from CI_REPLAY_V3_0_TRACE_ON_2_4_DB_Run_without_heavyCalls as A inner join CI_REPLAY_V3_0_TRACE_ON_3_0_DB_Run_without_heavyCalls B
    on a.[SP_Number] = b.[SP_Number]

V2_4_CPU	V3_0_CPU	CPU_Diff
14629390	24161274	-9531884

This means 65% more CPU are done in SQL 2005

select sum(a.Duration/1000) as V2_4_Duration, sum(b.Duration/1000) as V3_0_Duration, sum(a.Duration/1000) - sum(b.Duration/1000) as Duration_Diff
from CI_REPLAY_V3_0_TRACE_ON_2_4_DB_Run_without_heavyCalls as A inner join CI_REPLAY_V3_0_TRACE_ON_3_0_DB_Run_without_heavyCalls B
    on a.[SP_Number] = b.[SP_Number]

select top 10 textdata, Duration
from CI_REPLAY_V3_0_TRACE_ON_2_4_DB_Run_without_heavyCalls
order by Duration desc

print 00202051;declare @p15 int  set @p15=0  exec dbo.p_CI_SearchInvestorByAddressPaged @DomainName=N'AMERICAS',@UserName=N'MurrayP',@CompanyCode=N'',@ExternalCompanyCode=N'',@AddressKey=N'150SOWHITEHALL%',@LocalityName=N'%',@StateProvinceName=N'%',@Postcode=N'60067%',@ISO3CountryCode=N'%',@AccountHoldersOnly=N'Y',@SortColumn=N'',@SortOrder=N'',@RecordStartNumber=0,@RecordsToReturn=51,@TotalPopulationSize=@p15 output,@DebugMode=0  select @p15

V2_4_Duration	V3_0_Duration	Duration_Diff
29777184	21692260	8084924

This means exection is 27% faster in SQL 2005

print (8084924/29777184.0)* 100

select min(a.[StartTime]), max(a.[StartTime])
from CI_REPLAY_V3_0_TRACE_ON_2_4_DB_Run_without_heavyCalls as A inner join CI_REPLAY_V3_0_TRACE_ON_3_0_DB_Run_without_heavyCalls B
    on a.[RowNumber] = b.[SP_Number]
select min(a.[StartTime]), max(a.[StartTime])
from CI_REPLAY_V3_0_TRACE_ON_3_0_DB_Run_without_heavyCalls a

sp_helpindex CI_REPLAY_V3_0_TRACE_ON_3_0_DB_Run_without_heavyCalls

ALTER TABLE [dbo].CI_REPLAY_V3_0_TRACE_ON_2_4_DB_Run_without_heavyCalls ADD PRIMARY KEY CLUSTERED 
(
	[RowNumber] ASC
)

select sum(a.Writes) as V2_4_Writes, sum(b.Writes) as V3_0_Writes, sum(a.Writes) - sum(b.Writes) as Writes_Diff
from CI_REPLAY_V3_0_TRACE_ON_2_4_DB_Run_without_heavyCalls as A inner join CI_REPLAY_V3_0_TRACE_ON_3_0_DB_Run_without_heavyCalls B
    on a.[RowNumber] = b.[SP_Number]
V2_4_Writes	V3_0_Writes	Writes_Diff
417268	21583	395685

use ci_profile_au
select top 100 a.TextData, a.CPU, b.CPU, a.Duration, b.Duration/1000 as Duration, a.Reads, b.Reads
from CI_REPLAY_V3_0_TRACE_ON_2_4_DB_Run_without_heavyCalls as A inner join CI_REPLAY_V3_0_TRACE_ON_3_0_DB_Run_without_heavyCalls B
    on a.[RowNumber] = b.[SP_Number]
--where a.CPU*2< b.CPU
order by b.CPU desc

select * from dbo.CI_REPLAY_V3_0_TRACE_ON_3_0_DB_Run_without_heavyCalls

sp_helpuser

select sum(a.CPU), sum(a.CPU)
from CI_REPLAY_V3_0_TRACE_ON_2_4_DB_Run_without_heavyCalls as A inner join CI_REPLAY_V3_0_TRACE_ON_3_0_DB_Run_without_heavyCalls B
    on a.[RowNumber] = b.[SP_Number]

select count(*)
from CI_REPLAY_V3_0_TRACE_ON_3_0_DB_Run_without_heavyCalls
where TextData like '%p_CI_SearchICAccountByAddressPaged%'


select b.SP_Name, sum(a.CPU) as V2_4_CPU, sum(b.CPU) as V3_0_CPU,sum(b.CPU) - sum(a.CPU) as Overhead, count(*) as Exec_Count, 
(sum(b.CPU) - sum(a.CPU))/count(*) as Avg_Overhead
from CI_REPLAY_V3_0_TRACE_ON_2_4_DB_Run_without_heavyCalls as A inner join CI_REPLAY_V3_0_TRACE_ON_3_0_DB_Run_without_heavyCalls B
    on a.[RowNumber] = b.[SP_Number]
group by b.SP_Name
order by sum(b.CPU) - sum(a.CPU) desc

select top 10 dbo.fn_extractspname_ex(a.TextData)
from CI_REPLAY_V3_0_TRACE_ON_2_4_DB_Run_without_heavyCalls a


ALTER TABLE CI_REPLAY_V3_0_TRACE_ON_3_0_DB_Run_without_heavyCalls ADD SP_Name nvarchar(200) null

declare @rowcount int
declare @Start int, @End int
set @Start = 0
set @End = @Start + 50000

while (1=1)
begin
    update CI_REPLAY_V3_0_TRACE_ON_3_0_DB_Run_without_heavyCalls
    set SP_Name = dbo.fn_extractspname_ex(TextData)
    where Rownumber between @Start and @End
    select @rowcount = @@rowcount

    waitfor delay '00:00:02'

    if @rowcount = 0 break;
    
    set @Start = @End+ 1
    set @End = @Start + 100000
    select @Start, @End
end

  select top 10 *FROM [CI_Profile_AU].[dbo].[CI_REPLAY_V3_0_TRACE_ON_3_0_DB_Run_without_heavyCalls]


bimal - p_CI_GetInvestorTaxTransactionAccountsByDesignationTaxRegime
bimal - p_CI_GetInvestorAccountTransactionsPending

p_CI_GetInvestorTaxTransactionAccountsByDesignationTaxRegime
p_CI_GetInvestorAccountTransactionsPending

CI_REPLAY_V3_0_TRACE_ON_2_4_DB_Run_without_heavyCalls_Run_without_heavyCalls
CI_REPLAY_V3_0_TRACE_ON_3_0_DB_Run_without_heavyCalls_Run_without_heavyCalls


use CI_Profiler_NA_V30
select name from master..sysdatabases where name like 'CI%'

select sum(a.Reads) as V2_4_Reads, sum(b.Reads) as V3_0_Reads, sum(a.Reads) - sum(b.Reads) as Reads_Diff
from CI_REPLAY_V3_0_TRACE_ON_2_4_DB_Run_without_heavyCalls as A inner join CI_REPLAY_V3_0_TRACE_ON_3_0_DB_Run_without_heavyCalls B
    on a.[SP_Number] = b.[SP_Number]
Where a.SP_Name = 'p_CI_SearchICAccountByNameAddressPaged'

select count(*)
from CI_REPLAY_V3_0_TRACE_ON_2_4_DB_Run_without_heavyCalls as A inner join CI_REPLAY_V3_0_TRACE_ON_3_0_DB_Run_without_heavyCalls B
    on a.[SP_Number] = b.[SP_Number]
Where a.SP_Name = 'p_CI_SearchICAccountByNameAddressPaged'

select a.SP_Name , count(*) sp_calls, sum(a.Reads) as V2_4_Reads, sum(b.Reads) as V3_0_Reads, sum(a.Reads) - sum(b.Reads) as Reads_Diff
from CI_REPLAY_V3_0_TRACE_ON_2_4_DB_Run_without_heavyCalls as A inner join CI_REPLAY_V3_0_TRACE_ON_3_0_DB_Run_without_heavyCalls B
    on a.[SP_Number] = b.[SP_Number]
group by a.SP_Name
order by 5

select a.SP_Name , count(*) sp_calls, sum(a.CPU) as V2_4_CPU, sum(b.CPU) as V3_0_CPU, sum(a.CPU) - sum(b.CPU) as CPU_Diff
vfrom CI_REPLAY_V3_0_TRACE_ON_2_4_DB_Run_without_heavyCalls as A inner join CI_REPLAY_V3_0_TRACE_ON_3_0_DB_Run_without_heavyCalls B
    on a.[SP_Number] = b.[SP_Number]
group by a.SP_Name
order by 5

select a.SP_Name , count(*) sp_calls, sum(a.Duration/1000) as V2_4_Duration, sum(b.Duration/1000) as V3_0_Duration, sum(a.Duration/1000) - sum(b.Duration/1000) as Duration_Diff
from CI_REPLAY_V3_0_TRACE_ON_2_4_DB_Run_without_heavyCalls as A inner join CI_REPLAY_V3_0_TRACE_ON_3_0_DB_Run_without_heavyCalls B
    on a.[SP_Number] = b.[SP_Number]
group by a.SP_Name
order by 5

select a.SP_Name , count(*) sp_calls
, sum(a.Reads) as V2_4_Reads, sum(b.Reads) as V3_0_Reads, sum(a.Reads) - sum(b.Reads) as Reads_Diff
, sum(a.CPU) as V2_4_CPU, sum(b.CPU) as V3_0_CPU, sum(a.CPU) - sum(b.CPU) as CPU_Diff
, sum(a.Duration/1000) as V2_4_Duration, sum(b.Duration/1000) as V3_0_Duration, sum(a.Duration/1000) - sum(b.Duration/1000) as Duration_Diff
from CI_REPLAY_V3_0_TRACE_ON_2_4_DB_Run_without_heavyCalls as A inner join CI_REPLAY_V3_0_TRACE_ON_3_0_DB_Run_without_heavyCalls B
    on a.[SP_Number] = b.[SP_Number]
group by a.SP_Name
order by 5



sp_MShelpColumns z_M_OperatorRoles