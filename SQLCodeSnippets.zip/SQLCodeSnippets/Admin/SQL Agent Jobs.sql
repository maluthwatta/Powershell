use msdb;

select j.name as 'Job Name'
	,j.description as 'Job Description'
	,sl.name as 'Owner'
	,s.step_id as 'Step ID'
	,s.step_name as 'Step Name'
	,s.command as 'Command'
	,sc.name as 'Schedule Name'
	--,sc.freq_type
	,case sc.freq_type
	when 1 then 'Once'
	when 4 then 'Daily'
	when 8 then 'Weekly'
	when 16 then 'Monthly'
	when 32 then 'Monthly relative'
	When 64 then 'When SQL Server Agent starts' end as 'Frequency'
	,case sc.freq_type
	when 4 then LTRIM(STR(sc.freq_interval)) + ' day'
	when 8 then 
		(case sc.freq_interval
		when 1 then 'Sunday'
		when 2 then 'Monday'
		when 4 then 'Tuesday'
		when 8 then 'Wednesday'
		when 16 then 'Thursday'
		when 32 then 'Friday'
		when 64 then 'Saturday'
		when 65 then 'Saturday, Sunday'
		when 62 then 'Monday, Thuesday, Wednesday, Thursday, Friday'
		when 127 then 'Monday, Thuesday, Wednesday, Thursday, Friday, Saturday, Sunday' end)
	when 16 then 'Every ' + LTRIM(STR(sc.freq_interval)) + ' day of the month'
	when 32 then 'Monthly relative'
	When 64 then 'When SQL Server Agent starts' else '' end as 'Recurse every' 	
	--,sc.freq_interval
	--,sc.freq_subday_type
	,case sc.freq_subday_type
		when 1 then 'At ' + 
			right('0' + cast(floor(sc.active_start_time/10000) as varchar(2)),2) + ':' +
			right('0' + cast(((sc.active_start_time/100)%100) as varchar(2)),2) + ':' +
			right('0' + cast((sc.active_start_time%100) as varchar(2)),2)
		when 2 then 'Every ' + LTRIM(STR(sc.freq_subday_interval)) + ' second(s)'
		when 4 then 'Every ' + LTRIM(STR(sc.freq_subday_interval)) + ' minute(s)'
		when 8 then 'Every ' + LTRIM(STR(sc.freq_subday_interval)) + ' hour(s)' end as 'Occurs'
	,right('0' + cast(floor(sc.active_start_time/10000) as varchar(2)),2) + ':' +
			right('0' + cast(((sc.active_start_time/100)%100) as varchar(2)),2) + ':' +
			right('0' + cast((sc.active_start_time%100) as varchar(2)),2) As 'Start Time'
	,right('0' + cast(floor(sc.active_end_time/10000) as varchar(2)),2) + ':' +
			right('0' + cast(((sc.active_end_time/100)%100) as varchar(2)),2) + ':' +
			right('0' + cast((sc.active_end_time%100) as varchar(2)),2) As 'End Time'
	,substring(cast(sc.active_start_date as varchar(8)),1,4)+'/'+ substring(cast(sc.active_start_date as varchar(8)),5,2)
		+'/'+ substring(cast(sc.active_start_date as varchar(8)),7,2) As 'Start Date'
	/*,substring(cast(sc.active_end_date as varchar(8)),1,4)+'/'+ substring(cast(sc.active_end_date as varchar(8)),5,2)
		+'/'+ substring(cast(sc.active_end_date as varchar(8)),7,2) As 'End Date'*/
	
	--,sc.freq_subday_type
	--,sc.freq_subday_interval
	--,sc.freq_relative_interval
	--,sc.freq_recurrence_factor
	--,sc.enabled as 'SCHED Enabled'   
	/*,right('0' + LTRIM(STR(floor(active_start_time/10000),2,0)),2) + ':' +
		right('0' + LTRIM(STR(((active_start_time/100)%100),2,0)),2) + ':' +
		right('0' + LTRIM(STR(((active_start_time%100)),2,0)),2) As 'Run Time'
	,active_start_date
	,active_start_time
	,floor(active_start_time/10000) 'Hour'
	,((active_start_time/100)%100) 'Minute'
	,((active_start_time%100)) 'Second'	*/
	
	,case notify_level_email
		when 0 then 'Never'
		when 1 then 'When the job succeeds'
		when 2 then 'When the job fails'
		when 3 then 'When the job completes'
		end as 'Email Notification'
	,isnull((select email_address from sysoperators where id = notify_email_operator_id),'') As 'Notify'


from sysjobs j inner join 
sysjobsteps S on s.job_id=j.job_id inner join 
sysjobschedules sc on sc.job_id=j.job_id inner join
master..syslogins sl on sl.sid=j.owner_sid
where sc.enabled =1
order by j.name, s.step_id
