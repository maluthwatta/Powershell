zdba.dbo.p_DBA_HelpDB 'DW_UAT'

declare @i int
declare @sql varchar(100)
select @i = 8
while @i <= 48
begin
	select @sql = 'dbcc shrinkfile(' + Cast (@i as varchar(2)) + ')'
	print @sql
	exec (@sql)
	select @i = @i + 1
end

dbcc shrinkfile(2)