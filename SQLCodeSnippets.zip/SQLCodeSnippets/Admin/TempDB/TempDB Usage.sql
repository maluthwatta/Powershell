
/*

select * from sys.sysprocesses
where open_tran > 0
--where waittime > = 100000
--order by waittime desc
--order by physical_io desc
order by cpu desc

exec zdba.dbo.p_dba_helpdb tempdb

select * from sys.master_files
where database_id = 2

tempdb

alter database tempdb add log file ( name = templog2, filename = 'G:\R5T2_DEVSQL41IN3_LOG02___0130_mG\SQLLog\tempdb_log2.ldf', size = 100mb, filegrowth = 100mb )
alter database tempdb modify file ( name = templog, filegrowth = 100 );

\\csodevsql42ins3\g$\R5T2_DEVSQL41IN3_LOG02___0130_mG

alter database tempdb remove file templog2;

use tempdb

dbcc shrinkfile ( templog, 10000 );



		select
			db_name()
			,name
			,filename 
			,(size*8/1024.0) as _FileSize_MB_
			,((size*8/1024.0))-(fileproperty(name,'SpaceUsed')*8/1024.0) as _FreeSpace_MB_
			,fileproperty(name,'SpaceUsed')*8/1024.0 as _SpaceUsed_MB_
			,FILEGROUP_Name (groupid) as FileGroup
			,case
				when fileproperty(name, 'IsLogFile') = 1 then 'Log' 
				else 'Data'
			end as _FG_Usage_
			,case 
				when FILEGROUPPROPERTY ( FILEGROUP_Name (groupid) , 'IsDefault') = 1 then 'DEFAULT'
				else ''
			end as _Default_FG_ 
			,case 
				when status&0x100000 = 0 then 1024*8 
				else 1 
			end as growthfactor --pages or percent
			,growth
			,maxsize
		from dbo.sysfiles;
 
 

SELECT tdt.database_transaction_log_bytes_reserved,tst.session_id,
       t.[text], [statement] = COALESCE(NULLIF(
         SUBSTRING(
           t.[text],
           r.statement_start_offset / 2,
           CASE WHEN r.statement_end_offset < r.statement_start_offset
             THEN 0
             ELSE( r.statement_end_offset - r.statement_start_offset ) / 2 END
         ), ''
       ), t.[text])
     FROM sys.dm_tran_database_transactions AS tdt
     INNER JOIN sys.dm_tran_session_transactions AS tst
     ON tdt.transaction_id = tst.transaction_id
         LEFT OUTER JOIN sys.dm_exec_requests AS r
         ON tst.session_id = r.session_id
         OUTER APPLY sys.dm_exec_sql_text(r.plan_handle) AS t
     WHERE tdt.database_id = 2;

SELECT database_transaction_log_bytes_reserved,session_id 
  FROM sys.dm_tran_database_transactions AS tdt 
  INNER JOIN sys.dm_tran_session_transactions AS tst 
  ON tdt.transaction_id = tst.transaction_id 
  WHERE database_id = 2;



;WITH task_space_usage AS (
    -- SUM alloc/delloc pages
    SELECT session_id,
           request_id,
           SUM(internal_objects_alloc_page_count) AS alloc_pages,
           SUM(internal_objects_dealloc_page_count) AS dealloc_pages
    FROM sys.dm_db_task_space_usage WITH (NOLOCK)
    WHERE session_id <> @@SPID
    GROUP BY session_id, request_id
)
SELECT TSU.session_id,
       TSU.alloc_pages * 1.0 / 128 AS [internal object MB space],
       TSU.dealloc_pages * 1.0 / 128 AS [internal object dealloc MB space],
       EST.text,
       -- Extract statement from sql text
       ISNULL(
           NULLIF(
               SUBSTRING(
                 EST.text, 
                 ERQ.statement_start_offset / 2, 
                 CASE WHEN ERQ.statement_end_offset < ERQ.statement_start_offset 
                  THEN 0 
                 ELSE( ERQ.statement_end_offset - ERQ.statement_start_offset ) / 2 END
               ), ''
           ), EST.text
       ) AS [statement text],
       EQP.query_plan
FROM task_space_usage AS TSU
--INNER JOIN sys.dm_exec_requests ERQ WITH (NOLOCK)
left outer JOIN sys.dm_exec_requests ERQ WITH (NOLOCK)
    ON  TSU.session_id = ERQ.session_id
    AND TSU.request_id = ERQ.request_id
OUTER APPLY sys.dm_exec_sql_text(ERQ.sql_handle) AS EST
OUTER APPLY sys.dm_exec_query_plan(ERQ.plan_handle) AS EQP
WHERE EST.text IS NOT NULL OR EQP.query_plan IS NOT NULL
ORDER BY 3 DESC;


select * from sys.dm_db_session_space_usage
order by user_objects_alloc_page_count desc


SELECT SUM(unallocated_extent_page_count) AS [free pages], 
(SUM(unallocated_extent_page_count)*1.0/128) AS [free space in MB]
FROM sys.dm_db_file_space_usage;
 

SELECT transaction_id
FROM sys.dm_tran_active_snapshot_database_transactions 
ORDER BY elapsed_time_seconds DESC;
 
SELECT SUM(internal_object_reserved_page_count) AS [internal object pages used],
(SUM(internal_object_reserved_page_count)*1.0/128) AS [internal object space in MB]
FROM sys.dm_db_file_space_usage;

SELECT SUM(user_object_reserved_page_count) AS [user object pages used],
(SUM(user_object_reserved_page_count)*1.0/128) AS [user object space in MB]
FROM sys.dm_db_file_space_usage;
 
SELECT SUM(size)*1.0/128 AS [size in MB]
FROM tempdb.sys.database_files
 

SELECT session_id, 
      SUM(internal_objects_alloc_page_count) AS task_internal_objects_alloc_page_count,
      SUM(internal_objects_dealloc_page_count) AS task_internal_objects_dealloc_page_count 
    FROM sys.dm_db_task_space_usage 
    GROUP BY session_id;

    SELECT R1.session_id,
        R1.internal_objects_alloc_page_count 
        + R2.task_internal_objects_alloc_page_count AS session_internal_objects_alloc_page_count,
        R1.internal_objects_dealloc_page_count 
        + R2.task_internal_objects_dealloc_page_count AS session_internal_objects_dealloc_page_count
    FROM sys.dm_db_session_space_usage AS R1 
    INNER JOIN all_task_usage AS R2 ON R1.session_id = R2.session_id;



SELECT 
        R1.session_id 
,   R1.user_objects_alloc_page_count 
,   R1.user_objects_dealloc_page_count 
,   R1.internal_objects_alloc_page_count 
,   R1.internal_objects_dealloc_page_count  
,   R3.[text]
,       S.[program_name]
,       S.login_name 
,       S.[status]
,       S.cpu_time 
,       S.memory_usage
,       S.total_scheduled_time
,       S.total_elapsed_time 
,       S.last_request_start_time
,       S.last_request_end_time 
,       S.reads
,       S.writes 
,       S.logical_reads
FROM 
        sys.dm_db_task_space_usage AS R1
INNER JOIN
        sys.dm_exec_sessions AS S
ON
        R1.session_id = S.session_id
LEFT OUTER JOIN sys.dm_exec_requests AS R2
        ON R1.session_id = R2.session_id 
OUTER APPLY sys.dm_exec_sql_text(R2.sql_handle) AS R3
WHERE 
        S.is_user_process = 1
        AND 
        ( 
                R1.user_objects_alloc_page_count > 0
                OR R1.user_objects_dealloc_page_count > 0
                OR R1.internal_objects_alloc_page_count > 0
                OR R1.internal_objects_dealloc_page_count > 0
                OR R3.[text] IS NOT NULL
        );


-- what queries are currently using tempdb?
SELECT
	st.dbid AS QueryExecutionContextDBID,
	DB_NAME(st.dbid) AS QueryExecContextDBNAME,
	st.objectid AS ModuleObjectId,
	SUBSTRING(st.TEXT,
	dmv_er.statement_start_offset/2 + 1,
	(CASE WHEN dmv_er.statement_end_offset = -1
		THEN LEN(CONVERT(NVARCHAR(MAX),st.TEXT)) * 2
		ELSE dmv_er.statement_end_offset
	END - dmv_er.statement_start_offset)/2) AS Query_Text,
	dmv_tsu.session_id ,
	dmv_tsu.request_id,
	dmv_tsu.exec_context_id,
	(dmv_tsu.user_objects_alloc_page_count - dmv_tsu.user_objects_dealloc_page_count) AS OutStanding_user_objects_page_counts,
	(dmv_tsu.internal_objects_alloc_page_count - dmv_tsu.internal_objects_dealloc_page_count) AS OutStanding_internal_objects_page_counts,
	dmv_er.start_time,
	dmv_er.command,
	dmv_er.open_transaction_count,
	dmv_er.percent_complete,
	dmv_er.estimated_completion_time,
	dmv_er.cpu_time,
	dmv_er.total_elapsed_time,
	dmv_er.reads,dmv_er.writes,
	dmv_er.logical_reads,
	dmv_er.granted_query_memory,
	dmv_es.HOST_NAME,
	dmv_es.login_name,
	dmv_es.program_name
FROM sys.dm_db_task_space_usage dmv_tsu
	INNER JOIN sys.dm_exec_requests dmv_er
		ON (dmv_tsu.session_id = dmv_er.session_id AND dmv_tsu.request_id = dmv_er.request_id)
	INNER JOIN sys.dm_exec_sessions dmv_es
		ON (dmv_tsu.session_id = dmv_es.session_id)
	CROSS APPLY sys.dm_exec_sql_text(dmv_er.sql_handle) st
WHERE (dmv_tsu.internal_objects_alloc_page_count + dmv_tsu.user_objects_alloc_page_count) > 0
ORDER BY
	(dmv_tsu.user_objects_alloc_page_count - dmv_tsu.user_objects_dealloc_page_count) + (dmv_tsu.internal_objects_alloc_page_count - dmv_tsu.internal_objects_dealloc_page_count) DESC;



*/

