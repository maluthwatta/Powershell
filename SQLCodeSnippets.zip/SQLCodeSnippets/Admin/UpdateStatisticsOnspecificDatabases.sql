

declare @GVdbname sysname
declare @GVdbTable table (GVdbname sysname)
declare @sql varchar(200)
insert into @GVdbTable
select name 
from sys.databases
where name like 'IVP^_M%' escape '^'

while exists (select GVdbname from @GVdbTable)
begin
 select top 1 @GVdbname = GVdbname from @GVdbTable
 select @sql = 'use [' + @GVdbname + '] '
 select @sql = @sql + 'exec sp_msforeachtable @command1 = ''update statistics ?'''
 exec (@sql)
 delete @GVdbTable where GVdbname = @GVdbname
end


