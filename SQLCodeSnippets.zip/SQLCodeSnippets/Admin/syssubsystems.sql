select subsystem, subsystem_dll, agent_exe 
from msdb.dbo.syssubsystems
where subsystem = 'SSIS'



select * from msdb.dbo.syssubsystems