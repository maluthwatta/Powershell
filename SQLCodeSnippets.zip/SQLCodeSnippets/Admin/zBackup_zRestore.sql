
--Backup a database 
exec sp_zbackup_db
  @database      = 'CC_NA_CpyPro_migtest'
 ,@filename1	 = '\\melysqlbkup1\DevDumps\CC\MigrationScripts\16Feb2006_MigrationRun\Manoj.zbak'
 ,@name          = 'CC_Prod_Site_Data'
 --,@init   = 1
 ,@differential  = 0
 ,@stats         = 5
 --,@priority    = 4

--Get the file list names and paths
exec sp_zRestore_filelistonly '<file_path,sysname, file path>.zbak'

--Restore a database
exec dbo.sp_zRestore_db
  @database       = 'CC_dev_migration_Manoj'
 ,@filename1    =  'G:\SQLBackups\CC\Manoj.zbak'
 ,@stats        = 5
 ,@replace  = 1
 ,@recovery = 1
 -- ,@priority     = 4
 ,@logical_file1  = 'CCUK_primary'
 ,@physical_file1 = 'G:\SQLData\CC\CC_DEV_MIGRATION.mdf'
 ,@logical_file2  = 'CCUK_Log'
 ,@physical_file2 = 'f:\sqllog\CC_DEV_MIGRATION.ldf'
 ,@logical_file3  = 'CCUK_SITEDATA1'
 ,@physical_file3 = 'G:\SQLData\CC\CC_DEV_MIGRATION_1.ndf'
 ,@logical_file4  = 'CCUK_SITEDATA1'
 ,@physical_file4 = 'G:\SQLData\CC\CC_DEV_MIGRATION_2.ndf'
 
--Restore using Log

exec dbo.sp_zRestore_Log
  @database       = 'CC_AU_CpyPro_Site_Manoj'
 ,@filename1    =  '\\melysqlbkup1\DevDumps\CC\MigrationScripts\Manoj.zBAK'
 ,@stats        = 5
 ,@stopat         ='Jan 31, 2006 05:08 PM'
 ,@recovery = 1
 -- ,@priority     = 4
 ,@logical_file1  = 'CC_Prod_Site_Data'
 ,@physical_file1 = 'I:\SQLData\CC\CC_AU_CpyPro_Site_v20_NEW.mdf'
 ,@logical_file2  = 'CC_Prod_Site_Log'
 ,@physical_file2 = 'H:\SQLLog\CC_AU_CpyPro_Site_v20_NEW.ldf'


--Get the running processes
select * from master.dbo.sysprocesses where dbid = db_id('IVP_Control_Test30')


--Kill a process
kill 112663

--Get the users
sp_helpuser

 

 



 

 

 

 

 

 
