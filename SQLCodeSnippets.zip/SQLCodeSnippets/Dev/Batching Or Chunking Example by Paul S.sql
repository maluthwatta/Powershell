if object_id ( 'MySchema.p_MyApp_MyProcedure' ) is null
begin
	-- If the procedure doesn't exist, create an empty one with our desired name
	exec ( 'create procedure MySchema.p_MyApp_MyProcedure as begin return end;' );
end;
go

alter procedure MySchema.p_MyApp_MyProcedure
	@MyParam1 varchar(20)	-- Example parameter to make whatever you're doing work
	,@MyParam2 int = 9999	-- Example parameter to make whatever you're doing work
	,@MyParam3 datetime = '1-Jan-1800 00:00:00'	-- Example parameter to make whatever you're doing work
	,@MyRetentionNumberOfDays int = 30	-- Example parameter should we want to purge data older than a retention period
	,@BatchSize bigint = 5000	-- Different plans will be chosen by the optimiser based on the batch size.  You need to find the sweet spot for your workload for the SQL instance on which it is running.
	,@Debug tinyint = 0
		-- @Debug = 0 doesn't print out any progress information.
		-- @Debug = 1 prints out a single list of key variable values for the SP, plus a row of statistics at the end of the SP.
		-- @Debug = 2 includes all from @Debug = 1, plus a row of statistics for each deleted batch.
as
begin

	begin try

		set nocount on;

		declare
			@errorMessage nvarchar(800)
			,@errorNumber int
			,@errorSeverity int
			,@errorState int
			,@errorLine int
			,@errorProcedure nvarchar(255)
			,@TotalRowCount int = 0
			,@MyDateTimeColumnToFilterTheCandidates datetime
			,@ExpectedNbrRows int = 0
			,@ActualNbrRows int = 0
			,@BatchStart bigint = 1
			,@BatchEnd bigint = 0
			,@BatchStartTime datetime2(7)
			,@BatchEndTime datetime2(7)
			,@SPStartTime datetime2(7) = current_timestamp
			,@SPEndTime datetime2(7)
			,@BatchNumber int = 1
			,@PrintText varchar(400) = '';

		set @MyRetentionNumberOfDays = -1 * abs(@MyRetentionNumberOfDays);

		if object_id( 'tempdb..#Candidates' ) is not null
		begin
			drop table #Candidates;
		end;

		create table #Candidates
		(
			MyUniqueColumn int not null	-- Replace this with your unique column(s) that are preferrably used for the clustered index but at the very least make up a unique index
			,RowID bigint not null
			,primary key clustered ( RowID asc )
			,unique ( MyUniqueColumn asc )
		);

		if @Debug >= 1
		begin
			select
				MyParam1 = @MyParam1
				,MyParam2 = @MyParam2
				,MyParam3 = @MyParam3
				,MyRetentionNumberOfDays = @MyRetentionNumberOfDays
				,BatchSize = @BatchSize
				,Debug = @Debug
				,TotalRowCount = @TotalRowCount
				,MyDateTimeColumnToFilterTheCandidates = @MyDateTimeColumnToFilterTheCandidates
				,ExpectedNbrRows = @ExpectedNbrRows
				,ActualNbrRows = @ActualNbrRows
				,BatchStart = @BatchStart
				,BatchEnd = @BatchEnd
				,BatchStartTime = @BatchStartTime
				,BatchEndTime = @BatchEndTime
				,SPStartTime = @SPStartTime
				,SPEndTime = @SPEndTime
				,BatchNumber = @BatchNumber
				,PrintText = @PrintText;
		end;

		set @MyDateTimeColumnToFilterTheCandidates = dateadd( day, @MyRetentionNumberOfDays, current_timestamp );

		-- Get a result set containing the unique column(s) of the candidate rows to be purged
		insert into #Candidates
		(
			MyUniqueColumn
			,RowID
		)
		select
			mttbp.MyUniqueColumn
			,RowID = row_number() over ( order by mttbp.MyUniqueColumn asc )
		from MySchema.MyTableToBePurged as mttbp
		where mttbp.MyDateTimeColumnToFilterTheCandidates < @MyDateTimeColumnToFilterTheCandidates;

		set @ExpectedNbrRows = @@rowcount;

		set @BatchEnd = @BatchStart + @BatchSize - 1;
		while @BatchStart <= @ExpectedNbrRows
		begin
			set @BatchStartTime = current_timestamp;

			with Candidates as
			(
				select top ( @BatchSize )
					c.MyUniqueColumn
				from #Candidates as c
				where c.RowID between @BatchStart and @BatchEnd
				order by c.RowID asc
			)
			delete
			from mttbp
			from Candidates as c
				inner join MySchema.MyTableToBePurged as mttbp
					on mttbp.MyUniqueColumn = c.MyUniqueColumn;

			select
				@ActualNbrRows = @@rowcount
				,@BatchEndTime = current_timestamp;

			set @TotalRowCount = @TotalRowCount + @ActualNbrRows;

			if @Debug >= 2
			begin
				set @PrintText = 'MySchema.MyTableToBePurged | BatchNumber: ' + cast( @BatchNumber as varchar(15) )
					+ ' | BatchStart: ' + cast( @BatchStart as varchar(15) )
					+ ' | BatchEnd: ' + cast( @BatchEnd as varchar(15) )
					+ ' | RowsDeleted: ' + cast( @ActualNbrRows as varchar(15) )
					+ ' | Start: ' + convert( varchar(30), @BatchStartTime, 121 )
					+ ' | End: ' + convert( varchar(30), @BatchEndTime, 121 )
					+ ' | DurationMS: ' + cast( datediff( ms, @BatchStartTime, @BatchEndTime ) as varchar(50) )
					+ ' | TotalRowsDeleted: ' + cast( @TotalRowCount as varchar(15) );

				raiserror( @PrintText, 0, 0 ) with nowait;
			end;

			select
				@BatchStart = @BatchStart + @BatchSize
				,@BatchEnd = @BatchEnd + @BatchSize
				,@BatchNumber += 1;
		end;

		set @SPEndTime = current_timestamp;

		if @Debug >= 1
		begin
			set @PrintText = 'MySchema.p_MyApp_MyProcedure | TotalRowsDeleted: ' + cast( @TotalRowCount as varchar(15) )
				+ ' | Start: ' + convert( varchar(30), @SPStartTime, 121 )
				+ ' | End: ' + convert( varchar(30), @SPEndTime, 121 )
				+ ' | DurationMS: ' + cast( datediff( ms, @SPStartTime, @SPEndTime ) as varchar(50) );

			raiserror( @PrintText, 0, 0 ) with nowait;
		end;

		return 0;

	end try

	begin catch

		select
			@errorNumber = error_number()
			,@errorSeverity = error_severity()
			,@errorState = error_state()
			,@errorLine = error_line()
			,@errorProcedure = isnull(error_procedure(), '-');

		set @errorMessage = N'Error %d, Level %d, state %d, in procedure %s, at line %d, ' +
			'Underlying message: '+ error_message();

		if @@trancount > 0 rollback transaction;

		raiserror
		(
			@errorMessage
			,@errorSeverity
			,1
			,@errorNumber
			,@errorSeverity
			,@errorState
			,@errorProcedure
			,@errorLine
		);

	end catch

end;
go
