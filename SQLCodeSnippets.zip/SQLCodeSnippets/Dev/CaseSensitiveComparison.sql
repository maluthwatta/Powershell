

select convert(varbinary(255), 'answer')
select convert(varbinary(255), 'Answer')




create table t_case (case_name varchar(20))
insert into t_case(case_name) values('April')  
SELECT * FROM t_case  
    WHERE case_name COLLATE Latin1_General_CS_AS = 'April' 