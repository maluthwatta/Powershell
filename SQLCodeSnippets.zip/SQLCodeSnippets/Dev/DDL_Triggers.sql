CREATE TABLE [dbo].[tblDDLEventLog](
[ID] [int] IDENTITY(1,1) NOT NULL,
[EventTime] [datetime] NULL,
[EventType] [varchar](15) NULL,
[ServerName] [varchar](25) NULL,
[DatabaseName] [varchar](25) NULL,
[ObjectType] [varchar](25) NULL,
[ObjectName] [varchar](25) NULL,
[UserName] [varchar](15) NULL,
[CommandText] [varchar](max) NULL,)
Go


CREATE TRIGGER [ddltrg_CREATE_TABLE_LOG] ON DATABASE -- Create Database DDL Trigger
FOR CREATE_TABLE -- Trigger will raise when creating a Table
AS

SET NOCOUNT ON 
DECLARE @xmlEventData XML 

-- Capture the event data that is created 
SET @xmlEventData = eventdata() 

-- Insert information to a EventLog table
INSERT INTO dbo.tblDDLEventLog
(
EventTime,
EventType,
ServerName,
DatabaseName,
ObjectType,
ObjectName,
UserName,
CommandText
)

SELECT REPLACE(CONVERT(VARCHAR(50), @xmlEventData.query('data(/EVENT_INSTANCE/PostTime)')),'T', ' '),
CONVERT(VARCHAR(15), @xmlEventData.query('data(/EVENT_INSTANCE/EventType)')),
CONVERT(VARCHAR(25), @xmlEventData.query('data(/EVENT_INSTANCE/ServerName)')),
CONVERT(VARCHAR(25), @xmlEventData.query('data(/EVENT_INSTANCE/DatabaseName)')),
CONVERT(VARCHAR(25), @xmlEventData.query('data(/EVENT_INSTANCE/ObjectType)')),
CONVERT(VARCHAR(25), @xmlEventData.query('data(/EVENT_INSTANCE/ObjectName)')),
CONVERT(VARCHAR(15), @xmlEventData.query('data(/EVENT_INSTANCE/UserName)')),
CONVERT(VARCHAR(MAX), @xmlEventData.query('data(/EVENT_INSTANCE/TSQLCommand/CommandText)')) 
GO

-- To capture all table events
CREATE TRIGGER [ddltrg_CREATE_TABLE_LOG] ON DATABASE 
FOR DDL_DATABASE_LEVEL_EVENTS 
AS

/* Your code goes here */


-- To disallow tables creation without tbl prefix
CREATE TRIGGER [ddltrg_CheckCreateTable] ON DATABASE
FOR CREATE_TABLE
AS

SET NOCOUNT ON 
DECLARE @xmlEventData XML,
@tableName VARCHAR(50)

SET @xmlEventData = eventdata() 
SET @tableName = CONVERT(VARCHAR(25), @xmlEventData.query('data(/EVENT_INSTANCE/ObjectName)'))

IF LEFT(@tableName, 3) <> 'tbl' 
BEGIN
RAISERROR ( 'You cannot create table name without starting with tbl',
16,- 1 )
ROLLBACK
END 



--Enable/Disable triggers
DISABLE TRIGGER ddltrg_CREATE_TABLE_LOG
ON ALL SERVER
GO

ENABLE TRIGGER ddltrg_CREATE_TABLE_LOG
ON ALL SERVER
GO

--Trigger Execution Order
sp_settriggerorder [ @triggername = ] '[ triggerschema. ] triggername' 
        , [ @order = ] 'value' 
        , [ @stmttype = ] 'statement_type' 
        [ , [ @namespace = ] { 'DATABASE' | 'SERVER' | NULL } ]
        

--Where triggers are saved

--Database level
SELECT *
FROM sys.triggers

SELECT *
FROM sys.trigger_events

--Server level

SELECT *
FROM sys.server_triggers

SELECT *
FROM sys.server_trigger_events

