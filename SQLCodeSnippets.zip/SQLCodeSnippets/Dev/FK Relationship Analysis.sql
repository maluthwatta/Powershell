exec sp_foreign_keys_rowset 'dbo.CGPortfolios'

select * from sys.objects
where type_desc = 'USER_TABLE'
and [name] not like 'DEL_%'
--where [name] Like '%sp_foreign_keys_rowset%'

select [name], [object_id]
from sys.objects

select [name]
from sys.objects
where [object_id] = 


select s1.name, p1.name
from sys.objects s1 
inner join sys.objects p1 on p1.parent_object_id = s1.[object_id]
where p1.type_desc = 'FOREIGN_KEY_CONSTRAINT'
order by p1.name


and [name] not like 'DEL_%'

select * from sys.foreign_keys
order by [name]

--select * from sysforeignkeys sql2000

select * from sys.foreign_key_columns

select o.name as [Table Name], c.name as [Column Name], c.column_id as [Column ID]
from sys.columns c inner join
	sys.objects o on o.object_id = c.object_id
order by o.name


select * from sys.objects
select * from sys.columns
where name='InvestorAccounts'

select distinct constraint_object_id
	,(select [name]
	from sys.objects
	where [object_id] = constraint_object_id)
	,constraint_column_id
    ,parent_object_id
	,(select [name]
	from sys.objects
	where [object_id] = parent_object_id)
	,parent_column_id
    ,referenced_object_id
	,(select [name]
	from sys.objects
	where [object_id] = referenced_object_id)
	,referenced_column_id
from sys.foreign_key_columns

select * from sys.objects
where name = 'InvestorAccounts'

select * from sys.columns
where object_id = 1326731879


select * from sys.objects
where name = 'InvestorCompanyAccounts__FK1'
--1490428354

select * from sys.objects
where name = 'InvestorCompanyAccounts__FK2'
--1474428297

select [name] from sys.objects
where object_id = 2142734786
--1474428297

select * from sys.foreign_key_columns
where constraint_object_id IN (1490428354,1474428297) 


select t.[name] as fk_table_name	
	,pc.[name] as fk_column_name
	,c.[name] as rk_table_name
	,rc.[name] as rk_column_name	
from sys.foreign_key_columns fk inner join
	sys.objects as t on t.object_id = fk.parent_object_id inner join
	sys.objects as c on c.object_id = fk.referenced_object_id inner join	
	sys.columns as pc on pc.object_id = fk.parent_object_id
			and pc.column_id = fk.parent_column_id	inner join
	sys.columns as rc on rc.object_id = fk.referenced_object_id
			and rc.column_id = fk.referenced_column_id	
order by fk_table_name, rk_table_name, fk_column_name, rk_column_name
--where fk.constraint_object_id IN (1490428354,1474428297) 








select fk.[name]
	, fk.object_id 
	,(select [name]
	from sys.objects
	where [object_id] = fk.parent_object_id)
	,fk.referenced_object_id
	,(select [name]
	from sys.objects
	where [object_id] = fk.referenced_object_id)
	, 'DDDD'
	,*
from sys.foreign_keys fk
where name IN ('InvestorCompanyAccounts__FK1', 'InvestorCompanyAccounts__FK2')
order by fk.[name]


/*START RECURSIVE METHODS*/
Use Manoj_Test1;

IF (OBJECT_ID ('dbo.Manoj_SampleOrg', 'U') IS NOT NULL)
  DROP TABLE dbo.Manoj_SampleOrg
GO
CREATE TABLE dbo.Manoj_SampleOrg
 (
   LevelID		INT NOT NULL PRIMARY KEY,
   Position		NVARCHAR(50) NOT NULL,
   ReportingLevelID	INT REFERENCES dbo.Manoj_SampleOrg (LevelID)
 )
GO
-- Insert some sample data into the table based on the structure
-- shown above
INSERT INTO dbo.Manoj_SampleOrg SELECT 1, 'Chief Executive Officer', NULL
INSERT INTO dbo.Manoj_SampleOrg SELECT 2, 'Senior Director - Development', 1
INSERT INTO dbo.Manoj_SampleOrg SELECT 3, 'Senior Director - Finance', 1
INSERT INTO dbo.Manoj_SampleOrg SELECT 4, 'Senior Director - Human Resources', 1
INSERT INTO dbo.Manoj_SampleOrg SELECT 5, 'Product Development Manager', 2
INSERT INTO dbo.Manoj_SampleOrg SELECT 6, 'Project Lead', 5
INSERT INTO dbo.Manoj_SampleOrg SELECT 7, 'QA Lead', 5
INSERT INTO dbo.Manoj_SampleOrg SELECT 8, 'Documentation Lead', 5
INSERT INTO dbo.Manoj_SampleOrg SELECT 9, 'Developers', 6
INSERT INTO dbo.Manoj_SampleOrg SELECT 10, 'Testers', 7
INSERT INTO dbo.Manoj_SampleOrg SELECT 11, 'Writers', 8
INSERT INTO dbo.Manoj_SampleOrg SELECT 12, 'Accountants', 3
INSERT INTO dbo.Manoj_SampleOrg SELECT 13, 'HR Professionals', 4
GO

select * from dbo.Manoj_SampleOrg

WITH SampleOrgChart (Level, Position, ReportingLevel, OrgLevel, SortKey) AS
 (
  -- Create the anchor query. This establishes the starting
  -- point
  SELECT
     a.LevelID, a.Position, a.ReportingLevelID, 0,
     CAST (a.LevelID AS VARBINARY(900))
   FROM dbo.Manoj_SampleOrg a
   WHERE a.Position = 'Product Development Manager'
  UNION ALL
  -- Create the recursive query. This query will be executed
  -- until it returns no more rows
  SELECT
    a.LevelID, a.Position, a.ReportingLevelID, b.OrgLevel+1,
    CAST (b.SortKey + CAST (a.LevelID AS BINARY(4)) AS VARBINARY(900))
   FROM dbo.Manoj_SampleOrg a
     INNER JOIN SampleOrgChart b ON a.ReportingLevelID = b.Level
   WHERE b.OrgLevel < 1
 )
SELECT * FROM SampleOrgChart ORDER BY SortKey


/*END RECURSIVE METHODS */