WITH PK_FK(fk_table_name, fk_column_name, rk_table_name, rk_column_name, depth, sortcol)

AS

( 
  -- anchor member
	select t.[name] as fk_table_name	
		,pc.[name] as fk_column_name
		,c.[name] as rk_table_name
		,rc.[name] as rk_column_name
		,0		
		,CAST(t.[name] AS VARBINARY(900))	
	from sys.foreign_key_columns fk inner join
		sys.objects as t on t.object_id = fk.parent_object_id inner join
		sys.objects as c on c.object_id = fk.referenced_object_id inner join	
		sys.columns as pc on pc.object_id = fk.parent_object_id
			and pc.column_id = fk.parent_column_id	inner join
		sys.columns as rc on rc.object_id = fk.referenced_object_id
			and rc.column_id = fk.referenced_column_id	
	where t.[name] = 'Companies' 

  UNION ALL  

  -- recursive member
   	select t.[name] as fk_table_name	
		,pc.[name] as fk_column_name
		,c.[name] as rk_table_name
		,rc.[name] as rk_column_name	
		,PK_FK.depth+1
		, CAST(sortcol + CAST(t.[name] AS VARBINARY(900)) AS VARBINARY(900))
	from sys.foreign_key_columns fk inner join
		sys.objects as t on t.object_id = fk.parent_object_id inner join
		sys.objects as c on c.object_id = fk.referenced_object_id inner join	
		sys.columns as pc on pc.object_id = fk.parent_object_id
			and pc.column_id = fk.parent_column_id	inner join
		sys.columns as rc on rc.object_id = fk.referenced_object_id
			and rc.column_id = fk.referenced_column_id	inner join 
		PK_FK on PK_FK.rk_table_name = t.[name]

)

-- outer query

SELECT 
	REPLICATE('|         ', depth) + fk_table_name	
	+ '  -  ' + fk_column_name
	+ '  -  ' + rk_table_name
	+ '  -  ' + rk_column_name	
FROM PK_FK
order by sortcol

