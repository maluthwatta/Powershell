/*
	
	Create the SP first
	
	THIS SCRIPTS WILL ONLY DELETE RECORDS IN A TRIGGER DISABLE ENVIRONMENT, SIMPLE CHANGE CAN DO IT IN THE TRIGGER ENABLED ENVIRONMENT AS WELL - SOME WORK FOR YOU!!
	SCRIPTS TO ENABLE AND DISABLE TRIGGERS ATTACHED AS WELL!!

	Set variable in the "second Script"
	Run deletion for the Z_ records first (deleting Z_ table recoerds is a simple change to the scripts.)
	Run the "second Script" to generate the scripts to delete records.Scripts will be in the order of deletion.
Enable disable scripts need "second Script" run first to populate the tables
	
	

*/

---Create SP-----
if exists (select 1 from sysobjects 
           where name = N'p_CheckFKRelations'
           and OBJECTPROPERTY (id, N'ISProcedure') = 1)
   drop procedure dbo.p_CheckFKRelations
go

create procedure p_CheckFKRelations

@tableName nvarchar(200)

as 

set nocount on
Declare @max int ,@count int,@Tablepara nvarchar(200)
declare @rowcount int
set @count=1

if not exists (select 1 from information_schema.tables where table_name='table_list')
Create table table_list 
( 

Seq int identity(1,1),
table_name nvarchar(200),
Ref_table nvarchar(200),
FK_Text nvarchar(2000) default('')

)


Create table #table_list 
( Seq int identity(1,1),
table_name nvarchar(200),
)

insert into #table_list (table_name) select distinct object_name(fkeyid) from sysforeignkeys where rkeyid=object_id(@tableName) order by object_name(fkeyid)
	select @rowcount=@@rowcount

select @max=max(Seq) from #table_list

while (@max >= @count) and (@rowcount>0)
begin
	select @Tablepara=table_name from #table_list where seq=@count
	set @count=@count+1	
	if @rowcount >0
		begin
		exec p_CheckFKRelations @Tablepara	
			
		end
	else
		return 0
End	
insert into table_list (table_name,Ref_table)  select  table_name,@tableName from #table_list T where not exists ( select 1 from table_list L where L.table_name=T.table_name and Ref_table=@tableName)




-----second Script-------

set nocount on

declare @tableName nvarchar(200)
declare @whereclause nvarchar(500)
declare @tableNameAlias nvarchar(10)
 
set @tableName='CompanyCorporateActions'
set @tableNameAlias='CCA'
--set @whereclause='companyProfileID = 100002'
set @whereclause='ConfirmedFlag <> ''' + 'Y' + ''''

--CompanyCorporateActions         
--CompanyProfileInvestmentPlans  
--CompanyProfileMeetings



if  exists (select 1 from information_schema.tables where table_name='table_list')
drop table table_list

exec p_CheckFKRelations @tableName


declare @Maxseq int, @Counter int ,@subSeq int ,@SubCounter int ,@key int,@maxKey int
declare @table_name nvarchar(200),@Reftable_name nvarchar(200),@Alias nvarchar(5),@AliasRef nvarchar(10),@Join nvarchar(500),@preRefTableAlias nvarchar(200)
select @Maxseq=max(seq) from table_list 
--update	table_list set FK_Text = table_name + '->' + Ref_table from table_list where seq=@counter
select @Join=''	
set @Counter=1
while @counter <= @Maxseq
begin 

	select @Join=''	
	select @table_name=table_name,@Reftable_name=Ref_table from table_list where seq=@counter
	select @Alias=left(@table_name,1) + right (@Reftable_name,1) + cast(@counter as nvarchar)

	if @Reftable_name=@tableName 
		select @AliasRef=@tableNameAlias
	else
		select @AliasRef =left(@table_name,1) + right (@Reftable_name,1) + 'REF' + convert(nvarchar(5),@counter )


select @maxkey =max(keyno) from sysforeignkeys where fkeyid=object_id(@table_name) and rkeyid=object_id(@Reftable_name) 
select @key=1
while @maxkey>=@key
begin 
	select @Join = 
	case @key when 1 then
	 ' ' + @Alias + '.' 
	+ col_name( fkeyid,fkey) 
	+ ' = ' + @AliasRef + '.' 
	+  col_name( rkeyid,rkey) 
	--from sysforeignkeys where fkeyid=object_id(@table_name) and rkeyid=object_id(@Reftable_name) and keyno= @key
	else 
	 @Join + ' and  ' + @Alias + '.' 
	+ col_name( fkeyid,fkey) 
	+ ' = ' + @AliasRef + '.' 
	+  col_name( rkeyid,rkey) end
	from sysforeignkeys where fkeyid=object_id(@table_name) and rkeyid=object_id(@Reftable_name) and keyno= @key
	
	set @key=@key+1
end 

	update	table_list set FK_Text=
	case FK_Text when '' then 
		--'Delete ' + table_name + ' From ' + table_name + ' '+ @Alias +  ' inner join ' + Ref_table + ' ' + @AliasRef + ' on '	+ @Join	
		'Delete z_' + table_name + ' From z_' + table_name + ' '+ @Alias +  ' inner join ' + Ref_table + ' ' + @AliasRef + ' on '	+ @Join	 --deletinb
	else
		table_name + ' '+ @Alias + ' inner join ' + Ref_table +  ' ' + @AliasRef +  ' on ' + @Join   end 
	from table_list where seq=@counter

	set @SubCounter=@Maxseq-@counter
		while @SubCounter > 0
			begin 
				if exists (select 1 from table_list where table_name=@Reftable_name and seq > @SubCounter)
					begin
						select @preRefTableAlias =@AliasRef
						select @subSeq=min(SEQ),@table_name=table_name,@Reftable_name=Ref_table from table_list where table_name=@Reftable_name and seq > @SubCounter
								group by SEQ,table_name,Ref_table
							select @Join=''
							if @Reftable_name=@tableName
							select @AliasRef=@tableNameAlias 
							else
							select @AliasRef =left(@Reftable_name,1) + right (@Reftable_name,1) + 'REF' + convert(nvarchar(5),@SubCounter )
							select @Join = ' ' + @preRefTableAlias + '.' +  col_name( fkeyid,fkey) +' = ' + @Aliasref + '.' +  col_name( rkeyid,rkey) 
							from sysforeignkeys where fkeyid=object_id(@table_name) and rkeyid=object_id(@Reftable_name) 

						update	table_list set FK_Text = FK_Text + ' inner join ' +   @Reftable_name +  ' ' + @AliasRef + ' on ' + @Join from table_list where seq=@counter
						set @SubCounter=@Maxseq-@subSeq
					end
				else
					set @SubCounter=@SubCounter-1
			end
	
	set @counter=@counter + 1
end

update table_list set FK_TEXT = FK_Text + ' where ' + @tableNameAlias + '.' + @whereclause
--insert into table_list (table_name,FK_TEXT)  select  @tableName,'Delete from ' + @tableName + '  Where ' + @whereclause
insert into table_list (table_name,FK_TEXT)  select  @tableName,'Delete from Z_' + @tableName + '  Where ' + @whereclause --deleting z_ records
select   FK_Text from table_list





go

go

--Enable Triggers

declare @seq int,@maxseq int
declare @table_name nvarchar(200),@SQl nvarchar(300)
select @maxseq=max(seq) from table_list
set @seq=1
while @maxseq>=@seq
	begin 
		select @table_name=table_Name from table_list where seq =@seq 
		select @SQl = 'Alter table ' + @table_name + ' enable trigger All'	
		print(@SQl)
		select @seq=@seq + 1
	end 


go


print '--Disable Triggers--'

declare @seq int,@maxseq int
declare @table_name nvarchar(200),@SQl nvarchar(300)
select @maxseq=max(seq) from table_list
set @seq=1
while @maxseq>=@seq
	begin 
		select @table_name=table_Name from table_list where seq =@seq 
		select @SQl = 'Alter table ' + @table_name + ' Disable trigger All'	
		print(@SQl)
		select @seq=@seq + 1
	end 







--#########################################
select * from sysforeignkeys