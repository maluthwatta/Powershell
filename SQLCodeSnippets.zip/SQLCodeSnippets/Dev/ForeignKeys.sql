
with CTEforeignKeys (parent_schema, parent_table, parent_column, FK, referenced_schema, referenced_table, referenced_column, Level)
as
(
select schprnt.name as [parent_schema], oprnt.name as [parent_table], colprnt.name as [parent_column], fk.name as [FK]
	,scref.name as [referenced_schema], oref.name as [referenced_table], colref.name as [referenced_column], 0 as Level
from sys.foreign_keys fk 
	inner join sys.objects oprnt on oprnt.object_id = fk.parent_object_id 
	inner join sys.schemas schprnt on schprnt. schema_id = oprnt.schema_id 
	inner join sys.objects oref on oref.object_id = fk.referenced_object_id 
	inner join sys.schemas scref on scref.schema_id = oref.schema_id
	inner join sys.foreign_key_columns fcc on fcc.parent_object_id = oprnt.object_id and fcc.constraint_object_id = fk.object_id
	inner join sys.columns colprnt on colprnt.object_id = oprnt.object_id and colprnt.column_id = fcc.parent_column_id
	inner join sys.columns colref on colref.object_id = oref.object_id and colref.column_id = fcc.referenced_column_id 
where schprnt.name = 'Sales' and oprnt.name = 'Store'

union all

select schprnt.name as [parent_schema], oprnt.name as [parent_table], colprnt.name as [parent_column], fk.name as [FK]
	,scref.name as [referenced_schema], oref.name as [referenced_schema], colref.name as [referenced_column], Level + 1
from sys.foreign_keys fk 
	inner join sys.objects oprnt on oprnt.object_id = fk.parent_object_id 
	inner join sys.schemas schprnt on schprnt. schema_id = oprnt.schema_id 
	inner join sys.objects oref on oref.object_id = fk.referenced_object_id 
	inner join sys.schemas scref on scref.schema_id = oref.schema_id
	inner join sys.foreign_key_columns fcc on fcc.parent_object_id = oprnt.object_id and fcc.constraint_object_id = fk.object_id
	inner join sys.columns colprnt on colprnt.object_id = oprnt.object_id and colprnt.column_id = fcc.parent_column_id
	inner join sys.columns colref on colref.object_id = oref.object_id and colref.column_id = fcc.referenced_column_id 
	inner join CTEforeignKeys cte on cte.referenced_schema = schprnt.name and cte.referenced_table = oprnt.name
where oprnt.name <> oref.name
)

select * from CTEforeignKeys

