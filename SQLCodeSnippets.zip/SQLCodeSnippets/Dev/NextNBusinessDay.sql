Create function dbo.f_getNextBusinessDay(@startDate datetime, @offsetDates int)
Returns datetime
As
Begin
Declare @businessDate datetime
Declare @weeks int

If (@offsetDates < 0)
Begin
	if datepart (dw, @startDate) = 1
		select @startDate = dateadd (d, -1, @startDate)
	select @weeks = (datepart (dw, @startDate) + @offsetDates - 6)/5
End
Else
Begin
	if datepart (dw, @startDate) = 7
		select @startDate = dateadd (d, 1, @startDate)
	select @weeks = (datepart (dw, @startDate) + @offsetDates - 2)/5
End

Select @businessDate = dateadd (d, @offsetDates + (@weeks*2), @startDate)

Return @businessDate
End