
declare @tab table(i int, s varchar(10), val varchar(20))

create table #TFSTest(i int, s varchar(10), val varchar(20))

insert into #TFSTest(i, s, val) values (1, 'A', 'This is 1A')
insert into #TFSTest(i, s, val) values (1, 'B', 'This is 1B')
insert into #TFSTest(i, s, val) values (1, 'C', 'This is 1C')
insert into #TFSTest(i, s, val) values (2, 'A', 'This is 2A')
insert into #TFSTest(i, s, val) values (3, 'A', 'This is 3A')
insert into #TFSTest(i, s, val) values (3, 'C', 'This is 3C')
insert into #TFSTest(i, s, val) values (3, 'F', 'This is 3F')
insert into #TFSTest(i, s, val) values (4, 'B', 'This is 4B')
insert into #TFSTest(i, s, val) values (5, 'A', 'This is 5A')
insert into #TFSTest(i, s, val) values (5, 'C', 'This is 5C')


select distinct s
into #s
from #TFSTest

select * from #TFSTest
select * from #s

select i, s, val 
from #TFSTest inner join #s 

select i
	,[A] as [A]
	,[B] as [B]
	,[C] as [C]
	,[D] as [D]
From (select i, s, val from #TFSTest) o
pivot (max(val) for s in ([A],[B],[C],[D]))p

