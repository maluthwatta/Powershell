Create table dbo.zzIndexPercentage
	(ID int not null,
	CODE varchar(5) not null)

delete from dbo.zzIndexPercentage

select * from dbo.zzIndexPercentage

DECLARE @RandomNumber float
DECLARE @RandomInteger int
DECLARE @MaxValue int
DECLARE @MinValue int
DECLARE @N int
DECLARE @I int
DECLARE @RndString varchar(5)

SET @MaxValue = 90
SET @MinValue = 65
SET @N = 1
SET @I = 800000

WHILE @I<1000000
BEGIN

  SET @RndString = ''
  SET @N = 1
  WHILE @N<6
  BEGIN
   SELECT @RandomNumber = RAND()
   SELECT @RandomInteger = ((@MaxValue + 1) - @MinValue) * @RandomNumber + @MinValue
   SELECT @RndString = @RndString + CHAR(@RandomInteger)
   SELECT @N = @N + 1
  END 
SELECT @I = @I + 1

insert into dbo.zzIndexPercentage(ID, CODE)
values (@I,  @RndString)
END

CREATE NONCLUSTERED INDEX IX_ID
    ON dbo.zzIndexPercentage(ID);
GO

CREATE NONCLUSTERED INDEX IX_CODE
    ON dbo.zzIndexPercentage(CODE);
GO

zzIndexPercentage


Select ID
From dbo.zzIndexPercentage
Where ID between 1 AND 5000000

Where ID >= 1 and ID <=100000

Where ID between 1 AND 100000

sp_helpindex zzIndexPercentage

dbcc show_statistics(zzIndexPercentage,IX_ID)
dbcc show_statistics(zzIndexPercentage,IX_CODE)
IX_ID

Select CODE
From dbo.zzIndexPercentage
Where CODE between 'AAAAA' AND 'ZZZZZ'

DBCC DBREINDEX (zzIndexPercentage, IX_CODE)
DBCC DBREINDEX (zzIndexPercentage, IX_ID)
GO


