/*Use Manoj_Test1;
CREATE TABLE dbo.Manoj_Employees

(

  empid   int         NOT NULL,

  mgrid   int         NULL,

  empname varchar(25) NOT NULL,

  CONSTRAINT PK_Employees PRIMARY KEY(empid),

  CONSTRAINT FK_Employees_mgrid_empid

    FOREIGN KEY(mgrid)

    REFERENCES dbo.Manoj_Employees(empid)

)

CREATE INDEX idx_nci_mgrid ON dbo.Manoj_Employees(mgrid)

 

SET NOCOUNT ON

INSERT INTO dbo.Manoj_Employees VALUES(1 , NULL, 'Nancy')

INSERT INTO dbo.Manoj_Employees VALUES(2 , 1   , 'Andrew')

INSERT INTO dbo.Manoj_Employees VALUES(3 , 1   , 'Janet')

INSERT INTO dbo.Manoj_Employees VALUES(4 , 1   , 'Margaret')

INSERT INTO dbo.Manoj_Employees VALUES(5 , 2   , 'Steven')

INSERT INTO dbo.Manoj_Employees VALUES(6 , 2   , 'Michael')

INSERT INTO dbo.Manoj_Employees VALUES(7 , 3   , 'Robert')

INSERT INTO dbo.Manoj_Employees VALUES(8 , 3   , 'Laura')

INSERT INTO dbo.Manoj_Employees VALUES(9 , 3   , 'Ann')

INSERT INTO dbo.Manoj_Employees VALUES(10, 4   , 'Ina')

INSERT INTO dbo.Manoj_Employees VALUES(11, 7   , 'David')

INSERT INTO dbo.Manoj_Employees VALUES(12, 7   , 'Ron')

INSERT INTO dbo.Manoj_Employees VALUES(13, 7   , 'Dan')

INSERT INTO dbo.Manoj_Employees VALUES(14, 11  , 'James')

*/

Use Manoj_Test1;

--select * from dbo.Manoj_Employees;

WITH EmpCTE(empid, empname, mgrid, depth, sortcol)

AS

( 

  -- anchor member

  SELECT empid, empname, mgrid, 0,

    CAST(empid AS VARBINARY(900))

  FROM dbo.Manoj_Employees

  WHERE empid = 3

 

  UNION ALL

  

  -- recursive member

  SELECT E.empid, E.empname, E.mgrid, M.depth+1,

    CAST(sortcol + CAST(E.empid AS BINARY(4)) AS VARBINARY(900))

  FROM dbo.Manoj_Employees AS E

    JOIN EmpCTE AS M

      ON E.mgrid = M.empid

)

-- outer query

SELECT

  REPLICATE('|         ', depth)

    + '(' + (CAST(empid AS VARCHAR(10))) + ') '

    + empname AS empname

FROM EmpCTE

ORDER BY sortcol


