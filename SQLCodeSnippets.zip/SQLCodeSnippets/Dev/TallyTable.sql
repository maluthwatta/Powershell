--TALLY table examples

--Create the TALLY table

USE TempDB     --DB that everyone has where we can cause no harm    
SET NOCOUNT ON --Supress the auto-display of rowcounts for appearance/speed
DECLARE @StartTime DATETIME    --Timer to measure total duration    
SET @StartTime = GETDATE() --Start the timer

IF OBJECT_ID('dbo.Tally') IS NOT NULL         
DROP TABLE dbo.Tally

SELECT TOP 11000 --equates to more than 30 years of dates        
	IDENTITY(INT,1,1) AS N   
INTO dbo.Tally   
FROM Master.dbo.SysColumns sc1,        
	 Master.dbo.SysColumns sc2
	 
--===== Add a Primary Key to maximize performance  
ALTER TABLE dbo.Tally    
ADD CONSTRAINT PK_Tally_N         
	PRIMARY KEY CLUSTERED (N) WITH FILLFACTOR = 100
	
	
	
--===============================================
--      Display the count from 1 to 10
--      using a Tally table.
--=============================================== 
SELECT N   
FROM dbo.Tally  
WHERE N <= 10  
ORDER BY N

--===== Stepping Through Characters
DECLARE @Parameter VARCHAR(8000)    
SET @Parameter = ',Element01,Element02,Element03,Element04,Element05,'
SELECT N, SUBSTRING(@Parameter,N,1)   
FROM dbo.Tally  
WHERE N <= LEN(@Parameter)  
ORDER BY N
 
--====="Jumping" to Certain Characters
DECLARE @Parameter VARCHAR(8000)    
SET @Parameter = ',Element01,Element02,Element03,Element04,Element05,'
SELECT N, SUBSTRING(@Parameter,N,1)   
FROM dbo.Tally  
WHERE N <= LEN(@Parameter) AND SUBSTRING(@Parameter,N,1) = ','  
ORDER BY N

--===== do the "Split".
DECLARE @Parameter VARCHAR(8000)    
SET @Parameter = 'Element01,Element02,Element03,Element04,Element05'
DECLARE @Elements TABLE
         (Number INT IDENTITY(1,1), --Order it appears in original string
          Value  VARCHAR(8000))

SET @Parameter = ','+@Parameter +','
INSERT INTO @Elements(Value) 
SELECT SUBSTRING(@Parameter,N+1,CHARINDEX(',',@Parameter,N+1)-N-1)   
FROM dbo.Tally  WHERE N < LEN(@Parameter) AND SUBSTRING(@Parameter,N,1) = ',' 
SELECT * FROM @Elements

--=======

SELECT dates.ShippedDate,
        ISNULL(SUM(o.Freight),0) AS TotalFreight   
FROM dbo.Orders o  
RIGHT OUTER JOIN
        (--==== Create all shipped dates between start and end date
        SELECT t.N-1+@DateStart AS ShippedDate           
        FROM dbo.Tally t          
        WHERE t.N-1+@DateStart <= @DateEnd        ) dates     
  ON o.ShippedDate = dates.ShippedDate  
GROUP BY dates.ShippedDate


--===== 
DECLARE @DateStart DATETIMEDECLARE @DateEnd   DATETIME
SELECT @DateStart = '2008-01-01 06:00',        @DateEnd   = DATEADD(yy,5,@DateStart)

--===== Display the shift number and date/times 
SELECT (t.N-1)%3 + 1 AS ShiftNumber,
        DATEADD(hh,8*(t.N-1),@DateStart) AS ShiftStart,
        DATEADD(hh,8*(t.N  ),@DateStart) AS ShiftEnd
FROM dbo.Tally t  
WHERE DATEADD(hh,8*(t.N-1),@DateStart) <= @DateEnd