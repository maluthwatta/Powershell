CREATE TABLE Customers
(
	[CustomerID] [int] IDENTITY(1,1) NOT NULL,
	[CustomerName] [varchar](64) NULL,
	[AddressXML] [xml] NULL
) 

insert into Customers values ('TestCustomer',
'<CustomerAddress Id="1">
  <line1>abc</line1>
  <line2>xyz</line2>
  <line3>123456</line3>
</CustomerAddress>')

insert into Customers values ('Bila',
'<CustomerAddress Id="3">
  <line1>23, Stephan Rd</line1>
  <line2>Bell Park</line2>
  <line3>3886</line3>
</CustomerAddress>')


select * from Customers

SELECT AddressXML.query ('/CustomerAddress[@Id = 3]')  FROM   Customers
SELECT  * FROM Customers WHERE AddressXML.value('(/CustomerAddress/line1)[1]', 'nvarchar(1000)')  ='45 Taldra Dr'
SELECT  * FROM Customers WHERE  AddressXML.exist ('/CustomerAddress[@Id = 1]') = 1

UPDATE Customers SET AddressXML.modify
('insert    <Line4>Country</Line4>
  after (/CustomerAddress/line3)[1]')


SELECT AddressXML.query('.')as nodes
FROM   Customers
CROSS APPLY AddressXML.nodes('/CustomerAddress') as MyNodes(a)
