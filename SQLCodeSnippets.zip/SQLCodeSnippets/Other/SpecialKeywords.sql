Patindex 
/*Returns the starting position of the first occurrence of a pattern in a specified expression, 
or zeros if the pattern is not found, on all valid text and character data types. */

