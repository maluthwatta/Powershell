
--* Create SystemTransaction record *--
DECLARE 
    @v_BusinessDate datetime,
    @v_EffectiveDate datetime,
    @v_DateTimeModified datetime,
    @v_SystemTransactionID decimal(12,0)
        
	EXEC dbo.p_USWCommonStoredProcs;5 @v_BusinessDate OUTPUT, @v_EffectiveDate OUTPUT, @v_DateTimeModified OUTPUT, @v_SystemTransactionID OUTPUT


Update Operators
set UserName='gemmellc-44736', OperatorEnabled='N', DateTimeModified = getdate(), SystemTransactionID =  @v_SystemTransactionID 
where OperatorID=44736 



select * from Operators where OperatorID=44736 

select * from dbo.z_Operators where OperatorID=44736 
z_Operators__PK



	


