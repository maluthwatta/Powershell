$global:CTSRegionFQDN = "oceania.cshare.net"
$global:CTSRubrikServer = "rubrik.oceania.cshare.net"
$global:CTSMaxDataStreams = 8
$global:CTSRubrikOrganization = "Oceania DEV DBA Team" 
$global:CTSRubrikOrganizationId = "Organization:::32e2120e-e9a6-4006-8615-4c21085302ee"

$global:CTSRubrikClusterTestedVersion = "5.2.2-p2-9915"
$global:CTSRubrikApiTestedVersion =  "5.3.0"

[hashtable]$global:CTSPostMigrationOptions = @{}
$CTSPostMigrationOptions.Add("CTSRecoverDBOption", 1)
$CTSPostMigrationOptions.Add("CTSDBCompatibilityLevelOption", 2)
$CTSPostMigrationOptions.Add("CTSUpdateDBUsageOption", 4)
$CTSPostMigrationOptions.Add("CTSCheckDBOption", 8)
$CTSPostMigrationOptions.Add("CTSUpdateDBStatsOption", 16)
