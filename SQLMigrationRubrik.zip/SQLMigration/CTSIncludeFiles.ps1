#Include classes/functions

. .\CTSGlobalVariables.ps1
. .\CTSLogger.ps1
. .\Get-CTSFQDN.ps1
. .\Invoke-CTSValidation.ps1
. .\Export-CTSJsonForRubrikRestore.ps1
. .\Test-CTSFilePath.ps1
. .\Get-CTSTargetFilePaths.ps1
. .\Restore-CTSDatabase.ps1
. .\New-CTSLogShipping.ps1
. .\New-CTSSnapshot.ps1
. .\Get-CTSRubrikStatus.ps1
. .\Set-CTSDBMigrationState.ps1
. .\set-CTSPostMigrationUpgradeDB.ps1
. .\set-CTSPostMigrationUpgradeForDBs.ps1
. .\set-CTSRestrictSourceDBAccess.ps1


# Post restore functions
. .\Connect-CTSRubrikServer.ps1
. .\Invoke-CTSPostMigratedDBValidation
. .\Remove-CTSLogShipping.ps1
. .\Remove-CTSLogShippingForDBs.ps1