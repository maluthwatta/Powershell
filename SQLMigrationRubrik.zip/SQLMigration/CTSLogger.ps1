<#
****************************************************************************************************
Author				:	Manoj Aluthwatta
 Date Written		:	25/05/2021
 Modifications		:	
					:
 Description		:	The purpose of this class is to log entries to file/console
                    :   Some reference from the article below.
                    :   https://pshirwin.wordpress.com/2017/01/04/a-simple-logger-using-powershell-class/
 Usage              :            
                    :
 Dependencies       :   

****************************************************************************************************
#>

Class CTSLogger{
    [string]$LogFileName
    [bool]$Console = $true
    [bool]$WriteToFile = $true
    [bool]$WriteWarningMessage = $false       
    [PSObject[]]$LogMessages

    CTSLogger(){
        $this.WriteToFile = $false
    }

    CTSLogger($FileName){
        $this.LogFileName = $FileName
    }
    
    WriteInformation($MessageData){      
        $this.WriteInformation($MessageData, $null)      
    }

    WriteWarning($MessageData){
        $this.WriteWarningMessage = $true
        $this.WriteInformation($MessageData)
        $this.WriteWarningMessage = $false
    }

    WriteInformation($MessageData, $AdditionalInfo){
        $Date = Get-Date
        $DateStr = $Date.ToString("yyyy/MM/dd HH:mm:ss")          
        $Message = "$DateStr | $MessageData"   
        $this.WriteConcoleOut($Message) 

        #Add to the log
        $LogDetails = [PSCustomObject]@{
            LogTime = $Date
            LogMessage = $MessageData
            AdditionalInfo = $AdditionalInfo
        }
        $this.LogMessages +=  $LogDetails
    }

    WriteHeader($MessageData){
        $Message = "`n"
        $Message += $MessageData + "`n"
        $Message += '-' * $MessageData.Length
        $this.WriteConcoleOut($Message)
    }

    WriteBlankLine(){
        $Message = "`n"
        $this.WriteConcoleOut($Message)
    }

    WriteConcoleOut($Message){
        if($this.WriteToFile){
            $Message | Add-Content $($this.LogFileName)   
        }        
        if($this.Console){
            if ($this.WriteWarningMessage){
                Write-Warning -Message $Message -WarningAction Continue
            }
            else{
                Write-Information -MessageData $Message -InformationAction Continue
            }
        }
    }

    WriteArray($Entries){        
        $Padchars = 25  
        foreach ($row in $Entries) {
            $Message = ""
            $this.WriteConcoleOut($Message)

            foreach ($item in $row.PSObject.Properties) {
                [string]$ItemName = $item.Name
                $ItemName = $ItemName.PadRight($Padchars, " ")
                $FixedString = $ItemName.Substring(0, $Padchars)
                $Message = "$FixedString : $($item.Value)"
                $this.WriteConcoleOut($Message)                
            }
        }  
    }
}



