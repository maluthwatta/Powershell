<#
****************************************************************************************************
 Author				:	Manoj Aluthwatta
 Date Written		:	23/07/2021
 Modifications		:	
					:
 Description		:	The purpose of this script is to connect to Rubrik Server
                    :
 Usage              :            
                    :
 Dependencies       :   
                    :   

****************************************************************************************************
#>

function Connect-CTSRubrikServer {

    param(
        [Parameter(ParameterSetName = 'CredentialFile')]
        [string]$RubrikCredentialFile,
        [Parameter(ParameterSetName = 'Token')]
        [string]$Token
    )

        switch($true){
            {$RubrikCredentialFile} {$RubrikCredential = Import-CliXml -Path $RubrikCredentialFile
                $ConnectRubrik = @{
                    Server = $global:CTSRubrikServer
                    Credential = $RubrikCredential
                    OrganizationID = $global:CTSRubrikOrganizationId
                }
            }
            {$Token} {
                $ConnectRubrik = @{
                    Server = $global:CTSRubrikServer
                    Token = $Token
                    OrganizationID = $global:CTSRubrikOrganizationId
                }
            }
            default {
                Write-Output("Please Log into Rubrik server to get the details")
                $ConnectRubrik = @{
                    Server = $global:CTSRubrikServer
                    Credential = (Get-Credential -Credential (($env:USERDOMAIN) + "\" + ($env:USERNAME)))
                    OrganizationID = $global:CTSRubrikOrganizationId
                }
            }
        }

        return Connect-Rubrik @ConnectRubrik        
}