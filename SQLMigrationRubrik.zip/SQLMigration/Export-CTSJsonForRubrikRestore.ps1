<#
****************************************************************************************************
Author				:	Manoj Aluthwatta
 Date Written	    :	01/06/2021
 Modifications		:	
					:
 Description		:	The purpose of this function is to generates a JSON file for 
                    :   input database details for Rubrik restore process
                    :
 Usage              :            
                    :
 Dependencies       :   

****************************************************************************************************
#>

function Export-CTSJsonForRubrikRestore
{
  <#
      .SYNOPSIS
      Generates a JSON file for input database details for Rubrik restore process

      .DESCRIPTION
      Generates a JSON file for input database details for Rubrik restore process

      .NOTES
      Written by MA
      2021-01-15

      .EXAMPLE
      Export-CTSJsonForRubrikRestore -SourceDB "SourceDB1" `
        -SourceInstance "SourceiInstance1" `
        -TargetDB "TargetDB1" `
        -TargetInstance "CSOVDEVSQL28\Ins1" `
        -FinishRecovery $True `
        -Overwrite $False  
        -RunMode 1`
        
        Run Mode
        0 - Provide basic json structure
        1 - Provide basic json structure + force user to fill in data and log file paths
        2 - Extract all files from the source
      
      .LINK
    
  #>

  [CmdletBinding()]
  Param(
    # CSV file name and path 
    [String]$csvFileName = ".\RestoreList.csv", 
    # json out folder path
    [String]$jsonOutFolderPath = $null
  )
    Begin { 

        #Include classes/functions
        . .\CTSGlobalVariables.ps1
        . .\CTSLogger.ps1
        . .\Get-CTSFQDN.ps1

        if (!(Test-Path $csvFileName -PathType Leaf)){
            throw "csv file not found/invalid."
        }

        $DatabaseListFile = $csvFileName
        
        $RestoreDatabaseList = Import-Csv -Path $DatabaseListFile -Delimiter "|"
        $RestoreDatabaseList| Foreach-Object {
            $_.PSObject.Properties | Foreach-Object {$_.Value = $_.Value.Trim()}  
        }

        #If advanced mode is selected create a Rubrik connection
        $RestoreDatabaseList| Foreach-Object -Process  {if ($_.Mode -eq 2) {               
                import-module Rubrik
                Write-Output "Logging in to Rubrik to get details."

                $SQLRubrikConnection = Connect-Rubrik -Server rubrik.oceania.cshare.net `
                        -Credential (Get-Credential -Credential (($env:USERDOMAIN) + "\" + ($env:USERNAME))) 
            } 
        }
    }

  Process {

    $RestoreListArray = @()

    foreach ($RestoreDatabase in $RestoreDatabaseList) {

        $TargetDataFilePath = ""
        $TargetLogFilePath = ""

        switch($RestoreDatabase.Mode){
            {$_ -in "0", "1"} {
                if ($RestoreDatabase.Mode -eq "1"){
                    $TargetDataFilePath = "ADD DATA FILE PATH"
                    $TargetLogFilePath = "ADD LOG FILE PATH"          
                }
            
                $RestoreDatabaseDetail = [PSCustomObject]@{
                    SourceDatabase =  $RestoreDatabase.SourceDatabase
                    SourceServerInstance = $RestoreDatabase.SourceServerInstance
                    TargetDatabase = $RestoreDatabase.TargetDatabase
                    TargetServerInstance = $RestoreDatabase.TargetServerInstance
                    TargetDataFilePath = $TargetDataFilePath
                    TargetLogFilePath = $TargetLogFilePath
                    OverWrite = $RestoreDatabase.OverWrite
                    FinishRecovery = $RestoreDatabase.FinishRecovery
                }        
            }
            
            #Advanced mode - Add individual file paths
            2{

                #Connect to Rubrik to get details. 
                try{                    
                    $SourceInstanceFQDN = (Get-CTSFQDN -ServerInstance $RestoreDatabase.SourceServerInstance)[0]
                    $dbid = Get-RubrikDatabase -ServerInstance $SourceInstanceFQDN -Database $RestoreDatabase.SourceDatabase -Relic:$false | Get-RubrikDatabase 
                    $RubrikDatabaseFiles = Get-RubrikDatabaseFiles -id $dbid.id -RecoveryDateTime $dbid.latestRecoveryPoint
                }
                catch{
                    throw "Source database is invalid/does not have snapshots"
                }

                $DatabaseFileList = @()
                foreach ($RubrikDatabaseFile in  $RubrikDatabaseFiles) {

                    $FileList = [PSCustomObject]@{
                        logicalName =  $RubrikDatabaseFile.logicalName
                        exportPath = $RubrikDatabaseFile.originalPath
                        newFilename = $RubrikDatabaseFile.originalName
                    }
                    $DatabaseFileList += $FileList                
                }
                
                $RestoreDatabaseDetail = [PSCustomObject]@{
                    SourceDatabase =  $RestoreDatabase.SourceDatabase
                    SourceServerInstance = $RestoreDatabase.SourceServerInstance
                    TargetDatabase = $RestoreDatabase.TargetDatabase
                    TargetServerInstance = $RestoreDatabase.TargetServerInstance
                    targetFilePaths = $DatabaseFileList
                    OverWrite = $RestoreDatabase.OverWrite
                    FinishRecovery = $RestoreDatabase.FinishRecovery
            }
        }        

        } 
        $RestoreListArray += $RestoreDatabaseDetail    
    }

    $MainRestoreJson = [PSCustomObject]@{
        restoreDatabaseList =  $RestoreListArray
    }

    $RunDate = Get-Date  
    $TimeStamp = $RunDate.ToString("yyyyMMddHHmmss")
    $jsonFileName = "RestoreList_$TimeStamp.json"
    $OutFileName = ""

    if ($jsonOutFolderPath){
        if (!($jsonOutFolderPath -match '\\$')){
            $jsonOutFolderPath += "\"
        }
        $OutFileName = $jsonOutFolderPath + $jsonFileName
    }
    else{
        $OutFileName = ".\$jsonFileName" 
    }
    ConvertTo-Json $MainRestoreJson -Depth 100 | Out-File $OutFileName 
    Write-Output "json file has been generated: $OutFileName."
  }
}