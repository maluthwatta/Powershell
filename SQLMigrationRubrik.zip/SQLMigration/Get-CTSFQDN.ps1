<#
****************************************************************************************************
Author				:	Manoj Aluthwatta
 Date Written		:	25/05/2021
 Modifications		:	
					:
 Description		:	The purpose of this script is to add the Fully Qualified Domain Name(FQDN)
                    :   to a server name.
                    :
 Usage              :            
                    :
 Dependencies       :                    

****************************************************************************************************
#>

function Get-CTSFQDN {

    Param([String]$ServerInstance)

    $FQDN = $global:CTSRegionFQDN

    try{    
        # if the FQDN is not supplied for source DB then append it
        if ($ServerInstance.toUpper().IndexOf($FQDN.toUpper()) -lt 0){    
            # Check if an instance is specified then break it and also append the FQDN
            if ($ServerInstance.IndexOf('\') -gt 0){
                $Server, $Instance = $ServerInstance.Split("\")
                $ServerInsWithFQDN = $Server + '.' + $FQDN + "\" + $Instance
                $HostWithFQDN = $Server + '.' + $FQDN
            }
            else {
                $ServerInsWithFQDN = $ServerInstance + '.' + $FQDN
                $HostWithFQDN = $ServerInsWithFQDN
            }
        }
        else {
            $ServerInsWithFQDN = $ServerInstance    
        }    
        return $ServerInsWithFQDN, $HostWithFQDN       
    }
    catch{
        throw $_.Exception.Message     
    }   
}