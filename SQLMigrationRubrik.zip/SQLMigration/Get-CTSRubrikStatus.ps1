<#
****************************************************************************************************
 Author				:	Paul Stickland
 Date Written		:	20210608
 Modifications		:	
					:
 Description		:	This function gets the latest status information for one or more Rubrik
                    :   requests passed in via a custom object array.  Returns a new custom object
                    :   array containing the updated Rubrik request status details.
 Usage              :            
                    :
 Dependencies       :   

****************************************************************************************************
#>

function Get-CTSRubrikStatus {

    Param(
		[PSCustomObject[]]$CTSDBMigrationList
		,[CTSLogger]$CTSLogger
	)

    try{
		[array]$CTSAllRubrikRequestDetails = @()
		[int]$CTSRubrikRequestDurationMS = $null

		# Have any entries been provided in $CTSDBMigrationList?
		if ( ( $CTSDBMigrationList.count ) -eq 0 ) {
			$CTSLogger.WriteInformation("No Rubrik requests supplied for a status check.")
		}
		else {
			$CTSLogger.WriteInformation("Get the status of any outstanding Rubrik requests for each database ...")
		}

		# Get a status update for each currently active Rubrik request
		foreach ( $CTSRubrikRequest in ( $CTSDBMigrationList.Where( { ( ( ( $_.RubrikRequestID ) ) -and ( $_.RubrikRequestStatus -ne 'SUCCEEDED' ) -and ( $_.RubrikRequestStatus -ne 'FAILED' ) ) } ) |
			Select-Object DBRequestID, SourceServerInstance, SourceDatabase, TargetServerInstance, TargetDatabase, RubrikRequestID ) ) {

			$CTSLogger.WriteInformation("Get the status of an outstanding Rubrik request for restoring [$($CTSRubrikRequest.SourceDatabase)] on [$($CTSRubrikRequest.SourceServerInstance)] to [$($CTSRubrikRequest.TargetDatabase)] on [$($CTSRubrikRequest.TargetServerInstance)] ...")

			try {
				# Call Rubrik to get a status update for the current request
				$CTSRubrikRequestDetail = ( Get-RubrikRequest -id ($CTSRubrikRequest.RubrikRequestID) -Type 'mssql' )

				$CTSLogger.WriteInformation("Status obtained of an outstanding Rubrik request for restoring [$($CTSRubrikRequest.SourceDatabase)] on [$($CTSRubrikRequest.SourceServerInstance)] to [$($CTSRubrikRequest.TargetDatabase)] on [$($CTSRubrikRequest.TargetServerInstance)].")

				[int]$CTSRubrikRequestDurationMS = $null

				# Compute the request duration in milliseconds if it has completed
				$CTSLogger.WriteInformation("Check request StartTime and EndTime for restoring [$($CTSRubrikRequest.SourceDatabase)] on [$($CTSRubrikRequest.SourceServerInstance)] to [$($CTSRubrikRequest.TargetDatabase)] on [$($CTSRubrikRequest.TargetServerInstance)].")
				$CTSLogger.WriteInformation("Request StartTime: $(($CTSRubrikRequestDetail).StartTime)")
				$CTSLogger.WriteInformation("Request EndTime: $(($CTSRubrikRequestDetail).EndTime)")

				if ($CTSRubrikRequestDetail.StartTime) {
					$CTSRubrikRequestStartTimeConverted = ([datetime]$CTSRubrikRequestDetail.StartTime)
				}
				else {
					$CTSRubrikRequestStartTimeConverted = $null
				}

				if ($CTSRubrikRequestDetail.EndTime) {
					$CTSRubrikRequestEndTimeConverted = ([datetime]$CTSRubrikRequestDetail.EndTime)
				}
				else {
					$CTSRubrikRequestEndTimeConverted = $null
				}

				if ( ($CTSRubrikRequestStartTimeConverted) -and ($CTSRubrikRequestEndTimeConverted) ) {
					$CTSRubrikRequestDurationMS = ((New-TimeSpan -Start ([datetime]$(($CTSRubrikRequestDetail).StartTime)) -End ([datetime]$($CTSRubrikRequestDetail.EndTime))).TotalMilliseconds)
				}
				else {
					$CTSRubrikRequestDurationMS = $null
				}

				# Add the latest Rubrik request status details to an array
				$CTSAllRubrikRequestDetails += ([PSCustomObject]@{
					RubrikRequestID = ($CTSRubrikRequest.RubrikRequestID)
					DBRequestID = ($CTSRubrikRequest.DBRequestID)
					RubrikRequestStatus = ($CTSRubrikRequestDetail.status)
					RubrikPercentageComplete = ($CTSRubrikRequestDetail.progress)
					RubrikRequestStartTime = ($CTSRubrikRequestStartTimeConverted)
					RubrikRequestEndTime = ($CTSRubrikRequestEndTimeConverted)
					RubrikRequestDurationMS = $CTSRubrikRequestDurationMS
					}
				)

				Clear-Variable CTSRubrikRequestDetail
				Clear-Variable CTSRubrikRequestDurationMS
			}
			catch {
				$CTSAllRubrikRequestDetails += ([PSCustomObject]@{
						RubrikRequestID = ($CTSRubrikRequest.RubrikRequestID)
						DBRequestID = ($CTSRubrikRequest.DBRequestID)
						RubrikRequestStatus = "FAILED"
						RubrikPercentageComplete = $null
						RubrikRequestStartTime = $null
						RubrikRequestEndTime = $null
						RubrikRequestDurationMS = $null
					}
				)

				$CTSLogger.WriteWarning("An error occurred when attempting to get a Rubrik status update for restoring [$($CTSRubrikRequest.SourceDatabase)] on [$($CTSRubrikRequest.SourceServerInstance)] to [$($CTSRubrikRequest.TargetDatabase)] on [$($CTSRubrikRequest.TargetServerInstance)].")
				$CTSLogger.WriteWarning("Error Details:  $ERROR[0]")
			}
		}

		if ( ( ( $CTSDBMigrationList.count ) -gt 0 ) -and ( ( $CTSAllRubrikRequestDetails.count ) -eq 0 ) ){
			$CTSLogger.WriteInformation("No Rubrik requests required an updated status check.")
		}
		elseif ( ( ( $CTSDBMigrationList.count ) -gt 0 ) -and ( ( $CTSAllRubrikRequestDetails.count ) -gt 0 ) ) {
			$CTSLogger.WriteInformation("Active Rubrik requests have been checked for an updated status.")
		}

		# Return the latest Rubrik request status details array
		return $CTSAllRubrikRequestDetails       
    }
    catch{
        #throw $_.Exception.Message     
		$CTSLogger.WriteWarning("An error occurred: $ERROR[0]")
    }
}
