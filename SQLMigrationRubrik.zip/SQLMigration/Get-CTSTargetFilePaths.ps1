<#
****************************************************************************************************
 Author				:	Manoj Aluthwatta
 Date Written		:	25/03/2020
 Modifications		:	
					:
 Description		:	The purpose of this script is to compile the target database file paths
                    :
 Usage              :            
                    :
 Dependencies       :   SourceDbRubrikID, LatestRecoveryPoint, TargetDataFilePath, TargetLogFilePath
                    :   TargetFilePaths, TargetDatabase

****************************************************************************************************
#>

function Get-CTSTargetFilePaths
{
  Param(
    $CTSDBInfo,
    [CTSLogger] $CTSLogger) 

    $TargetDB = $($CTSDBInfo.TargetDatabase)
    $TargetDataFilePathLoc = $($CTSDBInfo.TargetDataFilePath)
    $TargetLogFilePathLoc = $($CTSDBInfo.TargetLogFilePath)
    $RecoveryDateTime = $($CTSDBInfo.LatestRecoveryPoint)
    $SourceRubrikId =$($CTSDBInfo.SourceDbRubrikID)
    $TargetFilePathsOverride = $($CTSDBInfo.TargetFilePaths)
    $CTSLogger.WriteInformation("Started creating target file path array for TargetDB: $TargetDB")

    # if data & log file paths are not provided extract from the server
    if ((!$TargetDataFilePathLoc) -or (!$TargetLogFilePathLoc)){
        $TargetSQLInstance = Get-SqlInstance -ServerInstance $CTSDBInfo.TargetServerInstance                                    
        if (!$TargetDataFilePathLoc){
            $TargetDataFilePathLoc = $TargetSQLInstance.DefaultFile  
            $CTSLogger.WriteInformation("Target data file location extracted: $($TargetDataFilePathLoc)")      
        }
        if (!$TargetLogFilePathLoc) {
            $TargetLogFilePathLoc = $TargetSQLInstance.DefaultLog 
            $CTSLogger.WriteInformation("Target log file location extracted: $($TargetLogFilePathLoc)")
        }
    }

    # Create the target file path array 
    $CTSLogger.WriteInformation("Started getting file list details from Rubrik")

    $TargetFilePaths = @()
    $RubrikDatabaseFiles = Get-RubrikDatabaseFiles -id $SourceRubrikId -RecoveryDateTime $RecoveryDateTime
    $CTSLogger.WriteInformation("Completed getting file list details from Rubrik")

    foreach ($DatabaseFile in $RubrikDatabaseFiles) {
        $LogicalFileName = $DatabaseFile.logicalName
        $FileExtensionExtracted = $DatabaseFile.originalName.split(".")[1]

        switch ($DatabaseFile.FileID){
            1 {
                $FileExtension = "mdf"
                $ExportPath = $TargetDataFilePathLoc
            }
            2 {
                $FileExtension = "ldf"
                $ExportPath = $TargetLogFilePathLoc
            }
            {$_ -gt 2} {
                if ($FileExtensionExtracted -eq "ldf"){
                    $FileExtension = "ldf"
                    $ExportPath = $TargetLogFilePathLoc
                }
                else {
                    $FileExtension = "ndf"
                    $ExportPath = $TargetDataFilePathLoc                       
                }
            }
        }  
        $NewFileName = $TargetDB + "_" + $LogicalFileName + "." + $FileExtension
        $TargetFilePaths += @{logicalName=$LogicalFileName;exportPath=$ExportPath;newFilename=$NewFileName} 
    }

    # Override if TargetDataFilePath is provided
    if ($TargetDataFilePath){
        $TargetFilePaths | ForEach-Object {
            if ($_.newFilename.split(".")[1] -ne "ldf"){
                $_.exportPath = $TargetDataFilePath
            }
        }
    }

    # Override if TargetLogFilePath is provided
    if ($TargetLogFilePath){
        $TargetFilePaths | ForEach-Object {
            if ($_.newFilename.split(".")[1] -eq "ldf"){
                $_.exportPath = $TargetLogFilePath
            }
        }
    }

    # Override if targetFilePaths are provided
    $TargetFilePaths | ForEach-Object {
        $extracted = $_
            $TargetFilePathsOverride | ForEach-Object {
                if ($_.logicalName -eq $extracted.logicalName) {
                    if ($_.exportPath){
                        $extracted.exportPath = $_.exportPath        
                    }
                    if ($_.newFilename){
                        $extracted.newFilename = $_.newFilename
                    } 
                }
            }
        }       
    

    foreach ($TargetFile in $TargetFilePaths) {
        $CTSLogger.WriteInformation("TargetFilePaths: $($TargetFile.logicalName), $($TargetFile.exportPath)$($TargetFile.newFilename)")
    }      
    
    $CTSDBInfo.TargetFilePaths = $TargetFilePaths  
    $CTSLogger.WriteInformation("Completed creating target file path array for TargetDB: $TargetDB")    
    $CTSLogger.WriteInformation("")  

    return $CTSDBInfo
}