#Include the Restore function module
. .\Export-CTSJsonForRubrikRestore.ps1

Export-CTSJsonForRubrikRestore -csvFileName ".\RestoreList.csv" -jsonOutFolderPath "C:\Temp\"