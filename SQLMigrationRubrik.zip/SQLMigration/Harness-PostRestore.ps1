#Include classes/functions
. .\Set-CTSRestoreAndUpgradeMigratedDatabases.ps1

Set-CTSRestoreAndUpgradeMigratedDatabases -CTSPostRestoreDBjsonFile "PostRestoreDbList.json"