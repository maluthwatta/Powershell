#Include classes/functions
. .\Invoke-CTSRubrikRoutines.ps1

Invoke-CTSRubrikRoutines -CTSjsonFile "RestoreList_FULLdbs.json"





