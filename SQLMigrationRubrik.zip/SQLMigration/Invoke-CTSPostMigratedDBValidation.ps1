<#
****************************************************************************************************
 Author				:	Manoj Aluthwatta
 Date Written		:	12/07/2021
 Modifications		:	
					:
 Description		:	Validate the databases and seperates them into two arrays
                    :   1. Log shipping targets
                    :   2. Non log shipping targets 
 Usage              :            
                    :
 Dependencies       :   

****************************************************************************************************
#>

function Invoke-CTSPostMigratedDBValidation {

    Param(
		$CTSDBUpgradeList
		,[CTSLogger]$CTSLogger
	)

    try {

        # Get all database that are current log shipping targets
        $CTSLogger.WriteInformation("Getting the list of all log shipping targets started.")
        $CurrentLogShippingTargets = Get-RubrikLogShipping
        $CTSLogger.WriteInformation("Getting the list of all log shipping targets completed.")

        # Update the UpgradeList if DBs found on Log shipping target    

        $LogShippingDatabases = @()
        $RestoreDatabases = @()

        $CTSDBUpgradeList | ForEach-Object { $DBList = $_
            $CurrentLogShippingTargets | ForEach-Object {
                If ( ($_.secondaryDatabaseName -eq $DBList.TargetDatabase ) -and ($_.location -eq (Get-CTSFQDN -ServerInstance $DBList.TargetServerInstance)[0]) ){
                    if ($($_.status.status) -ne 'OK'){
                        $DBList.ValidationStatus = "ERROR: $($_.status.message)"
                        $CTSLogger.WriteWarning("ERROR: Target Server: $($_.location) Target DB: $($_.secondaryDatabaseName) $($_.status.status) ")
                    }
                    else{
                        $DBList.ValidationStatus = "Log shipping target database found"
                        $CTSLogger.WriteInformation("Log shipping target database found: $($_.secondaryDatabaseName) on instance $($_.location)")
                        $CTSLogger.WriteInformation("Extracting source instance details from rubrik..")
                        $PrimaryDbRubrikDetails = get-rubrikdatabase -id $_.primaryDatabaseId
                        $SourceHost = $PrimaryDbRubrikDetails.rootProperties.rootname 

                        if ($PrimaryDbRubrikDetails.instanceName -ne 'MSSQLSERVER'){
                            $SourceInstance = $SourceHost + "\" + $PrimaryDbRubrikDetails.instanceName
                        }
                        else {
                            $SourceInstance = $SourceHost 
                        }
                        $CTSLogger.WriteInformation("Source database instance name obtained: $SourceInstance")
                    }

                    $LogShippingDBDetail = [PSCustomObject]@{
                        DBRequestDetails = $DBList
                        DBLogShippingDetails =  $_
                        DBSourceInstanceName = $SourceInstance
                    }
                    $LogShippingDatabases += $LogShippingDBDetail                     
                }
            }
        }   

        # Check other databases exist
        $CTSLogger.WriteInformation("Checking if restore databases exist...")

        $RestoreDBs = $CTSDBUpgradeList | Where-object { $null -eq $_.ValidationStatus } 
        
        foreach ($RestoreDB in $RestoreDBs) {
            if ( '' -eq (Invoke-Sqlcmd -Query "SELECT DB_ID('$($RestoreDB.TargetDatabase)') As DBID" -ServerInstance $RestoreDB.TargetServerInstance -Database "Tempdb").DBID )
            {
                $CTSDBUpgradeList[$RestoreDB.DBUpgradeID].ValidationStatus = "ERROR: Target database does NOT exist"
                $CTSLogger.WriteWarning("ERROR: Target database does NOT exist: $($RestoreDB.TargetDatabase) Target Instance: $($RestoreDB.TargetServerInstance)")
            }
            else {
                $CTSDBUpgradeList[$RestoreDB.DBUpgradeID].ValidationStatus = "Target database exist"
                $CTSLogger.WriteInformation("Target database exist: $($RestoreDB.TargetDatabase) Target Instance: $($RestoreDB.TargetServerInstance) ")
                $RestoreDatabases += $RestoreDB 
            }
        }

        # List all validated records
        $ValidatedList = $CTSDBUpgradeList | Where-object { ($_.ValidationStatus -notmatch "ERROR" ) }
        $CTSLogger.WriteHeader("Validated database requests:")
        $CTSLogger.WriteArray($ValidatedList) 

        # If non-validated databases exist report and throw an error
        $ErrorList = $CTSDBUpgradeList | Where-object { ($_.ValidationStatus -Match "ERROR" ) }
        if ($ErrorList){
            $CTSLogger.WriteHeader("Database requests with errors:")
            $CTSLogger.WriteArray($ErrorList)
            throw ("Please rectify validation errors")
        }     
        else {
            #Return the log shipping databases and restore databases as two arrays
            return $LogShippingDatabases, $RestoreDatabases
        }          
    }
    catch {
        throw
    }

}


