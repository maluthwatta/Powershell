<#
****************************************************************************************************
 Author				:	
 Date Written		:	
 Modifications		:	
					:
 Description		:	
                    :
 Usage              :            
                    :
 Dependencies       :   

****************************************************************************************************
#>

function Invoke-CTSRubrikRoutines
{
  Param(
    $CTSjsonFile,
    $CTSLogDir = ".\Logs",
	[int]$CTSMinRubrikCheckLoopDurationSec = 60,
	[int]$CTSMinStatusReportLoopDurationSec = 300
	)
    
    #Include classes/functions
    . .\CTSIncludeFiles.ps1


    #Import modules
    Import-Module -Name Rubrik
    Import-Module -Name SqlServer

    #Create the status log file
    $StatusLogFileDir = $CTSLogDir
    $RunDate = Get-Date  
    $TimeStamp = $RunDate.ToString("yyyyMMddHHmmss")
    $LogFileName = "RubrikRestore_$TimeStamp.log"

    try{
        #Create the directory if it does not exist
        If(!(test-path $StatusLogFileDir))
        {
            Write-Output "Creating $StatusLogFileDir"
            New-Item -ItemType Directory -Force -Path $StatusLogFileDir
        }
        $StatusLogFile = New-Item -Path $StatusLogFileDir -Name $LogFileName -ItemType "file" 
        $CTSLogger = [CTSLogger]::new($StatusLogFile.FullName)    

		$CTSLogger.WriteInformation("Start of database restore / migration process ...")

		[array]$ValidatedDBList = @()
		$CTSRubrikSnapshotHash = @{}
      
		$ValidatedDBList = Invoke-CTSValidation -CTSjsonFile $CTSjsonFile -CTSLogger $CTSLogger     
        
        [int]$CTSNbrDBsToBeProcessed = $ValidatedDBList.Count
		[array]$CTSLatestDBMigrationState = @()

		$CTSLatestDBMigrationState = $ValidatedDBList
		$StartStatusReportLoopTime = Get-Date
       
        while ($CTSNbrDBsToBeProcessed -gt 0) {

            $StartCheckLoopTime = Get-Date

            $CTSRubrikRequestStatus = get-CTSRubrikStatus $CTSLatestDBMigrationState $CTSLogger

            $CTSLatestDBMigrationState, $CTSNbrDBsToBeProcessed = ( set-CTSDBMigrationState $CTSLatestDBMigrationState $CTSRubrikRequestStatus $CTSLogger )
           
            foreach ($ValidatedDB in ( $CTSLatestDBMigrationState.where( { ( $_.CurrentState -in ("AwaitingLogShipping", "AwaitingRestoration", "AwaitingSnapshot") ) -and ( $CTSNbrDBsToBeProcessed -gt 0 ) } ) ) ) {
                try{
                
                    if ( $ValidatedDB.CurrentState -in ( "AwaitingLogShipping", "AwaitingRestoration" ) ){
                        $TargetFilePaths = Get-CTSTargetFilePaths -CTSDBInfo $ValidatedDB -CTSLogger $CTSLogger
                    }

                    switch($ValidatedDB.CurrentState){
                        "AwaitingLogShipping"{                
                            $results = New-CTSLogShipping -CTSDBInfo $TargetFilePaths -CTSLogger $CTSLogger                                    
                        }    
                        "AwaitingRestoration"{
                            $results = Restore-CTSDatabase -CTSDBInfo $TargetFilePaths -CTSLogger $CTSLogger
                        }
                        "AwaitingSnapshot"{

							if ( $CTSRubrikSnapshotHash.ContainsKey("$($ValidatedDB.SourceServerInstance)_$($ValidatedDB.SourceDatabase)") ) {
								$CTSLogger.WriteInformation("Skipping database snapshot request.  Creation of a new Rubrik snapshot has already been requested for [$($ValidatedDB.SourceDatabase)] on $($ValidatedDB.SourceServerInstance) for this restore/migration request.")
								$results = $ValidatedDB
								$results.RubrikRequestID = $CTSRubrikSnapshotHash."$($ValidatedDB.SourceServerInstance)_$($ValidatedDB.SourceDatabase)".RubrikRequestID
								$results.RubrikRequestStatus = $CTSRubrikSnapshotHash."$($ValidatedDB.SourceServerInstance)_$($ValidatedDB.SourceDatabase)".RubrikRequestStatus
								$results.CurrentState = $CTSRubrikSnapshotHash."$($ValidatedDB.SourceServerInstance)_$($ValidatedDB.SourceDatabase)".CurrentState
							}
							else {
								$results = New-CTSSnapshot -CTSDBInfo $ValidatedDB -CTSLogger $CTSLogger

								$CTSRubrikSnapshotHashDetails = @{}
								$CTSRubrikSnapshotHashDetails.Add("RubrikRequestID", $results.RubrikRequestID)
								$CTSRubrikSnapshotHashDetails.Add("RubrikRequestStatus", $results.RubrikRequestStatus)
								$CTSRubrikSnapshotHashDetails.Add("CurrentState", $results.CurrentState)

								$CTSRubrikSnapshotHash.Add("$($ValidatedDB.SourceServerInstance)_$($ValidatedDB.SourceDatabase)", $CTSRubrikSnapshotHashDetails)
							}

						}
                    }

                    $CTSLatestDBMigrationState[$ValidatedDB.DBRequestID].RubrikRequestID = $results.RubrikRequestID
                    $CTSLatestDBMigrationState[$ValidatedDB.DBRequestID].RubrikRequestStatus = $results.RubrikRequestStatus
                    $CTSLatestDBMigrationState[$ValidatedDB.DBRequestID].CurrentState = $results.CurrentState

                }
                catch{
                    $CTSLogger.WriteWarning("Error occurred for migrating [$($ValidatedDB.SourceDatabase)] on $($ValidatedDB.SourceServerInstance) to [$($ValidatedDB.TargetDatabase)] on $($ValidatedDB.TargetServerInstance).")
                    $CTSLogger.WriteWarning("Error Details:  $ERROR[0]")

                    switch($ValidatedDB.CurrentState){
                        "AwaitingLogShipping"{                
                            $CTSLatestDBMigrationState[$ValidatedDB.DBRequestID].CurrentState =  "LogShippingFailed"                                   
                        }    
                        "AwaitingRestoration"{
                            $CTSLatestDBMigrationState[$ValidatedDB.DBRequestID].CurrentState =  "RestoreFailed" 
                        }
                        "AwaitingSnapshot"{
                            $CTSLatestDBMigrationState[$ValidatedDB.DBRequestID].CurrentState =  "SnapshotFailed" 
                        }
                    }                    
                }       
            }
        
			#Is it time to report the current status of all requests based on the minimim reporting duration parameter?  If so, do so.
			$EndStatusReportLoopTime = Get-Date
            $ActualStatusReportLoopTime = NEW-TIMESPAN $StartStatusReportLoopTime $EndStatusReportLoopTime
            [int]$StatusReportLoopTimeDiff = $CTSMinStatusReportLoopDurationSec - $ActualStatusReportLoopTime.TotalSeconds

			if ( ( $StatusReportLoopTimeDiff -le 0) -or ($CTSNbrDBsToBeProcessed -eq 0) ) {
				$CTSLogger.WriteBlankLine()
				$CTSLogger.WriteInformation("Current request status summary:")
				$CTSLogString = "-" * 234
				$CTSLogger.WriteInformation("$CTSLogString")
				$CTSLogString = ("{0,11} {1,-25} {2,-50} {3,-25} {4,-50} {5, -22} {6, -20} {7, 24}" -f "DBRequestID", "SourceServerInstance", "SourceDatabase", "TargetServerInstance", "TargetDatabase", "CurrentState", "RubrikRequestStatus", "RubrikPercentageComplete")
				$CTSLogger.WriteInformation("$CTSLogString")
				$CTSLogString = "-" * 234
				$CTSLogger.WriteInformation("$CTSLogString")

				foreach ($CTSDBMigrationState in $CTSLatestDBMigrationState) {
					$CTSLogString = ("{0,11} {1,-25} {2,-50} {3,-25} {4,-50} {5, -22} {6, -20} {7, 24}" -f $CTSDBMigrationState.DBRequestID, $CTSDBMigrationState.SourceServerInstance, $CTSDBMigrationState.SourceDatabase, $CTSDBMigrationState.TargetServerInstance, $CTSDBMigrationState.TargetDatabase, $CTSDBMigrationState.CurrentState, $CTSDBMigrationState.RubrikRequestStatus, $CTSDBMigrationState.RubrikPercentageComplete)
					$CTSLogger.WriteInformation("$CTSLogString")
				}

				$CTSLogString = "-" * 234
				$CTSLogger.WriteInformation("$CTSLogString")
				$CTSLogger.WriteBlankLine()

				$CTSLogString = $null
				$EndStatusReportLoopTime = $null
				$StartStatusReportLoopTime = Get-Date
			}

			#Has enough time elapsed since the previous Rubrik check compared to the supplied minimum duration?  If not, wait a bit so we don't overload Rubrik with requests.
			$EndCheckLoopTime = Get-Date    
            $ActualLoopTime = NEW-TIMESPAN $StartCheckLoopTime $EndCheckLoopTime
            [int]$LoopTimeDiff = $CTSMinRubrikCheckLoopDurationSec - $ActualLoopTime.TotalSeconds
            if ( ($LoopTimeDiff -gt 0) -and ($CTSNbrDBsToBeProcessed -gt 0) ) {
                    $CTSLogger.WriteInformation("Waiting for $LoopTimeDiff seconds due to the $CTSMinRubrikCheckLoopDurationSec second minimum duration Rubrik status check loop threshold ...")
                    Start-Sleep -s $LoopTimeDiff
                    $CTSLogger.WriteInformation("Wait completed.")
            }

            $StartCheckLoopTime = $null
            $EndCheckLoopTime = $null
            $LoopTimeDiff = $null
            $ActualLoopTime = $null
      	}

        $CTSLogger.WriteInformation("All database requests have now been processed with success or failure.")
        $CTSLogger.WriteInformation("End of database restore / migration process.")
}
catch{
        $CTSLogger.WriteWarning("An error occurred: $_")
    }
}

