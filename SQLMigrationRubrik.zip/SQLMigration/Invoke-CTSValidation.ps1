<#
****************************************************************************************************
 Author				:	Manoj Aluthwatta
 Date Written		:	25/05/2021
 Modifications		:	
					:
 Description		:	The purpose of this script is to validate the database details
                    :
 Usage              :            
                    :
 Dependencies       :                    

****************************************************************************************************
#>

function Invoke-CTSValidation {

    Param([String]$CTSjsonFile,
    [CTSLogger] $CTSlogger)   

    $DatabaseListFile = $CTSjsonFile

    try{
        $jsonDatabaseList = Get-Content $DatabaseListFile | ConvertFrom-Json
    }
    Catch{
        $CTSLogger.WriteInformation("json file not found/invalid.")
        throw "json file not found/invalid."
    }

    $CTSLogger.WriteInformation("Connecting to Rubrik...")
    $SQLRubrikConnection = Connect-CTSRubrikServer -RubrikCredentialFile $null
    $CTSLogger.WriteInformation("Connected to Rubrik")
  
 
    If (!$SQLRubrikConnection){
        $CTSLogger.WriteInformation("Could not connect to Rubrik cluster")
        throw "Could not connect to Rubrik cluster"
    }

    $DatabaseList = $jsonDatabaseList.restoreDatabaseList

    $SourceInstanceDetails = @{}
    $TargetInstanceDetails = @{}
    
    $DbListRefined = @()  
     
    #Verify Rubrik versions
    $RubrikClusterTestedVersion = $global:CTSRubrikClusterTestedVersion
    $RubrikApiTestedVersion =  $global:CTSRubrikApiTestedVersion

    $RubrikClusterCurrentVersion = (Get-RubrikVersion).version
    $RubrikCurrentApiInfo = Get-Module Rubrik 
    $RubrikApiCurrentVersion =  $RubrikCurrentApiInfo.Version.Major.ToString() + "." +   
        $RubrikCurrentApiInfo.Version.Minor.ToString() + "." + $RubrikCurrentApiInfo.Version.Build.ToString()
    
    $CTSLogger.WriteInformation("Rubrik cluster current version: $RubrikClusterCurrentVersion")
    $CTSLogger.WriteInformation("Rubrik API local version: $RubrikApiCurrentVersion")
    $CTSLogger.WriteInformation("Rubrik cluster version at test time: $RubrikClusterTestedVersion")
    $CTSLogger.WriteInformation("Rubrik API version at test time: $RubrikApiTestedVersion")    
    
    if ($RubrikClusterCurrentVersion -ne $RubrikClusterTestedVersion){ 
        $CTSLogger.WriteWarning("Rubrik cluster version tested is different to current version. Functionality may be affected")
    }
    
    if ($RubrikApiCurrentVersion -ne $RubrikApiTestedVersion){
        $CTSLogger.WriteWarning("Rubrik API version tested is different to current version. Functionality may be affected") 
    }
    
    #Retrieve all server instances from Rubrik
    $CTSLogger.WriteInformation("Started getting instance details from Rubrik")    
    $RubrikAllServerInstances = Get-RubrikSQLInstance
    
    $CTSLogger.WriteInformation("Completed getting instance details from Rubrik")
    
    #$ValidationServerStart = $(Get-Date)
    $CTSLogger.WriteInformation("Started Server validation")    
    $SourceInstances = $DatabaseList.sourceServerInstance | Sort-Object | Get-Unique
    
    foreach ($SourceInstance in $SourceInstances) {  
        $SourceInstanceFqdn = (Get-CTSFQDN -ServerInstance $SourceInstance)[0]
    
        $SourceRubrikInsFQDN = ""
        $SourceRubrikIns = $null
    
        #Loop through all the intances and validate
        foreach ($RubrikInstance in $RubrikAllServerInstances){
            switch ($RubrikInstance.rootProperties.rootType)
            {
                "Host"{
                    $SourceRubrikInsFQDN = $RubrikInstance.rootProperties.rootName
                }
                "WindowsCluster"{
                    $SourceRubrikInsFQDN = $RubrikInstance.rootProperties.rootName + "." + $global:CTSRegionFQDN
                }
            }
            if  ($RubrikInstance.name -ne "MSSQLSERVER") {
                $SourceRubrikInsFQDN = $SourceRubrikInsFQDN + "\" + $RubrikInstance.name
            }
    
            if ($SourceRubrikInsFQDN -eq $SourceInstanceFqdn){
                $SourceRubrikIns = $RubrikInstance
                break
            }
        }
    
        if ($SourceRubrikIns){
            $SourceRubrikInsID = $SourceRubrikIns.id
        }
        else {
            $SourceRubrikInsID = $null
            $CTSLogger.WriteWarning("Error validating source server instance $SourceInstance")
        }
        $SourceInstanceDetails.Add($SourceInstance, $SourceRubrikInsID)
    }
    
    #Get the unique target instances
    $TargetInstances = $DatabaseList.targetServerInstance | Sort-Object $_.targetServerInstance  -Unique | Select-Object $_.targetServerInstance
    
    foreach ($TargetInstance in $TargetInstances) {  
        
        $TargetInstanceFqdn = (Get-CTSFQDN -ServerInstance $TargetInstance)[0]
    
        $TargetRubrikInsFQDN = ""
        $TargetRubrikIns = $null
    
        #Loop through all the intances and validate
        foreach ($RubrikInstance in $RubrikAllServerInstances){
            switch ($RubrikInstance.rootProperties.rootType)
            {
                "Host"{
                    $TargetRubrikInsFQDN = $RubrikInstance.rootProperties.rootName
                }
                "WindowsCluster"{
                    $TargetRubrikInsFQDN = $RubrikInstance.rootProperties.rootName + "." + $global:CTSRegionFQDN
                }
            }
            if  ($RubrikInstance.name -ne "MSSQLSERVER") {
                $TargetRubrikInsFQDN = $TargetRubrikInsFQDN + "\" + $RubrikInstance.name
            }
    
            if ($TargetRubrikInsFQDN -eq $TargetInstanceFqdn){
                $TargetRubrikIns = $RubrikInstance
                break
            }
        }    
    
        if ($TargetRubrikIns){
            $TargetRubrikInsID = $TargetRubrikIns.id
        }
        else {
            $TargetRubrikInsID = $null
            $CTSLogger.WriteWarning("Error validating target server instance $TargetInstance")
        }
        $TargetInstanceDetails.Add($TargetInstance, $TargetRubrikInsID) 
    }
    
    #$ValidationServerEnd = $(Get-Date)
    #$timeServerValidation = NEW-TIMESPAN $ValidationServerStart $ValidationServerEnd
    #$totalServerDuration = $timeServerValidation.Seconds
    
    $CTSLogger.WriteInformation("Completed Server validation")
    
    #$ValidationDatabaseStart = Get-Date
    $CTSLogger.WriteInformation("Extracting database details started")
    
    #Filter the verified source instances
    $VerifiedSourceInstances = $SourceInstanceDetails.GetEnumerator() | Where-Object {$null -ne $_.Value}
    
    #Source instance database verification
    $VerifiedSourceInstanceDbList = @()
    
    foreach ($VerifiedSourceInstance in $VerifiedSourceInstances){
        $CTSLogger.WriteInformation("Started extracting Rubrik database details for $($VerifiedSourceInstance.Key)")    
        $VerifiedSourceInstanceDbList += Get-RubrikDatabase -InstanceID $VerifiedSourceInstance.Value -Relic:$false  `
                | Select-Object name, id, recoveryModel, effectiveSlaDomainName, isInAvailabilityGroup, @{l="ServerInstance";e={$VerifiedSourceInstance.Key}}         
        $CTSLogger.WriteInformation("Completed extracting Rubrik database details for $($VerifiedSourceInstance.Key)")
    }
    
    #Filter the verified target instances
    $VerifiedTargetInstances = $TargetInstanceDetails.GetEnumerator() | Where-Object {$null -ne $_.Value}
    
    #Target instance database verification
    $VerifiedTargetInstanceDbList = @()
    
    #If the instance databases already retrieved (in source instance) copy to target instance db's
    foreach ($VerifiedTargetInstance in $VerifiedTargetInstances){
        if ($SourceInstanceDetails.ContainsKey($VerifiedTargetInstance.Name)){
            $VerifiedTargetInstanceDbList += $VerifiedSourceInstanceDbList | Where-Object {$_.ServerInstance -eq $VerifiedTargetInstance.Name} 
        }
        else {    
            $CTSLogger.WriteInformation("Started extracting Rubrik database details for $($VerifiedTargetInstance.Key)")    
            $VerifiedTargetInstanceDbList += Get-RubrikDatabase -InstanceID $VerifiedTargetInstance.Value -Relic:$false | 
                Select-Object name, id, @{l="ServerInstance";e={$VerifiedTargetInstance.Key}}     
            $CTSLogger.WriteInformation("Completed extracting Rubrik database details for $($VerifiedTargetInstance.Key)")
        }
    }
    
    #$ValidationDatabaseEnd = Get-Date
    #$timeDbValidation = NEW-TIMESPAN $ValidationDatabaseStart $ValidationDatabaseEnd
    
    #$totalDbDuration = $timeDbValidation.Seconds
    
    $CTSLogger.WriteInformation("Extracting database details completed")

    [int]$RowID = 0
    
    foreach ($database in $DatabaseList){
        # Check Source DB's
        $RubrikSourceDBID = $null
        $LatestRecoveryPoint = $null
        $RecoveryModel = $null
        $CurrentSLA = $null        

        foreach ($RubrikSourceDB in $VerifiedSourceInstanceDbList){
            if (($database.sourceDatabase -eq $RubrikSourceDB.name) -and ($database.sourceServerInstance -eq $RubrikSourceDB.ServerInstance)){
                $RubrikSourceDBID = $RubrikSourceDB.id
                if (($RubrikSourceDB.recoveryModel -eq "FULL") -or ($RubrikSourceDB.isInAvailabilityGroup)) {                    
                    $CTSLogger.WriteInformation("Started extracting latest recovey point for $($RubrikSourceDB.name)") 
                    $LatestRecoveryPoint = Get-RubrikDatabase -id $RubrikSourceDB.id -Relic:$false | 
                            Get-RubrikDatabase | Select-Object latestRecoveryPoint
                    $CTSLogger.WriteInformation("Completed extracting latest recovey point for $($RubrikSourceDB.name)") 
                    if ($RubrikSourceDB.recoveryModel -eq "FULL"){
                        $RecoveryModel = "FULL"
                    }
                    else{
                        $RecoveryModel = "AG"
                    }

                }
                else{
                    $RecoveryModel = $RubrikSourceDB.recoveryModel
                }

                
                $CurrentSLA = $RubrikSourceDB.effectiveSlaDomainName
                break
            }
        }
    
        # Check Target DB's
        $RubrikTargetDBID = $null
        foreach ($RubrikTargetDB in $VerifiedTargetInstanceDbList){
            if (($database.targetDatabase -eq $RubrikTargetDB.name) -and ($database.targetServerInstance -eq $RubrikTargetDB.ServerInstance)){
                $RubrikTargetDBID = $RubrikTargetDB.id
                break
            }
        }
    
        $DatabaseDetail = [PSCustomObject]@{
            DBRequestID = $RowID
            SourceDatabase =  $database.sourceDatabase
            SourceServerInstance = $database.sourceServerInstance
            TargetDatabase = $database.targetDatabase
            TargetServerInstance = $database.targetServerInstance
            SourceInsRubrikID = $SourceInstanceDetails.Get_Item($database.sourceServerInstance)        
            TargetInsRubrikID = $TargetInstanceDetails.Get_Item($database.targetServerInstance)
            SourceDbRubrikID = $RubrikSourceDBID
            TargetDbRubrikID = $RubrikTargetDBID
            LatestRecoveryPoint = $LatestRecoveryPoint.latestRecoveryPoint
            RecoveryModel = $RecoveryModel
            CurrentSLA = $CurrentSLA
            TargetDataFilePath = $database.targetDataFilePath
            TargetLogFilePath = $database.targetLogFilePath
            TargetFilePaths = $database.targetFilePaths
            OverWrite = $database.Overwrite
            FinishRecovery = $database.finishRecovery     
            RestrictAccessToSimpleModeSourceDBs = $database.RestrictAccessToSimpleModeSourceDBs
            ValidationStatus = @()
            CurrentState = "AwaitingVerification"
            RubrikRequestID = $null
            RubrikRequestStatus = $null
            RubrikPercentageComplete = $null
            RubrikRequestStartTime = $null
            RubrikRequestEndTime = $null
        }    
        $DbListRefined += $DatabaseDetail
        $RowID ++
    }

    $CTSLogger.WriteInformation("Started running validation against extracted information")

    # Validation    
    $DbListRefined | ForEach-Object {  $OuterList = $_        
        #Source Instance Validation
        If (!$OuterList.SourceInsRubrikID) {$OuterList.ValidationStatus +="Invalid source server instance name"}
        #Source Database Validation
        If (!$OuterList.SourceDbRubrikID) {$OuterList.ValidationStatus +="Invalid source database name" }
        #Target Instance Validation
        If (!$OuterList.TargetInsRubrikID) {$OuterList.ValidationStatus +="Invalid target server instance name"}
        #Target Database already exists and overwrite is not specified
        If ($OuterList.TargetDbRubrikID -and $OuterList.OverWrite -ne 1) {$OuterList.ValidationStatus +="Target database already exist and overwrite flag is not set to 1"}
        #For full recovery databases bakcups need to be available
        If (($OuterList.RecoveryModel -eq "FULL") -and !$OuterList.LatestRecoveryPoint) {$OuterList.ValidationStatus +="Backups unavailable for this database"}   
        #Overwrite flag validation Validation
        If (!($OuterList.OverWrite -eq 0 -or $OuterList.OverWrite -eq 1 )) {$OuterList.ValidationStatus +="Invalid OverWrite Flag"}            
        #Overwrite flag validation Validation
        If (!($OuterList.FinishRecovery -eq 0 -or $OuterList.FinishRecovery -eq 1 )) {$OuterList.ValidationStatus +="Invalid FinishRecovery Flag"}                    
        #If target data file path is provided check the existence
        If ( ($OuterList.TargetDataFilePath) -and (!(Test-CTSFilePath -ServerInstanceName $OuterList.TargetServerInstance -FilePath $OuterList.TargetDataFilePath)))  
            {$OuterList.ValidationStatus +="TargetDataFilePath does not exist"}              
        #If target log file path is provided check the existence
        If ( ($OuterList.TargetLogFilePath) -and (!(Test-CTSFilePath -ServerInstanceName $OuterList.TargetServerInstance -FilePath $OuterList.TargetLogFilePath)))  
            {$OuterList.ValidationStatus +="TargetLogFilePath does not exist"}               

        #If target file paths array provided check the path existence
        If ($OuterList.TargetFilePaths){ 
            $OuterList.TargetFilePaths | ForEach-Object { 
                if(! (Test-CTSFilePath -ServerInstanceName $OuterList.TargetServerInstance -FilePath $_.exportPath)) {
                    $OuterList.ValidationStatus +="exportPath $($_.exportPath) does not exist"
                }
            }
        } 
    } 

    # Target database needs to be unique
    $DbListRefined | Group-Object -Property TargetServerInstance, TargetDatabase | Where-Object {$_.Count -gt 1} | 
        Foreach-Object{$_.group | Foreach-Object{$_.ValidationStatus +="Target database is not unique"}}      

    # If doing a log shipping and the target database already exists then do a refresh host and check again. 
    $HostsToRefresh =  $DbListRefined | Where-Object {(($_.RecoveryModel -eq "FULL") -or ($_.RecoveryModel -eq "AG")) -and ($_.TargetDbRubrikID)} | Select-Object TargetServerInstance, TargetInsRubrikID  -Unique
    if ($HostsToRefresh){

        $RefreshedDatabases = @()
        $CTSLogger.WriteInformation("Log shipping target database(s) exist. Refreshing the host(s)")
        foreach ($HostName in $HostsToRefresh) {
            $HostNameFQDN = $((Get-CTSFQDN $HostName.TargetServerInstance)[1])
            $CTSLogger.WriteInformation("Refreshing Rubrik Host $HostNameFQDN started")
            New-RubrikHost -Name $HostNameFQDN  | Out-Null
            $CTSLogger.WriteInformation("Refreshing Rubrik Host $HostNameFQDN completed")
            $CTSLogger.WriteInformation("Getting database list for $($HostName.TargetServerInstance) started")
            $RefreshedDatabases += Get-RubrikDatabase -InstanceID $HostName.TargetInsRubrikID -Relic:$false
            $CTSLogger.WriteInformation("Getting database list for $($HostName.TargetServerInstance) completed")            
        }
        
        $DbListToVerify = $DbListRefined | Where-Object {(($_.RecoveryModel -eq "FULL") -or ($_.RecoveryModel -eq "AG")) -and ($_.TargetDbRubrikID)}
        foreach ($DbToVerify in $DbListToVerify) {
            $CTSLogger.WriteInformation("Checking whether destination database $($DbToVerify.TargetDatabase) exists after the refresh ")

            if ($($DbToVerify.TargetDbRubrikID) -in $RefreshedDatabases.ID){
                $DbListRefined[$($DbToVerify.DBRequestID)].ValidationStatus +=  "Log shipping target(s) already exist"
            }
            else {
                $CTSLogger.WriteInformation("Destination database $($DbToVerify.TargetDatabase) does not exist anymore. Setting TargetDbRubrikID to null")
                $DbListRefined[$($DbToVerify.DBRequestID)].TargetDbRubrikID = $null                
            }
        }
    }
    

    $DbListRefined | ForEach-Object {  if ($_.ValidationStatus){$_.CurrentState = "VerificationFailed"} else {$_.CurrentState = "VerificationPassed"}}

    $CTSLogger.WriteInformation("Completed running validation against extracted information")
    $CTSLogger.WriteInformation("Completed Validation")    
    
    $DBListWithErrors = $DbListRefined | Where-Object {($_.ValidationStatus).count -ne 0}    
    if ($DBListWithErrors){
        $CTSLogger.WriteHeader("Database requests with errors:")
        $CTSLogger.WriteArray($DBListWithErrors)   
    } 
    
    $DBListWithNoErrors = $DbListRefined | Where-Object {($_.ValidationStatus).count -eq 0}   
    if ($DBListWithNoErrors){
        $CTSLogger.WriteHeader("Database requests validated successfully:")
        $CTSLogger.WriteArray($DBListWithNoErrors)   
    }
       
    $CTSLogger.WriteBlankLine()

    if ($DBListWithErrors){
        throw "Validation errors reported. Please rectify and run again"
    }
    else{
        $CTSLogger.WriteInformation("Validation completed with no errors. Continuing with next steps.")
        $CTSLogger.WriteBlankLine()
        return $DbListRefined
    }
}