#Include logger class
. .\LoggerClass.ps1

$Logger = [Logger]::new("C:\Temp\RubrikLog.log")

$logger.WriteInformation("Started Validation")
$logger.WriteInformation("Finished Validation")


#Write a warning
$logger.WriteWarning = $true
$logger.WriteInformation("Error validating target server")
$Logger.WriteWarning = $false

#Write a header
$logger.WriteHeader("Output Results")
