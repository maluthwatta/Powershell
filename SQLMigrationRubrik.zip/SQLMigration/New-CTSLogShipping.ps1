<#
****************************************************************************************************
 Author				      :	Manoj Aluthwatta 
 Date Written		    :	01/06/2021
 Modifications		  :	
					          :
 Description		    :	The purpose of this script is to create a new log shipping target
                    :
 Usage              :            
                    :
 Dependencies       :   
                    :   

****************************************************************************************************
#>
function New-CTSLogShipping
{
  Param(
    $CTSDBInfo,
    [CTSLogger] $CTSLogger) 
    
    $CTSLogger.WriteInformation("Started submitting new Log Shipping reqest for $($CTSDBInfo.TargetDatabase)")

    $result = New-RubrikLogShipping `
        -id $($CTSDBInfo.SourceDbRubrikID) `
        -targetInstanceId $($CTSDBInfo.TargetInsRubrikID) `
        -targetDatabaseName $($CTSDBInfo.TargetDatabase) `
        -maxDataStreams $global:CTSMaxDataStreams `
        -TargetFilePaths $($CTSDBInfo.TargetFilePaths) `
        -state "RESTORING"
    
    $CTSLogger.WriteInformation("Completed submitting new Log Shipping target request for $($CTSDBInfo.TargetDatabase)")
    $CTSLogger.WriteInformation("Rubrik Request ID obtained: $($result.id)")
    $CTSLogger.WriteBlankLine()
    $CTSDBInfo.RubrikRequestID = $($result.id)
    $CTSDBInfo.RubrikRequestStatus = $($result.Status)
    $CTSDBInfo.CurrentState = "LogShippingInProgress"
    return $CTSDBInfo
}