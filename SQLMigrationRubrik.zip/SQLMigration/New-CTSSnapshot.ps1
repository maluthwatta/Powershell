<#
****************************************************************************************************
 Author				      :	Manoj Aluthwatta
 Date Written		    :	01/06/2021
 Modifications		  :	
				            :
 Description		    :	The purpose of this function is to create a new Rubrik Snapshot
                    :
 Usage              :            
                    :
 Dependencies       :   
                    :   

****************************************************************************************************
#>
function New-CTSSnapshot
{
  Param(
    $CTSDBInfo,
    [CTSLogger] $CTSLogger) 
    
    $CTSLogger.WriteInformation("Started submitting new Rubrik Snapshot request for $($CTSDBInfo.SourceDatabase)")

    $result = New-RubrikSnapShot `
        -id $($CTSDBInfo.SourceDbRubrikID) `
        -SLA $($CTSDBInfo.CurrentSLA)
    
    $CTSLogger.WriteInformation("Completed submitting new Rubrik Snapshot request for $($CTSDBInfo.SourceDatabase)")
    $CTSLogger.WriteInformation("Rubrik Request ID obtained: $($result.id)")
    $CTSLogger.WriteBlankLine()
    $CTSDBInfo.RubrikRequestID = $($result.id)
    $CTSDBInfo.RubrikRequestStatus = $($result.Status)
    $CTSDBInfo.CurrentState = "SnapshotInProgress"
    return $CTSDBInfo
}