<#
****************************************************************************************************
 Author				:	Manoj Aluthwatta
 Date Written		:	12/07/2021
 Modifications		:	
					:
 Description		:	This function breaks log shipping target and syncronises with the source database
                    :   
                    :   
 Usage              :            
                    :
 Dependencies       :   

 References         : https://github.com/rubrikinc/rubrik-scripts-for-powershell/blob/master/MSSQL/Invoke-LogShippingFailover.ps1

****************************************************************************************************
#>

function Remove-CTSLogShipping {

    Param(
        $PrimaryDatabaseName
        ,$PrimaryDatabaseId
        ,$PrimaryInstanceName
        ,$SecondaryDatabaseName
        ,$SecondaryDatabaseId
        ,$SecondayInstanceName
        ,$LogShippingId
        ,$LogShippingState
        ,[bool]$SetPrimaryDbReadOnly
		,[CTSLogger]$CTSLogger
	)

    # Interim notification time duration between the logs being applied
    $LogApplyNotificationIntervalSec = 60

    try {
        $CTSLogger.WriteInformation("Breaking log shipping on target database $SecondaryDatabaseName on $SecondayInstanceName .Primary database: $PrimaryDatabaseName") 

        #Set database read only
        if ($SetPrimaryDbReadOnly){
            $CTSLogger.WriteInformation("Setting the primary database read only/restricted mode...")   
            if (set-CTSRestrictSourceDBAccess -CTSSourceServerInstance $PrimaryInstanceName -CTSSourceDatabase $PrimaryDatabaseName -CTSLogger $CTSLogger){
                $CTSLogger.WriteInformation("Setting the primary database read only/restricted completed") 
            }
            else {
                $CTSLogger.WriteWarning("Setting the primary database read only/restricted access FAILED") 
                return "Setting the primary database read only/restricted access FAILED"
            }
        }

        #Take the final transaction log backup
        $CTSLogger.WriteInformation("Taking the final transaction log backup of $PrimaryDatabaseName started...")    
        $RubrikRequest = New-RubrikLogBackup -id $PrimaryDatabaseId
        Get-RubrikRequest -id $RubrikRequest.id -Type mssql -WaitForCompletion
        $CTSLogger.WriteInformation("Taking the final transaction log backup of $PrimaryDatabaseName completed")   

        $CTSLogger.WriteInformation("Getting the latest recovery point for $PrimaryDatabaseName")  
        $latestRecoveryPoint = ((Get-RubrikDatabase -id $PrimaryDatabaseId).latestRecoveryPoint)
        
        Set-RubrikLogShipping -id $LogShippingId -state $LogShippingState       

        $StartLoopTime = $CurrentLoopTime = Get-Date

        $CTSLogger.WriteInformation("Applying all of the logs started...")
            do{
                $CheckRubrikLogShipping = Get-RubrikLogShipping -id $LogShippingId
                $lastAppliedPoint = ($CheckRubrikLogShipping.lastAppliedPoint)               
                
                if (((NEW-TIMESPAN $StartLoopTime $CurrentLoopTime).TotalSeconds - $LogApplyNotificationIntervalSec) -gt 0){
                    $CTSLogger.WriteInformation("Last applied log point: $lastAppliedPoint. Target Log point: $latestRecoveryPoint")
                    $CTSLogger.WriteInformation("Next log point applied update after $LogApplyNotificationIntervalSec seconds")
                    $StartLoopTime = Get-Date
                }
                Start-Sleep -Seconds 1
                $CurrentLoopTime = Get-Date         
            } until ($latestRecoveryPoint -eq $lastAppliedPoint)

        $CTSLogger.WriteInformation("Applying all of the logs completed")      

        # Remove log shipping and recover Target database
        $CTSLogger.WriteInformation("Removing Log Shipping")
        Remove-RubrikLogShipping -id $LogShippingId   | out-null    

        $CTSLogger.WriteInformation("Quick comparison of the source database and the target database")
        $CTSLogger.WriteInformation("Latest Recovery Point: $latestRecoveryPoint")
        $CTSLogger.WriteInformation("Last Applied Point: $lastAppliedPoint")
        $CTSLogger.WriteInformation("Log shipping restore SUCCESSFUL")

        return "Log shipping restore SUCCESSFUL"
    }
    catch {
        #If the database was set to read only change it here


        $CTSLogger.WriteWarning("Log shipping restore FAILED: $_")
        return "Log shipping restore FAILED"
    }
}
