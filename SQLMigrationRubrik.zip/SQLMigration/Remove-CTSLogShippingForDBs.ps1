<#
****************************************************************************************************
 Author				:	Manoj Aluthwatta
 Date Written		:	12/07/2021
 Modifications		:	
					:
 Description		:	This function removes log shipping for multiple databases. 
                    :   
                    :   
 Usage              :            
                    :
 Dependencies       :   

****************************************************************************************************
#>

function Remove-CTSLogShippingForDBs {

    Param(
        $LogShippingDBs        
		,[CTSLogger]$CTSLogger
	)

    $ResultDBList = @()

    foreach ($LogShippingDB in $LogShippingDBs) {
        $LogShippingDB.DBRequestDetails.CurrentState = Remove-CTSLogShipping `
        -PrimaryDatabaseName $($LogShippingDB.DBLogShippingDetails.primaryDatabaseName) `
        -PrimaryDatabaseId $($LogShippingDB.DBLogShippingDetails.primaryDatabaseId) `
        -PrimaryInstanceName $($LogShippingDB.DBSourceInstanceName) `
        -SecondaryDatabaseName $($LogShippingDB.DBLogShippingDetails.secondaryDatabaseName) `
        -SecondaryDatabaseId $($LogShippingDB.DBLogShippingDetails.secondaryDatabaseId) `
        -SecondayInstanceName $($LogShippingDB.DBLogShippingDetails.location) `
        -LogShippingId $($LogShippingDB.DBLogShippingDetails.id) `
        -LogShippingState $($LogShippingDB.DBLogShippingDetails.state) `
        -SetPrimaryDbReadOnly $($LogShippingDB.DBRequestDetails.SetPrimaryDbReadOnly) `
        -CTSLogger $CTSLogger

        $ResultDBList += $LogShippingDB
    }

    return $ResultDBList
}