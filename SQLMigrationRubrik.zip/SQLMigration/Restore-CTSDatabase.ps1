<#
****************************************************************************************************
 Author				      :	MA
 Date Written	    	:	01/06/2021
 Modifications		  :	
					          :
 Description		    :	The purpose of this script is to restore a database from Rubrik
                    :
 Usage              :            
                    :
 Dependencies       :   

****************************************************************************************************
#>
function Restore-CTSDatabase
{
  Param(
    $CTSDBInfo,
    [CTSLogger] $CTSLogger) 
    
    $CTSLogger.WriteInformation("Started submitting the Restore Request for $($CTSDBInfo.TargetDatabase)")
    $FinishRecovery = [bool]$($CTSDBInfo.FinishRecovery)
    $Overwrite = [bool]$($CTSDBInfo.OverWrite)

    $result = Export-RubrikDatabase `
        -id $($CTSDBInfo.SourceDbRubrikID) `
        -targetInstanceId $($CTSDBInfo.TargetInsRubrikID) `
        -targetDatabaseName $($CTSDBInfo.TargetDatabase) `
        -recoveryDateTime $($CTSDBInfo.LatestRecoveryPoint) `
        -maxDataStreams $global:max_data_streams `
        -FinishRecovery:$FinishRecovery  `
        -Overwrite:$Overwrite `
        -TargetDataFilePath $null `
        -TargetLogFilePath $null `
        -TargetFilePaths $($CTSDBInfo.TargetFilePaths) `
        -Verbose 

    $CTSLogger.WriteInformation("Completed submitting the Restore Request")
    $CTSLogger.WriteInformation("Rubrik Request ID obtained: $($result.id)")
    $CTSLogger.WriteBlankLine()
    $CTSDBInfo.RubrikRequestID = $($result.id)
    $CTSDBInfo.RubrikRequestStatus = $($result.Status)
    $CTSDBInfo.CurrentState = "RestoreInProgress"
    return $CTSDBInfo
}