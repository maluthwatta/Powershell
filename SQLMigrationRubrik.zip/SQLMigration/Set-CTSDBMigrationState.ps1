<#
****************************************************************************************************
 Author				:	Paul Stickland
 Date Written		:	20210608
 Modifications		:	
					:
 Description		:	This function performs carries out two main tasks:
                    :   	- Updates a database migration list array using Rubrik request status
                    :		  information supplied in a second array.
                    :		- Determines whether the migration state for each database in the
                	:		  migration list array can be updated to the next step and carries out
                    :		  this update where appropriate.
 Usage              :            
                    :
 Dependencies       :   

****************************************************************************************************
#>

function Set-CTSDBMigrationState {

    Param(
		[array]$CTSDBMigrationList
		,[array]$CTSRubrikRequestStati
		,[CTSLogger]$CTSLogger
	)

    try{
			# Have any entries been provided in $CTSDBMigrationList?
			if ( ( $CTSDBMigrationList.count ) -eq 0 ) {
				$CTSLogger.WriteInformation("No databases provided in the database list.")
			}
			else {
				# Have any entries been provided in the Rubrik statistics paramter $CTSRubrikRequestStati?
				if ( ( $CTSRubrikRequestStati.count ) -eq 0 ) {
					$CTSLogger.WriteInformation("No Rubrik request stati provided to update the database migration state.")
				}

				[int]$CTSDBsToBeProcessed = $CTSDBMigrationList.Count

				# Update entries in $CTSDBMigrationList with Rubrik statistics and status updates
				foreach ( $CTSRubrikRequestStatus in ( $CTSRubrikRequestStati ) ) {

					$CTSLogger.WriteInformation("Update the status of an outstanding Rubrik request for restoring [$($CTSDBMigrationList[$CTSRubrikRequestStatus.DBRequestID].SourceDatabase)] on [$($CTSDBMigrationList[$CTSRubrikRequestStatus.DBRequestID].SourceServerInstance)] to [$($CTSDBMigrationList[$CTSRubrikRequestStatus.DBRequestID].TargetDatabase)] on [$($CTSDBMigrationList[$CTSRubrikRequestStatus.DBRequestID].TargetServerInstance)] ...")

					$CTSDBMigrationList[($CTSRubrikRequestStatus.DBRequestID)].RubrikRequestStatus = $CTSRubrikRequestStatus.RubrikRequestStatus
					$CTSDBMigrationList[($CTSRubrikRequestStatus.DBRequestID)].RubrikPercentageComplete = $CTSRubrikRequestStatus.RubrikPercentageComplete
					$CTSDBMigrationList[($CTSRubrikRequestStatus.DBRequestID)].RubrikRequestStartTime = $CTSRubrikRequestStatus.RubrikRequestStartTime
					$CTSDBMigrationList[($CTSRubrikRequestStatus.DBRequestID)].RubrikRequestEndTime = $CTSRubrikRequestStatus.RubrikRequestEndTime

					$CTSLogger.WriteInformation("Status update complete for an outstanding Rubrik request for restoring [$($CTSDBMigrationList[$CTSRubrikRequestStatus.DBRequestID].SourceDatabase)] on [$($CTSDBMigrationList[$CTSRubrikRequestStatus.DBRequestID].SourceServerInstance)] to [$($CTSDBMigrationList[$CTSRubrikRequestStatus.DBRequestID].TargetDatabase)] on [$($CTSDBMigrationList[$CTSRubrikRequestStatus.DBRequestID].TargetServerInstance)].")
				}

				# Evaluate each entry in $CTSDBMigrationList to determine if processing for a db can be progressed to the next step or marked as failed or complete
				foreach ( $CTSDB in ( $CTSDBMigrationList ) ) {
					$CTSLogger.WriteInformation("Check and update the current state step where a change has occurred for restoring [$($CTSDB.SourceDatabase)] on [$($CTSDB.SourceServerInstance)] to [$($CTSDB.TargetDatabase)] on [$($CTSDB.TargetServerInstance)] ...")

					switch ( $CTSDB.CurrentState ) {

#						"AwaitingVerification" {
#
#						}

						"VerificationFailed" {
							$CTSDBsToBeProcessed --
							break
						}

						"VerificationPassed"{
							#Source database is using the simple recovery model
							if ( ( $CTSDB.RecoveryModel ) -eq "SIMPLE" ) {
								$CTSDBMigrationList[$CTSDB.DBRequestID].CurrentState = "AwaitingSnapshot"
							}
							else {
								#Source database is using the full or bulk recovery model
								$CTSDBMigrationList[$CTSDB.DBRequestID].CurrentState = "AwaitingLogShipping"
							}
							break
						}

#						"AwaitingSnapshot"{
#
#						}

#						"AwaitingLogShipping"{
#
#						}

#						"AwaitingRestoration"{
#							
#						}

						"SnapshotInProgress"{
							# Has the database snapshot completed with success?
							if ( ( $CTSDB.RubrikRequestStatus ) -eq "SUCCEEDED" ) {
								#Snapshot completed so configure for next stage
								$CTSDBMigrationList[$CTSDB.DBRequestID].RubrikRequestID = $null
								$CTSDBMigrationList[$CTSDB.DBRequestID].RubrikPercentageComplete = $null
								$CTSDBMigrationList[$CTSDB.DBRequestID].RubrikRequestStartTime = $null
								$CTSDBMigrationList[$CTSDB.DBRequestID].RubrikRequestEndTime = $null
								$CTSDBMigrationList[$CTSDB.DBRequestID].RubrikRequestStatus = $null
								$CTSDBMigrationList[$CTSDB.DBRequestID].CurrentState = "AwaitingRestoration"

								$CTSLogger.WriteInformation("The request to create a Rubrik snapshot of database [$($CTSDB.SourceDatabase)] on [$($CTSDB.SourceServerInstance)] has succeeded.")
								$CTSLogger.WriteInformation("Getting the latest Rubrik recovery point for database [$($CTSDB.SourceDatabase)] on [$($CTSDB.SourceServerInstance)] ...")

								$CTSLatestRecoveryPoint = (Get-RubrikDatabase -id ($CTSDBMigrationList[$CTSDB.DBRequestID].SourceDbRubrikID) -relic:$false).latestRecoveryPoint
								$CTSDBMigrationList[$CTSDB.DBRequestID].LatestRecoveryPoint = (Get-Date $CTSLatestRecoveryPoint)

								$CTSLogger.WriteInformation("The latest Rubrik recovery point for database [$($CTSDB.SourceDatabase)] on [$($CTSDB.SourceServerInstance)] has been retrieved.")
								$CTSLogger.WriteInformation("Database [$($CTSDB.SourceDatabase)] on [$($CTSDB.SourceServerInstance)] is now awaiting restoration to [$($CTSDB.TargetDatabase)] on [$($CTSDB.TargetServerInstance)].")
							}
							# Has the database snapshot failed?
							elseif ( ( $CTSDB.RubrikRequestStatus ) -eq "FAILED" ) {
								$CTSDBMigrationList[$CTSDB.DBRequestID].CurrentState = "SnapshotFailed"

								$CTSDBsToBeProcessed --

								$CTSLogger.WriteWarning = $true
								$CTSLogger.WriteInformation("The request to create a Rubrik snapshot of database [$($CTSDB.SourceDatabase)] on [$($CTSDB.SourceServerInstance)] has failed.")
								$CTSLogger.WriteWarning = $false
							}
							break
						}

						"LogShippingInProgress"{
							# Has the log shipping setup completed with success?
							if ( ( $CTSDB.RubrikRequestStatus ) -eq "SUCCEEDED" ) {
								$CTSDBMigrationList[$CTSDB.DBRequestID].CurrentState = "Complete"

								$CTSDBsToBeProcessed --

								$CTSLogger.WriteInformation("The request to configure Rubrik log shipping of database [$($CTSDB.SourceDatabase)] on [$($CTSDB.SourceServerInstance)] to [$($CTSDB.TargetDatabase)] on [$($CTSDB.TargetServerInstance)] has succeeded.")
							}
							# Has the log shipping setup failed?
							elseif ( ( $CTSDB.RubrikRequestStatus ) -eq "FAILED" ) {
								$CTSDBMigrationList[$CTSDB.DBRequestID].CurrentState = "LogShippingFailed"

								$CTSDBsToBeProcessed --

								$CTSLogger.WriteWarning = $true
								$CTSLogger.WriteInformation("The request to configure Rubrik log shipping of database [$($CTSDB.SourceDatabase)] on [$($CTSDB.SourceServerInstance)] to [$($CTSDB.TargetDatabase)] on [$($CTSDB.TargetServerInstance)] has failed.")
								$CTSLogger.WriteWarning = $false
							}
							break
						}

						"RestoreInProgress"{
							# Has the database restore completed with success?
							if ( ( $CTSDB.RubrikRequestStatus ) -eq "SUCCEEDED" ) {
								$CTSDBMigrationList[$CTSDB.DBRequestID].CurrentState = "Complete"

								$CTSDBsToBeProcessed --

								$CTSLogger.WriteInformation("The request to restore database [$($CTSDB.SourceDatabase)] on [$($CTSDB.SourceServerInstance)] to [$($CTSDB.TargetDatabase)] on [$($CTSDB.TargetServerInstance)] has succeeded.")
							}
							# Has the database restore failed?
							elseif ( ( $CTSDB.RubrikRequestStatus ) -eq "FAILED" ) {
								$CTSDBMigrationList[$CTSDB.DBRequestID].CurrentState = "RestoreFailed"

								$CTSDBsToBeProcessed --

								$CTSLogger.WriteWarning = $true
								$CTSLogger.WriteInformation("The request to restore database [$($CTSDB.SourceDatabase)] on [$($CTSDB.SourceServerInstance)] to [$($CTSDB.TargetDatabase)] on [$($CTSDB.TargetServerInstance)] has failed.")
								$CTSLogger.WriteWarning = $false
							}
							break
						}

						"SnapshotFailed"{
							$CTSDBsToBeProcessed --
							break
						}

						"LogShippingFailed"{
							$CTSDBsToBeProcessed --
							break
						}

						"RestoreFailed"{
							$CTSDBsToBeProcessed --
							break
						}

						"Complete"{
							$CTSDBsToBeProcessed --
							break
						}
					}
					$CTSLogger.WriteInformation("Current state step checked and updated where a change has occurred for restoring [$($CTSDB.SourceDatabase)] on [$($CTSDB.SourceServerInstance)] to [$($CTSDB.TargetDatabase)] on [$($CTSDB.TargetServerInstance)].")
				}

				$CTSLogger.WriteInformation("Migration state for each database has been updated.")
				$CTSLogger.WriteInformation("[$($CTSDBsToBeProcessed)] of [$($CTSDBMigrationList.Count)] databases are still being processed")
			}
		return $CTSDBMigrationList, $CTSDBsToBeProcessed
    }
    catch{
        throw $_.Exception.Message     
    }    
}
