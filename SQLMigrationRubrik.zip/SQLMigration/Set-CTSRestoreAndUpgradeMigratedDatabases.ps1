<#
****************************************************************************************************
 Author				:	Manoj Aluthwatta
 Date Written		:	12/07/2021
 Modifications		:	
					:
 Description		:	 
                    :   
                    :   
 Usage              :            
                    :
 Dependencies       :   

****************************************************************************************************
#>

function Set-CTSRestoreAndUpgradeMigratedDatabases {

    Param(
        $CTSPostRestoreDBjsonFile
        ,$CTSLogDir = ".\Logs"
	)
    
    #Include classes/functions
    . .\CTSIncludeFiles.ps1

    #Import modules
    Import-Module -Name Rubrik
    Import-Module -Name SqlServer

    #Create the status log file
    $StatusLogFileDir = $CTSLogDir
    $RunDate = Get-Date  
    $TimeStamp = $RunDate.ToString("yyyyMMddHHmmss")
    $LogFileName = "RubrikPostRestore_$TimeStamp.log"

    try {        

        #Create the directory if it does not exist
        If(!(test-path $StatusLogFileDir))
        {
            Write-Output "Creating $StatusLogFileDir"
            New-Item -ItemType Directory -Force -Path $StatusLogFileDir
        }
        $StatusLogFile = New-Item -Path $StatusLogFileDir -Name $LogFileName -ItemType "file" 
        $CTSLogger = [CTSLogger]::new($StatusLogFile.FullName)    

        $CTSLogger.WriteInformation("Start of log shipping and post database restore process ..")

        $CTSLogger.WriteInformation("Reading the post restore json file")
        $jsonPostRestoreDBs = Get-Content $CTSPostRestoreDBjsonFile | ConvertFrom-Json
       
        $PostRestoreDBList = $jsonPostRestoreDBs.postRestoreDatabaseList

        if (!($PostRestoreDBList)){
            throw ("Post restore database list is empty")
        }

        $PostRestoreDBArray = @()
        $DBID = 0
        foreach ($PostRestoreDB in $PostRestoreDBList ) {
            $PostRestoreDBArray += $PostRestoreDB | Select-Object *, @{n='ValidationStatus';e={$null}}, @{n='CurrentState';e={$null}}, @{n='DBUpgradeID';e={($DBID)}}  
            $DBID++       
        }
        
        $CTSLogger.WriteInformation("Connecting to Rubrik...")
        Connect-CTSRubrikServer -RubrikCredentialFile $null
        $CTSLogger.WriteInformation("Connected to Rubrik")

        #Validate the post migration databases
        $LogShippingDBs, $RestoreDBs = (Invoke-CTSPostMigratedDBValidation -CTSDBUpgradeList $PostRestoreDBArray -CTSLogger $CTSLogger)

        if (!($LogShippingDB)) {
            $CTSLogger.WriteInformation("Breaking log shipping started ..")
            #Remove log shipping for log shipped databases
            $LogShippingDbResults = Remove-CTSLogShippingForDBs -LogShippingDBs $LogShippingDBs -CTSLogger $CTSLogger
        }

        $LogShippingFailedDbs = $LogShippingDbResults | Where-Object { $_.CurrentState -match "FAILED" } 

        if ($LogShippingFailedDbs){
            $CTSLogger.WriteHeader("Log shipping databases failed to recover:")
            $CTSLogger.WriteArray($LogShippingFailedDbs)
        }

        $LogShippingSuccessfulDbs = $LogShippingDbResults | Where-Object { $_.CurrentState -match "SUCCESSFUL" } 

        # Do post restore process for all successful log shipped databases + restore databases
        $PostRestoreDBs = $RestoreDBs + $LogShippingSuccessfulDbs

        if ($PostRestoreDBs) {
            #Do the post restore process
            $CTSLogger.WriteInformation("Starting post database process..")
            #set-CTSPostMigrationUpgradeForDBs -CTSPostMigrationDBs $PostRestoreDBs -CTSLogger $CTSLogger
            $CTSLogger.WriteInformation("Completed post database migrration process")

        }
    }
    catch {
        $CTSLogger.WriteWarning("An error occurred: $_")
    }
}


