<#
****************************************************************************************************
 Author				:	MA
 Date Written	    :	01/06/2021
 Modifications		:	
			        :
 Description		:	The purpose of this function is check existence of a file path
                    :
 Usage              :            
                    :
 Dependencies       :   

****************************************************************************************************
#>
function Test-CTSFilePath
{
    param(
        $ServerInstanceName
        , $FilePath
    )

    if ($ServerInstanceName.IndexOf('\') -gt 0){
        $ServerVMName = $ServerInstanceName.Split("\")[0]
    }
    else{
        $ServerVMName = $ServerInstanceName
    }

    $FileAdminPath = $FilePath.Replace(":", "$")
    $FileAdminFullPath = "\\" + $ServerVMName + "\"  + $FileAdminPath

    return Test-Path $FileAdminFullPath
}