<#
****************************************************************************************************
 Author				:	Paul Stickland
 Date Written		:	20210707
 Modifications		:	
					:
 Description		:	This function carries out post-migration tasks for a provided destination
                    :	database:
                    :   	- Recovers the database if is not already recovered ;
                    :   	- Set the compatibility level to match the maximum supported level of
                    :   	  the target SQL instance ;
                    :   	- DBCC UPDATEUSAGE ;
                    :		- DBCC CHECKDB WITH DATA_PURITY ;
                	:		- UPDATE STATISTICS for all tables and indexed views WITH FULLSCAN.
					:
                    :	DotNet ADO database connectivity has been chosen over Invoke-Sqlcmd as at
                    :	the time of writing ADO appears to better handle parameterisation such to
                    :	avoid potential SQL injection issues.  Where there is no other option
                    :	for some commands than to use dynamic SQL, parameters (the database name)
                    :	are wrapped inside the TSQL "quotename" function as a defence for SQL
                    :	injection.
 Usage              :            
                    :
 Dependencies       :   

****************************************************************************************************
#>

function set-CTSPostMigrationUpgradeDB {

    Param(
		[parameter(Position = 1, Mandatory = $true)]
		[string]$TargetServerInstance

		,[parameter(Position = 2, Mandatory = $true)]
		[string]$TargetDatabase

		,[parameter(Position = 3, Mandatory = $false)]
		[ValidateSet($true,$false)]
		[bool]$SetDBToServerDefaultCompatibilityLevel = $true
		
		,[parameter(Position = 4, Mandatory = $false)]
		[ValidateSet($true,$false)]
		[bool]$UpdateDBUsage = $true
		
		,[parameter(Position = 5, Mandatory = $false)]
		[ValidateSet($true,$false)]
		[bool]$CheckDB = $true

		,[parameter(Position = 6, Mandatory = $false)]
		[ValidateSet($true,$false)]
		[bool]$UpdateStats = $true
		
		,[parameter(Position = 7, Mandatory = $true)]
		[CTSLogger]$CTSLogger
	)

    try{

		$CTSLogger.WriteInformation("Starting post-migration activities for the target database [$($TargetDatabase)] on [$($TargetServerInstance)] ...")

		[int]$RequestedOptions = 0
		[int]$CompletedOptions = 0
		[int]$CTSRecoverDBOption = $CTSPostMigrationOptions["CTSRecoverDBOption"]
		[int]$CTSDBCompatibilityLevelOption = $CTSPostMigrationOptions["CTSDBCompatibilityLevelOption"]
		[int]$CTSUpdateDBUsageOption = $CTSPostMigrationOptions["CTSUpdateDBUsageOption"]
		[int]$CTSCheckDBOption = $CTSPostMigrationOptions["CTSCheckDBOption"]
		[int]$CTSUpdateDBStatsOption = $CTSPostMigrationOptions["CTSUpdateDBStatsOption"]
		
		$RequestedOptions = $RequestedOptions + $CTSRecoverDBOption

		if ($($SetDBToServerDefaultCompatibilityLevel)) {
			$RequestedOptions = $RequestedOptions + $CTSDBCompatibilityLevelOption
		}
		if ($($UpdateDBUsage)) {
			$RequestedOptions = $RequestedOptions + $CTSUpdateDBUsageOption
		}
		if ($($CheckDB)) {
			$RequestedOptions = $RequestedOptions + $CTSCheckDBOption
		}
		if ($($UpdateStats)) {
			$RequestedOptions = $RequestedOptions + $CTSUpdateDBStatsOption
		}

		$CTSLogger.WriteInformation("Checking if the target database [$($TargetDatabase)] on [$($TargetServerInstance)] needs to be recovered and if neccesary attempting recovery ...")

		# Set up the SQL connection
		$SQLConn = New-Object System.Data.SqlClient.SqlConnection("Server = $TargetServerInstance; Database = 'master'; Integrated Security = True;")

		# [array]$SQLMessages = $null

		$SQLHandler = [System.Data.SqlClient.SqlInfoMessageEventHandler] {
			param(
				$sender
				,$event
			)
			
			# $SQLMessages += $event.Message
			$CTSLogger.WriteInformation("SQL | $($event.Message)")
		};

		$SQLConn.add_InfoMessage($SQLHandler);
		$SQLConn.FireInfoMessageEventOnUserErrors = $true;

		$SQLConn.Open()

		# Prepare SQL command to check and carry out recovery if the database needs to be recovered
		$SQLCMD = New-Object System.Data.SqlClient.SqlCommand
		$SQLCMD.Connection = $SQLConn
		$SQLCMD.CommandTimeout = 0

		$SQLQuery = "set nocount on; exec sp_executesql N'

			set nocount on;

			declare
				@errorMessage NVarChar(800)
				,@errorNumber int
				,@errorSeverity int
				,@errorState int
				,@errorLine int
				,@errorProcedure NVarChar(255)
			;

			begin try

				if exists ( select 1 from sys.databases where name = @DBName and state = 1 )
				begin
					declare
						@SQLQuery nvarchar(1000) = N''restore databases '' + quotename( @DBName ) + N'' with recovery;''
					;

					raiserror( @SQLQuery, 0, 0) with nowait;

					exec ( @SQLQuery );
					select DBRecovery = cast(1 as tinyint);
				end
				else
				begin
					select DBRecovery = cast(2 as tinyint);
				end;

			end try

			begin catch
				select
					@errorNumber = error_number()
					,@errorSeverity = error_severity()
					,@errorState = error_state()
					,@errorLine = error_line()
					,@errorProcedure = isnull(''procedure '' + error_procedure(), ''the query batch'')
					;
				
					select
						@errorMessage = N''Error %d, Level %d, state %d, in %s, at line %d.'' +
						''  The underlying message was: ''+ error_message();

				if @@TRANCOUNT > 0 rollback transaction;

				raiserror(
					@errorMessage
					,@errorSeverity
					,1
					,@errorNumber
					,@errorSeverity
					,@errorState
					,@errorProcedure
					,@errorLine
				);
			end catch
		', N'@DBName sysname', @DBName"

		$SQLParam1 = New-Object System.Data.SqlClient.SqlParameter("@DBName",[Data.SQLDBType]::NVarChar, 128)
		$SQLParam1.Value = $TargetDatabase
		$SQLCMD.CommandText = $SQLQuery
		$SQLCMD.Parameters.Add($SQLParam1) | Out-Null
		
		# Execute the SQL recovery command
		$SQLCMDOutput = [int]$SQLCMD.ExecuteScalar()
		$SQLCMD.StatementCompleted

		# Check the result of the SQL recovery command
		switch ( $SQLCMDOutput ) {
			1 {
				$CTSLogger.WriteInformation("Recovery for target database [$($TargetDatabase)] on [$($TargetServerInstance)] was required and has been successfully executed.")
				$CompletedOptions = $CompletedOptions + $CTSRecoverDBOption
				break
			}

			2 {
				$CTSLogger.WriteInformation("Recovery for target database [$($TargetDatabase)] on [$($TargetServerInstance)] was not required.")
				$CompletedOptions = $CompletedOptions + $CTSRecoverDBOption
				break
			}

			default {
				$CTSLogger.WriteWarning("Recovery requirement for target database [$($TargetDatabase)] on [$($TargetServerInstance)] could not be determined.")
				break
			}
		}

		$SQLCMD.Dispose()
		Clear-Variable SQLParam1
		Clear-Variable SQLCMD
		Clear-Variable SQLQuery
		Clear-Variable SQLCMDOutput


		# Has the option to set the target database compatibility level to match the compatibility level default of the target SQL instance been requested?
		if ($SetDBToServerDefaultCompatibilityLevel) {

			$CTSLogger.WriteInformation("Check compatibility level for target database [$($TargetDatabase)] on [$($TargetServerInstance)].  If less than the SQL instance default compatibility level, update the database compatibility level to match.")

			# Prepare the SQL command to set the target database to the SQL instance default compatibility level
			$SQLCMD = New-Object System.Data.SqlClient.SqlCommand
			$SQLCMD.Connection = $SQLConn
			$SQLCMD.CommandTimeout = 0

			$SQLQuery = "set nocount on; exec sp_executesql N'

				set nocount on;

				declare
					@errorMessage NVarChar(800)
					,@errorNumber int
					,@errorSeverity int
					,@errorState int
					,@errorLine int
					,@errorProcedure NVarChar(255)
				;

				begin try

					declare
						@InstanceCompatibilityLevel smallint
						,@DBCompatibilityLevelBefore smallint
						,@DBCompatibilityLevelAfter smallint
					;

					;with ProductVersion as
					(
						select
							ProductVersion = cast(serverproperty(''ProductVersion'') AS nvarchar(128))
					)
					select
						@InstanceCompatibilityLevel = try_convert(smallint, coalesce( parsename( convert(varchar(32), ProductVersion ), 4), parsename(convert(varchar(32), ProductVersion), 3) )) * 10
					from ProductVersion;

					select
						@DBCompatibilityLevelBefore = compatibility_level
					from sys.databases
					where name = @DBName;

					if @DBCompatibilityLevelBefore < @InstanceCompatibilityLevel
					begin
						declare
							@SQLQuery nvarchar(1000) = N''alter database '' + quotename( @DBName ) + N'' set compatibility_level = '' + cast( @InstanceCompatibilityLevel as nvarchar(4) ) + N'';''
						;
						exec ( @SQLQuery );
					end;

					select
						@DBCompatibilityLevelAfter = compatibility_level
					from sys.databases
					where name = @DBName;

					select
						InstanceCompatibilityLevel = @InstanceCompatibilityLevel
						,DBCompatibilityLevelBefore = @DBCompatibilityLevelBefore
						,DBCompatibilityLevelAfter = @DBCompatibilityLevelAfter
					;

				end try

				begin catch
					select
						@errorNumber = error_number()
						,@errorSeverity = error_severity()
						,@errorState = error_state()
						,@errorLine = error_line()
						,@errorProcedure = isnull(''procedure '' + error_procedure(), ''the query batch'')
					;
				
					select
						@errorMessage = N''Error %d, Level %d, state %d, in %s, at line %d.'' +
							''  The underlying message was: ''+ error_message();
							if @@TRANCOUNT > 0 rollback transaction;
							raiserror(
						@errorMessage
						,@errorSeverity
						,1
						,@errorNumber
						,@errorSeverity
						,@errorState
						,@errorProcedure
						,@errorLine
					);
				end catch
			', N'@DBName sysname', @DBName"

			$SQLParam1 = New-Object System.Data.SqlClient.SqlParameter("@DBName",[Data.SQLDBType]::NVarChar, 128)
			$SQLParam1.Value = $TargetDatabase
			$SQLCMD.CommandText = $SQLQuery
			$SQLCMD.Parameters.Add($SQLParam1) | Out-Null
			
			# Execute the SQL command to check and set the target database to the SQL instance default compatibility level
			$SQLResult = New-Object System.Data.DataTable
			$SQLAdapter = New-Object System.Data.sqlclient.sqlDataAdapter $SQLCMD

			[void]$SQLAdapter.Fill($SQLResult)

			if ( ($($SQLResult.Rows.Count) -eq 0) -or !($($SQLResult.Rows[0].DBCompatibilityLevelBefore)) -or !($($SQLResult.Rows[0].DBCompatibilityLevelAfter)) -or !($($SQLResult.Rows[0].InstanceCompatibilityLevel)) ) {
				$CTSLogger.WriteWarning("Unable to determine compatibility levels for the SQL instance or target database [$($TargetDatabase)] on [$($TargetServerInstance)] | DBCompatibilityLevelBefore: $($SQLResult.Rows[0].DBCompatibilityLevelBefore) | DBCompatibilityLevelAfter: $($SQLResult.Rows[0].DBCompatibilityLevelAfter) | InstanceCompatibilityLevel: $($SQLResult.Rows[0].InstanceCompatibilityLevel)" )
			}
			else {
				$CTSLogger.WriteInformation("Target database [$($TargetDatabase)] on [$($TargetServerInstance)] | DBCompatibilityLevelBefore: $($SQLResult.Rows[0].DBCompatibilityLevelBefore) | DBCompatibilityLevelAfter: $($SQLResult.Rows[0].DBCompatibilityLevelAfter) | InstanceCompatibilityLevel: $($SQLResult.Rows[0].InstanceCompatibilityLevel)" )
				$CompletedOptions = $CompletedOptions + $CTSDBCompatibilityLevelOption
			}

			$SQLCMD.StatementCompleted
			$SQLAdapter.Dispose()
			$SQLCMD.Dispose()
			Clear-Variable SQLResult
			Clear-Variable SQLAdapter
			Clear-Variable SQLCMD
			Clear-Variable SQLParam1
			Clear-Variable SQLQuery

			$CTSLogger.WriteInformation("End of compatibility level check stage for target database [$($TargetDatabase)] on [$($TargetServerInstance)].")
		}


		# Has the option to run dbcc updateusage for the target database been requested?
		if ( $UpdateDBUsage ) {

			$CTSLogger.WriteInformation("Check and correct pages and row count inaccuracies in the catalog views using dbcc updateusage for target database [$($TargetDatabase)] on [$($TargetServerInstance)] ...")

			# Prepare the SQL command to run dbcc updateusage for the target database
			$SQLCMD = New-Object System.Data.SqlClient.SqlCommand
			$SQLCMD.Connection = $SQLConn
			$SQLCMD.CommandTimeout = 0

			$SQLQuery = "set nocount on; exec sp_executesql N'
				set nocount on;

				declare
					@errorMessage NVarChar(800)
					,@errorNumber int
					,@errorSeverity int
					,@errorState int
					,@errorLine int
					,@errorProcedure NVarChar(255)
				;

				begin try

					declare
						@SQLQuery nvarchar(1000) = N''dbcc updateusage ( '' + quotename( @DBName ) + N'' ) with no_infomsgs;''
					;

					raiserror( @SQLQuery, 0, 0) with nowait;

					exec ( @SQLQuery );

					select UpdateUsage = cast(1 as tinyint);

				end try

				begin catch
					select
						@errorNumber = error_number()
						,@errorSeverity = error_severity()
						,@errorState = error_state()
						,@errorLine = error_line()
						,@errorProcedure = isnull(''procedure '' + error_procedure(), ''the query batch'')
					;
				
					select
						@errorMessage = N''Error %d, Level %d, state %d, in %s, at line %d.'' +
							''  The underlying message was: ''+ error_message();
							if @@TRANCOUNT > 0 rollback transaction;
							raiserror(
						@errorMessage
						,@errorSeverity
						,1
						,@errorNumber
						,@errorSeverity
						,@errorState
						,@errorProcedure
						,@errorLine
					);
				end catch
			', N'@DBName sysname', @DBName"

			$SQLParam1 = New-Object System.Data.SqlClient.SqlParameter("@DBName",[Data.SQLDBType]::NVarChar, 128)
			$SQLParam1.Value = $TargetDatabase
			$SQLCMD.CommandText = $SQLQuery
			$SQLCMD.Parameters.Add($SQLParam1) | Out-Null
			
			# Execute the SQL command to run dbcc updateusage for the target database
			# $SQLCMDOutput = $SQLCMD.ExecuteNonQuery()
			$SQLCMDOutput = [int]$SQLCMD.ExecuteScalar()
	
			# Check the result of the SQL recovery command
			switch ( $SQLCMDOutput ) {
				1 {
					$CTSLogger.WriteInformation("dbcc updateusage has been executed for target database [$($TargetDatabase)] on [$($TargetServerInstance)] without error.")
					$CompletedOptions = $CompletedOptions + $CTSUpdateDBUsageOption
					break
				}

				default {
					$CTSLogger.WriteWarning("An error occurred while attepting to run dbcc updateusage for target database [$($TargetDatabase)] on [$($TargetServerInstance)].")
					break
				}
			}

			$SQLCMD.StatementCompleted
			$SQLCMD.Dispose()
			Clear-Variable SQLCMD
			Clear-Variable SQLParam1
			Clear-Variable SQLQuery
			Clear-Variable SQLCMDOutput

			$CTSLogger.WriteInformation("End of dbcc updateusage stage for target database [$($TargetDatabase)] on [$($TargetServerInstance)].")

		}
		

		# Has the option to run dbcc checkdb for the target database been requested?
		if ( $CheckDB ) {

			$CTSLogger.WriteInformation("Executing dbcc checkdb for target database [$($TargetDatabase)] on [$($TargetServerInstance)] ...")

			# Prepare the SQL command to run dbcc checkdb for the target database
			$SQLCMD = New-Object System.Data.SqlClient.SqlCommand
			$SQLCMD.Connection = $SQLConn
			$SQLCMD.CommandTimeout = 0

			$SQLQuery = "set nocount on; exec sp_executesql N'
				set nocount on;

				declare
					@errorMessage NVarChar(800)
					,@errorNumber int
					,@errorSeverity int
					,@errorState int
					,@errorLine int
					,@errorProcedure NVarChar(255)
				;

				begin try

					declare
						@SQLQuery nvarchar(1000) = N''dbcc checkdb ( '' + quotename( @DBName ) + N'' ) with data_purity, no_infomsgs;''
					;
			
					raiserror( @SQLQuery, 0, 0) with nowait;
			
					exec ( @SQLQuery );

					select CheckDB = cast(1 as tinyint);

				end try
				begin catch
					select
						@errorNumber = error_number()
						,@errorSeverity = error_severity()
						,@errorState = error_state()
						,@errorLine = error_line()
						,@errorProcedure = isnull(''procedure '' + error_procedure(), ''the query batch'')
					;
				
					select
						@errorMessage = N''Error %d, Level %d, state %d, in %s, at line %d.'' +
							''  The underlying message was: ''+ error_message();
							if @@TRANCOUNT > 0 rollback transaction;
							raiserror(
						@errorMessage
						,@errorSeverity
						,1
						,@errorNumber
						,@errorSeverity
						,@errorState
						,@errorProcedure
						,@errorLine
					);
				end catch
			', N'@DBName sysname', @DBName"

			$SQLParam1 = New-Object System.Data.SqlClient.SqlParameter("@DBName",[Data.SQLDBType]::NVarChar, 128)
			$SQLParam1.Value = $TargetDatabase
			$SQLCMD.CommandText = $SQLQuery
			$SQLCMD.Parameters.Add($SQLParam1) | Out-Null
			
			# Execute the SQL command to run dbcc checkdb for the target database
			# $SQLCMDOutput = $SQLCMD.ExecuteNonQuery()
			$SQLCMDOutput = [int]$SQLCMD.ExecuteScalar()
	
			# Check the result of the SQL recovery command
			switch ( $SQLCMDOutput ) {
				1 {
					$CTSLogger.WriteInformation("dbcc checkdb has been executed for target database [$($TargetDatabase)] on [$($TargetServerInstance)] without error.")
					$CompletedOptions = $CompletedOptions + $CTSCheckDBOption
					break
				}

				default {
					$CTSLogger.WriteWarning("An error occurred while attepting to run dbcc checkdb for target database [$($TargetDatabase)] on [$($TargetServerInstance)].")
					break
				}
			}
	
			$SQLCMD.StatementCompleted
			$SQLCMD.Dispose()
			Clear-Variable SQLCMD
			Clear-Variable SQLParam1
			Clear-Variable SQLQuery
			Clear-Variable SQLCMDOutput

			$CTSLogger.WriteInformation("End of dbcc checkdb stage for target database [$($TargetDatabase)] on [$($TargetServerInstance)].")

		}


		# Has the option to update statistics for all tables and indexed views in the target database been requested?
		if ( $UpdateTableStats ) {

			$CTSLogger.WriteInformation("Updating statistics for all tables and indexed views in the target database [$($TargetDatabase)] on [$($TargetServerInstance)] ...")

			# Prepare the SQL command to update statistics for all tables and indexed views in the target database
			$SQLCMD = New-Object System.Data.SqlClient.SqlCommand
			$SQLCMD.Connection = $SQLConn
			$SQLCMD.CommandTimeout = 0

			$SQLQuery = "set nocount on; exec sp_executesql N'
				set nocount on;

				declare
					@errorMessage NVarChar(800)
					,@errorNumber int
					,@errorSeverity int
					,@errorState int
					,@errorLine int
					,@errorProcedure NVarChar(255)
				;

				begin try

					declare
						@SQLQuery nvarchar(4000) = N''use '' + quotename( @DBName ) + N'';

						declare
							@CurrRow int = 1
							,@TotalRows int = 0
							,@UpdateStatsQuery nvarchar(4000) = N''''''''
							,@PrintInfo nvarchar(4000)
						;

						create table #CandidateObjects
						(
							RowID int identity(1,1)
							,FullObjectName nvarchar(256) not null
							,primary key ( RowID asc )
						);

						insert into #CandidateObjects
						(
							FullObjectName
						)
						select
							FullObjectName = quotename( OBJECT_SCHEMA_NAME(object_id) ) + N''''.'''' + quotename( name )
						from sys.tables
						union all
						select
							FullObjectName = quotename( OBJECT_SCHEMA_NAME(v.object_id) ) + N''''.'''' + quotename( v.name )
						from sys.views AS v
						where exists
						(
							select 1
							from sys.indexes AS si
							where si.object_id = v.object_id
						);

						set @TotalRows = @@rowcount;

						while @CurrRow <= @TotalRows
						begin
							select
								@UpdateStatsQuery = N''''update statistics '''' + FullObjectName + N'''' with fullscan;''''
							from #CandidateObjects
							where RowID = @CurrRow;

							/*
							set @PrintInfo = convert( nchar(19), getdate(), 120 ) + N'''' | '''' + quotename( db_name() ) + N'''' | Statistic '''' + cast( @CurrRow as nvarchar(5) ) + '''' of '''' + cast( @TotalRows as nvarchar(5) ) + '''' | '''' + @UpdateStatsQuery;
							*/

							set @PrintInfo = quotename( db_name() ) + N'''' | Object '''' + cast( @CurrRow as nvarchar(5) ) + '''' of '''' + cast( @TotalRows as nvarchar(5) ) + '''' | '''' + @UpdateStatsQuery;
							raiserror( @PrintInfo, 0, 0) with nowait;
							set @PrintInfo = null;

							exec ( @UpdateStatsQuery );

							select
								@CurrRow += 1
								,@UpdateStatsQuery = N''''''''
							;
						end;
					'';

					/*
					print @SQLQuery;
					*/
					exec ( @SQLQuery );

					select UpdateStatistics = cast(1 as tinyint);

				end try
				begin catch
					select
						@errorNumber = error_number()
						,@errorSeverity = error_severity()
						,@errorState = error_state()
						,@errorLine = error_line()
						,@errorProcedure = isnull(''procedure '' + error_procedure(), ''the query batch'')
					;
				
					select
						@errorMessage = N''Error %d, Level %d, state %d, in %s, at line %d.'' +
							''  The underlying message was: ''+ error_message();
							if @@TRANCOUNT > 0 rollback transaction;
							raiserror(
						@errorMessage
						,@errorSeverity
						,1
						,@errorNumber
						,@errorSeverity
						,@errorState
						,@errorProcedure
						,@errorLine
					);
				end catch
			', N'@DBName sysname', @DBName"

			$SQLParam1 = New-Object System.Data.SqlClient.SqlParameter("@DBName",[Data.SQLDBType]::NVarChar, 128)
			$SQLParam1.Value = $TargetDatabase
			$SQLCMD.CommandText = $SQLQuery
			$SQLCMD.Parameters.Add($SQLParam1) | Out-Null
			
			# Execute the SQL command to update statistics for all tables and indexed views in the target database
			# $SQLCMDOutput = $SQLCMD.ExecuteNonQuery()
			$SQLCMDOutput = [int]$SQLCMD.ExecuteScalar()
	
			# Check the result of the SQL recovery command
			switch ( $SQLCMDOutput ) {
				1 {
					$CTSLogger.WriteInformation("update statistics has been executed for target database [$($TargetDatabase)] on [$($TargetServerInstance)] without error.")
					$CompletedOptions = $CompletedOptions + $CTSUpdateDBStatsOption
					break
				}

				default {
					$CTSLogger.WriteWarning("An error occurred while attepting to update statistics for target database [$($TargetDatabase)] on [$($TargetServerInstance)].")
					break
				}
			}
	
			$SQLCMD.StatementCompleted
			$SQLCMD.Dispose()
			Clear-Variable SQLCMD
			Clear-Variable SQLParam1
			Clear-Variable SQLQuery
			Clear-Variable SQLCMDOutput

			$CTSLogger.WriteInformation("End of statistics update stage for all tables and indexed views in target database [$($TargetDatabase)] on [$($TargetServerInstance)].")

		}
	
		$SqlConn.Dispose()

		$RequestedOptionsResult = @{}
		$RequestedOptionsResult.Add("RequestedOptions", $RequestedOptions)
		$RequestedOptionsResult.Add("CompletedOptions", $CompletedOptions)

		$CTSLogger.WriteInformation("The requested post-migration activities for the target database [$($TargetDatabase)] on [$($TargetServerInstance)] have been attempted.")
		return $RequestedOptionsResult
    }
    catch{
        #throw $_.Exception.Message     
		# $CTSLogger.WriteWarning("An error occurred: $ERROR[0]")
		$CTSLogger.WriteWarning("An error occurred: $_")
    }    
}
