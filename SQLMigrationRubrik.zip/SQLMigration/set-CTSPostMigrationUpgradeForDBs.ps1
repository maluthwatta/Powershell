<#
****************************************************************************************************
 Author				:	Paul Stickland
 Date Written		:	20210707
 Modifications		:	
					:
 Description		:	This function loops through an array of target databases and attempts to
                    :	call set-CTSPostMigrationUpgradeDB for each one to carry out post-
                    :	migration activities including:
                    :   	- Recovers the database if is not already recovered ;
                    :   	- Set the compatibility level to match the maximum supported level of
                    :   	  the target SQL instance ;
                    :   	- DBCC UPDATEUSAGE ;
                    :		- DBCC CHECKDB WITH DATA_PURITY ;
                	:		- UPDATE STATISTICS for all tables and indexed views WITH FULLSCAN.
					:
 Usage              :            
                    :
 Dependencies       :   set-CTSPostMigrationUpgradeDB

****************************************************************************************************
#>

function set-CTSPostMigrationUpgradeForDBs {

    Param(
		[parameter(Position = 1, Mandatory = $true)]
		[array[]]$CTSPostMigrationDBs

		,[parameter(Position = 2, Mandatory = $false)]
		[ValidateSet($true,$false)]
		[bool]$SetDBToServerDefaultCompatibilityLevel = $true
		
		,[parameter(Position = 3, Mandatory = $false)]
		[ValidateSet($true,$false)]
		[bool]$UpdateDBUsage = $true
		
		,[parameter(Position = 4, Mandatory = $false)]
		[ValidateSet($true,$false)]
		[bool]$CheckDB = $true

		,[parameter(Position = 5, Mandatory = $false)]
		[ValidateSet($true,$false)]
		[bool]$UpdateTableStats = $true
		
		,[parameter(Position = 6, Mandatory = $true)]
		[CTSLogger]$CTSLogger
	)

    try{

		# Have any entries been provided in $CTSDBMigrationList?
		if ( ( $CTSPostMigrationDBs.count ) -eq 0 ) {
			$CTSLogger.WriteWarning("No databases supplied for a status check.")
		}
		else {
			$CTSLogger.WriteInformation("Starting post-migration activities for an array of target databases ...")
		}

		$CTSDBHash = @{}

		# Create a hash table of unique post-migration database details
		foreach ( $CTSPostMigrationDB in ( $CTSPostMigrationDBs ) ) {

			$CTSPostMigrationDBKey = "$($CTSPostMigrationDB.TargetServerInstance)_$($CTSPostMigrationDB.TargetDatabase)"

			if ( $CTSDBHash.ContainsKey($CTSPostMigrationDBKey) ) {
				$CTSLogger.WriteInformation("A request to carry out post-migration activities already exists for [$($CTSPostMigrationDB.TargetDatabase)] on $($CTSPostMigrationDB.TargetServerInstance).  Skipping second and subsequent entries for the same target database.")
			}
			else {
				$CTSDBHashDetails = @{}
				$CTSDBHashDetails.Add("TargetServerInstance", $CTSPostMigrationDB.TargetServerInstance)
				$CTSDBHashDetails.Add("TargetDatabase", $CTSPostMigrationDB.TargetDatabase)
				$CTSDBHashDetails.Add("CurrentState", "PostMigrationQueued")
				$CTSDBHashDetails.Add("PostMigrationStart", $null)
				$CTSDBHashDetails.Add("PostMigrationEnd", $null)
				$CTSDBHashDetails.Add("RequestedOptions", $null)
				$CTSDBHashDetails.Add("CompletedOptions", $null)
	
				$CTSDBHash.Add($CTSPostMigrationDBKey, $CTSDBHashDetails)
				Clear-Variable CTSDBHashDetails
			}
		}


		# Iterate through each requested database to carry out post-migration activities
		# Note that we need to use clone as we want to be able to update the $CTSDBHash hash table
		$CTSDBHash.Keys.clone() | foreach-object {

			try {

				$CTSCurrentKey = $_
				$RequestedOptionsResult = @{}
				[int]$RequestedOptions = $null
				[int]$CompletedOptions = $null

				$TargetServerInstance = $CTSDBHash[$CTSCurrentKey].TargetServerInstance
				$TargetDatabase = $CTSDBHash[$CTSCurrentKey].TargetDatabase
				$CTSDBHash[$CTSCurrentKey].CurrentState = "PostMigrationRunning"
				$CTSDBHash[$CTSCurrentKey].PostMigrationStart = Get-Date

				$CTSLogger.WriteBlankLine()

				# Attempt to carry out post-migration activities with the set-CTSPostMigrationUpgradeDB function for the current database
				$RequestedOptionsResult = ( set-CTSPostMigrationUpgradeDB -TargetServerInstance $TargetServerInstance -TargetDatabase $TargetDatabase -SetDBToServerDefaultCompatibilityLevel $SetDBToServerDefaultCompatibilityLevel -UpdateDBUsage $UpdateDBUsage -CheckDB $CheckDB -UpdateStats $UpdateTableStats -CTSLogger $CTSLogger )

				$RequestedOptions = $RequestedOptionsResult.RequestedOptions
				$CompletedOptions = $RequestedOptionsResult.CompletedOptions

				$CTSDBHash[$CTSCurrentKey].RequestedOptions = $RequestedOptions
				$CTSDBHash[$CTSCurrentKey].CompletedOptions = $CompletedOptions

				if ( ( $RequestedOptions -eq $CompletedOptions ) ) {
					$CTSLogger.WriteInformation("All requested post-migration activities have been completed without error for database [$($TargetDatabase)] on [$($TargetServerInstance)].")
					$CTSDBHash[$CTSCurrentKey].CurrentState = "PostMigrationComplete"
				}
				else {
					[int]$CTSNbrRequestedActivites = 0
					[int]$CTSNbrCompletedActivites = 0
					$CTSPostMigrationOptions.Keys | ForEach-Object {
						if ( $RequestedOptions -band $($CTSPostMigrationOptions.item($_)) ) { $CTSNbrRequestedActivites ++ }
						if ( $CompletedOptions -band $($CTSPostMigrationOptions.item($_)) ) { $CTSNbrCompletedActivites ++ }
					}
					
					$CTSLogger.WriteWarning("$($CTSNbrRequestedActivites - $CTSNbrCompletedActivites) out of $($CTSNbrRequestedActivites) requested post-migration activities reported an issue for database [$($TargetDatabase)] on [$($TargetServerInstance)].")
					$CTSDBHash[$CTSCurrentKey].CurrentState = "PostMigrationFailed"
				}

				$CTSDBHash[$CTSCurrentKey].PostMigrationEnd = Get-Date
				# $CTSDBHash | convertto-json
			}
			catch {
				$CTSDBHash[$CTSCurrentKey].CurrentState = "PostMigrationFailed"
				$CTSDBHash[$CTSCurrentKey].PostMigrationEnd = Get-Date
				$CTSLogger.WriteWarning("An error occurred while attempting to carry out post-migration activities for database [$($TargetDatabase)] on [$($TargetServerInstance)].")
				$CTSLogger.WriteWarning("An error occurred: $_")
			}
		}

		$CTSLogger.WriteInformation("End of post-migration activities for the requested array of target databases.")
		return
    }
    catch{
        #throw $_.Exception.Message     
		# $CTSLogger.WriteWarning("An error occurred: $ERROR[0]")
		$CTSLogger.WriteWarning("An error occurred: $_")
    }    
}
