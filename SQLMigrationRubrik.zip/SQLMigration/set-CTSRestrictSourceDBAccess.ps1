<#
****************************************************************************************************
 Author				:	Paul Stickland
 Date Written		:	20210715
 Modifications		:	
					:
 Description		:	This function attempts to restrict access to the database provided in the
                    :	parameters.
                    :   	- If the database is NOT participating in an availability group or
					:		  mirroring and is not already READ_ONLY, this attempts to set it to
					:		  READ_ONLY.
                    :   	- If the database is paricipating in an availability group or mirroring
					:		  and is not already in RESTRICTED_USER mode, this attempts to set it
                    :   	  to RESTRICTED_USER mode.
					:
                    :	DotNet ADO database connectivity has been chosen over Invoke-Sqlcmd as at
                    :	the time of writing ADO appears to better handle parameterisation such to
                    :	avoid potential SQL injection issues.  Where there is no other option
                    :	for some commands than to use dynamic SQL, parameters (the database name)
                    :	are wrapped inside the TSQL "quotename" function as a defence for SQL
                    :	injection.
 Usage              :            
                    :
 Dependencies       :   

****************************************************************************************************
#>

function set-CTSRestrictSourceDBAccess {

    Param(
		[parameter(Position = 1, Mandatory = $true)]
		[string]$CTSSourceServerInstance

		,[parameter(Position = 2, Mandatory = $true)]
		[string]$CTSSourceDatabase

		,[parameter(Position = 3, Mandatory = $true)]
		[CTSLogger]$CTSLogger
	)

    try{

		$CTSLogger.WriteInformation("Attempting to restrict access to the database [$($CTSSourceDatabase)] on [$($CTSSourceServerInstance)] ...")

		# Set up the SQL connection
		$SQLConn = New-Object System.Data.SqlClient.SqlConnection("Server = $CTSSourceServerInstance; Database = 'master'; Integrated Security = True;")

		# [array]$SQLMessages = $null

		$SQLHandler = [System.Data.SqlClient.SqlInfoMessageEventHandler] {
			param(
				$sender
				,$event
			)
			
			# $SQLMessages += $event.Message
			$CTSLogger.WriteInformation("SQL | $($event.Message)")
		};

		$SQLConn.add_InfoMessage($SQLHandler);
		$SQLConn.FireInfoMessageEventOnUserErrors = $true;

		$SQLConn.Open()

		# Prepare SQL command to check and carry out recovery if the database needs to be recovered
		$SQLCMD = New-Object System.Data.SqlClient.SqlCommand
		$SQLCMD.Connection = $SQLConn
		$SQLCMD.CommandTimeout = 0

		$SQLQuery = "set nocount on; exec sp_executesql N'

			set nocount on;

			declare
				@errorMessage NVarChar(800)
				,@errorNumber int
				,@errorSeverity int
				,@errorState int
				,@errorLine int
				,@errorProcedure NVarChar(255)
			;

			begin try

				declare
					@DBState tinyint = null
					,@DBUserAccess tinyint = null
					,@DBIsReadOnly bit = null
					,@SQLQuery nvarchar(4000) = null
					,@DBNameUnQuoted sysname = null
					,@DBNameQuoted sysname = null
					,@DBNameLocalQuoted sysname = quotename( @DBNameLocal )
					,@InstanceName sysname = quotename( @@servername )
					,@DBInAGOrMirror bit = null
				;
				select
					@DBNameUnQuoted = name
					,@DBNameQuoted = quotename( name )
					,@DBState = state
					,@DBUserAccess = user_access
					,@DBIsReadOnly = is_read_only
				from sys.databases
				where name = @DBNameLocal;

				if exists
				(
					select 1
					from sys.availability_groups as g
						inner join sys.availability_databases_cluster as dc
							on dc.group_id = g.group_id
					where dc.database_name = @DBNameUnQuoted
					union all
					select 1
					from sys.database_mirroring
					where database_id = db_id(@DBNameUnQuoted)
						and mirroring_guid is not null
					)
				begin
					set @DBInAGOrMirror = 1;
				end
				else
				begin
					set @DBInAGOrMirror = 0;
				end;

				if @DBNameUnQuoted is null
				begin
					raiserror( ''The database %s on %s cannot be found.  No change made.'', 0, 0, @DBNameLocalQuoted, @InstanceName ) with nowait;
				end
				else
				begin
					if @DBState = 0
					begin
						if @DBIsReadOnly = 1
							and @DBUserAccess = 2
						begin
							raiserror( ''The database %s on %s is online, already READ_ONLY and set to RESTRICTED_USER mode.  No change made.'', 0, 0, @DBNameQuoted, @InstanceName ) with nowait;
							select DBRestrictionType = cast(3 as tinyint);
						end
						else if @DBIsReadOnly = 1
						begin
							raiserror( ''The database %s on %s is online and already READ_ONLY.  No change made.'', 0, 0, @DBNameQuoted, @InstanceName ) with nowait;
							select DBRestrictionType = cast(1 as tinyint);
						end
						else
						begin
							if @DBInAGOrMirror = 0
							begin
								raiserror( ''Attempting to set database %s on %s to READ_ONLY ...'', 0, 0, @DBNameQuoted, @InstanceName ) with nowait;

								if @DBUserAccess = 2
								begin
									set @SQLQuery = N''alter database '' + @DBNameQuoted + N'' set single_user with rollback immediate;'';
									set @SQLQuery = @SQLQuery + N''  alter database '' + @DBNameQuoted + N'' set read_only;'';
									set @SQLQuery = @SQLQuery + N''  alter database '' + @DBNameQuoted + N'' set restricted_user;'';
								end
								else
								begin
									set @SQLQuery = N''alter database '' + @DBNameQuoted + N'' set single_user with rollback immediate;'';
									set @SQLQuery = @SQLQuery + N''  alter database '' + @DBNameQuoted + N'' set read_only;'';
									set @SQLQuery = @SQLQuery + N''  alter database '' + @DBNameQuoted + N'' set multi_user;'';
								end;

								raiserror( @SQLQuery, 0, 0) with nowait;

								exec ( @SQLQuery );

								select
									@DBUserAccess = user_access
									,@DBIsReadOnly = is_read_only
								from sys.databases
								where name = @DBNameUnQuoted;

								if @DBIsReadOnly = 1
								begin
									if @DBUserAccess = 2
									begin
										select DBRestrictionType = cast(3 as tinyint);
									end
									else
									begin
										select DBRestrictionType = cast(1 as tinyint);
									end;
								end
								else
								begin
									raiserror( ''An issue occurred when attempting to set database %s on %s to READ_ONLY.'', 0, 0, @DBNameQuoted, @InstanceName ) with nowait;
								end;
							end
							else
							begin
								raiserror( ''The database %s on %s is participating in an availability group or database mirroring.'', 0, 0, @DBNameQuoted, @InstanceName ) with nowait;

								if @DBUserAccess = 2
								begin
									raiserror( ''The database %s on %s is already set to RESTRICTED_USER mode.  No change made.'', 0, 0, @DBNameQuoted, @InstanceName ) with nowait;
									select DBRestrictionType = cast(2 as tinyint);
								end
								else
								begin
									raiserror( ''Attempting to set database %s on %s to RESTRICTED_USER mode ...'', 0, 0, @DBNameQuoted, @InstanceName ) with nowait;

									set @SQLQuery = N''alter database '' + @DBNameQuoted + N'' set RESTRICTED_USER;'';

									raiserror( @SQLQuery, 0, 0) with nowait;

									exec ( @SQLQuery );

									if exists
									(
										select 1
										from sys.databases
										where name = @DBNameUnQuoted
											and user_access = 2
									)
									begin
										raiserror( ''The database %s on %s has been set to RESTRICTED_USER mode.'', 0, 0, @DBNameQuoted, @InstanceName ) with nowait;
										select DBRestrictionType = cast(2 as tinyint);
									end
									else
									begin
										raiserror( ''An issue occurred when attempting to set database %s on %s to RESTRICTED_USER mode.'', 0, 0, @DBNameQuoted, @InstanceName ) with nowait;
									end;
								end;
							end;
						end;
					end
					else
					begin
						raiserror( ''The database %s on %s is not currently online.  No change made.'', 0, 0, @DBNameQuoted, @InstanceName ) with nowait;
					end;
				end;
			end try

			begin catch
				select
					@errorNumber = error_number()
					,@errorSeverity = error_severity()
					,@errorState = error_state()
					,@errorLine = error_line()
					,@errorProcedure = isnull(''procedure '' + error_procedure(), ''the query batch'')
					;
				
					select
						@errorMessage = N''Error %d, Level %d, state %d, in %s, at line %d.'' +
						''  The underlying message was: ''+ error_message();

				if @@TRANCOUNT > 0 rollback transaction;

				raiserror(
					@errorMessage
					,@errorSeverity
					,1
					,@errorNumber
					,@errorSeverity
					,@errorState
					,@errorProcedure
					,@errorLine
				);
			end catch
		', N'@DBNameLocal sysname', @DBName"

		$SQLParam1 = New-Object System.Data.SqlClient.SqlParameter("@DBName",[Data.SQLDBType]::NVarChar, 128)
		$SQLParam1.Value = $CTSSourceDatabase
		$SQLCMD.CommandText = $SQLQuery
		$SQLCMD.Parameters.Add($SQLParam1) | Out-Null
		
		# Execute the SQL recovery command
		$SQLCMDOutput = [int]$SQLCMD.ExecuteScalar()
		$SQLCMD.StatementCompleted

		# Check the result of the SQL recovery command
		switch ( $SQLCMDOutput ) {
			1 {
				$CTSLogger.WriteInformation("The database [$($CTSSourceDatabase)] on [$($CTSSourceServerInstance)] is in READ_ONLY mode.")
				break
			}

			2 {
				$CTSLogger.WriteInformation("The database [$($CTSSourceDatabase)] on [$($CTSSourceServerInstance)] is in RESTRICTED_USER mode.")
				break
			}

			3 {
				$CTSLogger.WriteInformation("The database [$($CTSSourceDatabase)] on [$($CTSSourceServerInstance)] is in READ_ONLY and RESTRICTED_USER modes.")
				break
			}

			default {
				$CTSLogger.WriteWarning("An issue occurred when attempting to restrict access to database [$($CTSSourceDatabase)] on [$($CTSSourceServerInstance)].  No setting has been changed.")
				break
			}
		}

		$SQLCMD.Dispose()
		Clear-Variable SQLParam1
		Clear-Variable SQLCMD
		Clear-Variable SQLQuery
		Clear-Variable SQLCMDOutput
	
		$SqlConn.Dispose()

		$CTSLogger.WriteInformation("End of attempting to restrict access to the database [$($CTSSourceDatabase)] on [$($CTSSourceServerInstance)].")
		return $RequestedOptionsResult
    }
    catch{
        #throw $_.Exception.Message     
		# $CTSLogger.WriteWarning("An error occurred: $ERROR[0]")
		$CTSLogger.WriteWarning("An error occurred: $_")
    }    
}
