﻿####################################
#  DBA TEAM
#  14/06/2018
####################################

param
(
#    [String] $server_name
	[Parameter(Position=0)]
	[string] $patch_name
	,[Parameter(Position=1)]
	[string] $installation_source_file
)

$server_name = (get-item env:COMPUTERNAME).value;

$destination_local_path = "C:\SQL2014\"
$install_file_full_local_path = $destination_local_path + $installation_source_file

$log_file = $destination_local_path + "LogFile_" + $server_name + "_" + $patch_name + ".txt"

$install_file_command = "cmd.exe /c '$install_file_full_local_path /quiet /IAcceptSQLServerLicenseTerms /action=Patch /allinstances'"
$install_file_command_sb = [scriptblock]::Create( $install_file_command )

Write-Output "$patch_name installation process on $server_name"

Add-Content -Path $log_file "Start Time:  $(Get-Date)"
Add-Content -Path $log_file "$patch_name installation process on $server_name"

# apply the patch
Write-Output "$patch_name installation in progress ..."
Add-Content -Path $log_file "$patch_name installation started ..."

#action=Patch/RemovePatch
Invoke-Command -ScriptBlock $install_file_command_sb -ErrorVariable errmsg 2>$null

if ($errmsg) {
	Add-Content -Path $log_file $errmsg
}

# Delete the installation file
Remove-Item $install_file_full_local_path
Write-Output "Installation file deleted: $install_file_full_local_path"
Add-Content -Path $log_file "Installation file deleted: $install_file_full_local_path"

Write-Output "$patch_name installation on $server_name successfully completed`n"
Add-Content -Path $log_file "$patch_name installation on $server_name successfully completed"
Add-Content -Path $log_file "End Time:  $(Get-Date)"
