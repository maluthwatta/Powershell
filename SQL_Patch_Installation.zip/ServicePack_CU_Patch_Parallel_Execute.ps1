#
# Based on http://www.maxtblog.com/2012/01/quickblog-use-powershell-to-submit-sqlservicepack-job-to-multiple-server/
# Tips from the following links:
#  https://blogs.technet.microsoft.com/uktechnet/2016/06/20/parallel-processing-with-powershell/
#  https://blogs.technet.microsoft.com/heyscriptingguy/2010/03/18/hey-scripting-guy-how-can-i-receive-all-windows-powershell-jobs/
#  https://blogs.technet.microsoft.com/ashleymcglone/2016/08/30/powershell-remoting-kerberos-double-hop-solved-securely/
#  http://www.get-blog.com/?p=22


<#

##################################################################################################################
# The following is a workaround for when using Powershell V2, suggested at:
#
# http://www.leeholmes.com/blog/2008/07/30/workaround-the-os-handles-position-is-not-what-filestream-expected/
#
# to handle an issue when calling robocopy and / or having multiple ways to handle error logging as follows:

# The OS handle's position is not what FileStream expected. Do not use a handle simultaneously in one FileStream
# and in Win32 code or another FileStream. This may cause data loss.


$bindingFlags = [Reflection.BindingFlags] "Instance,NonPublic,GetField"
$objectRef = $host.GetType().GetField("externalHostRef", $bindingFlags).GetValue($host)

$bindingFlags = [Reflection.BindingFlags] "Instance,NonPublic,GetProperty"
$consoleHost = $objectRef.GetType().GetProperty("Value", $bindingFlags).GetValue($objectRef, @())

[void] $consoleHost.GetType().GetProperty("IsStandardOutputRedirected", $bindingFlags).GetValue($consoleHost, @())
$bindingFlags = [Reflection.BindingFlags] "Instance,NonPublic,GetField"
$field = $consoleHost.GetType().GetField("standardOutputWriter", $bindingFlags)
$field.SetValue($consoleHost, [Console]::Out)
$field2 = $consoleHost.GetType().GetField("standardErrorWriter", $bindingFlags)
$field2.SetValue($consoleHost, [Console]::Out)
##################################################################################################################

#>

# Increase the width of the buffer to stop redirected output from wrapping at 80 chars
# from https://stackoverflow.com/questions/978777/powershell-output-column-width
$Host.UI.RawUI.BufferSize = New-Object Management.Automation.Host.Size (256, 25)

$ScriptStartTime = $(Get-Date);
Write-Output "Script start time: $ScriptStartTime`n"

#############################
### CONFIGURATION SECTION ###
#############################

$servers = @()
$servers += "MyWindowsMachine1"
$servers += "MyWindowsMachine2"
$servers += "MyWindowsMachine3"
$servers += "AndSoOn"

$patch_name = "SQL2014_SP2_CU11"
$psExtractorFileName = "ServicePack_CU_Patch_Install.ps1"
$installation_source_file = "sqlserver2014-kb4077063-x64_b7f6242123ada2ce655beba2db38a02155313855.exe"
$installation_source_path = "\\Oceania\cts\DEPTDATA\Infrastructure\melsoftware\OS\SQL\SQL2014-SP2-CUs\SQL2014-SP2-CU11\"

$script_directory = "\\Oceania\cts\DEPTDATA\GPandD\DBA\DBA_DeptData\PSScripts\SQL_Patch_Automation\SQL2014_SP2_CU11\"
$log_directory = "\\Oceania\cts\DEPTDATA\GPandD\DBA\DBA_DeptData\PSScripts\SQL_Patch_Automation\SQL2014_SP2_CU11\ScriptLog\"
$destination_unc_path_part = "C$\SQLInstalls\SQLPatching\"
$ConcurrentFileCopies = 2;

#############################

$psExtractorLongName = $script_directory + $psExtractorFileName

Write-Output "Servers to upgrade:"
$servers

#$psExtractorLongName
#$psExtractorLongNameLog

#Calculate the number of servers per batch based on the number of concurrent batches we can run on the management server
$ServersPerBatch = [math]::ceiling($servers.Count / $ConcurrentFileCopies);

#$ServersPerBatch;

$ServerStart = 0;
$ServerEnd = $ServersPerBatch - 1;
$CurrentBatch = 1;

### We need to handle the file copy from the scheduling server.
### If we wanted to get each target SQL server to do it's own file copy, in AD for the source file server we would
### need to permit impersonation from every target SQL Server.  That imposes additional management for each new
### SQL Server created so for running this a couple of times a year it's not worth the effort (at this stage).

$RobocopyStartTime = $(Get-Date);
Write-Output "`n"
Write-Output "Robocopy start time: $RobocopyStartTime`n"

# Create an array to hold the Robocopy jobs
$RobocopyJobArray = New-Object -TypeName System.Collections.ArrayList


# We're going to run batches of file copies in parallel, with up to $ConcurrentFileCopies number of parallel
# batches.  The available network bandwidth will likely suggest we keep this number of concurrent batches
# somewhere between 2 and 4.  Within each batch we will serially run file copies for a subset of servers, one
# after another. Some examples:
#  (1) If we're copying to 2 servers and have $ConcurrentFileCopies = 4, we'll end up with 2 parallel batches
#      each with one file copy.
#  (2) If we're copying to 6 servers and have $ConcurrentFileCopies = 4, we'll end up with 3 batches with 2
#      serial file copies in each batch.
#  (2) If we're copying to 10 servers and have $ConcurrentFileCopies = 4, we'll end up with 4 batches with 3
#      serial file copies in 3 batches and 1 file copy in the 4th batch.
# Yeah it doesn't scale out as evenly as it could at the moment, but it's a start.

while ($ServerStart -lt $servers.Count) {
    $ServerBatch = $servers[$ServerStart..$ServerEnd];
    $JobName = "InstallerFileCopyBatch$CurrentBatch";
    #$ServerBatch
    #$JobName
    # Start a file copy batch and add the job to the Robocopy job array
    $RobocopyJobArrayID = $RobocopyJobArray.Add((start-job -Name $JobName -ScriptBlock {
        param (
            [array[]]$servers
            ,[string]$installation_source_path
            ,[string]$destination_unc_path_part
            ,[string]$installation_source_file
            ,[string]$install_file_full_unc_path
        )
        foreach ($server_name in $servers) {
            #$installation_source_path = "\\Oceania\cts\DEPTDATA\Infrastructure\melsoftware\OS\SQL\SQL2014-SP2-CUs\SQL2014-SP2-CU10\"
            #$destination_unc_path = "\\$server_name\C$\SQLInstalls\SQLPatching\"
            #$installation_source_file = "sqlserver2014-kb4052725-x64_c05851c9f4a802b06079034e48118be729b561e2.exe"
            $destination_unc_path = "\\$server_name\$destination_unc_path_part"
            $install_file_full_unc_path = $destination_unc_path + $installation_source_file
            #$install_file_full_unc_path

            # if destination_unc_path folder does not exist, create it.
            If(!(test-path $destination_unc_path))
            {
                New-Item -ItemType Directory -Force -Path $destination_unc_path
                Write-Output "$destination_unc_path folder created for $server_name"
                #Add-Content -Path $log_file "$destination_unc_path folder created for $server_name"
            }

            # if installation file exists skip copying.
            If(!(test-path $install_file_full_unc_path))
            {
                Write-Output "Copying $installation_source_file to $destination_unc_path for $server_name"
                #Add-Content -Path $log_file "Copying $installation_source_file to $destination_unc_path for $server_name"
                robocopy /np $installation_source_path $destination_unc_path $installation_source_file
                Write-Output "File copying complete for $server_name"
                #Add-Content -Path $log_file "File copying complete for $server_name"
            }
            else
            {
                Write-Output "Installation file already exists at $destination_unc_path for $server_name"
                #Add-Content -Path $log_file "Intallation file already exists at $destination_local_path for $server_name"
            }
        }
    } -ArgumentList ($ServerBatch, $installation_source_path, $destination_unc_path_part, $installation_source_file, $install_file_full_unc_path)
    ))

    $CurrentBatch += 1;
    $ServerStart = $ServerEnd + 1;
    $ServerEnd += $ServersPerBatch;

    if ($ServerStart -gt $servers.Count) {$ServerStart = $servers.Count};
    if ($ServerEnd -gt $servers.Count) {$ServerEnd = $servers.Count};
}

#$RobocopyJobs = Get-Job -Command "*robocopy*";
#$RobocopyJobs = Get-Job -name "InstallerFileCopyBatch*";

#$RobocopyJobs
Write-Output "Robocopy jobs:"
$RobocopyJobArray | format-table -Property ID, Name, State, HasMoredata, StatusMessage, Location, JobStateInfo, PSBeginTime, PSEndTime -AutoSize | Out-String -Width 256

# Check the Robocopy job array until all jobs have completed
$AllJobsComplete = $false;
while (-not $AllJobsComplete) {
    #$JobsInProgress = $RobocopyJobs | Where-Object { $_.state-match 'running'}
    $JobsInProgress = $RobocopyJobArray | Where-Object { $_.state-match 'running'}
    if (-not $JobsInProgress) {$AllJobsComplete = $true}
        else { $RobocopyJobArray | format-table -Property ID, Name, State, HasMoredata, StatusMessage, Location, JobStateInfo, PSBeginTime, PSEndTime -AutoSize | Out-String -Width 256 ; Start-Sleep -Seconds 5 }
}

Write-Output "Robocopy jobs:"
$RobocopyJobArray | format-table -Property ID, Name, State, HasMoredata, StatusMessage, Location, JobStateInfo, PSBeginTime, PSEndTime -AutoSize | Out-String -Width 256

# Retrieve the output of all the Robocopy jobs and then remove all the Robocopy jobs
$RobocopyJobArray | receive-job
$RobocopyJobArray | Remove-Job


$RobocopyEndTime = $(Get-Date);
Write-Output "Robocopy start time: $RobocopyStartTime | Robocopy end time: $RobocopyEndTime`n";


$psExtractorRun = ". " + $psExtractorLongName
$psExtractorSB = [scriptblock]::Create( "$psExtractorRun" )

# Start a Powershell session on each target server
$Jobsession = New-PSSession -Computername $servers;

write-output "Job sessions:"

## - display the sessions:
$Jobsession

$PatchInstallStart = $(Get-Date);
Write-Output "Install start time: $PatchInstallStart`n";

$InstallSQLServicePackCUOrPatchJobParent = New-Object -TypeName System.Collections.ArrayList


## - Submit jobs to background process on selected servers:
$InstallJobArrayID = $InstallSQLServicePackCUOrPatchJobParent.Add(( Invoke-Command -Session $Jobsession -AsJob -JobName 'InstallSQLServicePackCUOrPatch' -FilePath $psExtractorLongName -ArgumentList $patch_name, $installation_source_file ))

Write-Output "Installation job parent:"
$InstallSQLServicePackCUOrPatchJobParent | format-table -Property ID, Name, State, HasMoredata, StatusMessage, Location, JobStateInfo, PSBeginTime, PSEndTime -AutoSize | Out-String -Width 256

## Get the full list of parent and child jobs
$InstallSQLServicePackCUOrPatchJobs = (Get-Job -id ($InstallSQLServicePackCUOrPatchJobParent[$InstallJobArrayID]).ID -IncludeChildJob);

Write-Output "Installation jobs:"
$InstallSQLServicePackCUOrPatchJobs | format-table -Property ID, Name, State, HasMoredata, StatusMessage, Location, JobStateInfo, PSBeginTime, PSEndTime -AutoSize | Out-String -Width 256

$AllJobsComplete = $false;

# Loop until all installation jobs have completed
while (-not $AllJobsComplete) {
    # Get an array of jobs that are running
    $JobsInProgress = $InstallSQLServicePackCUOrPatchJobs | Where-Object { $_.state-match 'running'}

    # Get an array of child jobs that are not running
    $JobsCompleted = $InstallSQLServicePackCUOrPatchJobs | Where-Object { $_.State-notmatch 'running' -and (-not $_.ChildJobs) -and ($_.HasMoreData-match 'true') }

    # Get an array of servers for which the job has completed
    $CompletedServers = $JobsCompleted.Location

    # If there are completed servers, for each completed server:
    #  - retrieve the output
    #  - remove the session
    #  - restart the server
    if ($CompletedServers) {
        $JobsCompleted | Receive-Job

        Remove-PSSession -ComputerName $CompletedServers

		# Wait for a period before restarting the completed servers to try to avoid the following error:
		# #Failed to restart the computer with the following error message: Illegal operation attempted on a registry key that has been marked for deletion#
        Start-Sleep -Seconds 5

        Write-Output "Restarting server(s): $CompletedServers`n"
        #Restart-Computer -ComputerName $CompletedServers -Force
		# restart-computer is a WMI based command which utilises RPC
		# RPC relies on random ports which in turn requires an array of firewall ports to be opened
		# that's not very friendly for use in Azure or in the DMZ
        # Using invoke-command allows us to restart computers in Azure without having to configure the array of firewall ports used by RPC
        # Otherwise known as WMI Tunneling Through PowerShell Remoting
        Invoke-Command -Computername $CompletedServers -Scriptblock { Restart-Computer -Force }
    }

    # If there's no more jobs in progress, we're ready to exit, otherwise wait for a period and then check again
    if (-not $JobsInProgress) {
            $AllJobsComplete = $true
        }
        else {
            Start-Sleep -Seconds 5
        }
}


Write-Output "Installation jobs:"
$InstallSQLServicePackCUOrPatchJobs | format-table -Property ID, Name, State, HasMoredata, StatusMessage, Location, JobStateInfo, PSBeginTime, PSEndTime -AutoSize | Out-String -Width 256


$InstallSQLServicePackCUOrPatchJobParent | Remove-Job

$PatchInstallEnd = $(Get-Date);
Write-Output "Install start time: $PatchInstallStart | Install end time: $PatchInstallEnd`n";

## - To Close PS Sessions and remove variables:
Remove-PSSession $Jobsession
Remove-Variable Jobsession

Write-Output "Job session removed.`n";

Write-Output "Please check for each server upgrade attempted the SQL Server Setup Bootstrap Summary.txt file.`n";

$ScriptEndTime = $(Get-Date);
Write-Output "Script start time: $ScriptStartTime | Script end time: $ScriptEndTime`n";
