$/DBA OCEANIA/Development/Scripts/PSScripts/SQL_Patch_Automation/Parallel_Installation_Template

This folder contains the template files for the parallel installation of a Service Pack / CU to multiple Windows machines.
The above location within the GLobal TFS collection is the only place that will contain supported updates to this patch
automation solution.


-----------------------------------------------------
Run_ServicePack_CU_Patch_Parallel_Execute_Install.xml
-----------------------------------------------------
This the is Windows Scheduler job template.


-----------------------------------------------------
Run_ServicePack_CU_Patch_Parallel_Execute_Install.bat
-----------------------------------------------------
This is the batch file called by the Windows Scheduler job.


-----------------------------------------
ServicePack_CU_Patch_Parallel_Execute.ps1
-----------------------------------------
This is the main powershell script that will push the installation across "n" machines.


--------------------------------
ServicePack_CU_Patch_Install.ps1
--------------------------------
This is the powershell script pushed from the main script to each windows machine to execute the installation.


-------------
Configuration
-------------
You will see in the configurable variables sections of the PS scripts that this template is based on a SQL 2014 SP2 CU11.
The scripts can be configured to install any Service Pack / CU.
The $patch_name variable is used purely for recording in the output log file.
This patch process is designed to upgrade ALL instances for the target version that reside on a nominated Windows machine.
You *CANNOT* elect to only patch a subset of instances.


--------------------------------------
A note on the parallel copying section
--------------------------------------
You will notice a variable called $ConcurrentFileCopies.  As the name suggests, this restricts the number of concurrent file copies.
You may ask "Why are we copying the installation files?".  As the job will run from a management server, the source
installation file is on a file server and then we have a destination server (one or more), we end up with a multi-hop situation.
This is similar to that which we experience with applications initiating a bulk load of a data file stored on a file server
into a 3rd server being the SQL Server.  For SQL Server we cater for this with SPN's for the service account running SQL Server.
In order to enable a similar thing for this SP/CU installation, we'd have to enable "trusted for impersonation" for every target
windows server.  At the time of writing that seemed impractical, so instead we copy the source file from the file server
to each target windows server.
Getting back to the parallel copying, $ConcurrentFileCopies exists to restrict the number of file copies so as not to overload
the NIC's on the management server and file server.  Somewhere between 2 and 4 seems to be about right for a 1Gbit NIC.  If
you have larger NIC's available, increase accordingly to find the sweet spot.


--------------------------------------------------
Methodology for standalone replicated VM instances
--------------------------------------------------
Automated installation began ~ 2am


---------------------------
Methodology for AG clusters
---------------------------
It's recommended to follow the rolling upgrade process as documented at https://docs.microsoft.com/en-us/sql/database-engine/availability-groups/windows/upgrading-always-on-availability-group-replica-instances?view=sql-server-2016.
One node was done on one day, the second node the following day
Failovers were done prior to business hours
Installation was done during business hours via manual initiation of the windows scheduler job


---------------------------------
Methodology for failover clusters
---------------------------------
It's recommended to follow the rolling updates process as documented https://support.microsoft.com/en-us/help/958734/sql-server-failover-cluster-rolling-patch-and-service-pack-process.
One node was done on one day, the second node the following day
Failovers were done prior to business hours
Installation was done during business hours via manual initiation of the windows scheduler job


-----------------------------------
Patching folder structure (example)
-----------------------------------
Under our team folder on the GP&D file share we have a folder called "SQL_Patch_Automation".  Under that we create a folder for
each SP / CU / Security Patch that we deploy.  Within each patch folder we have "n" tranche folders.  A tranche may update a
series of replicated VM's, or it may update one or more VM's being used to host secondary AG's or act as passive failover
cluster nodes.  Each tranche folder contains a ScriptLog folder.  Here a log of an execution is recorded.

Here's an example based on OCEANIA Dev usage:

SQL_Patch_Automation
	-> SQL2014_SP3
		-> Tranche01
			-> ScriptLog
		-> Tranche02
			-> ScriptLog
		...
	-> SQL2014-SP3-CU3-Plus-CVE-2019-1068
		-> Tranche01
			-> ScriptLog
		-> Tranche02
			-> ScriptLog
		-> Tranche03
			-> ScriptLog
		...
	-> SQL2016_SP2
		-> Tranche01
			-> ScriptLog
		-> Tranche02
			-> ScriptLog
		-> Tranche03
			-> ScriptLog
		...
	-> SQL2016-SP2-CU7-Plus-CVE-2019-1068
		-> Tranche01
			-> ScriptLog
		-> Tranche02
			-> ScriptLog
		-> Tranche03
			-> ScriptLog
		...

	...

We tend to keep a single ServicePack_CU_Patch_Install.ps1 script in the patch level folder (eg. SQL2014_SP3, SQL2016_SP2) and
reference that from the main ServicePack_CU_Patch_Parallel_Execute.ps1 script within each tranche folder.
A tranche folder contains the Windows Scheduler job template, batch file, and powershell script, all of which have been updated
with appropriate target paths and servers.

While a deployment is running, one can open the log file contained within the ScriptLog folder and follow progress by
re-loading it in your favourite text editor.
