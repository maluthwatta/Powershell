-- sys.dm_hadr_availability_group_states provides health information for the AG as well as for the node you�re executing your query against as shown in the following query
SELECT ag_name
     , primary_replica
     , primary_recovery_health_desc
     , secondary_recovery_health_desc
     , synchronization_health_desc
FROM sys.dm_hadr_availability_group_states AS hadrAGS
     INNER JOIN sys.dm_hadr_name_id_map AS hadrNIM
          ON hadrAGS.group_id = hadrNIM.ag_id;


SELECT *
FROM sys.dm_hadr_database_replica_cluster_states
WHERE is_failover_ready = 0;


-- The following query provides a snapshot of database-level health for all AGs on a SQL instance, rationalizing identifying IDs for all objects to their name
-- You want to see zero (0) rows returned from this query.
SELECT hadrNIM.ag_name
     , hadrARCS.replica_server_name
     , hadrDRCS.[database_name]
     , hadrDRS.is_local
     , hadrDRS.synchronization_state_desc
     , hadrDRS.synchronization_health_desc
     , hadrDRS.database_state_desc
     , hadrDRS.is_suspended
     , hadrDRS.suspend_reason_desc
     , hadrDRS.last_sent_time
     , hadrDRS.last_received_time
     , hadrDRS.last_hardened_time
     , hadrDRS.last_redone_time
     , hadrDRS.last_commit_time
     , hadrDRS.log_send_queue_size
     , hadrDRS.log_send_rate
FROM sys.dm_hadr_database_replica_states AS hadrDRS
     INNER JOIN sys.dm_hadr_name_id_map AS hadrNIM
          ON hadrDRS.group_id = hadrNIM.ag_id
     INNER JOIN sys.dm_hadr_database_replica_cluster_states AS hadrDRCS
          ON hadrDRS.group_database_id = hadrDRCS.group_database_id
     INNER JOIN sys.dm_hadr_availability_replica_cluster_states AS hadrARCS
          ON hadrDRS.replica_id = hadrARCS.replica_id
where synchronization_state_desc <> 'SYNCHRONIZED'
ORDER BY hadrNIM.ag_name
     , hadrDRCS.[database_name]
     , hadrDRS.is_local;

-- The following query provides a snapshot of database-level health for all AGs on a SQL instance, rationalizing identifying IDs for all objects to their name
-- Same as the query immediately above but without the check for un-synchronised databases
SELECT hadrNIM.ag_name
     , hadrARCS.replica_server_name
     , hadrDRCS.[database_name]
     , hadrDRS.is_local
     , hadrDRS.synchronization_state_desc
     , hadrDRS.synchronization_health_desc
     , hadrDRS.database_state_desc
     , hadrDRS.is_suspended
     , hadrDRS.suspend_reason_desc
     , hadrDRS.last_sent_time
     , hadrDRS.last_received_time
     , hadrDRS.last_hardened_time
     , hadrDRS.last_redone_time
     , hadrDRS.last_commit_time
     , hadrDRS.log_send_queue_size
     , hadrDRS.log_send_rate
FROM sys.dm_hadr_database_replica_states AS hadrDRS
     INNER JOIN sys.dm_hadr_name_id_map AS hadrNIM
          ON hadrDRS.group_id = hadrNIM.ag_id
     INNER JOIN sys.dm_hadr_database_replica_cluster_states AS hadrDRCS
          ON hadrDRS.group_database_id = hadrDRCS.group_database_id
     INNER JOIN sys.dm_hadr_availability_replica_cluster_states AS hadrARCS
          ON hadrDRS.replica_id = hadrARCS.replica_id
ORDER BY hadrNIM.ag_name
     , hadrDRCS.[database_name]
     , hadrDRS.is_local;
