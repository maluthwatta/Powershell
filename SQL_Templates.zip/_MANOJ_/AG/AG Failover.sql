SELECT ag_name
     , primary_replica
     , primary_recovery_health_desc
     , secondary_recovery_health_desc
     , synchronization_health_desc
FROM sys.dm_hadr_availability_group_states AS hadrAGS
     INNER JOIN sys.dm_hadr_name_id_map AS hadrNIM
          ON hadrAGS.group_id = hadrNIM.ag_id;

/*


--#1 - Change failover mode from automatic to manual for all replicas
use master

alter availability group DEVSQLAG36L01
       modify replica on 'MELYVDEVSQL36\INS1'
       with ( failover_mode = manual );

alter availability group DEVSQLAG36L01
       modify replica on 'MELDVDEVSQL36\INS1'
       with ( failover_mode = manual );

--#2 - Check that failover mode is now manual for both replicas
select replica_server_name,failover_mode_desc,* from sys.availability_replicas;



--#3 - Change failover mode from manual to automatic for all replicas
alter availability group DEVSQLAG36L01
       modify replica on 'MELYVDEVSQL36\INS1'
       with ( failover_mode = automatic );


alter availability group DEVSQLAG36L01
       modify replica on 'MELDVDEVSQL36\INS1'
       with ( failover_mode = automatic );



--#4 - Check that failover mode is now automatic for both replicas
select replica_server_name,failover_mode_desc,* from sys.availability_replicas;
