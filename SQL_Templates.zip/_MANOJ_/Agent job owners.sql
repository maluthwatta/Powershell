/* Find agent jobs not owned by sa */
SELECT name JobName, SUSER_SNAME(owner_sid) JobOwner FROM msdb..sysjobs where owner_sid in 
(SELECT owner_sid FROM msdb..sysjobs where  SUSER_SNAME(owner_sid) != 'sa')



/* Change the agent job ownership*/
DECLARE @name_holder VARCHAR(1000)
DECLARE My_Cursor CURSOR
FOR
SELECT [name] FROM msdb..sysjobs where owner_sid in 
(SELECT owner_sid FROM msdb..sysjobs where  SUSER_SNAME(owner_sid) = 'OCEANIA\ZhangD')
OPEN My_Cursor
FETCH NEXT FROM My_Cursor INTO @name_holder
WHILE (@@FETCH_STATUS <> -1)
BEGIN
exec msdb..sp_update_job
        @job_name = @name_holder,
        @owner_login_name = 'CTS_DBA'
FETCH NEXT FROM My_Cursor INTO @name_holder
END 
CLOSE My_Cursor
DEALLOCATE My_Cursor