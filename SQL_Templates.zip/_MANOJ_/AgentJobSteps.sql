--Given job step id * the command
select *, CONVERT(binary(16), s.job_id) 
from msdb.dbo.sysjobsteps s inner join 
	msdb.dbo.sysjobs j on j.job_id = s.job_id
where s.step_id = 2
	and s.command like '%sys.sp_MScdc_capture_job%'