CREATE DATABASE SWT_Control_Dev
ON (NAME = SWT_Control_Dev, FILENAME = 'J:\V5_YF8K_NL_INS2_mpV_SQLData\SQLData\SWT\SWT_Control_Dev.mdf')
LOG ON (NAME = SWT_Control_Dev_log, FILENAME = 'J:\V1_YF8K_NL_INS2_mpV_SQLLog\SQLLog\SWT\SWT_Control_Dev_log.LDF')
FOR ATTACH