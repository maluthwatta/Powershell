select p.name from sys.server_role_members r inner join 
	sys.server_principals p on p.principal_id = r.member_principal_id
where role_principal_id = 10