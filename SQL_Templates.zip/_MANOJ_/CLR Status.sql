SELECT * FROM sys.configurations
WHERE name = 'clr enabled'