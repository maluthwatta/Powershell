declare @compress_option varchar(10)
set @compress_option = 'Page'
--set @compress_option = 'Row'

SET NOCOUNT ON 
if OBJECT_ID('tempdb..#index') is not null
drop table #index


select c.name as sch_name, b.name obj_name, a.name as index_name, a.indid,
dpages, convert(numeric(20,2),round(dpages*8/1024.,2)) as dpages_MB, 
reserved, convert(numeric(20,2),round(reserved*8/1024.,2)) as reserved_MB, 
rowcnt 
into #index 
from sys.sysindexes a 
inner join sysobjects b on a.id = b.id
inner join sys.schemas c on b.uid = c.schema_id
where b.type = 'U' and (a.name not like '_WA_Sys%' or a.name is null)
and convert(numeric(20,2),round(dpages*8/1024.,2)) > = 0 
order by dpages


IF OBJECT_ID('tempdb..#compression_error') is not null
drop table #compression_error


CREATE TABLE #compression_error 
(error_desc varchar(2000), 
err_number int, 
err_severity int, 
err_state int, 
err_procedure varchar(126), 
err_line int, 
err_message varchar(2048))

IF OBJECT_ID('tempdb..#datacompress') is not null
drop table #datacompress

create table #datacompress(
object_name	sysname
,schema_name	sysname
,index_id	int
,partition_number	int
,size_with_current_compression_setting_KB	bigint
,size_with_requested_compression_setting_KB 	bigint
,sample_size_with_current_compression_setting_KB bigint
,sample_size_with_requested_compression_setting_KB bigint)

--select * from #datacompress

DECLARE @compress_sql varchar(8000)

SET NOCOUNT ON 
DECLARE compress_cursor CURSOR FOR 
SELECT 
'
BEGIN TRY
INSERT INTO #datacompress EXEC sp_estimate_data_compression_savings 
    @schema_name = '''+c.name+''', 
    @object_name = '''+b.name+''', 
    @index_id = '+convert(varchar(10),a.indid)+', 
    @partition_number = NULL, 
    @data_compression = '''+@compress_option+''' ; 
END TRY
BEGIN CATCH
INSERT INTO #compression_error SELECT
	''['+c.name+'].['+b.name+'] failed in compression evaluation because the minimum row size plus internal overhead exceeds the maximum allowable table row size of 8060 bytes.'' AS Error_Desc
        ,ERROR_NUMBER() AS ErrorNumber
        ,ERROR_SEVERITY() AS ErrorSeverity
        ,ERROR_STATE() AS ErrorState
        ,ERROR_PROCEDURE() AS ErrorProcedure
        ,ERROR_LINE() AS ErrorLine
        ,ERROR_MESSAGE() AS ErrorMessage;
END CATCH;
'
from sys.sysindexes a 
inner join sysobjects b on a.id = b.id
inner join sys.schemas c on b.uid = c.schema_id
where b.type = 'U' and (a.name not like '_WA_Sys%' or a.name is null)
and convert(numeric(20,2),round(dpages*8/1024.,2)) > = 0 
order by dpages

OPEN compress_cursor;

FETCH NEXT FROM compress_cursor 
INTO @compress_sql;

WHILE @@FETCH_STATUS = 0
BEGIN

	exec (@compress_sql)
FETCH NEXT FROM compress_cursor 
    INTO @compress_sql;
END
CLOSE compress_cursor;
DEALLOCATE compress_cursor;

SET NOCOUNT OFF 