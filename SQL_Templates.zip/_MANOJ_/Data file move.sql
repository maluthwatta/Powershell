USE master 
GO

SELECT name, physical_name 
FROM sys.master_files 
WHERE database_id = DB_ID("Personnel");

ALTER DATABASE Personnel SET offline 
GO

ALTER DATABASE Personnel 
MODIFY FILE ( NAME = Personnel_Data, FILENAME = "C:\Data\Personnel_Data.mdf") 
GO

ALTER DATABASE database_name SET online 
GO
