SELECT name, suser_sname( owner_sid ) FROM sys.databases

--Change db owner
EXEC sp_changedbowner 'Albert';  
