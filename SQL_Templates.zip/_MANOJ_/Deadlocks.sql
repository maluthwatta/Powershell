Use Master 
SELECT
       xed.value('@timestamp', 'datetime') as Creation_Date,
       xed.query('.') AS Extend_Event
FROM
(
       SELECT CAST([target_data] AS XML) AS Target_Data
       FROM sys.dm_xe_session_targets AS xt
       INNER JOIN sys.dm_xe_sessions AS xs
       ON xs.address = xt.event_session_address
       WHERE xs.name = N'system_health'
       AND xt.target_name = N'ring_buffer'
) AS XML_Data
CROSS APPLY Target_Data.nodes('RingBufferTarget/event[@name="xml_deadlock_report"]') AS XEventData(xed)
ORDER BY Creation_Date DESC


------------------------------------------------------------------------------------------------------


select top 10 * from sys.dm_exec_query_stats

--top cached high readers
select top 100 db_name(dbid),text, execution_count, min_logical_reads, max_logical_reads,* from sys.dm_exec_query_stats Stat
cross apply sys.dm_exec_sql_text(stat.plan_handle) 
order by total_logical_reads DESC

Select * from sys.dm_exec_sql_text(0x03001000C8471A384922BE0053A200000100000000000000)
Select * from sys.dm_exec_query_plan(0x06005A00F1FD672340015D62010000000000000000000000)


16 - 0x050010007BE4A07F40A1CABB020000000000000000000000
6 -  0x05000600BCFF1A5140210B2B010000000000000000000000

select top 1 * from sys.dm_exec_cached_plans P  (nolock)
cross apply sys.dm_exec_sql_text(p.plan_handle) 
where text like N'%[GV_CWW].[dbo].[PACKAGE]%'

select * from sys.dm_exec_cached_plans P  (nolock)
cross apply sys.dm_exec_sql_text(p.plan_handle) 
where dbid=db_id('gv_cWw') and objType='Prepared'
order by usecounts desc


--------------------------------------
--Get object name from associatedObjectId 

SELECT OBJECT_NAME([object_id])
    FROM sys.partitions
    WHERE partition_id = 456489945132196