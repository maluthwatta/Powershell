use master

SELECT --TE.name AS [EventName] ,
        --V.subclass_name ,
              --T.startTime,
        --T.DatabaseName ,
              convert(varchar,T.startTime) startTime,
              T.TextData,
        T.ApplicationName,
              T.ClientProcessID,
              T.HostName,
              T.ServerName,
              T.LoginName
              --, *
       -- COUNT(*) AS TotalCount
FROM    dbo.fn_trace_gettable(( SELECT REVERSE(SUBSTRING(REVERSE(path),
                                                          CHARINDEX('\',
                                                              REVERSE(path)),
                                                          256)) + 'log.trc'
                                FROM    sys.traces
                                WHERE   is_default = 1
                              ), DEFAULT) T
        JOIN sys.trace_events TE ON T.EventClass = TE.trace_event_id
        JOIN sys.trace_subclass_values V ON V.trace_event_id = TE.trace_event_id
                                            AND V.subclass_value = T.EventSubClass
WHERE   --StartTime > DATEADD(mi,-40000,GETDATE()) AND 
TextData like '%AUBiztalkSvc_SIT%' 
--WHERE  TextData like '%SQLAGT_DEVSQLAG39I2%' 
--where StartTime > '2018-12-01 09:45' 
order by T.startTime desc

