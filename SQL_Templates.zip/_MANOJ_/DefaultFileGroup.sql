select df.name, df.physical_name,ds.name, ds.is_default
from sys.database_files df join sys.data_spaces ds    
	on df.data_space_id = ds.data_space_id