
--##################################

select 'drop user ' + '[' + name+ ']' from sys.database_principals
where type_desc IN ('WINDOWS_GROUP', 'WINDOWS_USER')
AND name NOT IN ('dbo')

--##################################



declare @sql nvarchar(max)
set @sql = ''

SELECT @sql = @sql+
'
print ''Dropping '+name+'''
drop user ['+name+'];
'
FROM
       sys.database_principals
WHERE
        name NOT IN('dbo','guest','INFORMATION_SCHEMA','sys','public')
        AND TYPE <> 'R'
order by
        name

print (@sql)
--execute (@sql)


