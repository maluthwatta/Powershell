use master

select *
from sys.dm_exec_procedure_stats AS d
where database_id = 16 and object_id = object_id('dbo.ja_SelectJobsForProcessing')


-- this one is handy when plans are coming back as null
select eqp.query_plan, query_plan_from_text = cast(eqpt.query_plan as xml), eqs.*
from sys.dm_exec_query_stats as eqs
	cross apply sys.dm_exec_query_plan ( eqs.plan_handle ) as eqp
	cross apply sys.dm_exec_text_query_plan( eqs.plan_handle, eqs.statement_start_offset, eqs.statement_end_offset) as eqpt
where eqs.sql_handle in
(
	select d.sql_handle
	from sys.dm_exec_procedure_stats AS d
	where d.object_id = object_id('dbo.p_CB_SearchStagingGenericSourceByImportFileID')
		and d.database_id = db_id()
)
order by eqs.last_execution_time desc


select eqp.query_plan, eqs.*
from sys.dm_exec_query_stats as eqs
	cross apply sys.dm_exec_query_plan ( eqs.plan_handle ) as eqp
where eqs.sql_handle in
(
	select d.sql_handle
	from sys.dm_exec_procedure_stats AS d
	where d.object_id = object_id('dbo.p_ESB_SearchPendingTransactionsByAccount')
		and d.database_id = db_id()
)
order by eqs.last_execution_time desc


select
	eqp.query_plan
	,statement_text = substring
		(
			st.text
			,( eqs.statement_start_offset / 2 ) + 1
			,
			(
				(
					CASE eqs.statement_end_offset
						WHEN -1 THEN DATALENGTH(st.text)
						ELSE eqs.statement_end_offset
					END - eqs.statement_start_offset
				) / 2
			) + 1
		)
	,eqs.*
from sys.dm_exec_query_stats as eqs
	cross apply sys.dm_exec_query_plan ( eqs.plan_handle ) as eqp
	cross apply sys.dm_exec_sql_text ( eqs.plan_handle ) as st
where eqs.sql_handle in
(
	select d.sql_handle
	from sys.dm_exec_procedure_stats AS d
	where d.object_id = object_id('dbo.p_ESB_SearchPendingTransactionsByAccount')
		and d.database_id = db_id()
)
order by eqs.last_execution_time desc




select * from sys.dm_exec_plan_attributes (0x050010001FA08C3A4001B13C010000000000000000000000)


select *
from sys.dm_exec_query_stats as eqs
	cross apply sys.dm_exec_sql_text ( eqs.plan_handle ) as st
where st.text like '%ja_SelectJobsForProcessing%'
and st.dbid = db_id ( 'CCS_AU_ProdTest_MEL_JobAutomation' )
order by eqs.creation_time desc


select st.*, dt.*
from
(
	select top 1000 *
	from sys.dm_exec_query_stats as eqs
	order by eqs.creation_time desc
) as dt
	cross apply sys.dm_exec_sql_text ( dt.plan_handle ) as st
where st.text like '%p_ESB_SearchPendingTransactionsByAccount%'
and st.dbid = db_id ( 'ESB_Dev2_CoreDB' )


select * from sys.dm_exec_sql_text ( 0x02000000b7d6352c1dc3fd002f2539f068f48f97f3558841 )

select eqp.query_plan, eqs.*
from sys.dm_exec_query_stats as eqs
	cross apply sys.dm_exec_query_plan ( eqs.plan_handle ) as eqp
where eqs.sql_handle in ( 0x0300D0007433B0373F961F0190A200000100000000000000 )
order by eqs.last_execution_time desc


select * from sys.dm_exec_query_stats as eqs
cross apply sys.dm_exec_query_plan ( eqs.plan_handle )
where eqs.sql_handle = 0x0200000070113b037d2991321a9deedb9c470fcc8c44da3d
--and eqs.statement_start_offset = 15298
--and eqs.statement_end_offset = 15888



use master

select * from sys.dm_exec_sql_text ( 0x02000000b7d6352c1dc3fd002f2539f068f48f97f3558841 )

select * from sys.dm_exec_query_stats as eqs
cross apply sys.dm_exec_query_plan ( eqs.plan_handle )
where eqs.sql_handle = 0x03005C008839117B4E20D600ACA100000100000000000000


select * from sys.dm_exec_query_stats as eqs
cross apply sys.dm_exec_query_plan ( eqs.plan_handle )
where eqs.sql_handle = 0x03005C008839117B4E20D600ACA100000100000000000000
--and eqs.statement_start_offset = 15298
--and eqs.statement_end_offset = 15888

select
	statement_text = substring
		(
			st.text
			,( eqs.statement_start_offset / 2 ) + 1
			,
			(
				(
					CASE eqs.statement_end_offset
						WHEN -1 THEN DATALENGTH(st.text)
						ELSE eqs.statement_end_offset
					END - eqs.statement_start_offset
				) / 2
			) + 1
		)
	,qp.query_plan
	,st.text
--	,*
from sys.dm_exec_query_stats as eqs
	cross apply sys.dm_exec_sql_text ( eqs.plan_handle ) as st
	cross apply sys.dm_exec_query_plan ( eqs.plan_handle ) as qp
where eqs.sql_handle = 0x03005C008839117B4E20D600ACA100000100000000000000
	and eqs.statement_start_offset = 1776
	and eqs.statement_end_offset = 3194


select
	statement_text = substring
		(
			st.text
			,( eqs.statement_start_offset / 2 ) + 1
			,
			(
				(
					CASE eqs.statement_end_offset
						WHEN -1 THEN DATALENGTH(st.text)
						ELSE eqs.statement_end_offset
					END - eqs.statement_start_offset
				) / 2
			) + 1
		)
	,*
from sys.dm_exec_query_stats as eqs
	cross apply sys.dm_exec_sql_text ( eqs.plan_handle ) as st
where eqs.sql_handle = 0x03005C008839117B4E20D600ACA100000100000000000000
	and eqs.statement_start_offset = 1776
	and eqs.statement_end_offset = 3194


select
	statement_text = substring
		(
			st.text
			,( eqs.statement_start_offset / 2 ) + 1
			,
			(
				(
					CASE eqs.statement_end_offset
						WHEN -1 THEN DATALENGTH(st.text)
						ELSE eqs.statement_end_offset
					END - eqs.statement_start_offset
				) / 2
			) + 1
		)
	,*
from sys.dm_exec_query_stats as eqs
	cross apply sys.dm_exec_sql_text ( eqs.plan_handle ) as st
	cross apply sys.dm_exec_query_plan ( eqs.plan_handle ) as qp
where eqs.sql_handle = 0x03000800dd931004c1a74b013ea000000100000000000000
	and eqs.statement_start_offset = 2232
	and eqs.statement_end_offset = 3004
