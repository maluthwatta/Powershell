select * from sys.dm_xe_sessions
select * from sys.dm_xe_session_events
select * from sys.dm_xe_session_event_actions 
select * from sys.dm_xe_packages 
select * from sys.dm_xe_session_event_actions