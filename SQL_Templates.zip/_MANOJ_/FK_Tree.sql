declare @parent_object sysname
set @parent_object = 'Control.ETLBatch'

select schema_name(schema_id), object_name(parent_object_id), name, *
from sys.foreign_keys 
where referenced_object_id = object_id(@parent_object)
order by schema_name(schema_id), object_name(parent_object_id)