
--This method works

SELECT
FileGroup = FILEGROUP_NAME(a.data_space_id), 
TableName = OBJECT_NAME(p.object_id), 
IndexName = i.name
FROM sys.allocation_units a
INNER JOIN sys.partitions p ON a.container_id = CASE WHEN a.type in(1,3) THEN p.hobt_id ELSE p.partition_id END AND p.object_id > 1024 
LEFT JOIN sys.indexes i ON i.object_id = p.object_id AND i.index_id = p.index_id
ORDER BY FileGroup




--1st Method
SELECT 
FileGroup = FILEGROUP_NAME(a.data_space_id), 
TableName = OBJECT_NAME(p.object_id), 
IndexName = i.name, *
FROM sys.allocation_units a
INNER JOIN sys.partitions p ON a.container_id = CASE WHEN a.type in(1,3) THEN p.hobt_id ELSE p.partition_id END AND p.object_id > 1024 
LEFT JOIN sys.indexes i ON i.object_id = p.object_id AND i.index_id = p.index_id
WHERE OBJECT_NAME(p.object_id) = 'BalanceActivity'
ORDER BY FileGroup
GO


--2nd Method
SELECT o.[name], o.[type], i.[name], i.[index_id], f.[name]
FROM sys.indexes i
INNER JOIN sys.filegroups f
ON i.data_space_id = f.data_space_id
INNER JOIN sys.all_objects o
ON i.[object_id] = o.[object_id]
WHERE i.data_space_id = 2 --* New FileGroup*
GO