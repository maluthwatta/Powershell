SELECT Name 
FROM sys.procedures 
WHERE OBJECT_DEFINITION(object_id) LIKE '%Data%' 