drop database GDE_Mittals1;
Go

create database GDE_Mittals1
on (name = GDE_Data, Filename = 'G:\INS1_DATA_01\SQLDATA\GDE\GDE_Mittals1_Data.MDF')
log on (name = GDE_Log, Filename = 'G:\INS1_LOG_01\SQLLOG\GDE\GDE_Mittals1_Log.LDF')
Go

use GDE_Mittals1;
Go

create user [OCEANIA\AU CT ALL COSMOS Investor Team];
Go

sp_addrolemember 'db_owner', [OCEANIA\AU CT ALL COSMOS Investor Team];
Go
