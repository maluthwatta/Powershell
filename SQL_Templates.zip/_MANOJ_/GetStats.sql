/*Returns size and fragmentation information for the data and indexes of the specified table or view.*/

Use master
Go
SELECT * FROM sys.dm_db_index_physical_stats
    (DB_ID(N'WEB_ContentProd51'), OBJECT_ID(N'dbo.C_Content'), NULL, NULL , 'DETAILED');
GO