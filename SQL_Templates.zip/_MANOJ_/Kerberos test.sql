  select net_transport, auth_scheme
  from sys.dm_exec_connections where session_id = @@spid