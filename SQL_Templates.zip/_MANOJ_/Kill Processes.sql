declare @txt varchar(max)
declare @db_name varchar(20)
select @db_name = 'CRM_TRN_2005'

select @txt = ''
select @txt =  @txt+ 'kill ' + cast (spid as varchar(3)) + char(13) from master..sysprocesses where dbid = db_id(@db_name)
print @txt

----------------------------

USE master;
GO
ALTER DATABASE AdventureWorks
SET SINGLE_USER
WITH ROLLBACK IMMEDIATE;
ALTER DATABASE AdventureWorks
SET MULTI_USER;
GO 