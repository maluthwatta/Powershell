--Create the cursor
declare mycursor cursor
for

-- Query for processes by login and database
select spid, Loginame
from master..sysProcesses
where Loginame='someuser' and dbid=db_id('somedb')


open mycursor

declare @spid int, @loginame varchar(255), @cmd varchar(255)

-- Loop through the cursor, killing each process
Fetch NEXT FROM MYCursor INTO @spid, @loginame
While (@@FETCH_STATUS <> -1)
begin
    -- I don't really know why this is necasary, but it is.
    select @cmd = 'kill ' + cast(@spid as varchar(5))
    exec(@cmd)

    Fetch NEXT FROM MYCursor INTO @spid, @loginame
end

close mycursor
deallocate mycursor
go