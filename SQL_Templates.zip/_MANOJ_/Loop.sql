declare @i int, @sql varchar(200)
select @i = 8
while @i <= 49
begin
	set @sql = 'dbcc shrinkfile(' +  cast (@i as varchar(10)) + ')'
	print(@sql)
	set @i = @i + 1
end