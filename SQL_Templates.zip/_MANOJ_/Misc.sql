/* Replace a newline in TSQL */
DECLARE @str VARCHAR(100)
SELECT REPLACE(REPLACE(@str, CHAR(13), ''), CHAR(10), '')