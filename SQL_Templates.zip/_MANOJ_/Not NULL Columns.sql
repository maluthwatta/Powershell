select t.name, c.name, c.is_nullable
from sys.columns c inner join sys.tables t on t.object_id = c.object_id
where c.is_nullable = 0 and t.name not in ('AA_ApplicationAttributes', 'AA_UpgradeLog', 'AA_ApplicationSignature' ) 
order by t.name, c.name