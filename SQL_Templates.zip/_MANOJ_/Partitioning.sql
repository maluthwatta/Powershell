--to get partition boundaries
select pf.name, * from sys.partition_range_values prv inner join sys.partition_functions pf
	on pf.function_id = prv.function_id
	
--to get the partition to which the data gets inserted
SELECT $PARTITION.pf_ETL_BalanceActivity(20110422) [PARTITION NUMBER]	

-- to find out what pf is being used by a ps
select ps.name as 'partition_schema', pf.name as 'partition_function', * 
from sys.partition_schemes ps 
inner join sys.partition_functions pf on pf.function_id = ps.function_id

-- to find out what file group is being used
select ds.name , dds.destination_id as 'pf boundary id' , ds2.name as 'FG' ,* 
from sys.destination_data_spaces dds
inner join sys.data_spaces ds on ds.data_space_id = dds.partition_scheme_id
inner join sys.data_spaces ds2 on ds2.data_space_id = dds.data_space_id

-- to find out the data type of the partition key
select pf.name, t.name, *
from sys.partition_functions pf 
	inner join sys.partition_parameters pp on pp.function_id = pf.function_id
	inner join sys.types t on t.system_type_id = pp.system_type_id

--Partition function values associated to each file group
select distinct ps.Name AS PartitionScheme, pf.name AS PartitionFunction,fg.name AS FileGroupName, rv.value AS PartitionFunctionValue
    from sys.indexes i  
    join sys.partitions p ON i.object_id=p.object_id AND i.index_id=p.index_id  
    join sys.partition_schemes ps on ps.data_space_id = i.data_space_id  
    join sys.partition_functions pf on pf.function_id = ps.function_id  
    left join sys.partition_range_values rv on rv.function_id = pf.function_id AND rv.boundary_id = p.partition_number
    join sys.allocation_units au  ON au.container_id = p.hobt_id   
    join sys.filegroups fg  ON fg.data_space_id = au.data_space_id  
where i.object_id = object_id('SystemTransactions') 


------------------------------------------


--- Partition boundaries...
WITH spc (data_space_id, function_id, boundary_id,
          boundary_value_on_right, boundary_value)
AS (    SELECT ps.data_space_id,
            val.function_id,
            val.boundary_id,
            pf.boundary_value_on_right,
            (CASE SQL_VARIANT_PROPERTY(val.[value], 'BaseType')
                WHEN 'date' THEN
                    '{d '''+LEFT(CONVERT(varchar(max), val.[value], 120), 10)+'''}'
                WHEN 'datetime' THEN
                    '{ts '''+CONVERT(varchar(max), val.[value], 120)+'''}'
                ELSE CAST(val.[value] AS varchar(max))
             END) AS boundary_value
    FROM sys.partition_range_values AS val
    INNER JOIN sys.partition_functions AS pf ON
        val.function_id = pf.function_id
    INNER JOIN sys.partition_schemes AS ps ON
        pf.function_id=ps.function_id),

--- Ranges, i.e. lower and upper bounds of a partition:
     rng (function_id, data_space_id, boundary_id, lower_rng, upper_rng)
AS (    SELECT ISNULL(a.function_id, b.function_id),
            ISNULL(a.data_space_id, b.data_space_id),
            ISNULL(a.boundary_id+1, b.boundary_id),
            a.boundary_value+(CASE
                WHEN a.boundary_value_on_right=1 THEN '<='
                WHEN a.boundary_value_on_right=0 THEN '<'
             END) AS lower_rng,
            (CASE
                WHEN b.boundary_value_on_right=1 THEN '<'+b.boundary_value
                WHEN b.boundary_value_on_right=0 THEN '<='+b.boundary_value
             END) AS upper_rng
    FROM spc AS a
    FULL JOIN spc AS b ON
        a.function_id=b.function_id AND
        a.boundary_id+1=b.boundary_id)

--- ... joined with sys.indexes and sys.tables:
SELECT p.[object_id],
    SCHEMA_NAME(t.[schema_id])+'.'+t.[name] AS [object_name],
    ix.index_id,
    ix.[name] AS index_name,
    pf.[name] AS pf_name,
    rng.boundary_id,
    ISNULL(rng.lower_rng, '')+'key'+ISNULL(rng.upper_rng, '') AS boundary,
    p.[rows],
    p.data_compression_desc
FROM rng
INNER JOIN sys.partition_functions AS pf ON
    rng.function_id = pf.function_id
INNER JOIN sys.indexes AS ix ON
    ix.data_space_id=rng.data_space_id
LEFT JOIN sys.tables AS t ON
    ix.[object_id]=t.[object_id]
LEFT JOIN sys.partitions AS p ON
    ix.[object_id]=p.[object_id] AND
    ix.index_id=p.index_id AND
    rng.boundary_id=p.partition_number
ORDER BY t.[schema_id], t.[name], p.index_id, rng.boundary_id;