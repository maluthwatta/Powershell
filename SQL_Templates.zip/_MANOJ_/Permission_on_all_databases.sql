Use master
GO

DECLARE @dbname VARCHAR(50)   
DECLARE @statement NVARCHAR(max)

DECLARE @login NVARCHAR(200) = 'Oceania\!ALL GD SEC Architecture Team'
DECLARE @role NVARCHAR(100) = 'db_datareader'


DECLARE db_cursor CURSOR 
LOCAL FAST_FORWARD
FOR  
SELECT name
FROM MASTER.dbo.sysdatabases
WHERE name NOT IN ('master','model','msdb','tempdb','distribution', 'zDBA')  
OPEN db_cursor  
	FETCH NEXT FROM db_cursor INTO @dbname  
	WHILE @@FETCH_STATUS = 0  
	BEGIN  

		SELECT @statement = 'use '+@dbname +';'+ 'CREATE USER ['+@login+'] 
		FOR LOGIN ['+@login+']; EXEC sp_addrolemember N'''+@role+''', 
		['+@login+'];'

		print @statement
		exec sp_executesql @statement		

		FETCH NEXT FROM db_cursor INTO @dbname  
	END  
CLOSE db_cursor  
DEALLOCATE db_cursor 