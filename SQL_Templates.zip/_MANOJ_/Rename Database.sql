sp_helpdb BICR_UK_SysTest_Regression



--Change the DB Name
ALTER DATABASE BICR_UK_SysTest_Regression
Modify Name = BICR_UK_SysTest_Regression_Testing ;


--Disconnect all existing session.
ALTER DATABASE BICR_UK_SysTest_Regression_Testing SET SINGLE_USER WITH ROLLBACK IMMEDIATE
GO
--Change database in to OFFLINE mode.
ALTER DATABASE BICR_UK_SysTest_Regression_Testing SET OFFLINE


ALTER DATABASE BICR_UK_SysTest_Regression_Testing MODIFY FILE (Name='BICR_Primary', FILENAME='G:\SQLData\BICR_UK_SysTest_Regression_Testing_1__Data2D00F792.MDF')
GO
ALTER DATABASE BICR_UK_SysTest_Regression_Testing MODIFY FILE (Name='BICR_Log', FILENAME='H:\SQLLog\BICR_UK_SysTest_Regression_Testing_3__Log2D00F792.LDF')
GO
ALTER DATABASE BICR_UK_SysTest_Regression_Testing MODIFY FILE (Name='BICR_Data', FILENAME='G:\SQLData\BICR_UK_SysTest_Regression_Testing_2__Data2D00F792.MDF')
GO


--Change database in to ONLINE mode.
ALTER DATABASE BICR_UK_SysTest_Regression_Testing SET ONLINE

