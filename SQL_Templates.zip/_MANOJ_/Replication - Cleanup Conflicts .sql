
SELECT s.conflict_table, c.rowguid, c.origin_datasource
      INTO #temp_conflicts
      FROM dbo.MSmerge_conflicts_info c
      JOIN sysmergearticles s
      ON c.tablenick = s.nickname

 

--Setup local variables
DECLARE @conflict_table nvarchar(255)
DECLARE @row uniqueidentifier
DECLARE @origin_datasource nvarchar(255)

--Step through conflicts and purge by RowGuid
DECLARE conflict_cursor CURSOR FOR
   SELECT conflict_table, rowguid, origin_datasource
   FROM #temp_conflicts
OPEN conflict_cursor;

FETCH NEXT FROM conflict_cursor INTO @conflict_table, @row, @origin_datasource;

WHILE @@FETCH_STATUS = 0

BEGIN
     --Purge conflict as "resolved"
    EXEC sp_deletemergeconflictrow
      @conflict_table = @conflict_table,        -- conflict table name from sysmergearticles
      @rowguid = @row,                                      -- row identifier from msmerge_conflicts_info
      @origin_datasource = @origin_datasource   -- origin of the conflict from msmerge_conflicts_info
   --Retrieve next conflict to purge

   FETCH NEXT FROM conflict_cursor
   INTO @conflict_table, @row, @origin_datasource;
END
 

CLOSE conflict_cursor;
DEALLOCATE conflict_cursor;
DROP table #temp_conflicts