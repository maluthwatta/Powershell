--Clear the entries in these tables to remove them from replication monitor

select * from distribution.[dbo].[MSpublications]
select * from distribution.[dbo].[MSreplication_monitordata]
select * from distribution.[dbo].[MSsnapshot_agents]