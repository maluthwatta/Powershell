select x.*,y.*   
from MSmerge_conflicts_info x   
inner join dbo.MSmerge_conflict_CC_MERGE_SIT_NONEMASTER_SiebelAccounts y   
    on x.rowguid = y.rcguid   
    
select 'delete from dbo.SiebelAccounts where SiebelCompanyCode = ''' + y.SiebelCompanyCode + ''''
from MSmerge_conflicts_info x   
inner join dbo.MSmerge_conflict_CC_MERGE_SIT_NONEMASTER_SiebelAccounts y   
    on x.rowguid = y.rcguid     

select 'delete from dbo.SiebelAccountAlerts where SiebelCompanyCode = ''' + y.SiebelCompanyCode + ''''
from MSmerge_conflicts_info x   
inner join dbo.MSmerge_conflict_CC_MERGE_SIT_NONEMASTER_SiebelAccounts y   
    on x.rowguid = y.rcguid     
