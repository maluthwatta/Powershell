USE [SMART_AU_NonProd]
GO


--to get all the SQL Instances
select�*�from�dbo.ComponentType t�
�������left�join�dbo.component c�on�t.componenttypeid�=�c.componenttypeid�
where�t.componenttypename�like�'SQLInstance%'�
order�by�t.componenttypename 

--all active instances
select * from rep.SQLInstance

--all databases
select * from rep.SQLDatabase


--database files
SELECT * FROM rep.SQLDatabaseFile dbf INNER JOIN
	rep.SQLDatabase db on db.ComponentID = dbf.ParentComponentID INNER JOIN
	rep.SQLInstance ins on ins.ComponentID = db.ParentComponentID
WHERE db.ComponentName = 'DW_CI_UAT'

