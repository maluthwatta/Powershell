--Kill Processes
ALTER DATABASE <DB>
SET SINGLE_USER
WITH ROLLBACK IMMEDIATE;
ALTER DATABASE <DB>
SET MULTI_USER;
GO 

---Restore
exec zDBA..p_DBA_RestoreDB @DB_Name = ''
     , @Backup_Path = ''   
     , @debug_flag = 1 

