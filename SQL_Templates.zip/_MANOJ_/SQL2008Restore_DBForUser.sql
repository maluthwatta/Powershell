exec zDBA..p_DBA_RestoreDB_ForUser @DBName = 'DW_Master'
      , @filename1 = '\\Melysqlbkup1\devdumps\DW\DW_Master_20101022.cBAK'
      , @debug = 1 -- value = 1 will generate the restore statement for you to customize if required. Default = 0
      , @force_restore = 1 -- Default is 1 (kill existing connections on the database)
