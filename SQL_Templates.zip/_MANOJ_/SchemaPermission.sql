SELECT SCHEMA_NAME(major_id) [Schema]
    , USER_NAME(grantee_principal_id) [Login]
    , permission_name [Permission]
    , state_desc [State]
    --, *
FROM sys.database_permissions
WHERE class_desc = 'SCHEMA'
ORDER BY major_id, grantee_principal_id, permission_name