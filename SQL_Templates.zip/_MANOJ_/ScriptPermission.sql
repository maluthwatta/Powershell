SET NOCOUNT ON
declare @dbname varchar(30)
declare @sql varchar(4000)
declare @sql1 varchar(4000)
declare @sql2 varchar(4000)
set @dbname = db_name()

select @sql2 = 'alter database '+ @dbname + ' set recovery Simple'
Print @sql2

Print 'Use ' + @dbname + ';' 

Print '/*Granting Database Permissions if Any:*/'
select 'create user ['+ name + '];'
from sysusers
where islogin= 1
and name not in ('dbo', 'guest', 'INFORMATION_SCHEMA', 'sys')
Print 'go'; 


Print '/*Granting Role Permissions if Any:*/'
set @sql1 ='select ''sp_addrolemember ''+ b.name + '', ['' + a.name + ''];
go'' from '+ @dbname+'..sysusers a,'
+@dbname+'..sysusers b, '+ @dbname+'..sysmembers c,master..sysdatabases s
where a.uid = c.memberuid and c.groupuid = b.uid and s.name like ''' +@dbname +''' and a.name <> ''dbo'''
exec(@sql1)
create table #DBUSERS (DBNAME varchar(50),USERNAME varchar(50), MEMBERNAME varchar(50), OBJECTNAME varchar(100), PERMGRANTED varchar(200), PERMDENIED varchar(50),COLUMNPERM varchar(10))
set @sql ='insert into #DBUSERS (DBNAME,USERNAME,OBJECTNAME,PERMGRANTED,PERMDENIED,COLUMNPERM)
select s.name,a.name,c.name,b.actadd,b.actmod,case when (b.seladd is not null or b.selmod is not null or b.updadd is not null or b.updmod is not null or b.refadd is not null or b.refmod is not null) then ''Y'' else ''N'' end
from '+@dbname+'..sysusers a,'+@dbname+'..syspermissions b,'+@dbname+'..sysobjects c,master..sysdatabases s
where a.uid = b.grantee and b.[id] = c.[id] and b.grantee <> 0 and s.name like '''+@dbname+''''
exec(@sql)
Print '/*Granting Object Permissions if Any:*/'
select 'grant '+case PERMGRANTED when 1 then 'SELECT'
when 2 then 'UPDATE'
when 3 then 'SELECT,UPDATE'
when 4 then 'REFERENCES'
when 5 then 'SELECT, REFERENCES'
when 6 then 'UPDATE,REFERENCES'
when 7 then 'SELECT,UPDATE,REFERENCES'
when 8 then 'INSERT'
when 9 then 'SELECT,INSERT'
when 10 then 'UPDATE,INSERT'
when 11 then 'SELECT,UPDATE,INSERT'
when 12 then 'REFERENCES,INSERT'
when 13 then 'SELECT,REFERENCES,INSERT'
when 14 then 'UPDATE,REFERENCES,INSERT'
when 15 then 'SELECT,UPDATE,REFERENCES,INSERT'
when 16 then 'DELETE'
when 17 then 'SELECT,DELETE'
when 18 then 'UPDATE,DELETE'
when 19 then 'SELECT,UPDATE,DELETE'
when 20 then 'REFERENCES,DELETE'
when 21 then 'SELECT,REFERENCES,DELETE'
when 22 then 'UPDATE,REFERENCES,DELETE'
when 23 then 'SELECT,UPDATE,REFERENCES,DELETE'
when 24 then 'INSERT,DELETE'
when 25 then 'SELECT,INSERT,DELETE'
when 26 then 'UPDATE,INSERT,DELETE'
when 27 then 'SELECT,UPDATE,INSERT,DELETE'
when 28 then 'REFERENCES,INSERT,DELETE'
when 29 then 'SELECT,REFERENCES,INSERT,DELETE'
when 30 then 'REFERENCES,INSERT,DELETE'
when 31 then 'SELECT,UPDATE,REFERENCES,INSERT,DELETE'
when 32 then 'EXECUTE' else NULL end+' on '+OBJECTNAME+' to ['+USERNAME + ']'
from #DBUSERS where PERMGRANTED <> 0
Print '/*Revoking Object Permissions if Any:*/'
select 'revoke '+case PERMDENIED when 1 then 'SELECT'
when 2 then 'UPDATE'
when 3 then 'SELECT,UPDATE'
when 4 then 'REFERENCES'
when 5 then 'SELECT, REFERENCES'
when 6 then 'UPDATE,REFERENCES'
when 7 then 'SELECT,UPDATE,REFERENCES'
when 8 then 'INSERT'
when 9 then 'SELECT,INSERT'
when 10 then 'UPDATE,INSERT'
when 11 then 'SELECT,UPDATE,INSERT'
when 12 then 'REFERENCES,INSERT'
when 13 then 'SELECT,REFERENCES,INSERT'
when 14 then 'UPDATE,REFERENCES,INSERT'
when 15 then 'SELECT,UPDATE,REFERENCES,INSERT'
when 16 then 'DELETE'
when 17 then 'SELECT,DELETE'
when 18 then 'UPDATE,DELETE'
when 19 then 'SELECT,UPDATE,DELETE'
when 20 then 'REFERENCES,DELETE'
when 21 then 'SELECT,REFERENCES,DELETE'
when 22 then 'UPDATE,REFERENCES,DELETE'
when 23 then 'SELECT,UPDATE,REFERENCES,DELETE'
when 24 then 'INSERT,DELETE'
when 25 then 'SELECT,INSERT,DELETE'
when 26 then 'UPDATE,INSERT,DELETE'
when 27 then 'SELECT,UPDATE,INSERT,DELETE'
when 28 then 'REFERENCES,INSERT,DELETE'
when 29 then 'SELECT,REFERENCES,INSERT,DELETE'
when 30 then 'REFERENCES,INSERT,DELETE'
when 31 then 'SELECT,UPDATE,REFERENCES,INSERT,DELETE'
when 32 then 'EXECUTE' else NULL end+' on '+OBJECTNAME+' to '+USERNAME 
from #dbusers where PERMDENIED <> 0
drop table #DBUSERS