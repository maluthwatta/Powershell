SELECT l.name as grantee_name, p.state_desc, p.permission_name 
FROM sys.server_permissions AS p JOIN sys.server_principals AS l ON
p.grantee_principal_id = l.principal_id
WHERE permission_name = 'VIEW Server State' ;