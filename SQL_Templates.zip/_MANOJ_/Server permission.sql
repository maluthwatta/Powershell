SELECT pr.principal_id, 
	   pr.name, pr.type_desc,   
       pe.state_desc, 
	   pe.permission_name   
FROM sys.server_principals AS pr   
JOIN sys.server_permissions AS pe 
	ON pe.grantee_principal_id = pr.principal_id