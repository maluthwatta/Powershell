select rp.Name as 'Role_Principal', mp.Name as 'Member_Principal'
from sys.server_role_members rm
inner join sys.server_principals rp 
	on rm.role_principal_id = rp.principal_id
inner join sys.server_principals mp
	on mp.principal_id = rm.member_principal_id
order by rp.Name
--order by mp.Name