exec sp_msforeachdb '

print ''?''

DBCC SHRINKDATABASE (?, 10, TRUNCATEONLY)

'
