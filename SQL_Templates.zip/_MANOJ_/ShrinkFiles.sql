
SELECT 'DBCC SHRINKFILE (N''' + mf.name + N''')' as sql_shrink
INTO #tmpShrinkScript
FROM sys.master_files mf 
    JOIN sys.databases d 
        ON mf.database_id = d.database_id 
WHERE d.database_id = db_id()


DECLARE @shrink_sql nvarchar(200)

DECLARE sql_cursor CURSOR  
    FOR SELECT sql_shrink FROM #tmpShrinkScript
OPEN sql_cursor  
FETCH NEXT FROM sql_cursor into @shrink_sql;  

WHILE @@FETCH_STATUS = 0  
BEGIN  
	print  @shrink_sql;
	BEGIN TRY
		EXECUTE sp_executesql @shrink_sql
	END TRY
	BEGIN CATCH
	    SELECT   
        ERROR_NUMBER() AS ErrorNumber  
       ,ERROR_MESSAGE() AS ErrorMessage;  	
	END CATCH
	FETCH NEXT FROM sql_cursor into @shrink_sql;  
END

CLOSE sql_cursor;  
DEALLOCATE sql_cursor;  
DROP TABLE #tmpShrinkScript