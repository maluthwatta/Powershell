--Create the SnapShot SQL
SELECT 
	'( NAME = ' + name + ', FILENAME = ''' + REVERSE(RIGHT(REVERSE(physical_name),(LEN(physical_name)-CHARINDEX('\', REVERSE(physical_name),1))+1)) + name + '_' + CONVERT(VARCHAR(8), GETDATE(), 112) + '.SS''' + '),'
FROM master.sys.master_files
WHERE database_id = db_id('CI_INVTEST')
and type_desc = 'ROWS'



/*
SYNTAX:

CREATE DATABASE CI_UK_UAT_WEB_TSC_UAT_20150220_SS ON
( NAME = CI_Data_1, FILENAME = 'H:\Data_01\SQLData\CI_Data_1_20150220.SS'),
............
( NAME = CISTAStage_2, FILENAME = 'H:\Data_01\SQLData\CISTAStage_2_20150220.SS')
AS SNAPSHOT OF CI_UK_UAT_WEB_TSC_UAT
GO

*/


/*
RESTORE DATABASE [CI_INVTEST] from 
DATABASE_SNAPSHOT = 'CI_INVTEST_20151013_SS';
*/