--Method 0 ##Recommended

select
       s.name
       ,o.name
       ,row_count
       ,reserved_page_count_kbytes = sum(reserved_page_count) * 8 -- *** VolReserved
       ,data_kbytes = sum(case when ps.index_id in (0, 1) then in_row_data_page_count + lob_used_page_count + row_overflow_used_page_count else 0 end) * 8
       ,index_kbytes = (sum(reserved_page_count - case when ps.index_id in (0, 1) then in_row_data_page_count + lob_used_page_count + row_overflow_used_page_count else 0 end - (reserved_page_count - used_page_count))) * 8
       ,used_page_count_kbytes = sum(used_page_count) * 8
       ,unused_page_count_kbytes = sum(reserved_page_count - used_page_count) * 8
       ,in_row_data_page_count_kbytes = sum(in_row_data_page_count) * 8
       ,in_row_used_page_count_kbytes = sum(in_row_used_page_count) * 8
       ,in_row_reserved_page_count_kbytes = sum(in_row_reserved_page_count) * 8
       ,lob_used_page_count_kbytes = sum(lob_used_page_count) * 8
       ,lob_reserved_page_count_kbytes = sum(lob_reserved_page_count) * 8
       ,row_overflow_used_page_count_kbytes = sum(row_overflow_used_page_count) * 8
       ,row_overflow_reserved_page_count_kbytes = sum(row_overflow_reserved_page_count) * 8
from sys.dm_db_partition_stats as ps
       inner join sys.objects as o
              on o.object_id = ps.object_id
       inner join sys.schemas as s
              on s.schema_id = o.schema_id
where o.type <> 'S'
group by s.name, o.name, ps.row_count
order by sum(reserved_page_count) * 8 desc

-----------------------------------------------------------------------------


-- Method 1

select o.name
, sum(i.rows) as rows
, sum(case when indid < 2 then i.dpages
when indid=255 then i.used
else 0 end) as allpages
from sysobjects o
join sysindexes i on o.id = i.id
where (indid < 2 or indid = 255)
and o.name not like 'sys%'
group by o.name, indid
order by rows desc 



-- Method 2

select sysTableTemp.UsersName + '.' + sysTableTemp.ObjectsName as CompleteName, sysTableTemp.IndexName, sysTableTemp.rows, case when sysTableTemp.indid  =  1 Then 1 Else 0 End as IsClusteredIndex, (case when sysTableTemp.indid > 1 and sysTableTemp.indid <> 255 Then pageTableTemp.PageSize * sysTableTemp.NonClusteredDataUsed end) as NonClusteredDataUsed, (pageTableTemp.PageSize * (isnull(sysTableTemp.AllData, 0))) As DataSizeUsed, ( case when sysTableTemp.indid  =  1 Then pageTableTemp.PageSize * (isnull(sysTableTemp.IndexSizeUsed, 0)- isnull(sysTableTemp.DataSizeUsed, 0)) end) AS ClustedDataUsed 
into #temp
from  ( select  v.low / 1024 as PageSize from    master..spt_values v  where   v.number=1 and v.type=N'E' ) as pageTableTemp, ( select  sysindexes.indid, sysindexes.name as IndexName,  sysobjects.name as ObjectsName, sysusers.name as UsersName, sysindexes.used as NonClusteredDataUsed, tempTable.DataSizeUsed, tempTable.IndexSizeUsed, tempTable.rows, tempTable.AllData from   sysindexes, sysobjects, sysusers, ( select  id, sum(case indid when 0   then sysindexes.dpages when 1   then sysindexes.dpages when 255 then isnull(sysindexes.used, 0) end) as DataSizeUsed, sum(case indid  when 0 then isnull(sysindexes.used, 0) when 1 then isnull(sysindexes.used, 0) when 255 then isnull(sysindexes.used, 0) end) as IndexSizeUsed, sum(case indid when 0 then convert(int, rows) when 1 then convert(int, rows) end) as rows, sum(case     when indid <= 0 then sysindexes.dpages + isnull(sysindexes.used, 0)     else isnull(sysindexes.used, 0) end) as AllData from   sysindexes group by sysindexes.id ) as tempTable where  sysindexes.id = sysobjects.id and sysusers.uid = sysobjects.uid and tempTable.id = sysindexes.id and sysobjects.name not like '#%'  and OBJECTPROPERTY(sysobjects.id, N'IsMSShipped') <> 1 and OBJECTPROPERTY(sysobjects.id, N'IsSystemTable') = 0 ) as sysTableTemp 
where sysTableTemp.ObjectsName like N'%' 
order by CompleteName, IsClusteredIndex DESC

Select CompleteName
--, IndexName
, max([rows]) as tot_rows
--, IsClusteredIndex
, convert(decimal(12,2),convert(decimal(12,2),sum(isnull(NonClusteredDataUsed,0)))/1024) as totNonClusteredDataUsed
, convert(decimal(12,2),convert(decimal(12,2),avg(DataSizeUsed))/1024) as DataSizeUsed
, convert(decimal(12,2),convert(decimal(12,2),sum(isnull(ClustedDataUsed ,0)))/1024) as totClustedDataUsed
from #temp
group by CompleteName
--order by max([rows]) desc
order by DataSizeUsed desc


select sum(a.DataSizeUsed) as TOT_DataSizeUsed
from  (
Select CompleteName
--, IndexName
, max([rows]) as tot_rows
--, IsClusteredIndex
, convert(decimal(12,2),convert(decimal(12,2),sum(isnull(NonClusteredDataUsed,0)))/1024) as totNonClusteredDataUsed
, convert(decimal(12,2),convert(decimal(12,2),avg(DataSizeUsed))/1024) as DataSizeUsed
, convert(decimal(12,2),convert(decimal(12,2),sum(isnull(ClustedDataUsed ,0)))/1024) as totClustedDataUsed
from #temp
group by CompleteName
--order by DataSizeUsed desc
) a

drop table #temp