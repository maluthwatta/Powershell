



SELECT 
	 tdt.database_transaction_begin_time
	,tdt.database_transaction_log_bytes_reserved
	,tst.session_id
	,sp.spid
	,sp.dbid
	,sp.blocked
	,sp.hostname
	,sp.program_name
	,sp.cmd
	,sp.nt_domain
	,sp.nt_username
FROM sys.dm_tran_database_transactions AS tdt
INNER JOIN sys.dm_tran_session_transactions AS tst
	ON	tdt.transaction_id = tst.transaction_id
INNER JOIN master.dbo.sysprocesses AS sp
	ON  sp.spid = tst.session_id 
WHERE database_id = 2		--Session hitting tempdb's Transaction Log
ORDER BY 
	database_transaction_log_bytes_reserved DESC;

-----------------------------------------------------------------------------------
-- PAUL S - So this query told me which sessions were consuming the tempdb log�
SELECT database_transaction_log_bytes_reserved,session_id 
  FROM sys.dm_tran_database_transactions AS tdt 
  INNER JOIN sys.dm_tran_session_transactions AS tst 
  ON tdt.transaction_id = tst.transaction_id 
  WHERE database_id = 2
 order by database_transaction_log_bytes_reserved desc;


-----------------------------------------------------------------------------------
select log_reuse_wait_desc,
* from sys.databases

zdba..p_dba_helpdb tempdb

select * from master..sysprocesses 
where open_tran>0

dbcc opentran

-----------------------------------------------

SELECT transaction_id
FROM sys.dm_tran_active_snapshot_database_transactions 
ORDER BY elapsed_time_seconds DESC;

---------------------------------------------------

SELECT name 
, db.log_reuse_wait_desc 
, ls.cntr_value  AS size_kb 
, lu.cntr_value AS used_kb 
, CAST(lu.cntr_value AS FLOAT) / CAST(ls.cntr_value AS FLOAT)  
  AS used_percent 
, CASE WHEN CAST(lu.cntr_value AS FLOAT) / CAST(ls.cntr_value AS FLOAT) > .5 THEN 
   CASE 
    /* tempdb special monitoring */ 
    WHEN db.name = 'tempdb'  
     AND log_reuse_wait_desc NOT IN ('CHECKPOINT', 'NOTHING') THEN 'WARNING'  
    /* all other databases, monitor foor the 50% fill case */ 
    WHEN db.name <> 'tempdb' THEN 'WARNING' 
    ELSE 'OK' 
    END 
  ELSE 'OK' END 
  AS log_status 
FROM sys.databases db 
JOIN sys.dm_os_performance_counters lu 
 ON db.name = lu.instance_name 
JOIN sys.dm_os_performance_counters ls 
 ON db.name = ls.instance_name 
WHERE lu.counter_name LIKE  'Log File(s) Used Size (KB)%' 
AND ls.counter_name LIKE 'Log File(s) Size (KB)%' 


--------------------------------------
use tempdb
Go

SELECT SUM(unallocated_extent_page_count) AS [free pages], 
(SUM(unallocated_extent_page_count)*1.0/128) AS [free space in MB]
FROM sys.dm_db_file_space_usage;
