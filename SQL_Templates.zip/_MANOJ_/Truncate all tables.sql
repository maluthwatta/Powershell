--disable all the triggers
EXEC sp_msforeachtable 'ALTER TABLE ? DISABLE TRIGGER all';
GO

-- disable referential integrity
EXEC sp_MSForEachTable 'ALTER TABLE ? NOCHECK CONSTRAINT ALL' 
GO 

EXEC sp_MSForEachTable 'DELETE FROM ?' 
GO 

-- enable referential integrity again 
EXEC sp_MSForEachTable 'ALTER TABLE ? WITH CHECK CHECK CONSTRAINT ALL' 
GO

-- reset all the identity columns back to 0
EXEC sp_MSForEachTable 'DBCC CHECKIDENT(''?'', RESEED, 0)'


-- enable all the triggers
EXEC sp_msforeachtable 'ALTER TABLE ? ENABLE TRIGGER all'