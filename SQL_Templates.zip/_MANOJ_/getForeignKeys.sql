select sch.name + '.' + oprnt.name as [base_table], colprnt.name as [parent_column], fk.name as [FK]
	,scref.name + '.' + oref.name as [referenced_table], colref.name as [referenced_column]
from sys.foreign_keys fk 
	inner join sys.objects oprnt on oprnt.object_id = fk.parent_object_id 
	inner join sys.schemas sch on sch. schema_id = oprnt.schema_id 
	inner join sys.objects oref on oref.object_id = fk.referenced_object_id 
	inner join sys.schemas scref on scref.schema_id = oref.schema_id
	inner join sys.foreign_key_columns fcc on fcc.parent_object_id = oprnt.object_id and fcc.constraint_object_id = fk.object_id
	inner join sys.columns colprnt on colprnt.object_id = oprnt.object_id and colprnt.column_id = fcc.parent_column_id
	inner join sys.columns colref on colref.object_id = oref.object_id and colref.column_id = fcc.referenced_column_id 
where sch.name = 'Production' and oprnt.name = 'Product'
order by oprnt.name