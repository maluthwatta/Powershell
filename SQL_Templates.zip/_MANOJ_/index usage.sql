
--returns all indexes for a database and their stats.
--Rows with no usage since the last restart will be null 

select object_schema_name(indexes.object_id) + '.' + object_name(indexes.object_id) as objectName,
         indexes.name, case when is_unique = 1 then 'UNIQUE ' else '' end + indexes.type_desc, 
         ddius.user_seeks, ddius.user_scans, ddius.user_lookups, ddius.user_updates
from sys.indexes
               left outer join sys.dm_db_index_usage_stats ddius
                        on indexes.object_id = ddius.object_id
                             and indexes.index_id = ddius.index_id
                             and ddius.database_id = db_id()
order by ddius.user_seeks + ddius.user_scans + ddius.user_lookups desc